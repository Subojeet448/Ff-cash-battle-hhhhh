# FF Cash Battle — native Android app (Kotlin + Jetpack Compose)

The whole website UI (tournament-ff-cash-battle) rebuilt as a **real native Android app**. No Capacitor, no website wrapper:
every screen, sheet, card and animation is Kotlin / Jetpack Compose. Same Firebase project as the website
(`tournament-e8da7`), so accounts, wallet, matches, notifications and chat are shared with ffcashbattle.in.

* package `com.ffcashbattle.app`, applicationId `in.ffcashbattle.app`
* Kotlin 2.1.20 · Compose BOM 2025.05.01 · AGP 8.9.2 · Gradle 8.14.3 · compileSdk/targetSdk 35 · minSdk 24 · JDK 17

## Build
1. Install Android Studio (Ladybug or newer, JDK 17). **File → Open** this folder, let Gradle sync.
2. Run on a phone/emulator (`app` configuration), or **Build → Generate Signed App Bundle / APK** for release.

### Settings to check before release
| What | Where | Note |
|---|---|---|
| Firebase Android app | Firebase console → project `tournament-e8da7` → add Android app `in.ffcashbattle.app` (+ your SHA-1 / SHA-256) → download `google-services.json` into `app/` | Needed for Google sign-in and push. If the website's API key is restricted to "HTTP referrers", Android calls are refused: use the key from `google-services.json` or loosen the restriction. |
| Google sign-in | `app/build.gradle.kts` → `GOOGLE_WEB_CLIENT_ID` | Paste the **Web client ID** (Firebase → Authentication → Sign-in method → Google → Web SDK configuration). Empty = the Google button shows a message. |
| Site / proof link | `SITE_URL` in `app/build.gradle.kts`, `data/Cfg.kt` | `https://ffcashbattle.in` (Proof = `/proof`, Terms = `/terms`). |
| Game server | `data/Cfg.kt` → `GAME_SERVER`, `GAME_API` | Same Render admin panel the website uses. |
| Separate chat project | `data/Cfg.kt` → `CHAT_TOKEN_URL` | Empty = chat runs in the main project (exactly like the website today). |
| Reset-password links | Firebase console → Authentication → Templates → action URL = `https://ffcashbattle.in/...` | The app opens `ffcashbattle.in` links itself (intent filter in the manifest). |

## Website → app map
| Website | App |
|---|---|
| Header, drawer, bottom nav, FAQ chips | `ui/shell/*`, `ui/screens/FaqLayer.kt` |
| Home, Matches (+ my matches), Rank, Wallet | `ui/screens/*Page.kt`, `ui/screens/match/*`, `ui/screens/wallet/*` |
| Join, Roster, Deposit, Withdraw (+success), Transfer, Gift, Refer + scratch card | `ui/modals/*` |
| Settings (Security & Payment, **Proofs → ffcashbattle.in/proof**, Terms, **website link**), Sound, Notice, Rules, Edit profile, Logout | `ui/modals/*` |
| Notification bell, message cards, balance cards, wallet FX (same sizes) | `ui/modals/NotificationsModal.kt`, `ui/comp/Notify.kt`, `state/AppStore.kt` |
| Login / sign-up / OTP / forgot password, welcome, ban screen, session overlay | `ui/screens/Auth*.kt`, `ForgotLayer.kt`, `WelcomeHost.kt`, `BanOverlay.kt` |
| **Chat** (World chat, friends, requests, DMs, groups, replies, edit/delete, verified moderation, saved messages + backup/restore, alerts) | `data/Chat*.kt`, `ui/screens/Chat*.kt`, `ui/screens/chat/*` |
| **Games** (Coin Battle, Bomb & Gems — in Chat → Game tab) | `data/Games.kt`, `ui/screens/GameOverlay.kt`, `assets/site/*` |

## How the games work
The server (admin panel on Render) runs all rules and money, as on the website. The two game screens are the website's
own game pages bundled in `app/src/main/assets/site/pages/game/` and shown in a **native full-screen host**
(`GameOverlay.kt`). `assets/site/js/bridge.js` ↔ `GameNative` (Kotlin) give the pages: Firebase login token + server calls
(done natively), wallet balance, live game updates (native Firestore listener), confirm dialog, deposit, close, sounds.
Hardware Back closes the lobby or asks "Leave the match?".

## Honest limits
* This project was **written without an Android SDK, so it has not been compiled or run here**. Expect to fix a few small
  compile errors / visual nits on the first Android Studio build (Build → Make Project shows them).
* Push when the app is fully closed (FCM) needs a server that sends the messages. In-app notifications, the bell, the
  system notification while the app is in the background (live listener) and chat alerts work without it.
* Proofs (`ffcashbattle.in/proof`) and Terms open inside the app in a full-screen web view, and the website login is separate.
* Chat alerts when the app is closed also need a server-side push.
