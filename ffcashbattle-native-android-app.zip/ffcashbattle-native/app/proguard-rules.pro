-keep class com.ffcashbattle.app.data.** { *; }
-keepattributes *Annotation*, Signature

# Coin Battle / Bomb & Gems run in a native WebView host: keep the methods the bundled pages call (bridge.js -> __ffNative)
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
-keep class com.ffcashbattle.app.ui.screens.GameNative { *; }
