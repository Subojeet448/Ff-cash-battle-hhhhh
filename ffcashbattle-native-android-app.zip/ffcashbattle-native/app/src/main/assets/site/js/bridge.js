/* Native bridge for the Coin Battle / Bomb & Gems pages.
 * The pages were written for an iframe ("window.parent.ballBridge"); inside the Android app they run in a native
 * full-screen host, and everything they need (login token, wallet, live game updates, confirm, deposit, close)
 * is answered by the Kotlin object `__ffNative`. The server (admin panel) still runs all rules and money. */
(function () {
  var N = window.__ffNative;
  if (!N) return;
  var skew = 0, seq = 0, cbs = {}, watchers = {};
  window.__ffDark = !!N.dark();

  var BASE = new URL('../../assets/img/game/', document.baseURI).href;
  var hash = function (s) { var h = 7; for (const c of String(s == null ? '' : s)) h = (h * 33 + c.charCodeAt(0)) >>> 0; return h; };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };

  // native answers (called by Kotlin)
  window.__ffCb = function (id, code, text, err) { var f = cbs[id]; delete cbs[id]; if (f) f(code, text, err); };
  window.__ffConfirm = function (id, ok) { var f = cbs[id]; delete cbs[id]; if (f) f(ok); };
  window.__ffWatch = function (id, json, err) {
    var w = watchers[id]; if (!w) return;
    if (err) { if (w.err) try { w.err(new Error(err)); } catch (e) {} return; }
    var o; try { o = JSON.parse(json); } catch (e) { return; }
    try { w.cb(o); } catch (e) {}
  };

  function make(kind, coll) {
    return {
      api: function (path, body, ms) {
        ms = ms || 75000;
        return new Promise(function (res, rej) {
          var id = ++seq;
          cbs[id] = function (code, text, err) {
            if (err) return rej(new Error(err));
            var j = {}; try { j = JSON.parse(text); } catch (e) {}
            if (j && j.now) skew = j.now - Date.now();
            if ((code < 200 || code > 299) && !(j && j.status)) return rej(new Error((j && j.error) || 'Server error ' + code));
            res(j);
          };
          N.api(id, kind, String(path), JSON.stringify(body || {}), ms);
        });
      },
      now: function () { return Date.now() + skew; },
      balance: function () { return Number(N.balance()) || 0; },
      me: function () { try { return JSON.parse(N.me()); } catch (e) { return { name: 'Player', photo: '' }; } },
      uid: function () { return N.uid(); },
      avatar: function (n) { return BASE + 'avatars/av' + (hash(n) % 12 + 1) + '.svg'; },
      vname: function (n, uid) { return N.verified(String(uid || '')) ? '<span class="vn">' + esc(n) + '</span><i class="fa-solid fa-circle-check vt" title="Verified"></i>' : esc(n); },
      watch: function (gid, cb, err) {
        var id = ++seq; watchers[id] = { cb: cb, err: err };
        N.watch(id, coll, String(gid));
        return function () { delete watchers[id]; N.unwatch(id); };
      },
      sfx: function (n) { try { N.sfx(String(n)); } catch (e) {} },
      confirm: function (o) {
        return new Promise(function (res) { var id = ++seq; cbs[id] = res; N.confirm(id, JSON.stringify(o || {})); });
      },
      deposit: function () { N.deposit(); },
      close: function () { N.close(); }
    };
  }
  window.ballBridge = make('ball', 'ball_games');
  window.bombBridge = make('bomb', 'bomb_games');

  // hardware Back: close the lobby, or leave the running match (the page asks to confirm)
  window.__ffBack = function () {
    var b = document.getElementById('bk'); if (b && b.classList.contains('on')) { b.click(); return 'close'; }
    var l = document.getElementById('lvg'); if (l) { l.click(); return 'leave'; }
    var r = document.getElementById('lv'); if (r) { r.click(); return 'lobby'; }
    return 'none';
  };
})();
