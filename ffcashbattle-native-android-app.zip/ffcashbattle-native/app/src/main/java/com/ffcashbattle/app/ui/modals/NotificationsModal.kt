package com.ffcashbattle.app.ui.modals

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.Msg
import com.ffcashbattle.app.data.NotifItem
import com.ffcashbattle.app.data.NotifStore
import com.ffcashbattle.app.data.Sfx
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.modals.notif.ClaimCard
import com.ffcashbattle.app.ui.modals.notif.NotifCard
import com.ffcashbattle.app.ui.modals.notif.NotifDetail
import com.ffcashbattle.app.ui.modals.notif.NotifEmpty
import com.ffcashbattle.app.ui.modals.notif.NotifSkeletons
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Website `#modal-notifications` (.nf-sheet): header, clear-all, inline confirm, cards, claim cards, detail popup. */
@Composable
fun NotificationsModal() {
    val c = FF.c
    val scope = rememberCoroutineScope()
    val screenH = LocalConfiguration.current.screenHeightDp

    var confirm by remember { mutableStateOf<String?>(null) }      // "all" or a notification key
    var lastConfirm by remember { mutableStateOf("all") }
    var detail by remember { mutableStateOf<NotifItem?>(null) }
    var outAll by remember { mutableStateOf(false) }
    var outKey by remember { mutableStateOf<String?>(null) }
    var busyKey by remember { mutableStateOf<String?>(null) }
    var scratchArg by remember { mutableStateOf<String?>(null) }
    var sheetClose by remember { mutableStateOf<() -> Unit>({ AppStore.closeModal() }) }

    LaunchedEffect(Unit) { NotifStore.open() }
    if (confirm != null) lastConfirm = confirm ?: "all"

    val items = NotifStore.items
    val fresh = items.count { it.fresh }

    fun deleteOne(n: NotifItem) {
        scope.launch {
            confirm = null
            outKey = n.key
            Sfx.play("clear")
            delay(420)
            NotifStore.delete(n)
            outKey = null
            detail = null
            AppStore.toast("Notification deleted")
        }
    }

    fun clearAll() {
        scope.launch {
            confirm = null
            Sfx.play("clear")
            val n = items.size
            outAll = true
            val job = launch { NotifStore.clearAll() }
            delay(450L + minOf(n - 1, 7).coerceAtLeast(0) * 55L)
            job.join()
            NotifStore.items = emptyList()
            outAll = false
            AppStore.toast(Msg.notif.cleared())
        }
    }

    fun scratch(n: NotifItem) {
        scratchArg = "scratch:" + (n.id ?: n.key)
        sheetClose()
    }

    Box(Modifier.fillMaxSize()) {
        ModalSheet(
            modifier = Modifier.heightIn(min = (screenH * 0.46f).dp),
            onDismiss = {
                val a = scratchArg
                if (a != null) AppStore.openModal("modal-refer", a) else AppStore.closeModal()
            },
            padding = PaddingValues(start = 30.dp, top = 30.dp, end = 30.dp, bottom = 24.dp),
        ) {
            val close = LocalSheetClose.current
            SideEffect { sheetClose = close }

            // ---------------------------------------------------------------- header
            Row(
                Modifier.fillMaxWidth().padding(bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    Modifier.boxShadow(14.dp, Color(0x594F46E5), RoundedCornerShape(14.dp)).size(42.dp).clip(RoundedCornerShape(14.dp))
                        .background(Brush.linearGradient(listOf(c.primary, Color(0xFF7C3AED)))),
                    contentAlignment = Alignment.Center,
                ) { FaIcon("fa-solid fa-bell", rem(1.1).value.dp, Color.White) }

                Column(Modifier.weight(1f)) {
                    FText(Msg.notif.title(), size = rem(1.35), weight = FontWeight.Bold, lineHeight = rem(1.35) * 1.1f)
                    val countText = when {
                        fresh > 0 -> "$fresh new"
                        items.isNotEmpty() -> items.size.toString() + (if (items.size == 1) " notification" else " notifications")
                        else -> "No notifications"
                    }
                    FText(countText, size = rem(0.7), weight = FontWeight.ExtraBold, color = if (fresh > 0) c.primary else c.textMuted, modifier = Modifier.padding(top = 2.dp))
                }

                val active = confirm == "all"
                Row(
                    Modifier.graphicsLayer { alpha = if (items.isEmpty()) 0.4f else 1f }
                        .press(0.94f) {
                            if (items.isEmpty()) AppStore.toast(Msg.notif.clearNothing())
                            else if (confirm == "all") confirm = null else confirm = "all"
                        }
                        .clip(RoundedCornerShape(30.dp))
                        .background(if (active) Color(0xFFEF4444) else Color(0x1AEF4444))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    FaIcon("fa-solid fa-trash-can", rem(0.76).value.dp, if (active) Color.White else Color(0xFFEF4444))
                    FText("Clear", size = rem(0.76), weight = FontWeight.ExtraBold, color = if (active) Color.White else Color(0xFFEF4444))
                }
                Box(Modifier.size(36.dp).clip(CircleShape).background(c.bgInput).tap { close() }, contentAlignment = Alignment.Center) {
                    FaIcon("fa-solid fa-xmark", rem(1.0).value.dp, c.textMuted)
                }
            }
            Box(Modifier.fillMaxWidth().heightIn(min = 1.dp, max = 1.dp).background(c.border))
            Box(Modifier.padding(bottom = 16.dp))

            // ---------------------------------------------------------------- inline confirm panel
            AnimatedVisibility(
                visible = confirm != null,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut(),
            ) {
                val all = lastConfirm == "all"
                val target = if (all) null else items.firstOrNull { it.key == lastConfirm }
                ConfirmPanel(
                    title = if (all) Msg.notif.clearTitle() else "Delete this notification?",
                    sub = if (all) Msg.notif.clearConfirm() else "This message will be removed permanently.",
                    yes = if (all) Msg.notif.clearYes() else "Yes, delete",
                    no = if (all) Msg.notif.clearNo() else "Keep it",
                    onNo = { confirm = null },
                    onYes = { if (all) clearAll() else if (target != null) deleteOne(target) else confirm = null },
                )
            }

            // ---------------------------------------------------------------- list / states
            when {
                !NotifStore.loaded && items.isEmpty() -> NotifSkeletons()
                NotifStore.failed && items.isEmpty() -> NotifEmpty(failed = true)
                items.isEmpty() -> NotifEmpty(failed = false)
                else -> items.forEachIndexed { i, n ->
                    val outIndex: Int? = when {
                        outAll -> minOf(i, 7)
                        outKey == n.key -> 0
                        else -> null
                    }
                    val target = confirm == n.key
                    if (n.claimAmount > 0 && n.id != null) {
                        ClaimCard(
                            n = n, outIndex = outIndex, target = target, busy = busyKey == n.key,
                            onDelete = { confirm = if (confirm == n.key) null else n.key },
                            onClaim = {
                                if (busyKey == null) scope.launch {
                                    busyKey = n.key
                                    try { NotifStore.markClaimed(n) } catch (_: Exception) { }
                                    busyKey = null
                                    AppStore.toast(Msg.notif.claimInfo())
                                }
                            },
                        )
                    } else {
                        NotifCard(
                            n = n, outIndex = outIndex, target = target,
                            onOpen = { detail = n },
                            onDelete = { confirm = if (confirm == n.key) null else n.key },
                            onScratch = { scratch(n) },
                        )
                    }
                }
            }
        }

        // -------------------------------------------------------------------- detail popup
        val d = detail
        if (d != null) {
            NotifDetail(
                n = d,
                onClose = { detail = null },
                onDelete = { confirm = d.key; detail = null },
                onScratch = { detail = null; scratch(d) },
            )
        }
    }
}

/** `.nf-confirm` — inline red-tinted panel with a question and two buttons. */
@Composable
private fun ConfirmPanel(title: String, sub: String, yes: String, no: String, onNo: () -> Unit, onYes: () -> Unit) {
    val c = FF.c
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(shape)
            .background(
                Brush.linearGradient(
                    if (c.isDark) listOf(Color(0x26EF4444), Color(0x14F43F5E)) else listOf(Color(0x14EF4444), Color(0x0AF43F5E)),
                ),
            )
            .border(1.dp, Color(0x59EF4444), shape)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x26EF4444)),
                contentAlignment = Alignment.Center,
            ) { FaIcon("fa-solid fa-trash-can", rem(1.0).value.dp, Color(0xFFEF4444)) }
            Column(Modifier.weight(1f)) {
                FText(title, size = rem(0.92), weight = FontWeight.Bold)
                FText(sub, size = rem(0.78), color = c.textMuted, lineHeight = rem(0.78) * 1.4f, modifier = Modifier.padding(top = 2.dp))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.weight(1f).press(0.96f) { onNo() }.clip(RoundedCornerShape(12.dp)).background(c.bgInput).padding(vertical = 11.dp, horizontal = 12.dp),
                contentAlignment = Alignment.Center,
            ) { FText(no, size = rem(0.82), weight = FontWeight.ExtraBold, color = c.textMain) }
            Box(
                Modifier.weight(1f).press(0.96f) { onYes() }.clip(RoundedCornerShape(12.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFFEF4444), Color(0xFFF43F5E)))).padding(vertical = 11.dp, horizontal = 12.dp),
                contentAlignment = Alignment.Center,
            ) { FText(yes, size = rem(0.82), weight = FontWeight.ExtraBold, color = Color.White) }
        }
    }
}
