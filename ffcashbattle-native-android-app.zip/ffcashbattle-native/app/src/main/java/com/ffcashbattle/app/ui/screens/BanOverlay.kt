package com.ffcashbattle.app.ui.screens

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay
import kotlin.random.Random

private val BoBg = Color(0xFF0F1424)
private val BoCard = Color(0xFF171E36)
private val BoLine = Color(0xFF2A3358)
private val BoText = Color(0xFFEEF0F8)
private val BoMuted = Color(0xFF9AA3C4)
private val BoRed = Color(0xFFFF4D5E)
private val BoAmber = Color(0xFFFFB84D)
private const val DAY = 86_400_000L

/** Immutable result of `app.checkBan(d)`. */
private class BanInfo(
    val perm: Boolean, val until: Long, val days: Int, val pid: String, val reason: String,
)

private fun banUntilMs(d: com.ffcashbattle.app.data.Doc): Long {
    val raw = d["bannedUntil"]
    if (raw == null || (raw is String && (raw.isBlank() || raw.equals("permanent", true)))) return 0L
    return d.ms("bannedUntil")
}

private fun computeBan(now: Long): BanInfo? {
    val d = AppStore.user
    if (AppStore.uid == null || !d.b("isBanned")) return null
    val until = banUntilMs(d)
    if (until != 0L && until < now) return null     // auto-expire
    val perm = until == 0L
    var days = d.n("banDays", d.n("bannedDays", 0.0)).toInt()
    if (!perm && days == 0) {
        val start = d.ms("bannedAt").takeIf { it > 0 } ?: d.ms("bannedOn").takeIf { it > 0 } ?: d.ms("banStart")
        days = if (start > 0) Math.round((until - start).toDouble() / DAY).toInt() else Math.ceil((until - now).toDouble() / DAY).toInt()
    }
    if (!perm && days < 1) days = 1
    val pid = d.s("playerId").ifEmpty { (AppStore.uid ?: "").take(7) }.ifEmpty { "-" }
    val reason = d.s("banReason").ifEmpty { d.s("bannedReason") }.trim()
    return BanInfo(perm, until, days, pid, reason)
}

private fun pad2(n: Long) = n.toString().padStart(2, '0')
private fun leftText(until: Long, now: Long): String {
    val s = maxOf(0L, (until - now) / 1000)
    return (s / 86400).toString() + "d " + pad2(s % 86400 / 3600) + "h " + pad2(s % 3600 / 60) + "m " + pad2(s % 60) + "s"
}

private fun banSupportWa(pid: String) {
    val text = java.net.URLEncoder.encode("Hello, my account is banned. Player ID: $pid", "UTF-8").replace("+", "%20")
    var link = AppStore.whatsapp.second.trim().ifEmpty { AppStore.supportNumber.trim() }
    if (link.isEmpty()) { AppStore.openWhatsApp(); return }
    if (!Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(link)) {
        val n = link.filter { it.isDigit() }
        if (n.isEmpty()) { AppStore.openWhatsApp(); return }
        link = "https://wa.me/$n?text=$text"
    } else if (Regex("wa\\.me|whatsapp\\.com", RegexOption.IGNORE_CASE).containsMatchIn(link) && !Regex("[?&]text=").containsMatchIn(link)) {
        link += (if (link.contains("?")) "&" else "?") + "text=" + text
    }
    AppStore.openUrl(link)
}

/** `#ban-overlay` — full-screen "account banned" screen (fixed dark look, same in light and dark mode). */
@Composable
fun BanOverlay() {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val info = computeBan(now)
    // tick every second only while a temporary ban is active (website: setInterval 1000)
    LaunchedEffect(info != null) {
        while (info != null) { delay(1000); now = System.currentTimeMillis() }
    }
    if (info == null) return
    BanContent(info, now)
}

@Composable
private fun BanContent(info: BanInfo, now: Long) {
    val ctx = LocalContext.current
    BackHandler(enabled = true) { (ctx as? Activity)?.moveTaskToBack(true) }

    val cardIn = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(1450); cardIn.animateTo(1f, tween(600, easing = CubicBezierEasing(0.2f, 0.8f, 0.2f, 1f))) }

    val inf = rememberInfiniteTransition(label = "ban")
    val breathe by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathe")
    val blink by inf.animateFloat(1f, 0.25f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "blink")

    var clock by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        val t0 = withFrameNanos { it }
        while (true) { clock = withFrameNanos { it } - t0 }
    }

    val status = if (info.perm) "Account banned" else "Temporarily banned"
    val title = if (info.perm) "You can’t play right now" else "Take a break for now"
    val sub = if (info.perm) "Your account broke our fair play rules, so it has been removed from all tournaments."
    else "Your account is paused. You can join tournaments again when the timer ends."

    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) { if (copied) { delay(1500); copied = false } }

    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    BoxWithConstraints(Modifier.fillMaxSize().background(BoBg).tap { }) {
        val viewportH = maxHeight
        // breathing red glow (top)
        Box(
            Modifier.fillMaxSize().drawBehind {
                val s = 1f + 0.06f * breathe
                val r = size.width * 0.75f * s
                drawCircle(
                    Brush.radialGradient(listOf(Color(0xFFFF4D5E).copy(alpha = 0.16f * (1f - 0.45f * breathe)), Color.Transparent), center = Offset(size.width / 2f, size.height * 0.2f), radius = r),
                    radius = r, center = Offset(size.width / 2f, size.height * 0.2f),
                )
            },
        )
        Embers(clock)

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 18.dp, end = 18.dp, top = top + 18.dp, bottom = bottom + 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Column(
                Modifier.widthIn(max = 420.dp).fillMaxWidth().heightIn(min = viewportH - top - bottom - 46.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                ShieldHero()
                Column(
                    Modifier.fillMaxWidth()
                        .graphicsLayer { alpha = cardIn.value; translationY = (1f - cardIn.value) * 20.dp.toPx() }
                        .boxShadow(60.dp, Color(0x40FF4D5E), RoundedCornerShape(24.dp))
                        .clip(RoundedCornerShape(24.dp)).background(BoCard).border(1.dp, BoLine, RoundedCornerShape(24.dp))
                        .padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Row(
                        Modifier.padding(bottom = 12.dp).clip(RoundedCornerShape(50)).background(Color(0x24FF4D5E)).padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.graphicsLayer { alpha = blink }.size(8.dp).clip(CircleShape).background(BoRed))
                        FText(status, size = 13.sp, weight = FontWeight.Bold, color = BoRed)
                    }
                    FText(title, size = rem(1.75), weight = FontWeight.ExtraBold, color = BoText, lineHeight = rem(1.75) * 1.15f, letterSpacing = (-0.245).sp, align = TextAlign.Center, modifier = Modifier.padding(bottom = 8.dp))
                    FText(sub, size = rem(0.95), color = BoMuted, lineHeight = rem(0.95) * 1.5f, align = TextAlign.Center, modifier = Modifier.padding(bottom = 18.dp).widthIn(max = 272.dp))

                    // Player ID
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(14.dp)).background(BoBg)
                            .dashedBorder(BoLine, 14.dp)
                            .padding(start = 14.dp, top = 10.dp, end = 12.dp, bottom = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            FText("Banned Player ID", size = 12.sp, color = BoMuted, lineHeight = 14.4.sp, modifier = Modifier.padding(bottom = 2.dp))
                            FText(info.pid, size = rem(1.1), weight = FontWeight.ExtraBold, color = BoText, letterSpacing = (0.066 * 15.4).sp, maxLines = 1)
                        }
                        Box(
                            Modifier.press(0.96f) {
                                try {
                                    val cm = AppStore.app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    cm.setPrimaryClip(ClipData.newPlainText("ffcb", info.pid))
                                } catch (_: Exception) { }
                                copied = true
                            }.clip(RoundedCornerShape(10.dp)).background(if (copied) Color(0xFF35D49A) else BoCard)
                                .border(1.dp, if (copied) Color(0xFF35D49A) else BoLine, RoundedCornerShape(10.dp))
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center,
                        ) { FText(if (copied) "Copied" else "Copy", size = 13.sp, weight = FontWeight.Bold, color = if (copied) Color.White else BoText) }
                    }

                    // rows
                    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(RoundedCornerShape(14.dp)).border(1.dp, BoLine, RoundedCornerShape(14.dp))) {
                        BanRow("Ban length", if (info.perm) "Permanent" else info.days.toString() + (if (info.days == 1) " Day" else " Days"), BoRed, true, false)
                        if (!info.perm) BanRow("Back in", leftText(info.until, now), BoAmber, true, true)
                        if (info.reason.isNotEmpty()) BanRow("Reason", info.reason, BoText, false, true)
                    }

                    // buttons
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        BanBtn("Contact support", "fa-brands fa-whatsapp", main = true) { banSupportWa(info.pid) }
                        if (AppStore.telegram.second.isNotBlank()) BanBtn("Telegram support", "fa-brands fa-telegram", main = false) { AppStore.openTelegram() }
                    }
                    FText("Think this is a mistake? Message support and share your Player ID.", size = rem(0.78), color = BoMuted, lineHeight = rem(0.78) * 1.45f, align = TextAlign.Center, modifier = Modifier.padding(top = 14.dp))
                }
            }
        }
    }
}

@Composable
private fun BanRow(label: String, value: String, valueColor: Color, bold: Boolean, divider: Boolean) {
    Column {
        if (divider) Box(Modifier.fillMaxWidth().heightIn(min = 1.dp, max = 1.dp).background(BoLine))
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 11.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            FText(label, size = rem(0.88), color = BoMuted, softWrap = false)
            FText(value, size = rem(0.88), weight = if (bold) FontWeight.ExtraBold else FontWeight.SemiBold, color = valueColor, align = TextAlign.End, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun BanBtn(text: String, icon: String, main: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().press(0.98f) { onClick() }.clip(shape)
            .background(if (main) BoRed else Color.Transparent).border(1.dp, if (main) BoRed else BoLine, shape).padding(14.dp),
        horizontalArrangement = Arrangement.spacedBy(9.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically,
    ) {
        FaIcon(icon, 15.dp, if (main) Color.White else BoText)
        FText(text, size = 15.sp, weight = FontWeight.Bold, color = if (main) Color.White else BoText)
    }
}

/** 1dp dashed rounded border drawn behind the content. */
private fun Modifier.dashedBorder(color: Color, radius: androidx.compose.ui.unit.Dp): Modifier = this.drawBehind {
    val sw = 1.dp.toPx()
    drawRoundRect(
        color, topLeft = Offset(sw / 2f, sw / 2f), size = androidx.compose.ui.geometry.Size(size.width - sw, size.height - sw),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius.toPx()),
        style = Stroke(sw, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 3.dp.toPx()))),
    )
}

// ------------------------------------------------------------------------------------------------ hero

@Composable
private fun ShieldHero() {
    val body = remember { Animatable(0f) }
    val slash = remember { Animatable(0f) }
    val crack = remember { Animatable(0f) }
    val thud = remember { Animatable(0f) }
    val shock = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(150); body.animateTo(1f, tween(900, easing = CubicBezierEasing(0.6f, 0f, 0.2f, 1f)))
    }
    LaunchedEffect(Unit) { delay(950); slash.animateTo(1f, tween(300, easing = androidx.compose.animation.core.FastOutLinearInEasing)) }
    LaunchedEffect(Unit) { delay(1300); crack.animateTo(1f, tween(350)) }
    LaunchedEffect(Unit) { delay(1250); thud.animateTo(1f, tween(450)) }
    LaunchedEffect(Unit) { delay(1250); shock.animateTo(1f, tween(600)) }

    val inf = rememberInfiniteTransition(label = "rings")
    val ring1 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2800, easing = androidx.compose.animation.core.FastOutLinearInEasing), RepeatMode.Restart), label = "r1")
    val started = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(1300); started.snapTo(1f) }

    Box(Modifier.fillMaxWidth().heightIn(min = 160.dp, max = 160.dp), contentAlignment = Alignment.Center) {
        // rings (start after 1.3s / 2.2s)
        if (started.value > 0f) {
            for (p in listOf(ring1, (ring1 + 0.32f) % 1f)) {
                Box(
                    Modifier.size(140.dp)
                        .graphicsLayer { val s = 0.7f + 1.1f * p; scaleX = s; scaleY = s; alpha = 0.5f * (1f - p) }
                        .border(2.dp, BoRed, CircleShape),
                )
            }
        }
        val sp = shock.value
        if (sp > 0f && sp < 1f) {
            Box(
                Modifier.size(140.dp).graphicsLayer { val s = 0.6f + 1.8f * sp; scaleX = s; scaleY = s; alpha = 0.9f * (1f - sp) }.border(3.dp, BoRed, CircleShape),
            )
        }
        Canvas(
            Modifier.size(width = 112.dp, height = 130.dp).graphicsLayer {
                val t = thud.value
                // keyframes: 0 -> 1.0, .3 -> 1.12 / -3deg, .55 -> .95 / 2deg, .8 -> 1.02 / -1deg, 1 -> 1.0
                val (sc, rot) = when {
                    t <= 0f || t >= 1f -> 1f to 0f
                    t < 0.3f -> lerpPair(1f to 0f, 1.12f to -3f, t / 0.3f)
                    t < 0.55f -> lerpPair(1.12f to -3f, 0.95f to 2f, (t - 0.3f) / 0.25f)
                    t < 0.8f -> lerpPair(0.95f to 2f, 1.02f to -1f, (t - 0.55f) / 0.25f)
                    else -> lerpPair(1.02f to -1f, 1f to 0f, (t - 0.8f) / 0.2f)
                }
                scaleX = sc; scaleY = sc; rotationZ = rot
            },
        ) {
            val kx = size.width / 116f
            val ky = size.height / 134f
            fun sx(x: Float) = x * kx
            fun sy(y: Float) = y * ky
            val bodyPath = Path().apply {
                moveTo(sx(58f), sy(6f)); lineTo(sx(104f), sy(22f)); lineTo(sx(104f), sy(62f))
                cubicTo(sx(104f), sy(94f), sx(84f), sy(117f), sx(58f), sy(128f))
                cubicTo(sx(32f), sy(117f), sx(12f), sy(94f), sx(12f), sy(62f))
                lineTo(sx(12f), sy(22f)); close()
            }
            drawPath(bodyPath, Color(0x24FF4D5E))
            drawPartial(bodyPath, body.value, BoRed, 4f * kx, true)
            val slashPath = Path().apply { moveTo(sx(38f), sy(48f)); lineTo(sx(78f), sy(88f)) }
            drawPartial(slashPath, slash.value, BoRed, 7f * kx, false)
            val crackPath = Path().apply { moveTo(sx(58f), sy(6f)); lineTo(sx(54f), sy(30f)); lineTo(sx(64f), sy(44f)); lineTo(sx(56f), sy(62f)) }
            drawPartial(crackPath, crack.value, BoRed.copy(alpha = 0.8f), 2.5f * kx, true)
        }
    }
}

private fun lerpPair(a: Pair<Float, Float>, b: Pair<Float, Float>, t: Float): Pair<Float, Float> =
    Pair(a.first + (b.first - a.first) * t, a.second + (b.second - a.second) * t)

private fun DrawScope.drawPartial(path: Path, progress: Float, color: Color, stroke: Float, round: Boolean) {
    if (progress <= 0f) return
    val pm = PathMeasure()
    pm.setPath(path, false)
    val seg = Path()
    pm.getSegment(0f, pm.length * progress, seg, true)
    drawPath(seg, color, style = Stroke(stroke, cap = StrokeCap.Round, join = if (round) StrokeJoin.Round else StrokeJoin.Miter))
}

// ------------------------------------------------------------------------------------------------ embers

private class Ember(val x: Float, val size: Float, val dx: Float, val period: Float, val delay: Float)

@Composable
private fun Embers(clockNanos: Long) {
    val embers = remember {
        val r = Random(11)
        List(12) { Ember(r.nextFloat(), 3f + r.nextFloat() * 4f, r.nextFloat() * 60f - 30f, 7f + r.nextFloat() * 7f, 1.5f + r.nextFloat() * 6f) }
    }
    val h = LocalConfiguration.current.screenHeightDp
    Canvas(Modifier.fillMaxSize()) {
        val t = clockNanos / 1_000_000_000f
        for (e in embers) {
            if (t < e.delay) continue
            val p = ((t - e.delay) % e.period) / e.period
            val a = when { p < 0.15f -> 0.7f * p / 0.15f; else -> 0.7f * (1f - (p - 0.15f) / 0.85f) }
            val y = size.height + 12.dp.toPx() - (size.height + 12.dp.toPx() + 0.05f * h.dp.toPx()) * p
            drawCircle(Color(0xFFFF4D5E).copy(alpha = a.coerceIn(0f, 1f)), radius = e.size.dp.toPx() / 2f, center = Offset(size.width * e.x + e.dx.dp.toPx() * p, y))
        }
    }
}
