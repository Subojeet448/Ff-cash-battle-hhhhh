package com.ffcashbattle.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.R
import com.ffcashbattle.app.data.Sfx
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.state.Page
import com.ffcashbattle.app.ui.comp.Coin
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.screens.wallet.toFixed
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

private val PopEase = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f)
private val FlyEase = CubicBezierEasing(0.4f, 0f, 0.2f, 1f)

/** Full-screen layers above everything else: the payment-verify card (`dep-verify-overlay`) and the golden-coin wallet animation (`walletfx`). */
@Composable
fun LoadingOverlay() {
    VerifyOverlay()
    WalletFxOverlay()
}

// =============================================================================================== payment verify overlay

@Composable
private fun VerifyOverlay() {
    val ov = AppStore.verifyOv
    var shown by remember { mutableStateOf(ov) }
    LaunchedEffect(ov) { if (ov != null) shown = ov else { delay(300); if (AppStore.verifyOv == null) shown = null } }
    val vis by animateFloatAsState(if (ov != null) 1f else 0f, tween(300), label = "dvoVis")
    BackHandler(enabled = ov != null) { if (ov != null && ov.mode != "loading") AppStore.hideVerify() }
    val s = shown ?: return

    Box(
        Modifier.fillMaxSize().graphicsLayer { alpha = vis }.background(Color(0xE00F172A)).padding(26.dp)
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        val enter by animateFloatAsState(if (ov != null) 1f else 0f, tween(450, easing = PopEase), label = "dvoCard")
        val mode = s.mode
        Column(
            Modifier.widthIn(max = 350.dp).fillMaxWidth()
                .graphicsLayer { translationY = (1f - enter) * 24.dp.toPx(); val sc = 0.94f + 0.06f * enter; scaleX = sc; scaleY = sc }
                .clip(RoundedCornerShape(28.dp)).background(Color.White)
                .padding(start = 22.dp, end = 22.dp, top = 30.dp, bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            DvoIcon(mode, s.tick)
            FText(s.title, size = rem(1.2), weight = FontWeight.Black, color = Color(0xFF0F172A), align = TextAlign.Center, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))
            FText(s.sub, size = rem(0.85), color = Color(0xFF64748B), lineHeight = rem(0.85) * 1.55f, align = TextAlign.Center)
            if (s.amount != null || s.ref != null) {
                Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DvoInfo("Amount", "₹" + (s.amount ?: "0"), Modifier.weight(1f))
                    DvoInfo(s.refLabel, s.ref ?: "--", Modifier.weight(1f))
                }
            }
            DvoSteps(mode)
            if (mode == "loading" || mode == "pending") DvoBar(mode == "pending")
            if (mode == "loading") FText("Checking... ${AppStore.verifyCountdown}s", size = rem(0.8), weight = FontWeight.Bold, color = Color(0xFF4F46E5), modifier = Modifier.padding(top = 14.dp))
            if (mode == "pending" || mode == "fail") {
                Box(
                    Modifier.padding(top = 16.dp).press(0.95f) { AppStore.hideVerify() }.clip(RoundedCornerShape(50.dp)).background(Color(0xFF4F46E5)).padding(horizontal = 30.dp, vertical = 12.dp),
                ) { FText(if (mode == "pending") "OK, got it" else "Close", weight = FontWeight.ExtraBold, color = Color.White) }
            }
        }
    }
}

@Composable
private fun DvoIcon(mode: String, tick: Int) {
    val inf = rememberInfiniteTransition(label = "dvoIcon")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart), label = "spin")
    val glow by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = androidx.compose.animation.core.LinearOutSlowInEasing), RepeatMode.Restart), label = "glow")
    val hour by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2000, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "hour")
    val pop = remember(mode, tick) { Animatable(0f) }
    LaunchedEffect(mode, tick) { if (mode == "success" || mode == "fail") pop.animateTo(1f, tween(if (mode == "success") 550 else 500, easing = if (mode == "success") PopEase else LinearEasing)) else pop.snapTo(1f) }
    val glowCol = when (mode) { "success" -> Color(0xFF10B981); "pending" -> Color(0xFFF59E0B); "fail" -> Color.Transparent; else -> Color(0xFFFBBF24) }
    val bg: Brush = when (mode) {
        "success" -> Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF34D399)))
        "pending" -> Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFFFBBF24)))
        "fail" -> Brush.linearGradient(listOf(Color(0xFFEF4444), Color(0xFFF87171)))
        else -> Brush.radialGradient(listOf(Color(0xFFFFF7D6), Color(0xFFFDE68A)))
    }
    Box(
        Modifier.size(92.dp)
            .graphicsLayer {
                if (mode == "success") { val k = pop.value; scaleX = k; scaleY = k; rotationZ = -90f * (1f - k) }
                if (mode == "fail") { translationX = shakeX(pop.value) * 8.dp.toPx() }
            }
            .drawBehind { if (glowCol != Color.Transparent) { val r = 26.dp.toPx() * glow; drawCircle(glowCol.copy(alpha = 0.5f * (1f - glow)), radius = size.minDimension / 2f + r) } }
            .clip(CircleShape).background(bg),
        contentAlignment = Alignment.Center,
    ) {
        when (mode) {
            "success" -> FaIcon("fa-solid fa-check", rem(2.3).value.dp, Color.White)
            "pending" -> FaIcon("fa-solid fa-hourglass-half", rem(2.3).value.dp, Color.White, Modifier.graphicsLayer { rotationZ = if (hour < 0.4f) 0f else if (hour < 0.6f) 180f * ((hour - 0.4f) / 0.2f) else 180f })
            "fail" -> FaIcon("fa-solid fa-xmark", rem(2.3).value.dp, Color.White)
            else -> Coin(66.dp, Modifier.graphicsLayer { rotationY = spin; cameraDistance = 14f * density })
        }
    }
}

/** `dvoShake`: 0 -> -8 -> 8 -> -8 -> 8 -> 0 (in 1/5 steps). */
private fun shakeX(k: Float): Float {
    val pts = floatArrayOf(0f, -1f, 1f, -1f, 1f, 0f)
    val i = (k * 5f).toInt().coerceIn(0, 4)
    return pts[i] + (pts[i + 1] - pts[i]) * (k * 5f - i)
}

@Composable
private fun DvoInfo(label: String, value: String, modifier: Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Column(modifier.clip(shape).background(Color(0xFFF8FAFC)).border(1.dp, Color(0xFFE2E8F0), shape).padding(horizontal = 8.dp, vertical = 9.dp)) {
        FText(label.uppercase(), size = rem(0.62), weight = FontWeight.ExtraBold, color = Color(0xFF94A3B8), letterSpacing = 0.5.sp, maxLines = 1)
        FText(value, size = rem(0.85), color = Color(0xFF0F172A), mono = true, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun DvoSteps(mode: String) {
    val n = when (mode) { "success" -> 3; "fail" -> 1; else -> 2 }
    val lineOn = { i: Int -> (i + 2) <= (if (mode == "success") 3 else if (mode == "fail") 1 else 2) }
    val onCol = when (mode) { "success" -> Color(0xFF10B981); "fail" -> Color(0xFFEF4444); else -> Color(0xFF4F46E5) }
    Row(Modifier.padding(top = 18.dp, bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        DvoStep("fa-solid fa-paper-plane", "Submitted", 1 <= n, mode, onCol)
        DvoLine(lineOn(0))
        DvoStep("fa-solid fa-building-columns", "Matching", 2 <= n, mode, onCol)
        DvoLine(lineOn(1))
        DvoStep("fa-solid fa-check", "Credited", 3 <= n, mode, onCol)
    }
}

@Composable
private fun DvoStep(icon: String, label: String, on: Boolean, mode: String, onCol: Color) {
    val sc by animateFloatAsState(if (on) 1.08f else 1f, tween(400), label = "stepScale")
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(
            Modifier.graphicsLayer { scaleX = sc; scaleY = sc }.size(34.dp).clip(CircleShape).background(if (on) onCol else Color(0xFFE2E8F0)),
            contentAlignment = Alignment.Center,
        ) { FaIcon(icon, rem(0.85).value.dp, if (on) Color.White else Color(0xFF94A3B8)) }
        FText(label, size = rem(0.62), weight = FontWeight.Bold, color = if (on) onCol else Color(0xFF94A3B8))
    }
}

@Composable
private fun DvoLine(on: Boolean) {
    val w by animateDpAsState(if (on) 28.dp else 0.dp, tween(600), label = "line")
    Box(Modifier.padding(bottom = 18.dp).size(width = 28.dp, height = 3.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFFE2E8F0))) {
        Box(Modifier.size(width = w, height = 3.dp).background(Color(0xFF4F46E5)))
    }
}

@Composable
private fun DvoBar(pending: Boolean) {
    val inf = rememberInfiniteTransition(label = "dvoBar")
    val slide by inf.animateFloat(-0.4f, 1f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "slide")
    val flow by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart), label = "flow")
    Box(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 8.dp).height(6.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFFE2E8F0)).drawBehind {
        val w = size.width * 0.4f
        val x = size.width * slide
        val cols = if (pending) listOf(Color(0xFFF59E0B), Color(0xFFFBBF24), Color(0xFFF59E0B)) else listOf(Color(0xFF4F46E5), Color(0xFFF43F5E), Color(0xFF4F46E5))
        val shift = -2f * w * flow
        drawRoundRect(
            Brush.horizontalGradient(cols, startX = x + shift, endX = x + shift + 2f * w, tileMode = androidx.compose.ui.graphics.TileMode.Repeated),
            topLeft = Offset(x, 0f), size = Size(w, size.height), cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()),
        )
    })
}

// =============================================================================================== walletfx (deposit / withdraw)

@Composable
private fun WalletFxOverlay() {
    val fx = AppStore.walletFx ?: return
    key(fx.id) { WalletFxRun(fx) }
}

private class FlyCoin(val jx: Float, val jy: Float, val mx: Float, val my: Float)

@Composable
private fun WalletFxRun(fx: AppStore.WalletFx) {
    val dep = fx.kind == "deposit"
    val old = if (dep) maxOf(0.0, fx.newBal - fx.amount) else fx.newBal + fx.amount
    val density = LocalDensity.current.density

    val show = remember { Animatable(0f) }
    val coinIn = remember { Animatable(0f) }          // transform: scale(0 -> 1)
    val coinFade = remember { Animatable(0f) }        // 0 = normal, 1 = fly/done state (scale .55, alpha .35)
    val leave = remember { Animatable(0f) }           // withdraw: coin flies away
    val pulseT = remember { Animatable(0f) }
    val flyClock = remember { Animatable(0f) }        // ms since the coins started flying
    var flyDir by remember { mutableIntStateOf(0) }   // 1: coin -> pill (deposit) · 2: pill -> coin (withdraw)
    var done by remember { mutableStateOf(false) }
    var ringsOff by remember { mutableStateOf(false) }
    var pulsing by remember { mutableIntStateOf(0) }  // 1 up (green) · 2 down (red)
    var amtShown by remember { mutableStateOf(0.0) }
    var balShown by remember { mutableStateOf(old) }
    var pillCenter by remember { mutableStateOf(Offset.Zero) }
    var bigCenter by remember { mutableStateOf(Offset.Zero) }
    var origin by remember { mutableStateOf(Offset.Zero) }
    val flies = remember { List(10) { FlyCoin(Random.nextFloat() * 30f - 15f, Random.nextFloat() * 30f - 15f, Random.nextFloat() * 120f - 60f, Random.nextFloat() * 60f + 40f) } }
    val isInt = fx.amount % 1.0 == 0.0

    suspend fun count(from: Double, to: Double, ms: Int, set: (Double) -> Unit) {
        val a = Animatable(0f)
        a.animateTo(1f, tween(ms, easing = LinearEasing)) { val p = value.toDouble(); set(from + (to - from) * (1.0 - Math.pow(1.0 - p, 3.0))) }
        set(to)
    }

    LaunchedEffect(Unit) {
        launch { show.animateTo(1f, tween(350)) }
        launch { coinIn.animateTo(1f, tween(600, easing = PopEase)) }
        if (dep) {
            Sfx.play("notification")
            launch { count(0.0, fx.amount, 900) { amtShown = it } }
            delay(1100)
            ringsOff = true
            launch { coinFade.animateTo(1f, tween(700)) }
            flyDir = 1
            launch { flyClock.snapTo(0f); flyClock.animateTo(650f + 9 * 85f, tween(650 + 9 * 85, easing = LinearEasing)) }
            delay(500)
            launch { count(old, fx.newBal, 1300) { balShown = it } }
            pulsing = 1
            launch { repeat(3) { pulseT.snapTo(0f); pulseT.animateTo(1f, tween(500, easing = LinearEasing)) }; pulsing = 0 }
            delay(1100)
            done = true
            try { AppStore.goto(Page.WALLET) } catch (_: Exception) { }
            delay(450)
            show.animateTo(0f, tween(350))
        } else {
            delay(500)
            Sfx.play("withdrawal")
            flyDir = 2
            launch { flyClock.snapTo(0f); flyClock.animateTo(650f + 9 * 85f, tween(650 + 9 * 85, easing = LinearEasing)) }
            launch { count(0.0, fx.amount, 1000) { amtShown = it } }
            delay(350)
            launch { count(old, fx.newBal, 1300) { balShown = it } }
            pulsing = 2
            launch { repeat(3) { pulseT.snapTo(0f); pulseT.animateTo(1f, tween(500, easing = LinearEasing)) }; pulsing = 0 }
            delay(1300)
            done = true
            leave.animateTo(1f, tween(750, easing = CubicBezierEasing(0.5f, 0f, 1f, 0.5f)))
            show.animateTo(0f, tween(350))
        }
        if (AppStore.walletFx?.id == fx.id) AppStore.walletFx = null
    }

    val inf = rememberInfiniteTransition(label = "wfx")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart), label = "spin")
    val ring1 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = androidx.compose.animation.core.LinearOutSlowInEasing), RepeatMode.Restart), label = "r1")
    val ring2 by inf.animateFloat(0f, 1f, infiniteRepeatable(keyframes { durationMillis = 1800; 0f at 0 using LinearEasing; 1f at 1800 }, RepeatMode.Restart, androidx.compose.animation.core.StartOffset(900)), label = "r2")
    val titleIn = remember { Animatable(0f) }; val amtIn = remember { Animatable(0f) }; val subIn = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { delay(150); titleIn.animateTo(1f, tween(500)) }
        launch { delay(250); amtIn.animateTo(1f, tween(500)) }
        launch { delay(350); subIn.animateTo(1f, tween(500)) }
    }

    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val ringCol = if (dep) Color(0x8CFBBF24) else Color(0x99F87171)
    val amtCol = if (dep) Color(0xFF34D399) else Color(0xFFF87171)

    Box(
        Modifier.fillMaxSize()
            .onGloballyPositioned { origin = it.positionInWindow() }
            .graphicsLayer { alpha = show.value }
            .background(Brush.radialGradient(listOf(Color(0xF01E1B4B), Color(0xF8020617)), center = Offset.Unspecified, radius = 1400f))
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(20.dp),
        contentAlignment = Alignment.Center,
    ) {
        // balance pill
        val pillScale = if (pulsing == 0) 1f else if (pulsing == 1) 1f + 0.1f * sin(PI.toFloat() * pulseT.value) else 1f - 0.06f * sin(PI.toFloat() * pulseT.value)
        Row(
            Modifier.align(Alignment.TopCenter).padding(top = maxOf(18.dp, top))
                .graphicsLayer { scaleX = pillScale; scaleY = pillScale }
                .drawBehind { if (pulsing != 0) drawRoundRect(if (pulsing == 1) Color(0xCC10B981).copy(alpha = 0.6f * sin(PI.toFloat() * pulseT.value)) else Color(0xCCEF4444).copy(alpha = 0.6f * sin(PI.toFloat() * pulseT.value)), cornerRadius = androidx.compose.ui.geometry.CornerRadius(40.dp.toPx()), size = size) }
                .clip(RoundedCornerShape(40.dp)).background(Color(0x1FFFFFFF)).border(1.dp, Color(0x40FFFFFF), RoundedCornerShape(40.dp))
                .padding(start = 8.dp, end = 10.dp, top = 7.dp, bottom = 7.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.onGloballyPositioned { pillCenter = it.boundsInWindow().center }) { Coin(30.dp) }
            FText(toFixed(balShown, 2), size = rem(1.05), weight = FontWeight.ExtraBold, color = Color.White, maxLines = 1)
            Box(Modifier.size(22.dp).clip(CircleShape).background(Color(0xFF10B981)), contentAlignment = Alignment.Center) { FText("+", size = rem(1.0), weight = FontWeight.Bold, color = Color.White) }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // stage: rings + coin
            Box(Modifier.size(190.dp).padding(bottom = 0.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(190.dp)) {
                    if (!(dep && ringsOff)) for (p in listOf(ring1, ring2)) {
                        val sc = 0.5f + 1.0f * p
                        drawCircle(ringCol.copy(alpha = ringCol.alpha * 0.9f * (1f - p)), radius = size.minDimension / 2f * sc, style = Stroke(3.dp.toPx()))
                    }
                }
                val cScale = (coinIn.value) * (1f - 0.45f * coinFade.value) * (if (!dep) (1f - 0.6f * leave.value) else 1f)
                val cAlpha = (1f - 0.65f * coinFade.value) * (1f - leave.value)
                Box(
                    Modifier.size(150.dp)
                        .onGloballyPositioned { bigCenter = it.boundsInWindow().center }
                        .graphicsLayer { scaleX = cScale; scaleY = cScale; alpha = cAlpha; translationY = -320.dp.toPx() * leave.value; rotationY = spin; cameraDistance = 14f * density }
                        .drawBehind { drawCircle(Brush.radialGradient(listOf(Color(0x8CFBBF24), Color.Transparent)), radius = size.minDimension * 0.75f) },
                    contentAlignment = Alignment.Center,
                ) { Coin(150.dp) }
            }
            Box(Modifier.height(22.dp))
            FText(
                fx.title ?: (if (dep) "Deposit Successful" else "Withdrawal Requested") + (if (dep && done) " ✓" else ""),
                size = rem(1.35), weight = FontWeight.Black, color = Color.White, align = TextAlign.Center,
                modifier = Modifier.padding(bottom = 6.dp).graphicsLayer { alpha = titleIn.value; translationY = (1f - titleIn.value) * 14.dp.toPx() },
            )
            Row(Modifier.graphicsLayer { alpha = amtIn.value; translationY = (1f - amtIn.value) * 14.dp.toPx() }) {
                FText((if (dep) "+" else "-") + "₹" + (if (isInt) amtShown.toLong().toString() else toFixed(amtShown, 2)), size = rem(2.6), weight = FontWeight.Black, color = amtCol, letterSpacing = 0.5.sp)
            }
            FText(
                fx.sub ?: if (dep) "Adding coins to your wallet…" else "Coins are on the way to your account…",
                size = rem(0.85), color = Color.White, align = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp).graphicsLayer { alpha = if (done) 0f else subIn.value * 0.75f; translationY = (1f - subIn.value) * 14.dp.toPx() },
            )
        }

        // little golden coins flying between the big coin and the balance pill
        if (flyDir != 0) {
            val coinPainter = painterResource(R.drawable.ff_coin)
            Canvas(Modifier.fillMaxSize()) {
                val from = (if (flyDir == 1) bigCenter else pillCenter) - origin
                val to = (if (flyDir == 1) pillCenter else bigCenter) - origin
                val clock = flyClock.value
                flies.forEachIndexed { i, f ->
                    val p = ((clock - i * 85f) / 650f)
                    if (p <= 0f || p >= 1f) return@forEachIndexed
                    val sx = from.x + f.jx.dp.toPx(); val sy = from.y + f.jy.dp.toPx()
                    val ex = to.x; val ey = to.y
                    val mx = (sx + ex) / 2f + f.mx.dp.toPx(); val my = minOf(sy, ey) - f.my.dp.toPx()
                    val x: Float; val y: Float; val sc: Float; val rot: Float; val al: Float
                    if (p < 0.45f) {
                        val k = FlyEase.transform(p / 0.45f)
                        x = sx + (mx - sx) * k; y = sy + (my - sy) * k; sc = 0.5f + 0.6f * k; rot = 200f * k; al = k
                    } else {
                        val k = FlyEase.transform((p - 0.45f) / 0.55f)
                        x = mx + (ex - mx) * k; y = my + (ey - my) * k; sc = 1.1f - 0.55f * k; rot = 200f + 220f * k; al = 1f - 0.1f * k
                    }
                    val sz = 28.dp.toPx()
                    translate(x - sz / 2f, y - sz / 2f) {
                        rotate(rot, pivot = Offset(sz / 2f, sz / 2f)) { scale(sc, sc, pivot = Offset(sz / 2f, sz / 2f)) { with(coinPainter) { draw(Size(sz, sz), alpha = al) } } }
                    }
                }
            }
        }
    }
}
