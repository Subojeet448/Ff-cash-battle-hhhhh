package com.ffcashbattle.app.ui.screens.wallet

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.data.Msg
import com.ffcashbattle.app.data.trxMs
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.NamedImage
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.screens.match.jsNum
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale

const val WEEK_MS = 7L * 24 * 60 * 60 * 1000

/** JS `Number(v).toFixed(dec)`. */
fun toFixed(v: Double, dec: Int): String = String.format(Locale.US, "%.${dec}f", v)

// ===================================================================================== walletfx.tween

class TweenState(val text: String, val bump: Float, val dir: Int)

/**
 * `walletfx.tween`: a number that glides to its new value (900 ms ease-out cubic). The first value is shown instantly (never replays from 0);
 * on a change the host flashes green (up) / red (down) and pops to 1.12x at 30 % of the animation (`.bal-up` / `.bal-down`).
 */
@Composable
fun tweenNumber(target: Double, dec: Int = 2, ms: Int = 900): TweenState {
    var cur by remember { mutableStateOf(target) }
    var first by remember { mutableStateOf(true) }
    var dir by remember { mutableIntStateOf(0) }
    var flash by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(target) {
        if (first) { first = false; cur = target; return@LaunchedEffect }
        val from = cur
        if (from == target) return@LaunchedEffect
        dir = if (target > from) 1 else -1
        launch {
            val a = Animatable(0f)
            a.animateTo(1f, tween(ms, easing = LinearEasing)) {
                val p = value.toDouble()
                val e = 1.0 - Math.pow(1.0 - p, 3.0)
                cur = from + (target - from) * e
            }
            cur = target
        }
        val f = Animatable(0f)
        f.animateTo(1f, tween(900, easing = LinearEasing)) { flash = value }
        delay(ms.toLong() + 300L - 900L)
        dir = 0; flash = 0f
    }
    val bump = if (dir == 0) 0f else { val p = flash; if (p < 0.3f) p / 0.3f else (1f - p) / 0.7f }
    return TweenState(toFixed(cur, dec), bump.coerceIn(0f, 1f), dir)
}

/** Color of the number during a `.bal-up` / `.bal-down` flash (blends from `base`). */
fun TweenState.color(base: Color): Color =
    if (dir == 0 || bump <= 0f) base else androidx.compose.ui.graphics.lerp(base, if (dir > 0) Color(0xFF10B981) else Color(0xFFEF4444), bump)

fun Modifier.tweenPop(t: TweenState): Modifier = graphicsLayer { val s = 1f + 0.12f * t.bump; scaleX = s; scaleY = s }

// ===================================================================================== trx helpers

/** Same formula as the admin panel (so both sides see the same number). */
fun orderNo(t: Doc): String {
    if (t.s("orderNo").isNotEmpty()) return t.s("orderNo")
    val title = t.s("title"); val type = t.s("type"); val k = t.s("kind")
    var p = if (type == "withdraw") "WD" else "DP"
    if (k == "admin_add" || Regex("^(System .* add|Admin credit|🎁)", RegexOption.IGNORE_CASE).containsMatchIn(title)) p = "AD"
    else if (k == "admin_cut" || Regex("^(System .* cut|Admin deduct)", RegexOption.IGNORE_CASE).containsMatchIn(title)) p = "AC"
    else if (k == "prize" || Regex("^Match win", RegexOption.IGNORE_CASE).containsMatchIn(title)) p = "PZ"
    else if (k == "refund" || type == "refund") p = "RF"
    else if (k == "gift") p = "GF"
    else if (type == "game") p = "GM"
    val ms = t.l("createdAt").takeIf { it > 0 } ?: t.trxMs().takeIf { it > 0 } ?: System.currentTimeMillis()
    val cal = Calendar.getInstance().apply { timeInMillis = ms }
    val ymd = cal.get(Calendar.YEAR).toString() + (cal.get(Calendar.MONTH) + 1).toString().padStart(2, '0') + cal.get(Calendar.DAY_OF_MONTH).toString().padStart(2, '0')
    val n = if (p == "DP" || p == "WD") 4 else 6
    val id = t.id.ifEmpty { "XXXXXX" }
    return "$p-$ymd-${id.takeLast(n).uppercase()}"
}

/** Wallet page filter: deposits / withdrawals / refunds and the game-money kinds, last 7 days only. */
fun walletRows(all: List<Doc>): List<Doc> {
    val cutoff = System.currentTimeMillis() - WEEK_MS
    val kinds = setOf("game_win", "game_entry", "game_refund", "gift", "prize", "admin_add", "admin_cut")
    return all.filter { t ->
        val type = t.s("type"); val kind = t.s("kind")
        (type == "deposit" || type == "withdraw" || type == "refund" || kind in kinds) && (t.trxMs().let { it <= 0L || it >= cutoff })
    }
}

/** JS `String(t.amount)`: numbers print without a trailing .0. */
fun rawAmount(t: Doc): String {
    val v = t["amount"]
    return (if (v is Number) jsNum(v.toDouble()) else v?.toString() ?: "").trim()
}

/** Proof share is offered for everything except waiting transactions and plain match entries. */
fun proofEligible(t: Doc): Boolean {
    val d = Msg.describe(t)
    val type = t.s("type").lowercase(); val kind = t.s("kind")
    if (d.status == "pending" || d.status == "processing") return false
    if (type == "game" && kind != "game_win" && kind != "prize" && !Regex("^Match win", RegexOption.IGNORE_CASE).containsMatchIn(t.s("title"))) return false
    return true
}

/** `.trx-status.status-*` colors (light / dark). Returns background to foreground. */
fun statusColors(status: String, dark: Boolean): Pair<Color, Color> = when (status) {
    "success" -> if (dark) Color(0x2910B981) to Color(0xFF34D399) else Color(0xFFDCFCE7) to Color(0xFF16A34A)
    "pending" -> if (dark) Color(0x29F59E0B) to Color(0xFFFBBF24) else Color(0xFFFEF3C7) to Color(0xFFD97706)
    "processing" -> if (dark) Color(0x2E3B82F6) to Color(0xFF60A5FA) else Color(0xFFDBEAFE) to Color(0xFF2563EB)
    "failed", "rejected" -> if (dark) Color(0x29EF4444) to Color(0xFFF87171) else Color(0xFFFEE2E2) to Color(0xFFDC2626)
    "refunded" -> if (dark) Color(0x336366F1) to Color(0xFFA5B4FC) else Color(0xFFE0E7FF) to Color(0xFF4F46E5)
    else -> if (dark) Color(0x29949FB8) to Color(0xFF94A3B8) else Color(0xFFE2E8F0) to Color(0xFF64748B)   // cancelled
}

/** `.trx-note.tone-*` text colors. */
fun noteColor(tone: String, muted: Color): Color = when (tone) {
    "warn" -> Color(0xFFD97706); "info" -> Color(0xFF2563EB); "success" -> Color(0xFF16A34A); "danger" -> Color(0xFFDC2626); else -> muted
}

/** `.td-icon.tone-*`. */
fun toneIconColors(tone: String, dark: Boolean): Pair<Color, Color> = when (tone) {
    "success" -> if (dark) Color(0x2E10B981) to Color(0xFF34D399) else Color(0xFFDCFCE7) to Color(0xFF16A34A)
    "warn" -> if (dark) Color(0x2EF59E0B) to Color(0xFFFBBF24) else Color(0xFFFEF3C7) to Color(0xFFD97706)
    "info" -> if (dark) Color(0x333B82F6) to Color(0xFF60A5FA) else Color(0xFFDBEAFE) to Color(0xFF2563EB)
    "danger" -> if (dark) Color(0x2EEF4444) to Color(0xFFF87171) else Color(0xFFFEE2E2) to Color(0xFFDC2626)
    else -> if (dark) Color(0x2E94A3B8) to Color(0xFF94A3B8) else Color(0xFFE2E8F0) to Color(0xFF64748B)
}

/** `faIcon name` ("fa-circle-check") → the drawable-backed FaIcon class string. */
fun faClass(icon: String): String = "fa-solid $icon"

/** `.trx-status` pill: 0.65rem, uppercase, bold. */
@Composable
fun StatusChip(status: String, label: String, big: Boolean = false, override: Pair<Color, Color>? = null) {
    val c = FF.c
    val (bg, fg) = override ?: statusColors(status, c.isDark)
    Box(
        Modifier.clip(RoundedCornerShape(if (big) 9.dp else 4.dp)).background(bg)
            .padding(horizontal = if (big) 10.dp else 8.dp, vertical = if (big) 4.dp else 2.dp),
    ) {
        FText(label.uppercase(), size = rem(if (big) 0.68 else 0.65), weight = FontWeight.Bold, color = fg, letterSpacing = if (big) 0.3.sp else 0.sp, maxLines = 1)
    }
}

/** Remembers which transactions were already painted — anything newer slides in at the top with a NEW badge (`app._seenTrx`). */
object TrxSeen {
    private var seen: Set<String>? = null
    fun diff(ids: List<String>): Set<String> {
        val prev = seen
        seen = ids.toHashSet()
        return if (prev == null) emptySet() else ids.filter { it !in prev }.toHashSet()
    }
}

// ===================================================================================== the row

/** `app.trxRow`: icon artwork · title/date/note · amount + status chip. Tap opens the detail sheet. */
@Composable
fun TrxRow(t: Doc, fresh: Boolean = false) {
    val c = FF.c
    val d = remember(t) { Msg.describe(t) }
    val type = t.s("type").lowercase(); val kind = t.s("kind"); val title = t.s("title")
    var ic = "coin"
    if (kind == "gift" || Regex("gift", RegexOption.IGNORE_CASE).containsMatchIn(title)) ic = "gift_code"
    else if (kind == "admin_cut" || Regex("^(System .* cut|Admin deduct)", RegexOption.IGNORE_CASE).containsMatchIn(title)) ic = "admin_cut"
    else if (kind == "admin_add" || Regex("^(System .* add|Admin credit)", RegexOption.IGNORE_CASE).containsMatchIn(title)) ic = "admin_add"
    else if (type == "withdraw") ic = "withdraw"
    else if (type == "deposit" || type == "refund") ic = "deposit"
    val method = t.s("method").uppercase()
    val img = when {
        type == "withdraw" && method == "GIFTCARD" -> "wallet_google_play"
        type == "withdraw" && method == "UPI" -> "wallet_upi"
        ic == "coin" -> "ff_coin"
        else -> "wallet_$ic"
    }
    val raw = rawAmount(t)
    val amt = if (raw.contains("₹")) raw else "₹$raw"
    val neg = Regex("^[-−]").containsMatchIn(raw) || ic == "admin_cut" || (type == "withdraw" && !raw.startsWith("+")) || (type == "game" && !raw.startsWith("+") && kind != "game_win")
    val tone = if (d.status == "failed" || d.status == "rejected" || d.status == "cancelled") "muted" else if (neg) "down" else if (ic == "gift_code") "gift" else "up"
    val dark = c.isDark
    val amtColor = when (tone) {
        "up" -> if (dark) Color(0xFF34D399) else Color(0xFF0F9F6E)
        "gift" -> if (dark) Color(0xFF22D3EE) else Color(0xFF0E7D9C)
        "down" -> if (dark) Color(0xFFF87171) else Color(0xFFB91C1C)
        else -> c.textMuted
    }
    val chipOverride = if (tone == "down" && d.status == "success") (if (dark) Color(0x2EEF4444) to Color(0xFFFCA5A5) else Color(0xFFFEE2E2) to Color(0xFFB91C1C)) else null
    val shape = RoundedCornerShape(22.dp)
    val narrow = LocalConfiguration.current.screenWidthDp <= 360

    // tx-new: slide in from the top, then the NEW badge fades after ~3.2 s
    val a = remember { Animatable(if (fresh) 0f else 1f) }
    val badge = remember { Animatable(1f) }
    LaunchedEffect(fresh) {
        if (fresh) {
            launch { a.animateTo(1f, tween(900, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f))) }
            delay(3200); badge.animateTo(0f, tween(800))
        }
    }
    Box(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
        Row(
            Modifier.fillMaxWidth()
                .graphicsLayer { alpha = minOf(1f, a.value * 1.6f); translationY = (1f - a.value) * -26.dp.toPx(); val s = 0.96f + 0.04f * a.value; scaleX = s; scaleY = s }
                .boxShadow(26.dp, Color(0x594F46E5).copy(alpha = if (dark) 0.2f else 0.35f), shape)
                .clip(shape).background(c.bgCard).border(1.dp, c.border, shape)
                .press(0.985f) { AppStore.openModal("modal-trx-detail", t) }
                .padding(start = 10.dp, end = 14.dp, top = 12.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            NamedImage(img, Modifier.size(if (narrow) 52.dp else 66.dp))
            Column(Modifier.weight(1f)) {
                FText(title, size = rem(if (narrow) 0.92 else 1.02), weight = FontWeight.ExtraBold, lineHeight = rem(if (narrow) 0.92 else 1.02) * 1.2f, maxLines = 2, overflow = TextOverflow.Ellipsis)
                FText(t.s("date"), size = rem(0.78), color = c.textMuted, modifier = Modifier.padding(top = 2.dp, bottom = 1.dp))
                if (d.short.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (d.tone == "success") FaIcon("fa-solid fa-check", rem(0.66).value.dp, noteColor(d.tone, c.textMuted))
                        FText(d.short, size = rem(0.78), weight = FontWeight.SemiBold, color = c.textMain)
                    }
                }
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                FText(amt, size = rem(if (narrow) 0.98 else 1.1), weight = FontWeight.Black, color = amtColor, letterSpacing = (-0.2).sp, maxLines = 1)
                StatusChip(d.status, d.label, big = true, override = chipOverride)
            }
        }
        if (fresh && badge.value > 0.01f) {
            Box(
                Modifier.padding(start = 14.dp).graphicsLayer { alpha = badge.value; translationY = -8.dp.toPx() - (1f - badge.value) * 6.dp.toPx() }
                    .boxShadow(14.dp, Color(0x99F43F5E), RoundedCornerShape(8.dp))
                    .clip(RoundedCornerShape(8.dp)).background(Brush.linearGradient(listOf(Color(0xFFF43F5E), Color(0xFFF59E0B))))
                    .padding(horizontal = 8.dp, vertical = 2.dp),
            ) { FText("NEW", size = rem(0.58), weight = FontWeight.Black, color = Color.White, letterSpacing = 0.6.sp) }
        }
    }
}
