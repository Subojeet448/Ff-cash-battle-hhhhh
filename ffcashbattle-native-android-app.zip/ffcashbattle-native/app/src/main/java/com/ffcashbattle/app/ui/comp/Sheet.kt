package com.ffcashbattle.app.ui.comp

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.theme.FF

/** Call to close the current sheet WITH its slide-down animation (falls back to AppStore.closeModal()). */
val LocalSheetClose = compositionLocalOf<() -> Unit> { { AppStore.closeModal() } }

private val SheetEase = CubicBezierEasing(0.2f, 1f, 0.2f, 1f)

/**
 * .modal-wrap + .modal-overlay + .modal-sheet : dimmed overlay and a bottom sheet (radius 28 top, padding 30, handle 44x5,
 * max-height 90% of the screen, slides up in 0.3s). Content scrolls when taller than the sheet.
 *
 * [padding] = CSS padding of the sheet. [handle] = show the grab handle. [center] = small centered popup instead of a bottom sheet
 * (used by #modal-notice / logout style dialogs). [onDismiss] is called after the closing animation (default: AppStore.closeModal()).
 */
@Composable
fun ModalSheet(
    modifier: Modifier = Modifier,
    onDismiss: () -> Unit = { AppStore.closeModal() },
    handle: Boolean = true,
    padding: PaddingValues = PaddingValues(30.dp),
    maxHeightFraction: Float = 0.9f,
    scroll: Boolean = true,
    center: Boolean = false,
    centerWidth: androidx.compose.ui.unit.Dp = 320.dp,
    containerColor: Color? = null,
    dismissOnOverlay: Boolean = true,
    topRadius: androidx.compose.ui.unit.Dp = 28.dp,
    decor: (androidx.compose.ui.graphics.drawscope.DrawScope.() -> Unit)? = null,   // extra background painting (gradients) on top of the sheet colour
    content: @Composable ColumnScope.() -> Unit,
) {
    val c = FF.c
    val state = remember { MutableTransitionState(false).apply { targetState = true } }
    val close: () -> Unit = { state.targetState = false }
    LaunchedEffect(state.currentState, state.targetState) {
        if (!state.targetState && !state.currentState) onDismiss()
    }
    val maxH = (LocalConfiguration.current.screenHeightDp * maxHeightFraction).dp
    val overlay = if (c.isDark) Color(0xA602040C) else Color(0x66000000)

    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(state, enter = fadeIn(tween(300)), exit = fadeOut(tween(300))) {
            Box(Modifier.fillMaxSize().background(overlay).tap(enabled = dismissOnOverlay) { close() })
        }
        Box(Modifier.fillMaxSize().imePadding(), contentAlignment = if (center) Alignment.Center else Alignment.BottomCenter) {
            AnimatedVisibility(
                state,
                enter = if (center) fadeIn(tween(250)) + scaleIn(tween(250), initialScale = 0.9f) else slideInVertically(tween(300, easing = SheetEase)) { it },
                exit = if (center) fadeOut(tween(200)) + scaleOut(tween(200), targetScale = 0.9f) else slideOutVertically(tween(260)) { it },
            ) {
                val shape = if (center) RoundedCornerShape(24.dp) else RoundedCornerShape(topStart = topRadius, topEnd = topRadius)
                CompositionLocalProvider(LocalSheetClose provides close) {
                    Column(
                        modifier
                            .then(if (center) Modifier.width(centerWidth) else Modifier.fillMaxWidth())
                            .heightIn(max = maxH)
                            .clip(shape)
                            .background(containerColor ?: c.bgCard)
                            .then(if (decor != null) Modifier.drawBehind(decor) else Modifier)
                            .tap(enabled = true) { /* swallow taps so the overlay does not close the sheet */ }
                            .then(if (scroll) Modifier.verticalScroll(rememberScrollState()) else Modifier)
                            .then(if (center) Modifier else Modifier.windowInsetsPadding(WindowInsets.navigationBars))
                            .padding(padding),
                    ) {
                        if (handle && !center) SheetHandle()
                        content()
                    }
                }
            }
        }
    }
}

/** .sheet-handle : 44x5, radius 5, centered, margin-bottom 20. */
@Composable
fun SheetHandle() {
    Box(Modifier.fillMaxWidth().padding(bottom = 20.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.width(44.dp).height(5.dp).clip(RoundedCornerShape(5.dp)).background(FF.c.border))
    }
}
