package com.ffcashbattle.app.ui.modals

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.Prefs
import com.ffcashbattle.app.data.Repo
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem

/** One language of the Fair Play Rules (config/rules.langs[]). */
private class RuleLang(val code: String, val label: String, val items: List<String>)

private val DEFAULT_RULES = listOf(
    RuleLang(
        "en", "English",
        listOf(
            "No Emulators Allowed (Mobile Only).", "No Hacks, Scripts, or Team-ups.", "Level 25+ ID Required.",
            "Wait in lobby 5 minutes before start.", "Winners must take Screenshot of Booyah.",
        ),
    ),
)

/** Last list loaded from the admin panel (kept between openings, refreshed at most once a minute — rules.js). */
private object RulesCache {
    var langs: List<RuleLang> = DEFAULT_RULES
    var loadedAt = 0L
}

/** Website `#modal-rules`: "Fair Play Rules" with up to three language tabs. */
@Composable
fun RulesModal() {
    val c = FF.c
    var langs by remember { mutableStateOf(RulesCache.langs) }
    var cur by remember { mutableStateOf(Prefs.str("rules_lang")) }
    if (langs.none { it.code == cur }) cur = langs.first().code

    LaunchedEffect(Unit) {
        if (System.currentTimeMillis() - RulesCache.loadedAt < 60000) return@LaunchedEffect
        try {
            val d = Repo.getDoc("config", "rules")
            val raw = d?.maps("langs").orEmpty()
            if (raw.isNotEmpty()) {
                val parsed = raw.mapNotNull { m ->
                    val items = (m["items"] as? List<*>)?.mapNotNull { it?.toString() }.orEmpty()
                    if (items.isEmpty()) null else RuleLang((m["code"] ?: "").toString(), (m["label"] ?: "").toString(), items)
                }.take(3)
                RulesCache.langs = parsed.ifEmpty { DEFAULT_RULES }
            }
            RulesCache.loadedAt = System.currentTimeMillis()
            langs = RulesCache.langs
        } catch (_: Exception) { }
    }

    ModalSheet {
        val close = LocalSheetClose.current
        Row(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            FaIcon("fa-solid fa-scale-balanced", rem(1.5).value.dp, c.primary)
            FText("Fair Play Rules", size = rem(1.5), weight = FontWeight.Bold)
        }
        if (langs.size > 1) {
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(14.dp)).background(c.bgInput).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (l in langs) {
                    val on = l.code == cur
                    val pop = remember { Animatable(1f) }
                    LaunchedEffect(on) { if (on) { pop.snapTo(0.9f); pop.animateTo(1f, spring(0.45f, Spring.StiffnessMedium)) } }
                    val shape = RoundedCornerShape(11.dp)
                    Box(
                        Modifier.weight(1f).graphicsLayer { scaleX = pop.value; scaleY = pop.value }
                            .then(if (on) Modifier.boxShadow(14.dp, Color(0xB34F46E5), shape) else Modifier)
                            .clip(shape).then(if (on) Modifier.background(c.primary) else Modifier)
                            .press(0.95f) { cur = l.code; Prefs.put("rules_lang", l.code) }.padding(horizontal = 6.dp, vertical = 9.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        FText(l.label, size = rem(0.82), weight = FontWeight.ExtraBold, color = if (on) Color.White else c.textMuted, align = TextAlign.Center, maxLines = 1)
                    }
                }
            }
        }
        val items = (langs.firstOrNull { it.code == cur } ?: langs.first()).items
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.bgInput).padding(15.dp)) {
            items.forEachIndexed { i, text ->
                val a = remember(cur, i) { Animatable(0f) }
                LaunchedEffect(cur, i) { a.animateTo(1f, tween(400, delayMillis = i * 70)) }
                Row(Modifier.fillMaxWidth().graphicsLayer { alpha = a.value; translationX = (a.value - 1f) * 10.dp.toPx() }) {
                    FText("${i + 1}.", size = rem(0.9), lineHeight = rem(0.9) * 1.65f, align = TextAlign.End, modifier = Modifier.width(22.dp).padding(end = 4.dp))
                    FText(text, size = rem(0.9), lineHeight = rem(0.9) * 1.65f, modifier = Modifier.weight(1f).padding(start = 2.dp))
                }
            }
        }
        BtnMain("I Understand", { close() }, Modifier.fillMaxWidth().padding(top = 20.dp))
    }
}
