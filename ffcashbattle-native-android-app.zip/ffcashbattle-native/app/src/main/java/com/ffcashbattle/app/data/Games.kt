package com.ffcashbattle.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.ffcashbattle.app.state.AppStore

/**
 * Admin can switch each game ON/OFF (Admin panel -> Coin Battle / Bomb & Gems). The switch is mirrored to config/games
 * (1 tiny read, cached 60 s) — port of loadFlags() in pages/game/ball.js.
 */
object Games {
    var ball by mutableStateOf(true)
    var bomb by mutableStateOf(true)
    private var loadedAt = 0L

    suspend fun load(force: Boolean = false) {
        if (!force && System.currentTimeMillis() - loadedAt < 60_000L) return
        loadedAt = System.currentTimeMillis()
        try {
            val d = Repo.getDoc("config", "games")
            ball = d?.get("ball") != false
            bomb = d?.get("bomb") != false
        } catch (_: Exception) { }
    }

    /** ballGame.open() / bombGame.open(): needs login and the game switched on. */
    fun open(which: String) {
        val on = if (which == "bomb") bomb else ball
        if (!on) { AppStore.toast((if (which == "bomb") "Bomb & Gems" else "Coin Battle") + " is switched off right now"); return }
        if (!AppStore.loggedIn) { AppStore.checkLogin { open(which) }; return }
        AppStore.gameOpen = which
    }
}
