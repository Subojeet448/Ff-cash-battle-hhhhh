package com.ffcashbattle.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.key
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.Faq
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FRich
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay

/** Small floating "FAQ" chip above the bottom bar (components/faq: `.faq-fab`). Hidden in chat / games. */
@Composable
fun FaqLayer() {
    val c = FF.c
    var ready by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(800); ready = true }                       // the website adds it 0.8 s after boot
    val hide = AppStore.chatOpen || AppStore.gameOpen != null
    val nav = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    AnimatedVisibility(
        visible = ready && !hide, modifier = Modifier.fillMaxSize(),
        enter = fadeIn(tween(250)) + scaleIn(tween(250), 0.85f), exit = fadeOut(tween(150)) + scaleOut(tween(150), 0.85f),
    ) {
        Box(Modifier.fillMaxSize().padding(start = 12.dp, bottom = 65.dp + nav + 12.dp), contentAlignment = Alignment.BottomStart) {
            val shape = RoundedCornerShape(99.dp)
            Row(
                Modifier.graphicsLayer { alpha = 0.92f }.shadow(5.dp, shape, ambientColor = Color(0x26151F36), spotColor = Color(0x26151F36))
                    .clip(shape).background(c.bgCard).border(1.dp, c.border, shape)
                    .press(0.92f) { Faq.open() }.height(30.dp).padding(horizontal = 11.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically,
            ) {
                FaIcon("fa-solid fa-circle-question", rem(0.8).value.dp, c.primary)
                FText("FAQ", size = rem(0.72), weight = FontWeight.ExtraBold, color = c.primary, letterSpacing = 0.3.sp)
            }
        }
    }
}

/** The small "FAQ" chip put next to the ✕ of the Add Money / Withdraw / Transfer / Join popups (`.faq-chip`). */
@Composable
fun FaqChip(topic: String, modifier: Modifier = Modifier) {
    val c = FF.c
    val shape = RoundedCornerShape(99.dp)
    Row(
        modifier.clip(shape).background(c.primaryLight).border(1.dp, c.border, shape).press(0.92f) { Faq.open(topic) }.height(28.dp).padding(horizontal = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        FaIcon("fa-solid fa-circle-question", rem(0.8).value.dp, c.primary)
        FText("FAQ", size = rem(0.7), weight = FontWeight.ExtraBold, color = c.primary)
    }
}

/** The FAQ bottom sheet (`#faq-wrap`). Mounted above the modals so every popup can open it. */
@Composable
fun FaqSheet() {
    val key = Faq.current ?: return
    key(key) {
        ModalSheet(
            onDismiss = { Faq.close() }, handle = false, topRadius = 24.dp, maxHeightFraction = 0.82f,
            padding = PaddingValues(start = 18.dp, top = 14.dp, end = 18.dp, bottom = 22.dp),
        ) {
            val c = FF.c
            val close = LocalSheetClose.current
            Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    FaIcon("fa-solid fa-circle-question", rem(1.05).value.dp, c.primary)
                    FText("FAQ · " + Faq.title(key), size = rem(1.05), weight = FontWeight.Black)
                }
                Box(Modifier.size(32.dp).clip(CircleShape).background(c.bgInput).press(0.9f) { close() }, contentAlignment = Alignment.Center) {
                    FaIcon("fa-solid fa-xmark", rem(1.0).value.dp, c.textMuted)
                }
            }
            val items = remember(key) { Faq.items(key) }
            val open: SnapshotStateList<Int> = remember(key) { mutableStateListOf() }
            if (items.isEmpty()) FText("Nothing here yet.", color = c.textMuted, modifier = Modifier.padding(vertical = 8.dp))
            items.forEachIndexed { i, (q, a) -> FaqItem(i, q, a, i in open, last = i == items.lastIndex) { if (i in open) open.remove(i) else open.add(i) } }
        }
    }
}

/** One `<details>` row: question with a "+" that turns into "×", answer sliding in. */
@Composable
fun FaqItem(index: Int, q: String, a: String, open: Boolean, last: Boolean, onToggle: () -> Unit) {
    val c = FF.c
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(minOf(index, 4) * 50L); enter.animateTo(1f, tween(400)) }
    val rot = remember { Animatable(0f) }
    LaunchedEffect(open) { rot.animateTo(if (open) 45f else 0f, tween(200)) }
    Column(
        Modifier.fillMaxWidth().graphicsLayer { alpha = enter.value; translationY = (1f - enter.value) * 8.dp.toPx() }
            .drawBehind { if (!last) drawRect(c.border, Offset(0f, size.height - 1.dp.toPx()), Size(size.width, 1.dp.toPx())) },
    ) {
        Box(Modifier.fillMaxWidth().press(1f) { onToggle() }.padding(top = 13.dp, bottom = 13.dp, end = 28.dp)) {
            FText(q, size = rem(0.9), weight = FontWeight.Bold, lineHeight = rem(0.9) * 1.4f, modifier = Modifier.fillMaxWidth())
            FText("+", size = rem(1.4), color = c.primary, modifier = Modifier.align(Alignment.TopEnd).padding(top = 0.dp).graphicsLayer { rotationZ = rot.value })
        }
        AnimatedVisibility(open, enter = fadeIn(tween(300)), exit = fadeOut(tween(120))) {
            FRich(a, Modifier.fillMaxWidth().padding(bottom = 13.dp), size = rem(0.84), color = c.textMuted, boldColor = c.textMain, lineHeight = rem(0.84) * 1.6f)
        }
    }
}
