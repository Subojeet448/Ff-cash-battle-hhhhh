package com.ffcashbattle.app.ui.shell

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.Sfx
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.state.Page
import com.ffcashbattle.app.ui.comp.Coin
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import java.util.Calendar

/**
 * `<header>` — 65dp (+ status bar), gear · brand + live clock · bell + wallet pill.
 * Final cascade values (header.css + polish.css + gamefx.css): bg-card @84%, 2dp gradient line under it, padding 0 20 (12 on narrow phones).
 */
@Composable
fun AppHeader(modifier: Modifier = Modifier) {
    val c = FF.c
    val w = LocalConfiguration.current.screenWidthDp
    val narrow = w <= 380
    val hPad = if (narrow) 12.dp else 20.dp
    val statusTop = WindowInsets.statusBars

    Box(
        modifier
            .fillMaxWidth()
            .boxShadow(10.dp, Color(0x08000000))
            .background(c.bgCard.copy(alpha = 0.95f))
            .drawBehind {
                val h = 2.dp.toPx()
                drawRect(
                    Brush.horizontalGradient(listOf(Color.Transparent, c.primary, Color(0xFFF43F5E), Color.Transparent)),
                    topLeft = Offset(0f, size.height - h), size = androidx.compose.ui.geometry.Size(size.width, h), alpha = 0.55f,
                )
            },
    ) {
        Row(
            Modifier.fillMaxWidth().windowInsetsPadding(statusTop).height(ShellDims.headerBase).padding(horizontal = hPad),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Gear()
            Brand(w)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Bell()
                WalletPill(narrow)
            }
        }
    }
}

/** Gear: tapping spins it once (gear-spin), plays the settings sound and toggles the drawer. */
@Composable
private fun Gear() {
    var spin by remember { mutableStateOf(0) }
    val rot by animateFloatAsState(spin * 360f, tween(600, easing = FastOutSlowInEasing), label = "gear")
    Box(Modifier.tap {
        spin += 1
        Sfx.play("settings")
        AppStore.toggleDrawer()
    }, contentAlignment = Alignment.Center) {
        FaIcon("fa-solid fa-gear", rem(1.5).value.dp, FF.c.primary, Modifier.graphicsLayer { rotationZ = rot })
    }
}

@Composable
private fun Brand(w: Int) {
    val size = when { w <= 340 -> rem(0.9); w <= 380 -> rem(1.02); else -> rem(1.35) }
    val inf = rememberInfiniteTransition(label = "brand")
    val shift by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(6000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "brandShift")
    val span = 300f
    val brush = Brush.linearGradient(
        listOf(Color(0xFF4F46E5), Color(0xFFF43F5E)),
        start = Offset(shift * span * 0.6f, 0f), end = Offset(shift * span * 0.6f + span, span * 0.25f), tileMode = TileMode.Mirror,
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FText(
            "FF Cash Battle", size = size, weight = FontWeight.Black, brush = brush,
            letterSpacing = if (w <= 380) (-0.2).sp else 0.3.sp, softWrap = false, maxLines = 1, lineHeight = size * 1.15f,
        )
        Clock()
    }
}

@Composable
private fun Clock() {
    var t by remember { mutableStateOf(clockText()) }
    LaunchedEffect(Unit) {
        while (true) {
            t = clockText()
            kotlinx.coroutines.delay(1000L - (System.currentTimeMillis() % 1000L))
        }
    }
    FText(t, size = rem(0.7), weight = FontWeight.SemiBold, color = FF.c.textMuted, mono = true, lineHeight = rem(0.7) * 1.15f)
}

private fun clockText(): String {
    val d = Calendar.getInstance()
    fun p(n: Int) = if (n < 10) "0$n" else "$n"
    return "${p(d.get(Calendar.HOUR_OF_DAY))}:${p(d.get(Calendar.MINUTE))}:${p(d.get(Calendar.SECOND))}"
}

/** `.notification-btn` — bell (1.2rem, padding 5) with the red 8dp pulsing `.notif-dot` (top 2, right 2, 1px white border). */
@Composable
private fun Bell() {
    val inf = rememberInfiniteTransition(label = "dot")
    val pulse by inf.animateFloat(1f, 1.25f, infiniteRepeatable(tween(800, easing = LinearEasing), RepeatMode.Reverse), label = "dotPulse")
    var shake by remember { mutableStateOf(0) }
    var swing by remember { mutableStateOf(0f) }
    val sw by animateFloatAsState(swing, spring(Spring.DampingRatioHighBouncy, Spring.StiffnessMediumLow), label = "swing")
    LaunchedEffect(shake) { if (shake > 0) { swing = 18f; kotlinx.coroutines.delay(60); swing = 0f } }

    Box(Modifier.press(0.88f) {
        shake += 1
        Sfx.play("notification")
        AppStore.notifDot = false
        AppStore.openModal("modal-notifications")
    }.padding(5.dp)) {
        FaIcon("fa-regular fa-bell", rem(1.2).value.dp, FF.c.textMain, Modifier.graphicsLayer { rotationZ = sw })
        if (AppStore.notifDot) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(top = (-3).dp, end = (-3).dp)
                    .graphicsLayer { scaleX = pulse; scaleY = pulse }
                    .size(8.dp).clip(CircleShape).background(FF.c.danger).border(1.dp, Color.White, CircleShape),
            )
        }
    }
}

/** `.wallet-pill` — coin + balance + green "+" bubble. */
@Composable
private fun WalletPill(narrow: Boolean) {
    val c = FF.c
    val coins = AppStore.headerCoins
    // bal-fx: the number pops when it changes
    var prev by remember { mutableStateOf(coins) }
    var pop by remember { mutableStateOf(false) }
    LaunchedEffect(coins) {
        if (coins != prev) { prev = coins; pop = true; kotlinx.coroutines.delay(450); pop = false }
    }
    val scale by animateFloatAsState(if (pop) 1.18f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "pop")
    val inf = rememberInfiniteTransition(label = "plus")
    val plusScale by inf.animateFloat(1f, 1.1f, infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "plusPulse")

    Row(
        Modifier
            .press(0.95f) { AppStore.checkLogin { AppStore.goto(Page.WALLET) } }
            .clip(RoundedCornerShape(30.dp))
            .background(c.bgInput)
            .border(1.dp, c.border, RoundedCornerShape(30.dp))
            .padding(horizontal = if (narrow) 8.dp else 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Coin(18.dp)
        FText(
            coins, size = rem(0.9), weight = FontWeight.Bold,
            color = if (pop) c.success else c.textMain, maxLines = 1,
            modifier = Modifier.graphicsLayer { scaleX = scale; scaleY = scale },
        )
        Box(
            Modifier.padding(start = 2.dp)
                .graphicsLayer { scaleX = plusScale; scaleY = plusScale }
                .boxShadow(8.dp, Color(0x7310B981), CircleShape)
                .size(22.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF059669))))
                .tap { AppStore.checkLogin { AppStore.openModal("modal-deposit") } },
            contentAlignment = Alignment.Center,
        ) { FText("+", size = rem(1.0), weight = FontWeight.Black, color = Color.White, lineHeight = rem(1.0)) }
    }
}
