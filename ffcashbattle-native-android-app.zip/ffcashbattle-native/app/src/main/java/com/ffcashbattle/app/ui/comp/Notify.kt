package com.ffcashbattle.app.ui.comp

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.state.NotifyCard
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem

/** `#toast` — the dark pill above the bottom nav (bottom:100px, padding 12x24, radius 50, white text, green check). */
@Composable
fun ToastHost() {
    val msg = AppStore.toastMsg
    Box(Modifier.fillMaxSize().padding(bottom = 100.dp), contentAlignment = Alignment.BottomCenter) {
        AnimatedVisibility(
            visible = msg != null,
            enter = fadeIn(tween(250)) + slideInVertically(tween(350)) { 20 },
            exit = fadeOut(tween(250)) + slideOutVertically(tween(250)) { 20 },
        ) {
            val last = remember { arrayOf("") }
            if (msg != null) last[0] = msg
            Row(
                Modifier.boxShadow(30.dp, Color(0x40000000), RoundedCornerShape(50.dp)).clip(RoundedCornerShape(50.dp)).background(Color(0xFF1E293B)).padding(horizontal = 24.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                FaIcon("fa-solid fa-circle-check", rem(1.0).value.dp, FF.c.success)
                FText(last[0], size = rem(1.0), color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 280.dp))
            }
        }
    }
}

/** `#notify-stack` — top-right stackable cards: left accent bar, round icon, title, message, close x, shrinking progress bar. */
@Composable
fun NotifyStack() {
    Box(Modifier.fillMaxSize().statusBarsPadding().padding(top = 12.dp, end = 12.dp, start = 12.dp), contentAlignment = Alignment.TopEnd) {
        Column(Modifier.widthIn(max = 340.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            for (n in AppStore.notifies.toList()) {
                androidx.compose.runtime.key(n.id) { NotifyCardView(n) }
            }
        }
    }
}

@Composable
fun NotifyCardView(n: NotifyCard) {
    val c = FF.c
    val accent = when (n.type) { "error" -> Color(0xFFEF4444); "info" -> Color(0xFF4F46E5); else -> Color(0xFF10B981) }
    val icon = when (n.type) { "error" -> "fa-circle-xmark"; "info" -> "fa-circle-info"; else -> "fa-circle-check" }
    val visible = remember { MutableTransitionState(false).apply { targetState = true } }
    val progress by animateFloatAsState(if (visible.currentState) 0f else 1f, tween(n.durationMs.toInt(), easing = LinearEasing), label = "bar")
    val shape = RoundedCornerShape(14.dp)
    AnimatedVisibility(visible, enter = slideInHorizontally(tween(400, easing = CubicBezierEasing(0.34f, 1.4f, 0.64f, 1f))) { it } + fadeIn(tween(250)), exit = slideOutHorizontally(tween(280)) { it } + fadeOut(tween(280))) {
        Box(
            Modifier.fillMaxWidth()
                .boxShadow(32.dp, Color(0x38_0F172A), shape)
                .clip(shape)
                .background(c.bgCard)
                .border(1.dp, c.border, shape)
                .drawBehind {
                    drawRect(accent, size = Size(4.dp.toPx(), size.height))                       // border-left:4px
                    drawRect(accent, topLeft = androidx.compose.ui.geometry.Offset(0f, size.height - 3.dp.toPx()), size = Size(size.width * progress, 3.dp.toPx()))   // .notify-bar
                },
        ) {
            Row(Modifier.padding(start = 13.dp + 4.dp, top = 13.dp, end = 38.dp, bottom = 15.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.size(34.dp).clip(CircleShape).background(accent.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                    FaIcon("fa-solid $icon", rem(1.05).value.dp, accent)
                }
                Column(Modifier.weight(1f)) {
                    FText(n.title, size = rem(0.92), weight = FontWeight.ExtraBold, color = c.textMain, lineHeight = rem(0.92) * 1.25f)
                    FText(n.message, size = rem(0.8), color = c.textMuted, lineHeight = rem(0.8) * 1.4f, modifier = Modifier.padding(top = 2.dp))
                }
            }
            Box(
                Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 8.dp).size(26.dp).clip(CircleShape).tap { AppStore.dismissNotify(n) },
                contentAlignment = Alignment.Center,
            ) { FaIcon("fa-solid fa-xmark", rem(0.85).value.dp, c.textMuted) }
        }
    }
}
