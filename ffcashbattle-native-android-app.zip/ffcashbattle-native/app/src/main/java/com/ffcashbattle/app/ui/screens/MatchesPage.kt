package com.ffcashbattle.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.screens.match.HistoryCard
import com.ffcashbattle.app.ui.screens.match.HistorySummary
import com.ffcashbattle.app.ui.screens.match.MxEmpty
import com.ffcashbattle.app.ui.screens.match.UpcomingCard
import com.ffcashbattle.app.ui.screens.match.matchStartMs
import com.ffcashbattle.app.ui.screens.match.rememberNow
import com.ffcashbattle.app.ui.shell.LocalPagePadding
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem

/** `#page-matches` — "My Matches": Join Match (room ID / password) and History tabs. */
@Composable
fun MatchesPage() {
    val c = FF.c
    val now by rememberNow()
    val tab = AppStore.matchesTab
    val history = tab == "history"
    val myUid = AppStore.uid ?: ""

    // `loadMyCompleted` — History pulls my older matches once (re-render happens through AppStore.matches)
    LaunchedEffect(history, AppStore.joinedIds.size) { if (history) AppStore.loadMyCompleted() }

    val mine = AppStore.matches.filter { it.id in AppStore.joinedIds }
    val hist = mine.filter { it.s("status") == "completed" }.sortedByDescending { matchStartMs(it) }
    val data = if (history) hist else mine.filter { it.s("status") != "completed" }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = LocalPagePadding.current) {
        item(key = "head") {
            Column(Modifier.padding(start = 20.dp, top = 20.dp, end = 20.dp, bottom = 10.dp)) {
                FText("My Matches", size = rem(1.5), weight = FontWeight.Bold)
                FText("Track your games", color = c.textMuted)
            }
        }
        item(key = "tabs") {
            val shape = RoundedCornerShape(14.dp)
            Row(
                Modifier.padding(start = 20.dp, end = 20.dp, bottom = 18.dp).fillMaxWidth().clip(shape).background(c.bgCard).border(1.dp, c.border, shape).padding(5.dp),
            ) {
                for ((tk, label, icon) in listOf(Triple("join", "Join Match", "fa-solid fa-gamepad"), Triple("history", "History", "fa-solid fa-clock-rotate-left"))) {
                    val on = tab == tk
                    Row(
                        Modifier.weight(1f).press(0.97f) { AppStore.matchesTab = tk }.clip(RoundedCornerShape(10.dp))
                            .background(if (on) c.primaryLight else androidx.compose.ui.graphics.Color.Transparent).padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically,
                    ) {
                        FaIcon(icon, rem(0.9).value.dp, if (on) c.primary else c.textMuted)
                        FText(label, size = rem(0.9), weight = if (on) FontWeight.Bold else FontWeight.SemiBold, color = if (on) c.primary else c.textMuted)
                    }
                }
            }
        }
        if (data.isEmpty()) {
            item(key = "empty-$tab") { MxEmpty(history) }
        } else {
            if (history) item(key = "summary") { HistorySummary(hist, myUid) }
            itemsIndexed(data, key = { _, m -> tab + m.id }) { i, m ->
                if (history) HistoryCard(m, myUid, i, now) else UpcomingCard(m, myUid, i, now)
            }
        }
        item(key = "tail") { Box(Modifier.padding(bottom = 20.dp)) }
    }
}
