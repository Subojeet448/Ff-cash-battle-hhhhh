package com.ffcashbattle.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.AuthFlow
import com.ffcashbattle.app.data.Cfg
import com.ffcashbattle.app.data.GoogleRes
import com.ffcashbattle.app.data.LoginRes
import com.ffcashbattle.app.data.Prefs
import com.ffcashbattle.app.data.VerifyView
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FRich
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.NamedImage
import com.ffcashbattle.app.ui.comp.SpinIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** All text the user typed + busy flags: kept outside the form composables so switching Login <-> Sign Up keeps what was typed (like the website). */
private class AuthUi {
    var lEmail by mutableStateOf("")
    var lPass by mutableStateOf("")
    var rName by mutableStateOf("")
    var rPhone by mutableStateOf("")
    var rEmail by mutableStateOf("")
    var rRef by mutableStateOf(Prefs.str("ffcb_ref").filter { it.isDigit() }.take(12))
    var rPass by mutableStateOf("")
    var busyLogin by mutableStateOf(false)
    var busyReg by mutableStateOf(false)
    var busyGoogle by mutableStateOf(false)
    var bad by mutableStateOf(emptySet<String>())
    var shakeTick by mutableIntStateOf(0)
    var done by mutableStateOf<Pair<String, String>?>(null)
}

/** Website `#auth-modal-wrapper`: the Login / Sign Up card on the dark animated backdrop. */
@Composable
fun AuthScreen() {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val ui = remember { AuthUi() }
    val tab = if (AppStore.authTab == "register") "register" else "login"
    LaunchedEffect(AuthFlow.loginPrefill) {
        if (AuthFlow.loginPrefill.isNotEmpty()) { ui.lEmail = AuthFlow.loginPrefill; ui.lPass = ""; AuthFlow.loginPrefill = "" }
    }
    LaunchedEffect(Unit) {
        AuthFlow.verifyReset()
        if (AppStore.authTab == "forgot") { AppStore.authTab = "login"; AuthFlow.fpForgot("") }
    }

    fun fail(vararg ids: String) { ui.bad = ids.toSet(); ui.shakeTick++; haptic.performHapticFeedback(HapticFeedbackType.LongPress) }

    val login: () -> Unit = {
        val email = ui.lEmail.trim(); val pass = ui.lPass
        if (email.isEmpty() || pass.isEmpty()) {
            fail(*listOfNotNull(if (email.isEmpty()) "lEmail" else null, if (pass.isEmpty()) "lPass" else null).toTypedArray())
            AppStore.toast("Fill all fields")
        } else if (!ui.busyLogin) {
            ui.busyLogin = true
            AppStore.scope.launch {
                when (val r = AuthFlow.login(email, pass)) {
                    is LoginRes.Ok -> {
                        ui.done = "Welcome back!" to "Logging you in…"
                        delay(1250)
                        AppStore.authOpen = false; ui.lPass = ""
                        AuthFlow.showWelcome(r.name, "Login successful")
                    }
                    is LoginRes.NeedsVerify -> {
                        ui.busyLogin = false; fail("lEmail")
                        AppStore.notify(
                            "info", if (r.sent) "Verification link sent" else "Verify your email first",
                            (if (r.sent) "We have sent a new verification link to your email. " else "Please use the verification link we already sent. ") + "Open it to verify, and also check your Spam / Junk folder.", 9000,
                        )
                    }
                    is LoginRes.Fail -> { ui.busyLogin = false; fail("lEmail", "lPass"); AppStore.toast(r.message) }
                }
            }
        }
    }
    val register: () -> Unit = {
        val name = ui.rName; val phone = ui.rPhone; val email = ui.rEmail.trim(); val pass = ui.rPass
        if (name.isBlank() || email.isEmpty() || pass.isEmpty() || phone.isEmpty()) {
            fail(*listOfNotNull(if (name.isBlank()) "rName" else null, if (phone.isEmpty()) "rPhone" else null, if (email.isEmpty()) "rEmail" else null, if (pass.isEmpty()) "rPass" else null).toTypedArray())
            AppStore.toast("Please fill in all the fields to create your account.")
        } else if (phone.length < 10) {
            fail("rPhone"); AppStore.toast("Please enter a valid 10-digit phone number.")
        } else if (!ui.busyReg) {
            ui.busyReg = true
            AppStore.scope.launch {
                val err = AuthFlow.register(name, phone, email, pass, ui.rRef)
                ui.busyReg = false
                if (err != null) { fail("rEmail", "rPass"); AppStore.toast(err) }
            }
        }
    }
    val google: () -> Unit = {
        if (!ui.busyGoogle) {
            ui.busyGoogle = true
            AppStore.scope.launch {
                when (val r = AuthFlow.google(ctx)) {
                    is GoogleRes.Ok -> {
                        ui.done = "Welcome!" to "Logging you in…"
                        delay(1250)
                        AppStore.authOpen = false
                        AuthFlow.showWelcome(r.name, "Google login successful")
                    }
                    GoogleRes.Cancelled -> ui.busyGoogle = false
                    is GoogleRes.Fail -> { ui.busyGoogle = false; fail(); AppStore.toast(r.message) }
                }
            }
        }
    }
    val verifyAction: () -> Unit = {
        AppStore.scope.launch {
            val st = AuthFlow.verifyAction()
            ui.busyReg = false
            if (st == "ok") { if (ui.rEmail.isNotEmpty()) ui.lEmail = ui.rEmail; ui.rPass = ""; AppStore.authTab = "login" }
            else if (st == "expired") { ui.rPass = ""; AppStore.authTab = "register" }
        }
    }

    AuthBackdrop(Modifier.fillMaxSize()) {
        BoxWithConstraints(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            val minH = maxHeight
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).heightIn(min = minH).padding(25.dp),
                verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                AuthCard(ui, tab, login, register, google, verifyAction)
            }
        }
    }
}

@Composable
private fun AuthCard(ui: AuthUi, tab: String, login: () -> Unit, register: () -> Unit, google: () -> Unit, verifyAction: () -> Unit) {
    val c = FF.c
    val shape = RoundedCornerShape(28.dp)
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) { enter.animateTo(1f, tween(650, easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f))) }
    val shake = remember { Animatable(0f) }
    LaunchedEffect(ui.shakeTick) { if (ui.shakeTick > 0) { shake.snapTo(0f); shake.animateTo(1f, tween(450, easing = LinearEasing)) } }
    val float by rememberInfiniteTransition(label = "logo").animateFloat(0f, 1f, infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Reverse), label = "f")

    Box(
        Modifier.widthIn(max = 400.dp).fillMaxWidth()
            .graphicsLayer {
                val e = enter.value
                translationY = (1f - e) * 70.dp.toPx(); scaleX = 0.92f + 0.08f * e; scaleY = 0.92f + 0.08f * e
                alpha = (e * 2.2f).coerceIn(0f, 1f)
                translationX = shakeOffset(shake.value, 8.dp.toPx())
            }
            .boxShadow(70.dp, Color(0x73000000), shape)
            .clip(shape).background(if (c.isDark) Color(0xF71E293B) else Color(0xF5FFFFFF)),
    ) {
        AuthTopBar(Modifier.align(Alignment.TopStart))
        Column(Modifier.fillMaxWidth().padding(start = 26.dp, top = 32.dp, end = 26.dp, bottom = 26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            FadeUp(120) {
                NamedImage("logo", Modifier.padding(bottom = 14.dp).size(92.dp).graphicsLayer { translationY = -6.dp.toPx() * float }.clip(RoundedCornerShape(26.dp)))
            }
            FadeUp(200) {
                FText(
                    "FF Cash Battle", size = rem(1.8), weight = FontWeight.Black, align = TextAlign.Center,
                    brush = Brush.horizontalGradient(listOf(c.primary, c.accent, c.primary)), modifier = Modifier.padding(bottom = 4.dp),
                )
            }
            FadeUp(260) {
                AnimatedContent(tab, transitionSpec = { fadeIn(tween(160, 160)) togetherWith fadeOut(tween(160)) }, label = "sub") { t ->
                    FText(
                        if (t == "register") "Create your account & start winning" else "Login to play matches & win", size = rem(0.92), color = c.textMuted,
                        align = TextAlign.Center, modifier = Modifier.padding(bottom = 18.dp),
                    )
                }
            }
            FadeUp(320) { AuthTabs(tab) { AppStore.authTab = it } }
            FadeUp(380) {
                AnimatedContent(
                    targetState = tab,
                    transitionSpec = {
                        val r = targetState == "register"
                        (fadeIn(tween(460, 170, CubicBezierEasing(0.22f, 1f, 0.36f, 1f))) + slideInHorizontally(tween(460, 170, CubicBezierEasing(0.22f, 1f, 0.36f, 1f))) { w -> if (r) w / 10 else -w / 10 }) togetherWith
                            (fadeOut(tween(170)) + scaleOut(tween(170), 0.97f)) using SizeTransform(clip = false)
                    },
                    label = "forms",
                ) { t ->
                    if (t == "register") RegisterForm(ui, register, google) else LoginForm(ui, login, google)
                }
            }
        }

        // close
        Box(
            Modifier.align(Alignment.TopEnd).padding(top = 16.dp, end = 16.dp).size(34.dp).clip(CircleShape).background(c.bgInput)
                .press(0.88f) { AppStore.authOpen = false; AuthFlow.verifyReset() },
            contentAlignment = Alignment.Center,
        ) { FaIcon("fa-solid fa-xmark", rem(1.2).value.dp, c.textMuted) }

        VerifyOverlay(AuthFlow.verify, AuthFlow.verifyLeft, verifyAction)
        ui.done?.let { DoneOverlay(it.first, it.second) }
    }
}

/** `.auth-tabs` — two tabs with a sliding white pill. */
@Composable
private fun AuthTabs(tab: String, onTab: (String) -> Unit) {
    val c = FF.c
    val pos = remember { Animatable(if (tab == "register") 1f else 0f) }
    LaunchedEffect(tab) { pos.animateTo(if (tab == "register") 1f else 0f, tween(500, easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f))) }
    Row(
        Modifier.fillMaxWidth().padding(bottom = 20.dp).clip(RoundedCornerShape(15.dp)).background(c.bgInput)
            .drawBehind {
                val pad = 4.dp.toPx(); val w = (size.width - pad * 2) / 2f
                val x = pad + w * pos.value
                drawRoundRect(if (c.isDark) Color(0xFF475569) else Color.White, Offset(x, pad), Size(w, size.height - pad * 2), CornerRadius(12.dp.toPx()))
            }.padding(4.dp),
    ) {
        for ((id, label) in listOf("login" to "Login", "register" to "Sign Up")) {
            Box(Modifier.weight(1f).press(0.97f) { onTab(id) }.padding(horizontal = 8.dp, vertical = 11.dp), contentAlignment = Alignment.Center) {
                FText(label, size = rem(0.92), weight = FontWeight.Bold, color = if (tab == id) (if (c.isDark) Color(0xFFC7D2FE) else c.primary) else c.textMuted)
            }
        }
    }
}

@Composable
private fun LoginForm(ui: AuthUi, login: () -> Unit, google: () -> Unit) {
    val c = FF.c
    Column(Modifier.fillMaxWidth()) {
        AuthInput(ui.lEmail, { ui.lEmail = it; ui.bad = ui.bad - "lEmail" }, "Email Address", "fa-solid fa-envelope", keyboardType = KeyboardType.Email, invalid = "lEmail" in ui.bad)
        AuthInput(ui.lPass, { ui.lPass = it; ui.bad = ui.bad - "lPass" }, "Password", "fa-solid fa-lock", eye = true, invalid = "lPass" in ui.bad, imeAction = ImeAction.Done, onDone = login)
        AuthButton("Login Now", ui.busyLogin, "Signing in...", login)
        OrDivider()
        GoogleButton(ui.busyGoogle, google)
        Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) {
            FText("Forgot Password?", size = rem(0.9), weight = FontWeight.Bold, color = c.primary, modifier = Modifier.press(0.96f) { AuthFlow.fpForgot(ui.lEmail) })
        }
        Row(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.Center) {
            FText("Don't have an account? ", size = rem(0.9), color = c.textMuted)
            FText("Sign Up", size = rem(0.9), weight = FontWeight.Bold, color = c.primary, modifier = Modifier.press(0.96f) { AppStore.authTab = "register" })
        }
    }
}

@Composable
private fun RegisterForm(ui: AuthUi, register: () -> Unit, google: () -> Unit) {
    val c = FF.c
    Column(Modifier.fillMaxWidth()) {
        AuthInput(ui.rName, { ui.rName = it; ui.bad = ui.bad - "rName" }, "Full Name", "fa-solid fa-user", invalid = "rName" in ui.bad)
        AuthInput(ui.rPhone, { ui.rPhone = it.filter { ch -> ch.isDigit() }.take(15); ui.bad = ui.bad - "rPhone" }, "Phone", "fa-solid fa-mobile-screen", keyboardType = KeyboardType.Number, invalid = "rPhone" in ui.bad)
        AuthInput(ui.rEmail, { ui.rEmail = it; ui.bad = ui.bad - "rEmail" }, "Email", "fa-solid fa-envelope", keyboardType = KeyboardType.Email, invalid = "rEmail" in ui.bad)
        AuthInput(ui.rRef, { ui.rRef = it.filter { ch -> ch.isDigit() }.take(12) }, "Referral code (optional)", "fa-solid fa-gift", keyboardType = KeyboardType.Number)
        AuthInput(ui.rPass, { ui.rPass = it; ui.bad = ui.bad - "rPass" }, "Password", "fa-solid fa-lock", eye = true, invalid = "rPass" in ui.bad, imeAction = ImeAction.Done, onDone = register, bottom = 10.dp)
        PwMeter(pwLevel(ui.rPass))
        AuthButton("Create Account", ui.busyReg, "Creating account...", register)
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.Center) {
            FText("By creating an account you agree to our ", size = rem(0.72), color = c.textMain.copy(alpha = 0.7f), lineHeight = rem(0.72) * 1.5f)
        }
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            FText("Terms of Service.", size = rem(0.72), weight = FontWeight.Bold, underline = true, color = c.textMain.copy(alpha = 0.7f), modifier = Modifier.press(0.96f) { AppStore.openWeb(Cfg.TERMS_URL, "Terms") })
        }
        OrDivider()
        GoogleButton(ui.busyGoogle, google)
        Row(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.Center) {
            FText("Already have an account? ", size = rem(0.9), color = c.textMuted)
            FText("Login", size = rem(0.9), weight = FontWeight.Bold, color = c.primary, modifier = Modifier.press(0.96f) { AppStore.authTab = "login" })
        }
    }
}

/** `.btn-main` with the `loading` state (spinner + label, pointer events off). */
@Composable
private fun AuthButton(label: String, busy: Boolean, busyLabel: String, onClick: () -> Unit) {
    BtnMain(onClick = { if (!busy) onClick() }, modifier = Modifier.fillMaxWidth().graphicsLayer { alpha = if (busy) 0.92f else 1f }) {
        if (busy) { SpinIcon(rem(1.0).value.dp, Color.White); Spacer(Modifier.size(8.dp)) }
        FText(if (busy) busyLabel else label, weight = FontWeight.Bold, color = Color.White, align = TextAlign.Center)
    }
}

// ====================================================================== success overlay

/** `.auth-done` — green circle reveal + self-drawing tick. */
@Composable
private fun BoxScope.DoneOverlay(title: String, sub: String) {
    val reveal = remember { Animatable(0f) }
    LaunchedEffect(Unit) { reveal.animateTo(1f, tween(700, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f))) }
    val txt = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(700); txt.animateTo(1f, tween(500, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f))) }
    Box(
        Modifier.matchParentSize()
            .drawWithContent {
                val diag = kotlin.math.sqrt(size.width * size.width + size.height * size.height)
                val center = Offset(size.width / 2f, size.height * 0.62f)
                val r = diag * 1.5f * reveal.value
                val p = Path().apply { addOval(Rect(center, r)) }
                clipPath(p) { this@drawWithContent.drawContent() }
            }
            .background(Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF059669)), Offset(0f, 0f), Offset(1000f, 2200f))),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            DrawnCheck(96.dp)
            Column(
                Modifier.graphicsLayer { alpha = txt.value; translationY = (1f - txt.value) * 14.dp.toPx() },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                FText(title, size = rem(1.5), weight = FontWeight.ExtraBold, color = Color.White, align = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
                FText(sub, size = rem(0.95), color = Color.White.copy(alpha = 0.9f), align = TextAlign.Center)
            }
        }
    }
}

// ====================================================================== verify-your-email screen

/** `.auth-verify` — slides over the card after Sign Up: 60 s countdown while the e-mail gets verified. */
@Composable
private fun BoxScope.VerifyOverlay(v: VerifyView?, left: Long, onAction: () -> Unit) {
    var last by remember { mutableStateOf(v) }
    if (v != null) last = v
    AnimatedVisibility(
        visible = v != null,
        modifier = Modifier.matchParentSize(),
        enter = slideInHorizontally(tween(550, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f))) { it + it / 20 },
        exit = slideOutHorizontally(tween(400, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f))) { it + it / 20 },
    ) {
        val s = last ?: return@AnimatedVisibility
        val c = FF.c
        val ok = s.state == "ok"; val bad = s.state == "expired"; val wait = s.state == "wait"
        val grad = if (ok) listOf(Color(0xFF10B981), Color(0xFF059669)) else if (bad) listOf(Color(0xFFEF4444), Color(0xFFB91C1C)) else listOf(c.primary, c.accent)
        val ringCol = if (ok) Color(0xFF10B981) else if (bad) Color(0xFFEF4444) else c.primary
        val inf = rememberInfiniteTransition(label = "av")
        val ring by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = CubicBezierEasing(0f, 0f, 0.2f, 1f)), RepeatMode.Restart), label = "ring")
        val flt by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Reverse), label = "flt")
        val low = wait && left <= 10_000L
        val pulse by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Reverse), label = "pls")
        val secs = ((left + 999) / 1000).toInt().coerceAtLeast(0)

        Column(
            Modifier.fillMaxSize().background(c.bgCard).padding(horizontal = 24.dp, vertical = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically), horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(contentAlignment = Alignment.Center) {
                Box(Modifier.size(84.dp).graphicsLayer { val k = 0.92f + 0.33f * ring; scaleX = k; scaleY = k; alpha = 0.55f * (1f - ring) }
                    .drawBehind { drawRoundRect(ringCol, size = size, cornerRadius = CornerRadius(32.dp.toPx()), style = Stroke(2.dp.toPx())) })
                Box(
                    Modifier.boxShadow(26.dp, grad[0].copy(alpha = 0.35f), RoundedCornerShape(26.dp)).size(84.dp).clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(grad)),
                    contentAlignment = Alignment.Center,
                ) {
                    FaIcon(if (ok) "fa-solid fa-circle-check" else if (bad) "fa-solid fa-hourglass-end" else "fa-solid fa-envelope", rem(2.2).value.dp, Color.White, Modifier.graphicsLayer { translationY = -6.dp.toPx() * flt })
                }
            }
            FText(if (ok) "Email verified!" else if (bad) "Time's up" else "Verify your email", size = rem(1.45), weight = FontWeight.ExtraBold, align = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
            Column(Modifier.widthIn(max = 310.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (wait) {
                    FRich(
                        "We have sent a verification link to [${s.email}].\nOpen the email and tap the link to verify, then login.",
                        Modifier.fillMaxWidth(), size = rem(0.92), color = c.textMuted, boldColor = c.textMain, align = TextAlign.Center, lineHeight = rem(0.92) * 1.5f,
                    )
                    Row(
                        Modifier.padding(top = 12.dp).clip(RoundedCornerShape(12.dp)).background(if (c.isDark) Color(0x24F59E0B) else Color(0xFFFFFBEB))
                            .padding(horizontal = 12.dp, vertical = 9.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top,
                    ) {
                        FaIcon("fa-solid fa-inbox", rem(0.78).value.dp, if (c.isDark) Color(0xFFFDE68A) else Color(0xFF92400E), Modifier.padding(top = 2.dp))
                        FRich(
                            "Can't see it? Please check your [Spam / Junk] folder too.", size = rem(0.78), color = if (c.isDark) Color(0xFFFDE68A) else Color(0xFF92400E),
                            boldColor = if (c.isDark) Color(0xFFFDE68A) else Color(0xFF92400E), lineHeight = rem(0.78) * 1.4f,
                        )
                    }
                } else {
                    FText(
                        if (ok) "Your account is ready.\nYou can login now." else "Your email was not verified within 60 seconds, so the registration was cancelled.\nPlease register again.",
                        size = rem(0.92), color = c.textMuted, align = TextAlign.Center, lineHeight = rem(0.92) * 1.5f,
                    )
                }
            }
            if (wait) {
                Column(Modifier.widthIn(max = 300.dp).fillMaxWidth()) {
                    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(10.dp)).background(c.bgInput)) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth((left / 60000f).coerceIn(0f, 1f)).clip(RoundedCornerShape(10.dp)).background(Brush.horizontalGradient(if (low) listOf(Color(0xFFF59E0B), Color(0xFFEF4444)) else listOf(c.primary, c.accent))))
                    }
                    FText(
                        "Verify within ${secs}s or registration is cancelled", size = rem(0.8), weight = FontWeight.Bold, color = if (low) c.danger else c.textMuted,
                        align = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 8.dp).graphicsLayer { alpha = if (low) 1f - 0.4f * pulse else 1f },
                    )
                }
                if (Regex("@(gmail|googlemail)\\.com$", RegexOption.IGNORE_CASE).containsMatchIn(s.email)) {
                    Row(
                        Modifier.press(0.95f) { AppStore.openUrl("https://mail.google.com/") }.clip(RoundedCornerShape(30.dp)).background(c.bgInput).padding(horizontal = 18.dp, vertical = 9.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
                    ) {
                        FaIcon("fa-brands fa-google", rem(0.85).value.dp, c.textMain)
                        FText("Open Gmail", size = rem(0.85), weight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(0.dp))
            val label = if (ok) "Go to Login" else if (bad) "Register Again" else "Cancel"
            if (wait) {
                BtnMain(onClick = onAction, modifier = Modifier.fillMaxWidth().padding(top = 4.dp), shine = false, colors = listOf(c.bgInput, c.bgInput)) {
                    FText(label, weight = FontWeight.Bold, color = c.textMuted, align = TextAlign.Center)
                }
            } else BtnMain(label, onAction, Modifier.fillMaxWidth().padding(top = 4.dp))
        }
    }
}

