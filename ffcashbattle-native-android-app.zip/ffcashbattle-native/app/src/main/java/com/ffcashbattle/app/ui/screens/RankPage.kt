package com.ffcashbattle.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.data.Repo
import com.ffcashbattle.app.data.Verified
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.Avatar
import com.ffcashbattle.app.ui.comp.CoinAmount
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.VerifiedName
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.comp.rememberWiggle
import com.ffcashbattle.app.ui.screens.match.CenterFlow
import com.ffcashbattle.app.ui.screens.match.jsNum
import com.ffcashbattle.app.ui.screens.match.nfIN
import com.ffcashbattle.app.ui.shell.LocalPagePadding
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.delay
import java.util.Calendar

private class LbPlayer(val id: String, val name: String, val score: Double, val verified: Boolean, val game: Double, val img: String?, val isMe: Boolean)

private val PERIOD_LABEL = mapOf("d" to "Today", "w" to "This week", "m" to "This month")

/** `lbKey`: d-YYYYMMDD · w-YYYYMMDD (week starts Monday) · m-YYYYMM. */
private fun lbKey(p: String): String {
    val d = Calendar.getInstance()
    fun pad(n: Int) = n.toString().padStart(2, '0')
    fun ymd(cl: Calendar) = cl.get(Calendar.YEAR).toString() + pad(cl.get(Calendar.MONTH) + 1) + pad(cl.get(Calendar.DAY_OF_MONTH))
    return when (p) {
        "d" -> "d-" + ymd(d)
        "w" -> { val m = d.clone() as Calendar; val k = (m.get(Calendar.DAY_OF_WEEK) - 1 + 6) % 7; m.add(Calendar.DAY_OF_MONTH, -k); "w-" + ymd(m) }
        else -> "m-" + d.get(Calendar.YEAR) + pad(d.get(Calendar.MONTH) + 1)
    }
}

private object LbCfg { var hidden: Set<String>? = null; var rewards: List<Double> = emptyList(); var loaded = false }

private val LbEase = CubicBezierEasing(0.34f, 1.3f, 0.64f, 1f)
private val SlideEase = CubicBezierEasing(0.25f, 0.1f, 0.25f, 1f)

/** `#page-leaderboard`: Daily / Weekly / Monthly ranking by match winnings (live: `lb/{key}.players`). */
@Composable
fun RankPage() {
    val c = FF.c
    var period by remember { mutableStateOf("d") }
    var players by remember { mutableStateOf<List<LbPlayer>?>(null) }
    var cfgTick by remember { mutableStateOf(LbCfg.loaded) }

    LaunchedEffect(Unit) {
        if (!LbCfg.loaded) {
            try {
                val cfg = Repo.getDoc("config", "leaderboard")
                LbCfg.hidden = cfg?.strList("hidden")?.toSet() ?: emptySet()
                LbCfg.rewards = (cfg?.list("rewards") ?: emptyList()).mapNotNull { (it as? Map<*, *>)?.get("amount") }.map { (it as? Number)?.toDouble() ?: it.toString().toDoubleOrNull() ?: 0.0 }.filter { it > 0 }
            } catch (_: Exception) { LbCfg.hidden = emptySet() }
            LbCfg.loaded = true
        }
        cfgTick = true
    }

    DisposableEffect(period, cfgTick) {
        var reg: ListenerRegistration? = null
        if (cfgTick) {
            val me = AppStore.uid
            reg = try {
                Repo.listenDoc("lb", lbKey(period)) { d, _ ->
                    val pl = d?.map("players") ?: emptyMap()
                    val hide = LbCfg.hidden ?: emptySet()
                    @Suppress("UNCHECKED_CAST")
                    players = pl.keys.filter { it !in hide }.mapNotNull { id ->
                        val o = pl[id] as? Map<String, Any?> ?: return@mapNotNull null
                        val score = (o["a"] as? Number)?.toDouble() ?: o["a"]?.toString()?.toDoubleOrNull() ?: 0.0
                        LbPlayer(
                            id, o["n"]?.toString()?.ifEmpty { null } ?: "User", score,
                            o["v"] == true || o["v"] == 1L || Verified.has(id),
                            (o["g"] as? Number)?.toDouble() ?: 0.0, o["p"]?.toString()?.ifEmpty { null }, id == me,
                        )
                    }.filter { it.score > 0 }.sortedByDescending { it.score }.take(50)
                }
            } catch (_: Exception) { players = emptyList(); null }
        }
        onDispose { try { reg?.remove() } catch (_: Exception) { } }
    }

    val data = players
    LazyColumn(Modifier.fillMaxSize(), contentPadding = LocalPagePadding.current) {
        // .lb-header
        item(key = "head") {
            Column(Modifier.fillMaxWidth().background(c.bgCard).padding(start = 20.dp, end = 20.dp, top = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                FText("Leaderboard", size = rem(1.5), weight = FontWeight.Bold)
                FText("Top earners — ranked by match winnings", color = c.textMuted, modifier = Modifier.padding(top = 2.dp, bottom = 12.dp))
                PeriodSeg(period) { period = it; players = null }
            }
        }
        if (period == "m" && LbCfg.rewards.isNotEmpty()) item(key = "reward") { MonthlyReward(LbCfg.rewards) }
        item(key = "podium") {
            val top = data?.take(3).orEmpty()
            Column(Modifier.fillMaxWidth().padding(top = if (period == "m" && LbCfg.rewards.isNotEmpty()) 12.dp else 0.dp)) {
                if (top.isNotEmpty()) Podium(top)
                else Box(Modifier.fillMaxWidth().height(0.dp))
            }
        }
        item(key = "colhead") {
            Row(Modifier.fillMaxWidth().padding(start = 25.dp, end = 25.dp, bottom = 10.dp, top = if (data.isNullOrEmpty()) 0.dp else 0.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                FText("Rank", size = rem(0.8), weight = FontWeight.SemiBold, color = c.textMuted)
                FText("Winnings", size = rem(0.8), weight = FontWeight.SemiBold, color = c.textMuted)
            }
        }
        when {
            data == null -> item(key = "skel") {
                Column(Modifier.padding(start = 20.dp, end = 20.dp)) { repeat(3) { LbSkel() } }
            }
            data.isEmpty() -> item(key = "empty") { LbEmpty(period) }
            else -> itemsIndexed(data.drop(3), key = { _, p -> period + p.id }) { i, p -> Box(Modifier.padding(start = 20.dp, end = 20.dp)) { RankItem(i + 4, p, i, period) } }
        }
        item(key = "tail") { Box(Modifier.padding(bottom = 80.dp)) }
    }
}

// =============================================================================================== segmented control

@Composable
private fun PeriodSeg(active: String, onPick: (String) -> Unit) {
    val c = FF.c
    val idx = when (active) { "d" -> 0; "w" -> 1; else -> 2 }
    BoxWithConstraints(Modifier.fillMaxWidth().widthIn(max = 340.dp).padding(bottom = 14.dp)) {
        val inner = maxWidth - 8.dp
        val tabW = inner / 3
        val x by animateDpAsState(tabW * idx, tween(380, easing = LbEase), label = "thumb")
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.bgInput).padding(4.dp)) {
            Box(Modifier.offset(x = x).width(tabW).height(36.dp).boxShadow(10.dp, Color(0x17000000), RoundedCornerShape(11.dp)).clip(RoundedCornerShape(11.dp)).background(Color.White))
            Row(Modifier.fillMaxWidth()) {
                for ((k, label) in listOf("d" to "Daily", "w" to "Weekly", "m" to "Monthly")) {
                    Box(Modifier.weight(1f).height(36.dp).press(0.96f) { onPick(k) }, contentAlignment = Alignment.Center) {
                        FText(label, size = rem(0.82), weight = FontWeight.ExtraBold, color = if (active == k) c.primary else c.textMuted)
                    }
                }
            }
        }
    }
}

// =============================================================================================== monthly rewards

@Composable
private fun MonthlyReward(rewards: List<Double>) {
    val now = System.currentTimeMillis()
    val cal = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.MONTH, 1) }
    val left = cal.timeInMillis - now
    val d = left / 86_400_000L
    val h = (left % 86_400_000L) / 3_600_000L
    val med = listOf("🥇", "🥈", "🥉")
    val shape = RoundedCornerShape(16.dp)
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(450, easing = SlideEase)) }
    val rot = rememberWiggle()
    Column(
        Modifier.padding(start = 20.dp, end = 20.dp, top = 12.dp).fillMaxWidth()
            .graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 14.dp.toPx() }
            .clip(shape).background(Brush.linearGradient(listOf(Color(0xFFFFFBEB), Color(0xFFFEF3C7)))).border(1.dp, Color(0xFFFDE68A), shape)
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FaIcon("fa-solid fa-gift", rem(0.85).value.dp, Color(0xFF92400E), Modifier.graphicsLayer { rotationZ = rot })
            FText("Monthly Rewards", size = rem(0.85), weight = FontWeight.Bold, color = Color(0xFF92400E), modifier = Modifier.weight(1f))
            Box(Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xFFFDE68A)).padding(horizontal = 9.dp, vertical = 3.dp)) {
                FText("ends in ${d}d ${h}h", size = rem(0.7), weight = FontWeight.ExtraBold, color = Color(0xFF92400E))
            }
        }
        CenterFlow(8.dp, 8.dp, Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp)) {
            rewards.forEachIndexed { i, r -> RewardChip(i, med.getOrNull(i) ?: "#${i + 1}", jsNum(r)) }
        }
        FText("Paid to your wallet & notification bell at 12:00 AM on the 1st.", size = rem(0.68), color = Color(0xFFA16207))
    }
}

@Composable
private fun RewardChip(i: Int, medal: String, amount: String) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(i * 80L); a.animateTo(1f, tween(450, easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f))) }
    Row(
        Modifier.graphicsLayer { val s = 0.6f + 0.4f * a.value; scaleX = s; scaleY = s; alpha = a.value }
            .clip(RoundedCornerShape(30.dp)).background(Color.White).padding(horizontal = 12.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        FText(medal, size = rem(0.85), weight = FontWeight.Black, color = Color(0xFF78350F))
        CoinAmount(amount, rem(0.85), FontWeight.Black, Color(0xFF78350F))
    }
}

// =============================================================================================== podium

@Composable
private fun Podium(top: List<LbPlayer>) {
    val c = FF.c
    val shape = RoundedCornerShape(bottomStart = 30.dp, bottomEnd = 30.dp)
    // order: 2nd, 1st, 3rd
    val order = ArrayList<Pair<LbPlayer, Int>>()
    top.getOrNull(1)?.let { order.add(it to 2) }
    top.getOrNull(0)?.let { order.add(it to 1) }
    top.getOrNull(2)?.let { order.add(it to 3) }
    BoxWithConstraints(Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
        val itemW = (maxWidth - 40.dp) * 0.30f
        Row(
            Modifier.fillMaxWidth().boxShadow(30.dp, Color(0x0D000000), shape).clip(shape).background(c.bgCard)
                .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 40.dp),
            horizontalArrangement = Arrangement.spacedBy(15.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.Bottom,
        ) {
            order.forEachIndexed { i, (p, r) -> PodiumItem(p, r, i, itemW) }
        }
    }
}

@Composable
private fun PodiumItem(p: LbPlayer, rank: Int, index: Int, itemW: Dp) {
    val c = FF.c
    val ringCol = when (rank) { 1 -> Color(0xFFF59E0B); 2 -> Color(0xFF94A3B8); else -> Color(0xFFB45309) }
    val box = if (rank == 1) 90.dp else 70.dp
    val ringW = if (rank == 1) 4.dp else 3.dp
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(index * 110L); a.animateTo(1f, tween(550, easing = LbEase)) }
    val inf = rememberInfiniteTransition(label = "pod")
    val fl by inf.animateFloat(0f, -4f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "fl")
    val crownFl by inf.animateFloat(0f, -4f, infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "cfl")

    Column(
        Modifier.width(itemW)
            .graphicsLayer {
                alpha = minOf(1f, a.value * 1.5f)
                translationY = (1f - a.value) * 40.dp.toPx() + (if (rank == 1) -15.dp.toPx() else 0f)
                val s = 0.85f + 0.15f * a.value; scaleX = s; scaleY = s
            },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(contentAlignment = Alignment.TopCenter) {
            if (rank == 1) FaIcon("fa-solid fa-crown", rem(1.5).value.dp, Color(0xFFF59E0B), Modifier.offset(y = (-25).dp + crownFl.dp))
            Box(Modifier.graphicsLayer { translationY = if (rank == 1) fl.dp.toPx() else 0f }.size(box)) {
                Box(
                    Modifier.size(box)
                        .then(if (rank == 1) Modifier.boxShadow(20.dp, Color(0x66F59E0B), CircleShape) else Modifier)
                        .clip(CircleShape).background(Color(0xFFEEEEEE)).border(ringW, ringCol, CircleShape).padding(ringW),
                ) { Avatar(p.img, p.name.ifEmpty { p.id }, box - ringW * 2, Modifier, borderColor = Color.White, borderWidth = 3.dp) }
                Box(
                    Modifier.align(Alignment.BottomCenter).offset(y = 8.dp).size(22.dp).clip(CircleShape).background(ringCol).border(2.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center,
                ) { FText(rank.toString(), size = rem(0.8), weight = FontWeight.Bold, color = Color.White) }
            }
        }
        Box(Modifier.padding(top = 10.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
            VerifiedName(p.name, p.id, rem(0.9), weight = FontWeight.Bold, maxLines = 2, force = p.verified)
        }
        CoinAmount(String.format(java.util.Locale.US, "%.2f", p.score), rem(1.0), FontWeight.SemiBold, c.primary, modifier = Modifier)
        if (p.game > 0) GameChip(p.game, Modifier.padding(top = 4.dp), small = true)
    }
}

@Composable
private fun GameChip(g: Double, modifier: Modifier = Modifier, small: Boolean = false) {
    val c = FF.c
    Row(
        modifier.clip(RoundedCornerShape(8.dp)).background(if (c.isDark) Color(0x388B5CF6) else Color(0x1F7C3AED)).padding(horizontal = 8.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        val col = if (c.isDark) Color(0xFFC4B5FD) else Color(0xFF6D28D9)
        FaIcon("fa-solid fa-circle-nodes", rem(if (small) 0.58 else 0.64).value.dp, col)
        FText("won ₹" + nfIN(Math.round(g * 100) / 100.0) + " in Coin Battle", size = rem(if (small) 0.58 else 0.64), weight = FontWeight.ExtraBold, color = col, maxLines = 1)
    }
}

// =============================================================================================== list

@Composable
private fun RankItem(pos: Int, p: LbPlayer, i: Int, period: String) {
    val c = FF.c
    val shape = RoundedCornerShape(12.dp)
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(minOf(i, 10) * 45L); a.animateTo(1f, tween(400, easing = SlideEase)) }
    Row(
        Modifier.fillMaxWidth().padding(bottom = 10.dp)
            .graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 14.dp.toPx() }
            .boxShadow(5.dp, Color(0x05000000), shape)
            .clip(shape).background(if (p.isMe) (if (c.isDark) c.primaryLight else Color(0xFFEEF2FF)) else c.bgCard)
            .border(1.dp, if (p.isMe) c.primary else c.border, shape)
            .padding(horizontal = 15.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FText(pos.toString(), weight = FontWeight.Bold, color = c.textMuted, align = TextAlign.Center, modifier = Modifier.width(30.dp))
        Box(Modifier.padding(start = 10.dp, end = 15.dp)) { Avatar(p.img, p.name.ifEmpty { p.id }, 40.dp) }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                VerifiedName(p.name, p.id, rem(1.0), weight = FontWeight.SemiBold, force = p.verified, modifier = Modifier.weight(1f, fill = false))
                if (p.isMe) FText(" (You)", weight = FontWeight.SemiBold)
            }
            FText("${PERIOD_LABEL[period]} winnings", size = rem(0.75), color = Color(0xFFAAAAAA))
            if (p.game > 0) GameChip(p.game)
        }
        CoinAmount(String.format(java.util.Locale.US, "%.2f", p.score), rem(1.0), FontWeight.ExtraBold, c.textMain)
    }
}

@Composable
private fun LbSkel() {
    val c = FF.c
    val inf = rememberInfiniteTransition(label = "lbShim")
    val x by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart), label = "x")
    Box(
        Modifier.fillMaxWidth().padding(bottom = 10.dp).height(56.dp).clip(RoundedCornerShape(14.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(c.bgInput, Color.White, c.bgInput),
                    startX = -600f + 1800f * x, endX = 600f + 1800f * x,
                ),
            ),
    )
}

@Composable
private fun LbEmpty(period: String) {
    val c = FF.c
    val rot = rememberWiggle(2600)
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(400, easing = SlideEase)) }
    Column(
        Modifier.fillMaxWidth().graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 14.dp.toPx() }.padding(horizontal = 10.dp, vertical = 34.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        FaIcon("fa-solid fa-trophy", rem(2.4).value.dp, Color(0xFFF59E0B).copy(alpha = 0.6f), Modifier.graphicsLayer { rotationZ = rot })
        FText("No winners yet — ${PERIOD_LABEL[period]!!.lowercase()}", weight = FontWeight.Bold, align = TextAlign.Center)
        FText("Win a match to appear here!", color = c.textMuted, align = TextAlign.Center)
    }
}
