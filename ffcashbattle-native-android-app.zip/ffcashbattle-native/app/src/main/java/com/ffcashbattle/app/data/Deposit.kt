package com.ffcashbattle.app.data

import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.screens.match.jsNum
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Transaction
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlin.math.abs

/** components/deposit/deposit.js — UPI deposit verified by UTR *or* Transaction ID, race-safe (one payment is credited only once). */
object Deposit {
    private val active = HashSet<String>()          // app._activeDepositPolls

    private class DepErr(msg: String) : RuntimeException(msg)

    // ------------------------------------------------------------------ reference helpers
    /** "Transaction ID : FMPIB6862334894", "UTR 412345678901" … → the bare reference ("" if none). */
    fun extractRef(raw: String): String {
        val t = raw.uppercase().replace(
            Regex("TRANSACTION\\s*(ID|NO|NUMBER)?|TXN\\s*(ID|NO)?|UPI\\s*(REF(ERENCE)?)?\\s*(ID|NO)?|REFERENCE\\s*(ID|NO|NUMBER)?|REF\\s*(ID|NO)?|UTR\\s*(NO|NUMBER)?|RRN"), " ",
        )
        return Regex("[A-Z0-9]{8,24}").find(t)?.value ?: ""
    }

    fun refKind(ref: String): String =
        if (Regex("^\\d{10,14}$").matches(ref)) "utr"
        else if (Regex("^[A-Z]{2,}[A-Z0-9]*\\d[A-Z0-9]*$").matches(ref) && ref.length >= 10) "txn" else "other"

    class Check(val status: String, val amount: Double = 0.0, val trxDocId: String? = null, val received: Double? = null)

    private fun chain(e: Throwable): Sequence<Throwable> = generateSequence(e) { it.cause }.take(8)

    // ------------------------------------------------------------------ submit
    /** `app.depositUPI` (after the form validated amt + ref). Returns true when the request is in and the poll started. */
    suspend fun submit(amt: Double, ref: String): Boolean {
        val uid = AppStore.uid
        if (uid == null) { AppStore.toast(Msg.deposit.needLogin()); return false }
        val reqRef = Repo.doc("deposit_requests", ref)        // doc id = the reference => a reference can exist only ONCE
        val now = System.currentTimeMillis()
        var resumed = false
        try {
            resumed = Repo.db.runTransaction(Transaction.Function<Boolean> { tx ->
                val cur = tx.get(reqRef)
                if (cur.exists()) {
                    val d = Doc.of(cur)
                    val st = d.s("status")
                    if (st == "success") throw DepErr(Msg.deposit.utrUsed())
                    if (d.s("uid").isNotEmpty() && d.s("uid") != uid) throw DepErr(Msg.deposit.utrOther())
                    if (st == "failed" || st == "mismatch" || st == "rejected") throw DepErr(Msg.deposit.utrRejected())
                    if (d.n("amount") != 0.0 && abs(d.n("amount") - amt) > 0.01) throw DepErr(Msg.deposit.utrAmount())
                    true
                } else {
                    tx.set(reqRef, mapOf("utr" to ref, "amount" to fsNum(amt), "uid" to uid, "name" to AppStore.user.s("appName").ifEmpty { AppStore.user.s("name") }.ifEmpty { "User" }, "status" to "pending", "createdAt" to now))
                    false
                }
            }).await()
        } catch (e: Exception) {
            AppStore.endAction("deposit_$ref", false)    // release the in-flight lock so the same UTR can be retried
            // Admin switched Add Money OFF after this screen was opened -> show the admin's note instead of a raw error
            if (chain(e).any { (it as? FirebaseFirestoreException)?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED }) {
                try { Repo.getDoc("config", "banner")?.let { AppStore.refreshFlags() } } catch (_: Exception) { }
                delay(400)
                if (AppStore.flagOff("dep")) { AppStore.toast(AppStore.flagMsg("dep")); return false }
            }
            val own = chain(e).firstOrNull { it is DepErr }?.message
            AppStore.toast(own ?: Msg.deposit.submitFailed())
            return false
        }
        try {
            if (!resumed) {
                val trxId = Repo.add(listOf("users", uid, "transactions"), mapOf(
                    "title" to Msg.deposit.title.pending(amt), "amount" to "+₹${jsNum(amt)}", "type" to "deposit", "status" to "pending",
                    "trxId" to ref, "method" to "UPI", "date" to java.text.DateFormat.getDateInstance(java.text.DateFormat.SHORT).format(java.util.Date()),
                    "createdAt" to now, "timestamp" to Repo.serverTs(),
                ))
                Repo.update(listOf("deposit_requests", ref), mapOf("trxDocId" to trxId))
            }
        } catch (_: Exception) { }
        startPoll(ref, amt, uid, overlay = true)
        return true
    }

    // ------------------------------------------------------------------ one atomic check
    /** success: this call credited the wallet · used: payment already credited · done: already completed · notfound · failed · gone */
    private suspend fun check(ref: String, amt: Double, uid: String): Check {
        val reqRef = Repo.doc("deposit_requests", ref)
        val fampayRef = Repo.doc("fampay_deposits", ref)
        return Repo.db.runTransaction(Transaction.Function<Check> { tx ->
            val reqSnap = tx.get(reqRef)
            if (!reqSnap.exists()) return@Function Check("gone")
            val r = Doc.of(reqSnap)
            val trxDocId = r.s("trxDocId").ifEmpty { null }
            if (r.s("uid") != uid) return@Function Check("failed")
            if (r.s("status") == "success") return@Function Check("done", trxDocId = trxDocId)
            if (r.s("status") != "pending" && r.s("status") != "processing") return@Function Check("failed", trxDocId = trxDocId)
            val fSnap = tx.get(fampayRef)
            if (!fSnap.exists()) return@Function Check("notfound", trxDocId = trxDocId)
            val f = Doc.of(fSnap)
            val fAmt = f.s("amount").toDoubleOrNull() ?: f.n("amount")
            if (fAmt.isNaN() || abs(fAmt - (r.s("amount").toDoubleOrNull() ?: r.n("amount"))) > 0.01) return@Function Check("notfound", trxDocId = trxDocId, received = fAmt)
            // ONE payment = ONE marker (id = the payment's main id): UTR and Transaction ID of the same payment share it
            val payId = f.s("payId").ifEmpty { ref }
            val usedRef = Repo.doc("fampay_used", payId)
            if (tx.get(usedRef).exists()) return@Function Check("used", trxDocId = trxDocId)
            val userRef = Repo.doc("users", uid)
            if (!tx.get(userRef).exists()) throw IllegalStateException("User missing")
            tx.set(usedRef, mapOf("ref" to ref, "uid" to uid, "at" to System.currentTimeMillis()))
            tx.update(userRef, mapOf("depositBalance" to com.google.firebase.firestore.FieldValue.increment(fAmt), "totalDeposited" to com.google.firebase.firestore.FieldValue.increment(fAmt), "lastDepositUtr" to ref))
            tx.update(reqRef, mapOf("status" to "success", "verifiedAt" to System.currentTimeMillis(), "receivedAmount" to fAmt, "claimed" to true))
            tx.delete(fampayRef)
            Check("success", amount = fAmt, trxDocId = trxDocId)
        }).await()
    }

    private suspend fun notify(uid: String, title: String, body: String) {
        try {
            Repo.add(listOf("users", uid, "notifications"), mapOf(
                "title" to title, "body" to body, "message" to body, "type" to "deposit", "read" to false,
                "date" to java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale("en", "IN")).format(java.util.Date()),
                "createdAt" to System.currentTimeMillis(), "timestamp" to Repo.serverTs(),
            ))
        } catch (_: Exception) { }
    }

    // ------------------------------------------------------------------ poll
    fun startPoll(ref: String, amt: Double, uid: String, overlay: Boolean) {
        val amtS = jsNum(amt)
        if (ref in active) {
            if (overlay) AppStore.showVerify(Msg.deposit.alreadyChecking.title, Msg.deposit.alreadyChecking.sub, "loading", amtS, ref)
            return
        }
        active.add(ref)
        var lastSeen: Check? = null
        var finished = false
        fun finish() { finished = true; active.remove(ref) }

        suspend fun onSuccess(received: Double, trxDocId: String?) {
            if (trxDocId != null) { try { Repo.update(listOf("users", uid, "transactions", trxDocId), mapOf("status" to "success", "title" to Msg.deposit.title.success(received))) } catch (_: Exception) { } }
            val n = Msg.deposit.successNotify(received, ref)
            notify(uid, n.title, n.body)
            AppStore.hideVerify()
            // the user doc listener delivers the credited balance; give it a moment, then run the ~3 s golden-coin animation
            val before = AppStore.depositBalance + AppStore.withdrawBalance
            var waited = 0
            while (waited < 2000 && AppStore.depositBalance + AppStore.withdrawBalance <= before) { delay(100); waited += 100 }
            val nowBal = AppStore.depositBalance + AppStore.withdrawBalance
            AppStore.playWalletFx("deposit", received, maxOf(nowBal, received))
        }

        suspend fun onFail(trxDocId: String?) {
            val seen = lastSeen
            val f = Msg.deposit.fail(amt, ref, seen?.status, seen?.received)
            try { Repo.update(listOf("deposit_requests", ref), mapOf("status" to "failed", "failedAt" to System.currentTimeMillis())) } catch (_: Exception) { }
            if (trxDocId != null) { try { Repo.update(listOf("users", uid, "transactions", trxDocId), mapOf("status" to "failed", "title" to Msg.deposit.title.failed(amt))) } catch (_: Exception) { } }
            notify(uid, f.title, f.body)
            if (overlay) AppStore.showVerify(f.title, f.sub, "fail", amtS, ref) else AppStore.toast(f.toast)
        }

        /** true when polling should stop */
        suspend fun handle(res: Check): Boolean {
            lastSeen = res
            return when (res.status) {
                "success" -> { onSuccess(res.amount, res.trxDocId); finish(); true }
                "used" -> { onFail(res.trxDocId); finish(); true }
                "done", "gone" -> { AppStore.hideVerify(); finish(); true }
                "failed" -> { AppStore.hideVerify(); finish(); true }
                else -> false
            }
        }

        fun runBackground() = AppStore.scope.launch {
            var attempts = 0
            var trxDocId: String? = null
            var createdAt = System.currentTimeMillis()
            try { Repo.getDoc("deposit_requests", ref)?.let { trxDocId = it.s("trxDocId").ifEmpty { null }; it.l("createdAt").takeIf { c -> c > 0 }?.let { c -> createdAt = c } } } catch (_: Exception) { }
            while (!finished && attempts < 30) {
                delay(10_000)
                if (finished) break
                attempts++
                try { if (handle(check(ref, amt, uid))) return@launch } catch (_: Exception) { }
                if (System.currentTimeMillis() - createdAt > 30 * 60 * 1000L) { onFail(trxDocId); finish(); return@launch }
            }
            active.remove(ref)       // stays pending; resumes next time the app opens
        }

        fun runForeground() = AppStore.scope.launch {
            AppStore.showVerify(Msg.deposit.verifying.title, Msg.deposit.verifying.sub, "loading", amtS, ref)
            AppStore.verifyCountdown = 10
            val tick = launch { while (true) { delay(1000); if (AppStore.verifyCountdown > 0) AppStore.verifyCountdown-- } }
            for (wait in listOf(1000L, 2000L, 2000L, 2000L, 2000L)) {
                delay(wait)
                try { if (handle(check(ref, amt, uid))) { tick.cancel(); return@launch } } catch (_: Exception) { }
            }
            tick.cancel()
            // Not matched yet -> PENDING (never a hard fail here). Keep checking in the background.
            try { Repo.update(listOf("deposit_requests", ref), mapOf("status" to "processing")) } catch (_: Exception) { }
            val p = Msg.deposit.pending(amt)
            AppStore.showVerify(p.title, p.sub, "pending", amtS, ref)
            runBackground()
        }

        if (overlay) runForeground() else runBackground()
    }

    /** wallet.js `fetchTransactions`: resume every pending / processing UPI verification in the background (no overlay). */
    fun resumePending(uid: String) {
        AppStore.scope.launch {
            try {
                for (st in listOf("pending", "processing")) {
                    val docs = Repo.getCol("deposit_requests") { it.whereEqualTo("uid", uid).whereEqualTo("status", st) }
                    for (r in docs) {
                        val utr = r.s("utr")
                        val amt = r.s("amount").toDoubleOrNull() ?: r.n("amount")
                        if (utr.isNotEmpty() && utr !in active) startPoll(utr, amt, uid, overlay = false)
                    }
                }
            } catch (_: Exception) { }
        }
    }
}
