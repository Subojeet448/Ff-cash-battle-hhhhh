package com.ffcashbattle.app.ui.modals

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.GameArt
import com.ffcashbattle.app.data.Img
import com.ffcashbattle.app.data.Prefs
import com.ffcashbattle.app.data.Repo
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.Avatar
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.InputBox
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.SpinIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

private val PHONE_OK = Regex("^[6-9]\\d{9}$")
private val TEN = Regex("^\\d{10}$")

/** Website `#modal-edit-profile`: photo, display name, game info, phone + password. */
@Composable
fun EditProfileModal() {
    val c = FF.c
    val d = AppStore.user
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val close = LocalSheetClose.current
    val fu = Repo.auth.currentUser

    var appName by remember { mutableStateOf(d.s("appName")) }
    var gameName by remember { mutableStateOf(d.s("gameName")) }
    var gameUid by remember { mutableStateOf(d.s("gameUid").let { if (it.endsWith(".0")) it.dropLast(2) else it }) }
    var temp by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    val left = if (d.has("nameChangesLeft")) d.i("nameChangesLeft") else 2
    val uidVerified = d.b("isUidVerified")
    val pid = d.s("playerId").ifEmpty { (AppStore.uid ?: "").take(7) }

    // phone & password block
    var phone by remember { mutableStateOf(d.s("phone")) }
    var hasPass by remember { mutableStateOf(fu?.providerData?.any { it.providerId == "password" } == true) }
    var phoneEdit by remember { mutableStateOf(false) }
    var phNew by remember { mutableStateOf("") }
    var phConf by remember { mutableStateOf("") }
    var pw1 by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var busyPhone by remember { mutableStateOf(false) }
    var busyPw by remember { mutableStateOf(false) }
    var busyReset by remember { mutableStateOf(false) }

    val pop = remember { Animatable(1f) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val r = withContext(Dispatchers.IO) { Img.squarePhoto(ctx, uri) }
            if (r.dataUrl != null) { temp = r.dataUrl; pop.snapTo(0.6f); pop.animateTo(1f, spring(0.45f, Spring.StiffnessMediumLow)) }
            else AppStore.toast(r.error ?: "This image could not be loaded. Please try another one.")
        }
    }

    fun save() {
        val name = appName.trim(); val gn = gameName.trim(); val uid = gameUid.trim()
        if (name.length < 3) { AppStore.toast("App Name: minimum 3 chars"); return }
        if (uid.isNotEmpty() && (!uid.all { it.isDigit() } || uid.length < 6 || uid.length > 12)) { AppStore.toast("FF UID invalid (6-12 digits)"); return }
        val up = HashMap<String, Any?>()
        if (name.isNotEmpty() && name != d.s("appName")) {
            if (left <= 0) { AppStore.toast("Name change limit reached"); return }
            up["appName"] = name; up["nameChangesLeft"] = left - 1
        }
        if (gn.isNotEmpty() && gn != d.s("gameName")) up["gameName"] = gn
        if (uid.isNotEmpty() && !uidVerified && uid != d.s("gameUid")) up["gameUid"] = uid
        temp?.let { up["photoUrl"] = it }
        if (up.isEmpty()) { close(); AppStore.toast("No changes to save."); return }
        val id = AppStore.uid ?: return
        saving = true
        scope.launch {
            try {
                if (up.containsKey("appName")) {
                    try { Repo.auth.currentUser?.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name).build())?.await() } catch (_: Exception) { }
                }
                Repo.set(listOf("users", id), up, merge = true)
                close(); AppStore.toast("Profile Updated!")
            } catch (e: Exception) {
                AppStore.toast("Error: " + (e.message ?: "try again"))
                saving = false
            }
        }
    }

    fun savePhone() {
        val u = Repo.auth.currentUser
        if (u == null) { AppStore.toast("Please login first"); return }
        val changing = TEN.matches(phone)
        val n = phNew.trim(); val cf = phConf.trim()
        if (!PHONE_OK.matches(n)) { AppStore.toast("Enter a valid 10-digit mobile number"); return }
        if (changing) {
            if (n == phone) { AppStore.toast("This is already your number"); return }
            if (n != cf) { AppStore.toast("Numbers do not match — confirm the new number"); return }
        }
        busyPhone = true
        scope.launch {
            try {
                val dup = Repo.getCol("users") { it.whereEqualTo("phone", n) }
                if (dup.any { it.id != u.uid }) { AppStore.toast("This number is already used by another account"); return@launch }
                Repo.update(listOf("users", u.uid), mapOf("phone" to n))
                phone = n; phoneEdit = false; phNew = ""; phConf = ""
                AppStore.toast(if (changing) "Number changed ✓" else "Number saved ✓")
            } catch (e: Exception) { AppStore.toast("Error: " + (e.message ?: "try again")) }
            finally { busyPhone = false }
        }
    }

    fun setPassword() {
        val u = Repo.auth.currentUser
        if (u == null) { AppStore.toast("Please login first"); return }
        val email = u.email
        if (email.isNullOrEmpty()) { AppStore.toast("No email on this account"); return }
        if (pw1.length < 8) { AppStore.toast("Password must be at least 8 characters"); return }
        if (pw1 != pw2) { AppStore.toast("Passwords do not match"); return }
        busyPw = true
        scope.launch {
            try {
                u.linkWithCredential(EmailAuthProvider.getCredential(email, pw1)).await()
                Repo.update(listOf("users", u.uid), mapOf("hasPassword" to true))
                hasPass = true; pw1 = ""; pw2 = ""
                AppStore.toast("Password set ✓")
            } catch (e: Exception) {
                val code = (e as? FirebaseAuthException)?.errorCode ?: ""
                AppStore.toast(
                    when (code) {
                        "ERROR_REQUIRES_RECENT_LOGIN" -> "Please login again, then retry"
                        "ERROR_EMAIL_ALREADY_IN_USE", "ERROR_CREDENTIAL_ALREADY_IN_USE", "ERROR_PROVIDER_ALREADY_LINKED" -> "This account already has a password — use Reset password"
                        else -> "Error: " + (e.message ?: "try again")
                    },
                )
            } finally { busyPw = false }
        }
    }

    fun resetPassword() {
        val u = Repo.auth.currentUser
        val email = u?.email
        if (u == null || email.isNullOrEmpty()) { AppStore.toast("No email on this account"); return }
        val left2 = 180000L - (System.currentTimeMillis() - Prefs.long("fp_last_" + email.lowercase()))
        if (left2 > 0) { AppStore.toast("Link already sent. Try again in " + ((left2 + 999) / 1000) + "s — check Inbox / Spam"); return }
        busyReset = true
        scope.launch {
            try {
                Repo.auth.sendPasswordResetEmail(email).await()
                Prefs.put("fp_last_" + email.lowercase(), System.currentTimeMillis())
                try { Repo.update(listOf("users", u.uid), mapOf("hasPassword" to true)) } catch (_: Exception) { }
                AppStore.toast("Reset link sent to $email ✓ Check Inbox / Spam")
            } catch (e: Exception) {
                val code = (e as? FirebaseAuthException)?.errorCode ?: ""
                AppStore.toast(if (code == "ERROR_TOO_MANY_REQUESTS" || e is FirebaseTooManyRequestsException) "Too many requests. Wait a few minutes." else "Error: " + (e.message ?: "try again"))
            } finally { busyReset = false }
        }
    }

    ModalSheet(padding = PaddingValues(start = 22.dp, top = 24.dp, end = 22.dp, bottom = 28.dp)) {
        // .ep-head
        Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            FText("Edit Profile", size = rem(1.25), weight = FontWeight.ExtraBold)
            Box(Modifier.size(34.dp).clip(CircleShape).background(c.bgInput).press(0.88f) { close() }, contentAlignment = Alignment.Center) {
                FaIcon("fa-solid fa-xmark", rem(1.0).value.dp, c.textMuted)
            }
        }

        // .ep-top — photo, hint, Player ID
        Column(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            val inf = rememberInfiniteTransition(label = "ep")
            val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Restart), label = "spin")
            Box(Modifier.size(96.dp).press(0.94f) { picker.launch("image/*") }, contentAlignment = Alignment.Center) {
                Box(
                    Modifier.requiredSize(112.dp).graphicsLayer { rotationZ = spin; alpha = 0.45f }.drawBehind {
                        drawCircle(c.primary, size.minDimension / 2f - 1.dp.toPx(), style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 4.dp.toPx()))))
                    },
                )
                Box(
                    Modifier.size(96.dp).graphicsLayer { scaleX = pop.value; scaleY = pop.value }
                        .boxShadow(22.dp, c.primary.copy(alpha = 0.3f), CircleShape)
                        .drawBehind { drawCircle(c.primary, size.minDimension / 2f + 3.dp.toPx()) },
                ) {
                    Avatar(temp ?: GameArt.photoOf(d), GameArt.seedOf(d), 96.dp, borderColor = c.bgCard, borderWidth = 3.dp)
                }
                Box(
                    Modifier.align(Alignment.BottomEnd).offset(2.dp, 0.dp).size(30.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(c.primary, c.primaryDark))).border(3.dp, c.bgCard, CircleShape),
                    contentAlignment = Alignment.Center,
                ) { FaIcon("fa-solid fa-camera", rem(0.8).value.dp, Color.White) }
            }
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                FText("Tap to change photo", size = rem(0.78), weight = FontWeight.SemiBold, color = c.primary)
                FText("(auto-resize)", size = rem(0.78), weight = FontWeight.Medium, color = c.textMuted)
            }
            Row(
                Modifier.padding(top = 8.dp).clip(RoundedCornerShape(20.dp)).background(c.bgInput).press(0.95f) { AppStore.copy(pid) }.padding(horizontal = 12.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
            ) {
                FaIcon("fa-regular fa-id-badge", rem(0.72).value.dp, c.textMuted)
                FText("Player ID", size = rem(0.72), weight = FontWeight.SemiBold, color = c.textMuted)
                FText(pid, size = rem(0.72), weight = FontWeight.Bold, mono = true, letterSpacing = 0.5.sp)
                FaIcon("fa-regular fa-copy", rem(0.72).value.dp, c.textMuted)
            }
        }

        // App username
        EpCard {
            EpLabel("App Username")
            EpField(appName, { appName = it }, "Display Name", "fa-solid fa-user", enabled = left > 0, maxLength = 24, count = "${appName.length}/24", bottom = 0.dp)
            Row(Modifier.fillMaxWidth().padding(start = 2.dp, end = 2.dp, top = 8.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                FaIcon("fa-regular fa-clock", rem(0.72).value.dp, c.textMuted, Modifier.padding(end = 4.dp))
                FText("Changes left: ", size = rem(0.72), color = c.textMuted)
                FText("$left", size = rem(0.72), weight = FontWeight.Bold)
            }
        }

        // Game information
        EpCard {
            EpTitle("fa-solid fa-gamepad", "Game Information")
            EpLabel("In-Game Name *")
            EpField(gameName, { gameName = it }, "Exact FF Name", "fa-solid fa-signature")
            Row(Modifier.fillMaxWidth().padding(start = 2.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                FText("Game UID", size = rem(0.75), weight = FontWeight.SemiBold, color = c.textMuted)
                if (uidVerified) {
                    FaIcon("fa-solid fa-circle-check", rem(0.8).value.dp, c.success)
                    FText("Verified", size = rem(0.8), color = c.success)
                }
            }
            EpField(gameUid, { gameUid = it.filter { ch -> ch.isDigit() }.take(12) }, "FF UID (6-12 digits)", "fa-solid fa-hashtag", keyboard = KeyboardType.Number, enabled = !uidVerified, bottom = 0.dp)
        }

        // Phone & password
        EpCard {
            EpTitle("fa-solid fa-shield-halved", "Phone & Password")
            Row(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val has = TEN.matches(phone)
                EpPill("fa-solid fa-mobile-screen", if (has) "Number saved" else "No number", has)
                EpPill("fa-solid fa-key", if (hasPass) "Password set" else "No password", hasPass)
            }
            val has = TEN.matches(phone)
            if (has && !phoneEdit) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        FaIcon("fa-solid fa-mobile-screen", rem(0.85).value.dp, c.primary)
                        FText("+91 " + phone.take(2) + "******" + phone.takeLast(2), size = rem(0.85), weight = FontWeight.ExtraBold, letterSpacing = 0.3.sp)
                    }
                    EpMini("Change number", "fa-solid fa-arrow-right-arrow-left") { phoneEdit = true; phNew = ""; phConf = "" }
                }
            } else {
                EpLabel(if (has) "New phone number" else "Enter phone number")
                EpField(phNew, { phNew = it.filter { ch -> ch.isDigit() }.take(10) }, "10-digit mobile number", "fa-solid fa-mobile-screen", keyboard = KeyboardType.Phone, maxLength = 10)
                if (has) EpField(phConf, { phConf = it.filter { ch -> ch.isDigit() }.take(10) }, "Confirm new number", "fa-solid fa-check-double", keyboard = KeyboardType.Phone, maxLength = 10)
                Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)) {
                    if (has) EpMini("Cancel", null, ghost = true) { phoneEdit = false; phNew = ""; phConf = "" }
                    EpMini(if (has) "Confirm & change" else "Save number", "fa-solid fa-floppy-disk", solid = true, busy = busyPhone) { savePhone() }
                }
            }

            // .ep-sep
            Column(
                Modifier.fillMaxWidth().padding(top = 14.dp)
                    .drawBehind { drawLine(c.border, Offset(0f, 0.5.dp.toPx()), Offset(size.width, 0.5.dp.toPx()), 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 3.dp.toPx()))) }
                    .padding(top = 14.dp),
            ) {
                if (!hasPass) {
                    EpLabel("Set password")
                    EpField(pw1, { pw1 = it }, "New password (min 8 characters)", "fa-solid fa-key", password = true)
                    EpField(pw2, { pw2 = it }, "Confirm password", "fa-solid fa-key", password = true)
                    Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.End) {
                        EpMini("Set password", "fa-solid fa-lock", solid = true, busy = busyPw) { setPassword() }
                    }
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            FaIcon("fa-solid fa-key", rem(0.85).value.dp, c.primary)
                            FText("Password is set", size = rem(0.85), weight = FontWeight.ExtraBold)
                        }
                        EpMini("Reset password", "fa-solid fa-envelope", busy = busyReset, busyLabel = "Sending…") { resetPassword() }
                    }
                    val em = fu?.email ?: d.s("email")
                    val masked = if (em.isNotEmpty()) em.replace(Regex("^(.{2}).*(@.*)$"), "$1***$2") else ""
                    FText(
                        if (masked.isNotEmpty()) "A reset link will be sent to $masked. Open it, set the new password." else "A reset link will be sent to your registered email.",
                        size = rem(0.72), color = c.textMuted, lineHeight = rem(0.72) * 1.45f, modifier = Modifier.fillMaxWidth().padding(start = 2.dp, end = 2.dp, top = 10.dp),
                    )
                }
            }
        }

        BtnMain(onClick = { if (!saving) save() }, modifier = Modifier.fillMaxWidth().graphicsLayer { alpha = if (saving) 0.7f else 1f }) {
            if (saving) SpinIcon(rem(1.0).value.dp, Color.White) else FaIcon("fa-solid fa-floppy-disk", rem(1.0).value.dp, Color.White)
            Box(Modifier.width(8.dp))
            FText(if (saving) "Saving..." else "Save Changes", weight = FontWeight.Bold, color = Color.White)
        }
    }

}

// ------------------------------------------------------------------------------------------ pieces

/** `.ep-card` */
@Composable
private fun EpCard(content: @Composable () -> Unit) {
    val c = FF.c
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(shape).background(if (c.isDark) Color(0x730F172A) else c.bgBody).border(1.dp, c.border, shape).padding(14.dp),
    ) { content() }
}

@Composable
private fun EpTitle(icon: String, text: String) {
    Row(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        FaIcon(icon, rem(0.9).value.dp, FF.c.primary)
        FText(text, size = rem(0.9), weight = FontWeight.ExtraBold, color = FF.c.primary)
    }
}

@Composable
private fun EpLabel(text: String) {
    FText(text, size = rem(0.75), weight = FontWeight.SemiBold, color = FF.c.textMuted, modifier = Modifier.fillMaxWidth().padding(start = 2.dp, bottom = 6.dp))
}

/** `.ep-field` — card-coloured input with a 2dp border, icon on the left and an optional counter on the right. */
@Composable
private fun EpField(
    value: String, onChange: (String) -> Unit, placeholder: String, icon: String, keyboard: KeyboardType = KeyboardType.Text,
    enabled: Boolean = true, maxLength: Int? = null, count: String? = null, password: Boolean = false, bottom: Dp = 12.dp,
) {
    val c = FF.c
    InputBox(
        value, onChange, Modifier.fillMaxWidth().padding(bottom = bottom).alpha(if (enabled) 1f else 0.65f), placeholder = placeholder,
        keyboardType = keyboard, password = password, enabled = enabled, maxLength = maxLength,
        restBg = if (enabled) c.bgCard else c.bgInput, restBorder = c.border,
        leading = { Box(Modifier.width(14.dp)) { FaIcon(icon, rem(0.95).value.dp, c.textMuted) } },
        trailing = if (count != null) ({ FText(count, size = rem(0.68), weight = FontWeight.SemiBold, color = c.textMuted) }) else null,
    )
}

@Composable
private fun EpPill(icon: String, text: String, ok: Boolean) {
    val c = FF.c
    val bg = if (ok) (if (c.isDark) Color(0x2E22C55E) else Color(0xFFDCFCE7)) else (if (c.isDark) Color(0x2E94A3B8) else Color(0xFFE2E8F0))
    val fg = if (ok) (if (c.isDark) Color(0xFF4ADE80) else Color(0xFF15803D)) else (if (c.isDark) Color(0xFFCBD5E1) else Color(0xFF475569))
    Row(
        Modifier.clip(RoundedCornerShape(20.dp)).background(bg).padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        FaIcon(icon, rem(0.68).value.dp, fg)
        FText(text, size = rem(0.68), weight = FontWeight.ExtraBold, color = fg)
    }
}

/** `.ep-mini` (outlined) / `.solid` (gradient) / `.ghost` (muted border). */
@Composable
private fun EpMini(label: String, icon: String?, solid: Boolean = false, ghost: Boolean = false, busy: Boolean = false, busyLabel: String = "Saving…", onClick: () -> Unit) {
    val c = FF.c
    val shape = RoundedCornerShape(12.dp)
    val fg = if (solid) Color.White else if (ghost) c.textMuted else c.primary
    var m = Modifier.graphicsLayer { alpha = if (busy) 0.6f else 1f }.clip(shape)
    m = if (solid) m.background(Brush.linearGradient(listOf(c.primary, c.primaryDark))) else m.border(1.5.dp, if (ghost) c.border else c.primary, shape)
    Row(
        m.press(0.93f) { if (!busy) onClick() }.padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        if (busy) SpinIcon(rem(0.74).value.dp, fg, icon = "fa-solid fa-spinner") else if (icon != null) FaIcon(icon, rem(0.74).value.dp, fg)
        FText(if (busy) busyLabel else label, size = rem(0.74), weight = FontWeight.ExtraBold, color = fg, maxLines = 1, softWrap = false)
    }
}
