package com.ffcashbattle.app.ui.comp

import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.Inter
import com.ffcashbattle.app.ui.theme.rem

/** A paragraph with inline <b> parts: segments are (text, bold) pairs — `[...]` in [markup] marks bold, e.g. "send via UPI, then enter your [UTR]". */
@Composable
fun FRich(
    markup: String, modifier: Modifier = Modifier, size: TextUnit = rem(1.0), color: Color = FF.c.textMain, boldColor: Color = color,
    lineHeight: TextUnit = TextUnit.Unspecified, align: TextAlign = TextAlign.Unspecified, weight: FontWeight = FontWeight.Normal,
) {
    val text = buildAnnotatedString {
        var bold = false
        val sb = StringBuilder()
        fun flush() {
            if (sb.isEmpty()) return
            if (bold) withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = boldColor)) { append(sb.toString()) } else append(sb.toString())
            sb.setLength(0)
        }
        for (ch in markup) {
            if (ch == '[') { flush(); bold = true } else if (ch == ']') { flush(); bold = false } else sb.append(ch)
        }
        flush()
    }
    BasicText(text, modifier, TextStyle(color = color, fontSize = size, fontFamily = Inter, fontWeight = weight, lineHeight = lineHeight, textAlign = align))
}
