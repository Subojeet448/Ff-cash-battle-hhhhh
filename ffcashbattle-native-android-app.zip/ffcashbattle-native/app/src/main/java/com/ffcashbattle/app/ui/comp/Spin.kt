package com.ffcashbattle.app.ui.comp

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp

/** `<i class="fa-solid fa-circle-notch fa-spin">` — a spinner that rotates once per second. */
@Composable
fun SpinIcon(size: Dp, tint: Color, modifier: Modifier = Modifier, icon: String = "fa-solid fa-circle-notch") {
    val inf = rememberInfiniteTransition(label = "spin")
    val r by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Restart), label = "r")
    FaIcon(icon, size, tint, modifier.graphicsLayer { rotationZ = r })
}

/** `giftWiggle` keyframes (0-70% rest, 78% -14deg, 86% 12deg, 94% -6deg, 100% 0) as a rotation in degrees. */
@Composable
fun rememberWiggle(ms: Int = 2400): Float {
    val inf = rememberInfiniteTransition(label = "wiggle")
    val w by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(ms, easing = LinearEasing), RepeatMode.Restart), label = "w")
    return when {
        w < 0.70f -> 0f
        w < 0.78f -> -14f * ((w - 0.70f) / 0.08f)
        w < 0.86f -> -14f + 26f * ((w - 0.78f) / 0.08f)
        w < 0.94f -> 12f - 18f * ((w - 0.86f) / 0.08f)
        else -> -6f + 6f * ((w - 0.94f) / 0.06f)
    }
}
