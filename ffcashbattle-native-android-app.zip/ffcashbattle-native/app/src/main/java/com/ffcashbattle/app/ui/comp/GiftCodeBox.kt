package com.ffcashbattle.app.ui.comp

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay

/** `window.app.giftCodeBox(code)` — Google Play gift code with a Copy button (notifications + transaction detail). */
@Composable
fun GiftCodeBox(code: String, modifier: Modifier = Modifier) {
    val c = FF.c
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) { if (copied) { delay(1500); copied = false } }
    Row(
        modifier.fillMaxWidth().padding(vertical = 12.dp)
            .clip(RoundedCornerShape(14.dp)).background(c.bgInput)
            .drawBehind {
                val sw = 1.5.dp.toPx()
                drawRoundRect(
                    c.success, topLeft = Offset(sw / 2, sw / 2), size = Size(size.width - sw, size.height - sw),
                    cornerRadius = CornerRadius(14.dp.toPx()), style = Stroke(sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(7.dp.toPx(), 5.dp.toPx()))),
                )
            }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        NamedImage("wallet_google_play", Modifier.size(30.dp))
        Column(Modifier.weight(1f)) {
            FText("GOOGLE PLAY GIFT CODE", size = rem(0.68), color = c.textMuted, weight = FontWeight.Bold, letterSpacing = 0.5.sp)
            FText(code, size = rem(1.0), mono = true, letterSpacing = 0.8.sp)
        }
        Row(
            Modifier.press(0.94f) {
                val cm = AppStore.app.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("ffcb", code))
                AppStore.toast("Gift code copied ✓")
                copied = true
            }.clip(RoundedCornerShape(10.dp)).background(c.success).padding(horizontal = 13.dp, vertical = 9.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            FaIcon(if (copied) "fa-solid fa-check" else "fa-regular fa-copy", rem(0.78).value.dp, Color.White)
            FText(if (copied) "Copied" else "Copy", size = rem(0.78), weight = FontWeight.ExtraBold, color = Color.White)
        }
    }
}
