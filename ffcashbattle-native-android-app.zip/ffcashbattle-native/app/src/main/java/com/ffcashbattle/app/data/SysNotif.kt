package com.ffcashbattle.app.data

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.ffcashbattle.app.MainActivity
import com.ffcashbattle.app.R

/** Real Android (status-bar / notification-shade) notifications: balance credited, withdrawal paid, room id ready, match result, chat. */
object SysNotif {
    const val CH_WALLET = "wallet"
    const val CH_MATCH = "matches"
    const val CH_CHAT = "chat"
    private var nextId = 1000

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_WALLET, ctx.getString(R.string.channel_wallet), NotificationManager.IMPORTANCE_HIGH).apply { description = ctx.getString(R.string.channel_wallet_desc) })
        nm.createNotificationChannel(NotificationChannel(CH_MATCH, ctx.getString(R.string.channel_matches), NotificationManager.IMPORTANCE_HIGH).apply { description = ctx.getString(R.string.channel_matches_desc) })
        nm.createNotificationChannel(NotificationChannel(CH_CHAT, ctx.getString(R.string.channel_chat), NotificationManager.IMPORTANCE_DEFAULT).apply { description = ctx.getString(R.string.channel_chat_desc) })
    }

    fun canPost(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun post(ctx: Context, channel: String, title: String, body: String, extra: Pair<String, String>? = null) {
        if (!canPost(ctx)) return
        val open = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (extra != null) putExtra(extra.first, extra.second)
        }
        val pi = PendingIntent.getActivity(ctx, nextId, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_notify)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        try { NotificationManagerCompat.from(ctx).notify(nextId++, n) } catch (_: SecurityException) { }
    }
}
