package com.ffcashbattle.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.ffcashbattle.app.state.AppStore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Locale

/** One entry of the bell sheet (global announcement or a personal notification). */
class NotifItem(
    val key: String,
    val id: String?,            // Firestore id of a personal notification (null = global announcement)
    val title: String,
    val message: String,
    val date: String,
    val ms: Long,
    val claimAmount: Double,
    val claimType: String,
    val claimed: Boolean,
    val giftCode: String,
    val scratchCard: String,
    val fresh: Boolean,         // arrived after the sheet was last opened (shows the NEW badge)
)

/**
 * Port of components/notifications/notifications.js (data part): fetch global + personal notifications, "new" counting
 * (notifSeenAt), clear-all (notifClearedAt), hide single global ones (notifHidden), delete personal ones, claim marking.
 * Also drives the red dot on the header bell.
 */
object NotifStore {
    var items by mutableStateOf<List<NotifItem>>(emptyList())
    var loaded by mutableStateOf(false)
    var failed by mutableStateOf(false)

    private var unsub: ListenerRegistration? = null
    private var liveFor: String? = null

    private fun clearedAt(): Long = Prefs.long("notifClearedAt", 0L)
    private fun seenAt(): Long = Prefs.long("notifSeenAt", 0L)

    private fun hidden(): MutableList<String> {
        val out = ArrayList<String>()
        try { val a = JSONArray(Prefs.str("notifHidden", "[]")); for (i in 0 until a.length()) out.add(a.getString(i)) } catch (_: Exception) { }
        return out
    }

    /** Start watching the signed-in user's personal notifications so the bell dot reacts to admin messages. */
    fun start(uid: String) {
        if (liveFor == uid && unsub != null) return
        stop(); liveFor = uid
        unsub = Repo.listenCol("users", uid, "notifications") { _, _ -> AppStore.scope.launch { load(markSeen = false, silent = true) } }
        AppStore.scope.launch { load(markSeen = false, silent = true) }
    }

    fun stop() {
        unsub?.remove(); unsub = null; liveFor = null
        items = emptyList(); loaded = false; failed = false
    }

    /** Called when the sheet opens: marks everything as seen after computing the NEW badges. */
    suspend fun open() { load(markSeen = true, silent = items.isNotEmpty()) }

    suspend fun load(markSeen: Boolean, silent: Boolean = false) {
        try {
            val uid = AppStore.uid ?: ""
            val seen = seenAt()
            val cleared = clearedAt()
            val hid = hidden().toHashSet()
            val raw = ArrayList<NotifItem>()
            val global = try { Repo.getCol("notifications", q = { it.orderBy("timestamp", Query.Direction.DESCENDING).limit(15) }) } catch (e: Exception) { if (uid.isEmpty()) throw e else emptyList() }
            for (d in global) {
                val ms = d.ms("timestamp")
                raw.add(NotifItem("g_${ms}_${d.s("title").take(20)}", null, d.s("title"), d.s("message").ifEmpty { d.s("body") }, d.s("date"), ms, 0.0, "", false, "", "", false))
            }
            if (uid.isNotEmpty()) {
                val mine = Repo.getCol("users", uid, "notifications")
                val fmt = SimpleDateFormat("dd MMM yyyy", Locale("en", "IN"))
                for (d in mine) {
                    val ms = d.ms("timestamp")
                    val date = d.s("date").ifEmpty { if (ms > 0) fmt.format(java.util.Date(ms)) else "" }
                    raw.add(NotifItem(d.id, d.id, d.s("title"), d.s("message").ifEmpty { d.s("body") }, date, ms, d.n("claimAmount"), d.s("claimType"), d.b("claimed"), d.s("giftCode"), d.s("scratchCard"), false))
                }
            }
            val shown = raw.filter { it.ms > cleared && it.key !in hid }.sortedByDescending { it.ms }
            fun isNew(n: NotifItem) = n.ms > seen || (n.claimAmount > 0 && n.id != null && !n.claimed)
            val withFresh = shown.map { n ->
                NotifItem(n.key, n.id, n.title, n.message, n.date, n.ms, n.claimAmount, n.claimType, n.claimed, n.giftCode, n.scratchCard, isNew(n))
            }
            val unseen = withFresh.count { it.fresh }
            items = withFresh; loaded = true; failed = false
            if (markSeen) { AppStore.notifDot = false; Prefs.put("notifSeenAt", System.currentTimeMillis()) }
            else if (unseen > 0) AppStore.notifDot = true
        } catch (e: Exception) {
            if (!silent) failed = true
        }
    }

    /** Delete one notification (personal -> Firestore, global -> hidden on this device). */
    suspend fun delete(n: NotifItem) {
        try {
            val uid = AppStore.uid ?: ""
            if (n.id != null && uid.isNotEmpty()) Repo.delete(listOf("users", uid, "notifications", n.id))
            else { val h = hidden(); h.add(n.key); Prefs.put("notifHidden", JSONArray(h.takeLast(200)).toString()) }
        } catch (_: Exception) { }
        items = items.filter { it.key != n.key }
    }

    /** Clear all: remember the time and delete every personal notification. */
    suspend fun clearAll() {
        Prefs.put("notifClearedAt", System.currentTimeMillis())
        try {
            val uid = AppStore.uid ?: ""
            if (uid.isNotEmpty()) for (d in Repo.getCol("users", uid, "notifications")) Repo.delete(listOf("users", uid, "notifications", d.id))
        } catch (_: Exception) { }
        AppStore.notifDot = false
    }

    /** Old "claim" notifications are only marked as claimed (rewards are credited by the admin). */
    suspend fun markClaimed(n: NotifItem) {
        val uid = AppStore.uid ?: ""
        if (n.id == null || uid.isEmpty()) return
        Repo.update(listOf("users", uid, "notifications", n.id), mapOf("claimed" to true, "claimedAt" to System.currentTimeMillis()))
        load(markSeen = true, silent = true)
    }
}
