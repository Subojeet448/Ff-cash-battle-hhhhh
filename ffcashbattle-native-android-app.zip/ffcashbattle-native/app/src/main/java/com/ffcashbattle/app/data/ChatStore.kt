package com.ffcashbattle.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.ffcashbattle.app.state.AppStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** One message kept on THIS phone (chat-keep.js `saved` object store). */
class SavedMsg(
    val k: String, val uid: String, val room: String, val roomName: String, val kind: String, val id: String,
    val from: String, val name: String, val text: String, val at: Long, val savedAt: Long, val dm: Boolean = false, val auto: Boolean = false,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("k", k); put("uid", uid); put("room", room); put("roomName", roomName); put("kind", kind); put("id", id)
        put("from", from); put("name", name); put("text", text); put("at", at); put("savedAt", savedAt)
        if (dm) put("dm", 1)
        if (auto) put("auto", 1)
    }

    companion object {
        fun of(o: JSONObject): SavedMsg = SavedMsg(
            o.optString("k"), o.optString("uid"), o.optString("room"), o.optString("roomName", "Chat"), o.optString("kind", "dm"), o.optString("id"),
            o.optString("from"), o.optString("name"), o.optString("text"), o.optLong("at"), o.optLong("savedAt"), o.optInt("dm") == 1, o.optInt("auto") == 1,
        )
    }
}

/**
 * Saved messages + the automatic copies of friend chats. The website keeps them in IndexedDB; the app keeps one JSON file per account
 * in the app's private storage, so they survive after the server deletes the messages.
 */
object ChatStore {
    private val rows = LinkedHashMap<String, SavedMsg>()
    private var loadedFor: String? = null

    /** Bumped on every change so Compose screens that show the list / counts redraw. */
    var version by mutableIntStateOf(0)
        private set

    private fun file(uid: String) = File(AppStore.app.filesDir, "chat_saved_" + uid.filter { it.isLetterOrDigit() || it == '_' } + ".json")

    @Synchronized fun load(uid: String) {
        if (loadedFor == uid) return
        rows.clear(); loadedFor = uid
        try {
            val f = file(uid)
            if (f.exists()) {
                val a = JSONArray(f.readText())
                for (i in 0 until a.length()) { val r = SavedMsg.of(a.getJSONObject(i)); if (r.k.isNotEmpty() && r.uid == uid) rows[r.k] = r }
            }
        } catch (_: Exception) { }
        version++
    }

    @Synchronized fun unload() { rows.clear(); loadedFor = null; version++ }

    private fun persist() {
        val uid = loadedFor ?: return
        val snap = rows.values.toList()
        AppStore.scope.launch(Dispatchers.IO) {
            try {
                val a = JSONArray(); snap.forEach { a.put(it.toJson()) }
                val f = file(uid); val tmp = File(f.parentFile, f.name + ".tmp")
                tmp.writeText(a.toString()); if (!tmp.renameTo(f)) { f.writeText(a.toString()); tmp.delete() }
            } catch (_: Exception) { }
        }
    }

    @Synchronized fun all(): List<SavedMsg> = rows.values.toList()
    @Synchronized fun has(k: String): Boolean = rows.containsKey(k)
    @Synchronized fun get(k: String): SavedMsg? = rows[k]
    @Synchronized fun savedKeys(): Set<String> = rows.values.filter { !it.dm }.map { it.k }.toHashSet()
    @Synchronized fun dmKeys(): Set<String> = rows.values.filter { it.dm }.map { it.k }.toHashSet()
    @Synchronized fun count(): Int = rows.size

    @Synchronized fun put(items: List<SavedMsg>) { if (items.isEmpty()) return; items.forEach { rows[it.k] = it }; version++; persist() }
    @Synchronized fun del(keys: Collection<String>) { if (keys.isEmpty()) return; keys.forEach { rows.remove(it) }; version++; persist() }
    @Synchronized fun clear() { rows.clear(); version++; persist() }

    /** Backup file text (chat-backup v1, same format as the website). */
    @Synchronized fun backupJson(uid: String): String {
        val a = JSONArray(); rows.values.forEach { a.put(it.toJson()) }
        return JSONObject().apply { put("app", "ff-cash-battle"); put("type", "chat-backup"); put("v", 1); put("uid", uid); put("at", System.currentTimeMillis()); put("count", rows.size); put("rows", a) }.toString()
    }

    /** Restore: returns the number of NEW messages, or -1 not a backup, -2 other account, 0 nothing found. */
    @Synchronized fun restore(uid: String, text: String): Int {
        val d = try { JSONObject(text) } catch (_: Exception) { return -1 }
        if (d.optString("type") != "chat-backup" || d.optJSONArray("rows") == null) return -1
        if (d.optString("uid") != uid) return -2
        val a = d.getJSONArray("rows"); val fresh = ArrayList<SavedMsg>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val k = o.optString("k")
            if (k.isEmpty() || o.optString("uid") != uid || !k.startsWith("$uid|") || !o.has("text") || o.optLong("at") <= 0L) continue
            if (rows.containsKey(k)) continue
            fresh.add(SavedMsg(k, uid, o.optString("room"), o.optString("roomName", "Chat"), o.optString("kind", "dm"), o.optString("id"), o.optString("from"), o.optString("name"),
                o.optString("text").take(2000), o.optLong("at"), o.optLong("savedAt").takeIf { it > 0 } ?: System.currentTimeMillis(), o.optInt("dm") == 1, o.optInt("auto") == 1))
        }
        put(fresh)
        return fresh.size
    }
}
