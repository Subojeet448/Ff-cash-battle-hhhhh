package com.ffcashbattle.app.ui.modals

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.Repo
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.state.Page
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.hypot

// ------------------------------------------------------------------------------------------------ session helpers

fun sessionFirstName(n: String?): String {
    val t = (n ?: "").trim().split(Regex("\\s+")).firstOrNull().orEmpty().take(16)
    return t.ifEmpty { "Player" }
}

fun sessionInitial(n: String?): String = sessionFirstName(n).take(1).uppercase()

fun sessionMeName(): String {
    val fb = try { Repo.auth.currentUser?.displayName } catch (_: Exception) { null }
    if (!fb.isNullOrBlank()) return fb
    val u = AppStore.user
    return u.s("name").ifEmpty { u.s("username") }.ifEmpty { "Player" }
}

/** `auth.confirmLogout` state machine (session.js): goodbye screen -> real sign-out -> fade out. */
object SessionUi {
    var show by mutableStateOf(false)
    var leave by mutableStateOf(false)
    var done by mutableStateOf(false)
    var step by mutableIntStateOf(0)
    var title by mutableStateOf("Logging out…")
    var sub by mutableStateOf("Securing your session")
    private var busy = false

    fun confirmLogout() {
        if (busy) return
        busy = true
        val name = sessionFirstName(sessionMeName())
        AppStore.closeModal()
        leave = false; done = false
        title = "Logging out…"; sub = "Securing your session"
        step = 1; show = true
        AppStore.scope.launch {
            var failed: Throwable? = null
            try {
                delay(750)
                step = 2; sub = "Signing you out"
                coroutineScope {
                    launch { AppStore.logout() }
                    delay(650)
                }
                AppStore.goto(Page.HOME)
                step = 4; done = true
                title = "You are logged out"
                sub = "See you soon, $name 👋"
                delay(1500)
            } catch (e: Exception) {
                failed = e
            }
            leave = true; show = false
            delay(800)
            leave = false; done = false; step = 0
            busy = false
            if (failed != null) AppStore.toast("Logout failed: " + (failed.message ?: failed.toString()))
        }
    }
}

// ------------------------------------------------------------------------------------------------ confirm sheet

/** Entrance used by .lo-title / .lo-text / .lo-user / .lo-actions: translateY 12 -> 0 + fade (0.45s). */
@Composable
private fun Rise(delayMs: Int, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(450, delayMillis = delayMs, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f))) }
    Box(modifier.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 12.dp.toPx() }) { content() }
}

@Composable
private fun LoDoor() {
    val inf = rememberInfiniteTransition(label = "door")
    val ring1 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart), label = "r1")
    val ring2 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart, StartOffset(1100)), label = "r2")
    val sway by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "sway")
    val pop = remember { Animatable(0f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, tween(550, easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f))) }
    val dark = FF.c.isDark
    val shape = RoundedCornerShape(28.dp)
    Box(Modifier.padding(top = 10.dp, bottom = 14.dp), contentAlignment = Alignment.Center) {
        for (p in listOf(ring1, ring2)) {
            Box(
                Modifier.size(84.dp)
                    .graphicsLayer { val s = 0.92f + 0.48f * p; scaleX = s; scaleY = s; alpha = 0.5f * (1f - p) }
                    .border(2.dp, Color(0xFFFB7185), shape),
            )
        }
        Box(
            Modifier.graphicsLayer {
                val s = 0.6f + 0.4f * pop.value
                scaleX = s; scaleY = s; rotationZ = -8f * (1f - pop.value); alpha = minOf(1f, pop.value * 1.6f)
            }
                .boxShadow(30.dp, if (dark) Color(0x73000000) else Color(0x38F43F5E), shape)
                .size(84.dp).clip(shape)
                .background(Brush.linearGradient(if (dark) listOf(Color(0xFF4C0519), Color(0xFF881337)) else listOf(Color(0xFFFFF1F2), Color(0xFFFFE4E6)))),
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.graphicsLayer { transformOrigin = TransformOrigin(0.3f, 1f); rotationZ = -9f * sway; translationX = 2.dp.toPx() * sway }) {
                FaIcon("fa-solid fa-door-open", 28.dp, if (dark) Color(0xFFFDA4AF) else Color(0xFFE11D48))
            }
        }
    }
}

@Composable
private fun LoButton(text: String, icon: String?, bg: Brush, fg: Color, shadow: Color?, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier.press(0.96f) { onClick() }
            .then(if (shadow != null) Modifier.boxShadow(22.dp, shadow, shape) else Modifier)
            .clip(shape).background(bg).padding(14.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) FaIcon(icon, rem(1.0).value.dp, fg)
        FText(text, weight = FontWeight.Bold, color = fg, align = TextAlign.Center)
    }
}

/** Website `#modal-logout`. */
@Composable
fun LogoutModal() {
    val c = FF.c
    val name = sessionMeName()
    val bal = if (AppStore.uid != null) "₹" + Math.floor(AppStore.balance).toLong() + " balance stays safe" else "Your balance is safe"
    ModalSheet(padding = PaddingValues(start = 22.dp, top = 26.dp, end = 22.dp, bottom = 28.dp)) {
        val close = LocalSheetClose.current
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            LoDoor()
            Rise(80) { FText("Leaving already?", size = rem(1.4), weight = FontWeight.ExtraBold, letterSpacing = (-0.2).sp, align = TextAlign.Center) }
            Rise(140, Modifier.padding(top = 6.dp, bottom = 16.dp)) {
                FText(
                    "Your account, matches and wallet stay safe. Log back in any time.",
                    size = rem(0.9), color = c.textMuted, lineHeight = rem(0.9) * 1.55f, align = TextAlign.Center, modifier = Modifier.widthIn(max = 300.dp),
                )
            }
            Rise(200, Modifier.padding(bottom = 18.dp)) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(c.bgInput).padding(horizontal = 14.dp, vertical = 11.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.boxShadow(14.dp, Color(0x4D4F46E5), CircleShape).size(42.dp).clip(CircleShape)
                            .background(Brush.linearGradient(listOf(c.primary, c.accent))),
                        contentAlignment = Alignment.Center,
                    ) { FText(sessionInitial(name), size = rem(1.05), weight = FontWeight.ExtraBold, color = Color.White) }
                    Column(Modifier.weight(1f)) {
                        FText(name, size = rem(0.95), weight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        FText(bal, size = rem(0.76), color = c.textMuted, modifier = Modifier.padding(top = 1.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Row(
                        Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0x2410B981)).padding(horizontal = 9.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically,
                    ) {
                        val g = if (c.isDark) Color(0xFF6EE7B7) else Color(0xFF059669)
                        FaIcon("fa-solid fa-shield-halved", rem(0.7).value.dp, g)
                        FText("Safe", size = rem(0.7), weight = FontWeight.Bold, color = g)
                    }
                }
            }
            Rise(260) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    LoButton("Stay logged in", null, Brush.linearGradient(listOf(c.bgInput, c.bgInput)), c.textMain, null, Modifier.weight(1f)) { close() }
                    LoButton(
                        "Log out", "fa-solid fa-right-from-bracket",
                        Brush.linearGradient(listOf(Color(0xFFF43F5E), Color(0xFFE11D48))), Color.White, Color(0x59E11D48), Modifier.weight(1.15f),
                    ) { SessionUi.confirmLogout() }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------ goodbye overlay

@Composable
private fun SoStep(text: String, state: Int) {   // 0 idle, 1 on, 2 ok
    val fg = when (state) { 1 -> Color.White; 2 -> Color(0xFF6EE7B7); else -> Color(0x73FFFFFF) }
    val bg = when (state) { 1 -> Color(0x736366F1); 2 -> Color(0x2910B981); else -> Color(0x12FFFFFF) }
    val inf = rememberInfiniteTransition(label = "stp")
    val blink by inf.animateFloat(1f, 0.3f, infiniteRepeatable(tween(500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "blink")
    Row(
        Modifier.clip(RoundedCornerShape(20.dp)).background(bg).padding(horizontal = 11.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.graphicsLayer { alpha = if (state == 1) blink else 1f; val s = if (state == 2) 1.15f else 1f; scaleX = s; scaleY = s }.size(7.dp).clip(CircleShape).background(fg))
        FText(text, size = rem(0.72), weight = FontWeight.Bold, color = fg)
    }
}

/** `#session-overlay` — full-screen indigo goodbye screen with progress ring. Hosted by AppRoot above the modals. */
@Composable
fun SessionOverlay() {
    val show = SessionUi.show
    val leave = SessionUi.leave
    val done = SessionUi.done
    val step = SessionUi.step

    val reveal = remember { Animatable(0f) }
    val ovAlpha = remember { Animatable(0f) }
    val boxIn = remember { Animatable(0f) }
    val arc = remember { Animatable(0f) }

    LaunchedEffect(show, leave) {
        if (show) {
            launch { reveal.animateTo(1f, tween(800, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f))) }
            launch { ovAlpha.animateTo(1f, tween(300)) }
            launch { boxIn.animateTo(1f, tween(700, delayMillis = 200, easing = CubicBezierEasing(0.34f, 1.4f, 0.64f, 1f))) }
        } else if (leave) {
            launch { boxIn.animateTo(0f, tween(450)) }
            ovAlpha.animateTo(0f, tween(600))
            reveal.snapTo(0f)
        }
    }
    LaunchedEffect(show) {
        if (show) {
            arc.snapTo(0f)
            delay(300)
            arc.animateTo(1f, tween(1550, easing = CubicBezierEasing(0.45f, 0f, 0.25f, 1f)))
        }
    }
    LaunchedEffect(done) { if (done) arc.animateTo(1f, tween(150)) }

    if (ovAlpha.value <= 0.001f && !show && !leave) return

    val inf = rememberInfiniteTransition(label = "so")
    val f1 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "f1")
    val f2 by inf.animateFloat(1f, 0f, infiniteRepeatable(tween(11000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "f2")
    val f3 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(13000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "f3")
    val nudge by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(650, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "nudge")

    val circle = remember(reveal.value) {
        GenericShape { size, _ ->
            val r = hypot(size.width, size.height) * 1.5f * reveal.value
            addOval(Rect(Offset(size.width / 2f, size.height * 0.62f), r))
        }
    }
    val doneProgress = remember { Animatable(0f) }
    LaunchedEffect(done) { if (done) { delay(120); doneProgress.animateTo(1f, tween(500, easing = CubicBezierEasing(0.65f, 0f, 0.35f, 1f))) } else doneProgress.snapTo(0f) }
    val corePop = remember { Animatable(1f) }
    LaunchedEffect(done) { if (done) { corePop.snapTo(0.8f); corePop.animateTo(1f, tween(550, easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f))) } }

    Box(
        Modifier.fillMaxSize()
            .graphicsLayer { alpha = ovAlpha.value; if (leave) { scaleX = 1.04f - 0.04f * (1f - ovAlpha.value); scaleY = scaleX } }
            .clip(circle)
            .background(
                Brush.radialGradient(
                    0f to Color(0xFF312E81), 0.45f to Color(0xFF1E1B4B), 1f to Color(0xFF0B1020),
                    center = Offset(540f, 0f), radius = 2200f,
                ),
            )
            .tap { },
        contentAlignment = Alignment.Center,
    ) {
        // blurred orbs (soft radial gradients; real blur is not available on every API level)
        Box(Modifier.fillMaxSize().drawBehind {
            fun orb(color: Color, a: Float, cx: Float, cy: Float, r: Float) =
                drawCircle(Brush.radialGradient(listOf(color.copy(alpha = a), Color.Transparent), center = Offset(cx, cy), radius = r), radius = r, center = Offset(cx, cy))
            orb(Color(0xFF6366F1), 0.55f, 70.dp.toPx() + 36.dp.toPx() * f1, 70.dp.toPx() + 28.dp.toPx() * f1, 260.dp.toPx())
            orb(Color(0xFFF43F5E), 0.55f, size.width - 60.dp.toPx() - 36.dp.toPx() * f2, size.height - 60.dp.toPx() - 28.dp.toPx() * f2, 240.dp.toPx())
            orb(Color(0xFF22D3EE), 0.28f, size.width * 0.62f + 30.dp.toPx() * f3, size.height * 0.45f + 20.dp.toPx() * f3, 170.dp.toPx())
        })
        Column(
            Modifier.padding(horizontal = 24.dp).graphicsLayer {
                val b = boxIn.value
                alpha = b
                translationY = (1f - b) * 18.dp.toPx() - (if (leave) 10.dp.toPx() * (1f - b) else 0f)
                val s = 0.92f + 0.08f * b
                scaleX = s; scaleY = s
            },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // ring
            Box(Modifier.size(118.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val k = size.width / 110f
                    val r = 46f * k
                    val stroke = 6f * k
                    drawCircle(Color(0x1FFFFFFF), radius = r, style = Stroke(stroke))
                    val col = if (done) Color(0xFF34D399) else Color(0xFFA5B4FC)
                    val glow = if (done) Color(0x5934D399) else Color(0x4D818CF8)
                    val topLeft = Offset(size.width / 2f - r, size.height / 2f - r)
                    val sz = Size(r * 2f, r * 2f)
                    drawArc(glow, -90f, 360f * arc.value, false, topLeft, sz, style = Stroke(stroke + 6f * k, cap = StrokeCap.Round))
                    drawArc(col, -90f, 360f * arc.value, false, topLeft, sz, style = Stroke(stroke, cap = StrokeCap.Round))
                }
                Box(
                    Modifier.graphicsLayer { scaleX = corePop.value; scaleY = corePop.value }
                        .size(96.dp).clip(CircleShape)
                        .background(if (done) Color(0x8C064E3B) else Color(0xC70F172A))
                        .border(1.dp, Color(0x14FFFFFF), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Box(Modifier.graphicsLayer { alpha = if (done) 0f else 1f; translationX = 5.dp.toPx() * nudge; val s = if (done) 0.4f else 1f; scaleX = s; scaleY = s }) {
                        FaIcon("fa-solid fa-right-from-bracket", rem(2.1).value.dp, Color(0xFFE0E7FF))
                    }
                    Canvas(Modifier.size(56.dp).graphicsLayer { alpha = if (done) 1f else 0f }) {
                        val k = size.width / 52f
                        val path = Path().apply { moveTo(14f * k, 27f * k); lineTo(22f * k, 35f * k); lineTo(38f * k, 18f * k) }
                        val pm = PathMeasure()
                        pm.setPath(path, false)
                        val seg = Path()
                        pm.getSegment(0f, pm.length * doneProgress.value, seg, true)
                        drawPath(seg, Color(0xFF34D399), style = Stroke(4.5f * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    }
                }
            }
            FText(SessionUi.title, size = rem(1.55), weight = FontWeight.ExtraBold, color = Color.White, letterSpacing = (-0.2).sp, align = TextAlign.Center, modifier = Modifier.padding(top = 24.dp, bottom = 6.dp))
            Box(Modifier.heightIn(min = (rem(0.95).value * 1.3f).dp)) {
                FText(SessionUi.sub, size = rem(0.95), color = Color.White.copy(alpha = 0.75f), align = TextAlign.Center)
            }
            Row(Modifier.padding(top = 22.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SoStep("Saving", if (step == 1) 1 else if (step > 1) 2 else 0)
                SoStep("Signing out", if (step == 2) 1 else if (step > 2) 2 else 0)
                SoStep("Done", if (step == 3) 1 else if (step > 3) 2 else 0)
            }
        }
    }
}
