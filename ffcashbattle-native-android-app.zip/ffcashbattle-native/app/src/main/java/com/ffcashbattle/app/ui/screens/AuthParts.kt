package com.ffcashbattle.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.InputBox
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay

/** fx-shake as a horizontal offset (k = 0..1 progress, amp = peak distance). */
internal fun shakeOffset(k: Float, amp: Float): Float {
    if (k <= 0f || k >= 1f) return 0f
    val pts = floatArrayOf(0f, -1f, 1f, -0.75f, 0.75f, -0.4f, 0.4f, 0f)
    val x = k * (pts.size - 1); val i = x.toInt().coerceIn(0, pts.size - 2)
    return (pts[i] + (pts[i + 1] - pts[i]) * (x - i)) * amp
}

/** CSS `radial-gradient(rx ry at cx cy, c0, transparent stop)`. */
internal fun DrawScope.authGlow(cx: Float, cy: Float, rx: Float, ry: Float, c0: Color, stop: Float) {
    val k = ry / rx
    withTransform({ translate(cx, cy); scale(1f, k, Offset.Zero) }) {
        drawRect(
            Brush.radialGradient(0f to c0, stop to c0.copy(alpha = 0f), center = Offset.Zero, radius = rx),
            topLeft = Offset(-cx, -cy / k), size = Size(size.width, size.height / k),
        )
    }
}

private fun orbPos(t: Float): Triple<Float, Float, Float> {       // auth-orb keyframes: 0/100% (0,0,1) · 33% (40,-30,1.12) · 66% (-30,35,.92)
    val pts = arrayOf(Triple(0f, 0f, 1f), Triple(40f, -30f, 1.12f), Triple(-30f, 35f, 0.92f), Triple(0f, 0f, 1f))
    val x = (t * 3f).coerceIn(0f, 2.9999f); val i = x.toInt(); val f = x - i
    val a = pts[i]; val b = pts[i + 1]
    return Triple(a.first + (b.first - a.first) * f, a.second + (b.second - a.second) * f, a.third + (b.third - a.third) * f)
}

/** Dark indigo backdrop with three floating colour orbs — `#auth-modal-wrapper` / `#fp-wrapper`. */
@Composable
fun AuthBackdrop(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val inf = rememberInfiniteTransition(label = "orbs")
    val t1 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Restart), label = "o1")
    val t2 by inf.animateFloat(1f, 0f, infiniteRepeatable(tween(17000, easing = LinearEasing), RepeatMode.Restart), label = "o2")
    val t3 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(20000, easing = LinearEasing), RepeatMode.Restart), label = "o3")
    Box(
        modifier.background(Color(0xFF0B1020)).drawBehind {
            val w = size.width; val h = size.height
            authGlow(w * 0.15f, h * 0.10f, 450.dp.toPx(), 260.dp.toPx(), Color(0x8C4F46E5), 0.6f)
            authGlow(w * 0.90f, h * 0.95f, 400.dp.toPx(), 260.dp.toPx(), Color(0x73F43F5E), 0.6f)
            fun orb(color: Color, d: Float, cx: Float, cy: Float, t: Float, alpha: Float) {
                val (dx, dy, s) = orbPos(t)
                val r = d.dp.toPx() / 2f * s
                val c = Offset(cx + dx.dp.toPx(), cy + dy.dp.toPx())
                drawCircle(Brush.radialGradient(0f to color.copy(alpha = alpha), 0.55f to color.copy(alpha = alpha * 0.55f), 1f to color.copy(alpha = 0f), center = c, radius = r * 1.5f), r * 1.5f, c)
            }
            orb(Color(0xFF6366F1), 260f, -70.dp.toPx() + 130.dp.toPx(), h * 0.08f + 130.dp.toPx(), t1, 0.5f)
            orb(Color(0xFFF43F5E), 220f, w + 50.dp.toPx() - 110.dp.toPx(), h * 0.94f - 110.dp.toPx(), t2, 0.5f)
            orb(Color(0xFF22D3EE), 160f, w * 0.55f + 80.dp.toPx(), h * 0.48f + 80.dp.toPx(), t3, 0.28f)
        },
        content = content,
    )
}

/** The 4px sweeping gradient line on top of the cards (`.auth-card::before`). */
@Composable
fun AuthTopBar(modifier: Modifier = Modifier) {
    val c = FF.c
    val t by rememberInfiniteTransition(label = "bar").animateFloat(0f, 1f, infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Restart), label = "t")
    Box(modifier.fillMaxWidth().height(4.dp).drawBehind {
        val w = size.width
        drawRect(Brush.horizontalGradient(listOf(c.primary, c.accent, c.primary), startX = -2f * w * t, endX = 2f * w - 2f * w * t, tileMode = TileMode.Repeated))
    })
}

/** fade-up entrance (`fx-fade-up`): opacity 0 -> 1 and 14dp upwards. */
@Composable
fun FadeUp(delayMs: Int, content: @Composable () -> Unit) {
    val k = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(delayMs.toLong()); k.animateTo(1f, tween(550, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f))) }
    Box(Modifier.graphicsLayer { alpha = k.value; translationY = (1f - k.value) * 14.dp.toPx() }) { content() }
}

/** Left icon slot so input text starts 47dp in, like `style="padding-left:45px"`. */
@Composable
fun AuthLead(icon: String) {
    Box(Modifier.width(19.dp)) { FaIcon(icon, rem(1.1).value.dp, FF.c.textMuted, Modifier.padding(start = 0.dp)) }
}

/** `.input-group` input with a left icon and an optional show/hide-password eye. */
@Composable
fun AuthInput(
    value: String, onChange: (String) -> Unit, placeholder: String, icon: String, modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text, eye: Boolean = false, invalid: Boolean = false,
    imeAction: ImeAction = ImeAction.Next, onDone: (() -> Unit)? = null, maxLength: Int? = null, bottom: Dp = 14.dp,
) {
    var show by remember { mutableStateOf(false) }
    val c = FF.c
    InputBox(
        value, onChange, modifier.fillMaxWidth().padding(bottom = bottom), placeholder = placeholder,
        keyboardType = if (eye) KeyboardType.Password else keyboardType, password = eye && !show, invalid = invalid,
        imeAction = imeAction, onDone = onDone, maxLength = maxLength, leading = { AuthLead(icon) },
        trailing = if (eye) ({
            // 36dp round button hugging the right edge; takes no height so the box keeps its normal size
            Box(
                Modifier.layout { m, cs -> val p = m.measure(cs); layout(p.width, 0) { p.place(0, -p.height / 2) } }
                    .padding(start = 0.dp).size(36.dp).clip(CircleShape).press(0.88f) { show = !show },
                contentAlignment = Alignment.Center,
            ) { FaIcon(if (show) "fa-regular fa-eye-slash" else "fa-regular fa-eye", rem(1.0).value.dp, c.textMuted) }
        }) else null,
    )
}

/** Password strength: 0 none · 1 weak · 2 good · 3 strong (same scoring as the website). */
fun pwLevel(v: String): Int {
    var s = 0
    if (v.length >= 6) s++; if (v.length >= 9) s++
    if (v.any { it in 'A'..'Z' } && v.any { it in 'a'..'z' }) s++
    if (v.any { it.isDigit() }) s++
    if (v.any { !it.isLetterOrDigit() || it.code > 127 }) s++
    return if (v.isEmpty()) 0 else if (s <= 1) 1 else if (s <= 3) 2 else 3
}

@Composable
fun PwMeter(level: Int, labelBottom: Dp = 8.dp) {
    val c = FF.c
    val frac by animateFloatAsState(listOf(0f, 0.33f, 0.66f, 1f)[level], tween(450, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)), label = "pw")
    val col = listOf(Color.Transparent, Color(0xFFEF4444), Color(0xFFF59E0B), Color(0xFF10B981))[level]
    Box(Modifier.fillMaxWidth().padding(top = 0.dp).height(5.dp).clip(RoundedCornerShape(5.dp)).background(c.border)) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(frac).clip(RoundedCornerShape(5.dp)).background(col))
    }
    Box(Modifier.fillMaxWidth().heightIn(min = 16.dp).padding(top = 4.dp, bottom = labelBottom)) {
        if (level > 0) FText(listOf("", "Weak", "Good", "Strong")[level], size = rem(0.72), weight = FontWeight.Bold, color = col)
    }
}

private val GOOGLE_PATHS = listOf(
    Color(0xFFFFC107) to "M43.6 20.1H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 8 3l5.7-5.7C34 6.1 29.3 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.3-.1-2.6-.4-3.9z",
    Color(0xFFFF3D00) to "M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 8 3l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z",
    Color(0xFF4CAF50) to "M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z",
    Color(0xFF1976D2) to "M43.6 20.1H42V20H24v8h11.3c-.8 2.2-2.2 4.1-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.6-.4-3.9z",
)

/** `.btn-google` */
@Composable
fun GoogleButton(busy: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    val paths = remember { GOOGLE_PATHS.map { (col, d) -> col to PathParser().parsePathString(d).toPath() } }
    Row(
        Modifier.fillMaxWidth().graphicsLayer { alpha = if (busy) 0.6f else 1f }
            .press(0.97f, enabled = !busy) { onClick() }
            .clip(shape).background(Color.White).border(1.dp, Color(0xFFDADCE0), shape).padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically,
    ) {
        Canvas(Modifier.size(20.dp)) { scale(size.width / 48f, Offset.Zero) { paths.forEach { (col, p) -> drawPath(p, col) } } }
        FText("Continue with Google", size = rem(0.95), weight = FontWeight.SemiBold, color = Color(0xFF3C4043))
    }
}

/** `.auth-or` — a line, "OR", a line. */
@Composable
fun OrDivider() {
    val c = FF.c
    Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f).height(1.dp).background(c.border))
        FText("OR", size = rem(0.72), weight = FontWeight.Bold, color = c.textMuted, letterSpacing = 1.sp)
        Box(Modifier.weight(1f).height(1.dp).background(c.border))
    }
}

/**
 * The self-drawing tick of `.ad-circle` + `.ad-check` (60x60 viewBox, white 4px strokes). Starts drawing on its own `delayMs` after it appears.
 */
@Composable
fun DrawnCheck(size: Dp, delayMs: Int = 150, tint: Color = Color.White) {
    val circle = remember { Animatable(0f) }
    val tick = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        circle.animateTo(1f, tween(600))
        tick.animateTo(1f, tween(400))
    }
    Canvas(Modifier.size(size)) {
        val s = this.size.width / 60f
        val sw = 4f * s
        // circle r=26 at (30,30), drawn clockwise from the top
        drawArc(tint, -90f, 360f * circle.value, false, Offset(4f * s, 4f * s), Size(52f * s, 52f * s), style = Stroke(sw, cap = StrokeCap.Round))
        val p = Path().apply { moveTo(18f * s, 31f * s); lineTo(27f * s, 40f * s); lineTo(43f * s, 22f * s) }
        val pm = PathMeasure(); pm.setPath(p, false)
        val seg = Path(); pm.getSegment(0f, pm.length * tick.value, seg, true)
        drawPath(seg, tint, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
