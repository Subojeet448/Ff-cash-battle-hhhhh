package com.ffcashbattle.app.data

/**
 * Central message catalog (English) — port of js/core/messages.js.
 * Every default message the website shows (popups, toasts, notifications, transaction-detail sheet) lives here,
 * so the app says exactly the same words as the website.
 */
object Msg {
    /** Set by AppStore (admin limits). */
    var minWd: () -> Int = { 10 }
    var minDep: () -> Int = { 5 }

    fun num(v: Any?): Double {
        val x = when (v) {
            null -> 0.0
            is Number -> v.toDouble()
            else -> v.toString().replace(Regex("[^0-9.\\-]"), "").toDoubleOrNull() ?: 0.0
        }
        return Math.abs(x)
    }

    /** JS: '₹' + (Number.isInteger(n) ? n : n.toFixed(2)) */
    fun inr(v: Any?): String {
        val n = num(v)
        return "₹" + (if (n % 1.0 == 0.0) n.toLong().toString() else String.format(java.util.Locale.US, "%.2f", n))
    }

    class StatusInfo(val label: String, val tone: String, val icon: String)

    val STATUS: Map<String, StatusInfo> = mapOf(
        "pending" to StatusInfo("Pending", "warn", "fa-hourglass-half"),
        "processing" to StatusInfo("Processing", "info", "fa-spinner"),
        "success" to StatusInfo("Successful", "success", "fa-circle-check"),
        "failed" to StatusInfo("Failed", "danger", "fa-circle-xmark"),
        "rejected" to StatusInfo("Rejected", "danger", "fa-circle-xmark"),
        "refunded" to StatusInfo("Refunded", "info", "fa-rotate-left"),
        "cancelled" to StatusInfo("Cancelled", "muted", "fa-ban"),
    )

    fun normStatus(raw: Any?): String {
        val s = (raw?.toString() ?: "pending").lowercase().trim().ifEmpty { "pending" }
        if (s in listOf("completed", "complete", "paid", "approved", "done", "credited")) return "success"
        if (s in listOf("mismatch", "error", "declined", "expired")) return "failed"
        if (s == "canceled") return "cancelled"
        if (s in listOf("refund", "returned")) return "refunded"
        return if (STATUS.containsKey(s)) s else "pending"
    }

    class Reason(val code: String, val label: String, val text: String)

    private fun r(label: String, text: String) = Reason("", label, text)

    val reasons: Map<String, Map<String, Reason>> = mapOf(
        "withdraw" to mapOf(
            "invalid_account" to r("Invalid bank details", "The account number or IFSC code does not match a valid bank account. Please double-check both and place a new request."),
            "name_mismatch" to r("Account name mismatch", "The account holder name does not match the name on your profile. Withdrawals can only be sent to an account in your own name."),
            "account_closed" to r("Account unavailable", "The receiving bank account is closed, frozen or not accepting credits. Please use a different, active account."),
            "bank_declined" to r("Declined by your bank", "Your bank declined the incoming transfer. This is usually temporary — please try again later or use another account."),
            "limit_exceeded" to r("Bank limit exceeded", "The transfer crossed the receiving limit of your account or bank. Try a smaller amount or another account."),
            "invalid_wallet" to r("Invalid wallet address", "The crypto wallet address is not valid. Please copy it again directly from your wallet app and retry."),
            "wrong_network" to r("Wrong network selected", "The address does not belong to the network you selected (e.g. TRC20 vs BEP20). Sending on the wrong network can lose funds, so we stopped the payout."),
            "below_minimum" to r("Below minimum amount", "The requested amount is below the minimum withdrawal amount, or too low to cover the processing fee."),
            "not_verified" to r("Profile not verified", "Your phone number or game UID is not verified yet. Please complete verification from your profile and try again."),
            "under_review" to r("Account under review", "Our security team is reviewing recent activity on your account. Withdrawals resume as soon as the review is complete."),
            "duplicate" to r("Duplicate request", "A similar withdrawal request was already submitted. Please wait for the first one to be completed before sending another."),
            "technical" to r("Technical issue", "Our payment partner had a temporary technical problem while sending your money. This is not your fault — please try again."),
            "other" to r("Could not be completed", "Our payments team was unable to complete this withdrawal. Please contact support with your reference ID for details."),
        ),
        "deposit" to mapOf(
            "utr_not_found" to r("Payment not found", "We could not find a payment with this UTR / Transaction ID in our bank records. Please check that you typed the 12-digit UTR correctly."),
            "amount_mismatch" to r("Amount mismatch", "The amount you entered does not match the amount we received for this payment. Please contact support with your payment screenshot."),
            "utr_used" to r("UTR already used", "This UTR / Transaction ID has already been used for a deposit, so it cannot be credited again."),
            "utr_other_user" to r("UTR belongs to another user", "This UTR / Transaction ID is already linked to a different account. Please use only your own payment details."),
            "bank_pending" to r("Bank confirmation pending", "Your bank has not confirmed this payment yet. UPI payments sometimes take a little while — if the money was debited it will be credited or returned automatically."),
            "bank_failed" to r("Payment failed at bank", "The payment did not complete on the bank side, so no money was received. If any amount was debited, your bank normally reverses it within 3–5 working days."),
            "wrong_receiver" to r("Paid to a different UPI ID", "The payment was sent to a UPI ID other than the one shown in the app. Always pay only to the UPI ID displayed on the deposit screen."),
            "timeout" to r("Verification timed out", "We waited for the payment to appear in our records but it did not arrive in time. If the money was debited, contact support — we will verify it manually."),
            "hash_not_found" to r("Transaction hash not found", "We could not find this transaction hash on the blockchain. Please check the hash and the network you used."),
            "low_confirmations" to r("Waiting for confirmations", "Your crypto transfer has not received enough network confirmations yet. It will be credited automatically once confirmed."),
            "wrong_network" to r("Wrong network used", "The transfer was sent on a different network than the one shown in the app, so it could not be matched to your account."),
            "below_minimum" to r("Below minimum deposit", "The deposited amount is below the minimum deposit amount."),
            "other" to r("Could not be verified", "We could not verify this payment automatically. Please contact support with your UTR / hash and a screenshot of the payment."),
        ),
        "refund" to mapOf(
            "match_cancelled" to r("Match cancelled", "This match was cancelled by the organisers, so your entry fee has been returned in full."),
            "match_not_started" to r("Not enough players", "The match did not get enough players to start on time, so it was cancelled and your entry fee was returned."),
            "room_issue" to r("Room could not be created", "We were unable to create or share the custom room for this match. Your entry fee has been returned."),
            "slot_conflict" to r("Slot conflict", "Your slot was taken by another player at the same moment. Your entry fee for the unused slot has been returned."),
            "duplicate_payment" to r("Duplicate payment", "You were charged more than once for the same payment. The extra amount has been returned to you."),
            "withdrawal_failed" to r("Withdrawal not completed", "Your withdrawal could not be completed, so the full amount has been returned to your Withdrawal Balance."),
            "deposit_excess" to r("Extra amount received", "We received more than the amount you entered. The extra amount has been returned to you."),
            "technical_error" to r("Technical error", "A technical error affected this transaction. We have reversed it and returned your money."),
            "admin_adjustment" to r("Support adjustment", "This amount was returned to your wallet by our support team after reviewing your request."),
            "other" to r("Refund issued", "This amount has been refunded to your wallet. Contact support if you have any questions."),
        ),
    ).mapValues { (_, cat) -> cat.mapValues { (k, v) -> Reason(k, v.label, v.text) } }

    fun reasonOf(kind: String, code: String): Reason = reasons[kind]!![code] ?: reasons[kind]!!["other"]!!

    private fun destOf(t: Doc?): String {
        if (t == null) return "account"
        return when (t.s("method").uppercase()) {
            "CRYPTO" -> (t.s("coin").ifEmpty { "crypto" }) + (if (t.s("network").isNotEmpty()) " (" + t.s("network") + ")" else "") + " wallet"
            "BANK" -> "bank account"
            "GIFTCARD" -> "Google Play gift card"
            "UPI" -> if (t.s("upiId").isNotEmpty()) "UPI ID " + t.s("upiId") else "UPI ID"
            else -> "account"
        }
    }

    fun refOf(t: Doc?): String {
        if (t == null) return ""
        val r = t.s("ref").ifEmpty { t.id }
        return r.take(8).uppercase()
    }

    private fun pickReason(t: Doc, kind: String): Reason? {
        val cat = reasons[kind] ?: emptyMap()
        val rc = t.s("reasonCode")
        if (rc.isNotEmpty() && cat.containsKey(rc)) return cat[rc]
        for (k in listOf("reason", "rejectReason", "failReason", "remark", "adminNote", "note")) {
            val v = t.s(k); if (v.isNotEmpty()) return Reason("custom", "Reason", v)
        }
        return null
    }

    // ---------------------------------------------------------------- WITHDRAWAL
    object withdraw {
        fun minAmount() = "The minimum withdrawal amount is ₹${minWd()}."
        fun fillAll() = "Please fill in all the fields to continue."
        fun shortName() = "Account holder name looks too short. Please enter the full name as per your bank."
        fun badAccount() = "Account number must be 9 to 18 digits."
        fun badUpi() = "Invalid UPI ID. It should look like name@okhdfcbank."
        fun badIfsc() = "Invalid IFSC code. It should look like SBIN0001234."
        fun insufficient(bal: Double?) = "Insufficient Withdrawal Balance" + (if (bal != null) " — you can withdraw up to " + inr(bal) else "") + ". Only winnings can be withdrawn."
        fun processing() = "Placing your withdrawal request…"
        fun title(amt: Any?, masked: String) = "Withdrawal ${inr(amt)} · $masked"
        fun popupTitle() = "Withdrawal Request Successful"
        fun popupBody(amt: Any?, net: Any?, t: Doc?) =
            "Your request to withdraw ${inr(amt)} has been received and sent to our payments team. After the ₹2 processing fee you will receive ${inr(net)} in your ${destOf(t)}, usually within 1–3 working days."
        fun gpPopupBody(amt: Any?) =
            "Your request for a Google Play gift card of ${inr(amt)} has been sent to the admin. The redeem code will appear in this app (Wallet and Notifications) with a Copy button, usually within 15–20 minutes."
        fun gpPopupFoot() = "We will notify you the moment your gift code is ready. Thank you for playing with us!"
        val popupSteps = listOf("Request received", "Under review by our team", "Money sent to you")
        fun popupFoot() = "We will notify you the moment your payment is sent. Thank you for playing with us!"
        fun toastFallback() = "Withdrawal request placed successfully."
        fun notifyOk(amt: Any?, net: Any?) = TitleBody("Withdrawal Request Received", "We have received your request to withdraw ${inr(amt)}. You will receive ${inr(net)} within 1–3 working days.")
    }

    class TitleBody(val title: String, val body: String)
    class TitleSub(val title: String, val sub: String)

    // ---------------------------------------------------------------- DEPOSIT
    object deposit {
        fun enterAmount() = "Please enter the amount you paid."
        fun minAmount() = "The minimum deposit amount is ₹${minDep()}."
        fun badUtr() = "Please enter a valid UTR or Transaction ID (8–24 letters / numbers). Example: FMPIB6862334894"
        fun needLogin() = "Please log in to add money to your wallet."
        fun submitFailed() = "We could not submit your deposit. Please check your connection and try again."
        fun utrUsed() = "This UTR / Transaction ID has already been used for a deposit."
        fun utrOther() = "This UTR / Transaction ID is linked to a different account."
        fun utrRejected() = "This UTR / Transaction ID was already reviewed and could not be verified. Please contact support."
        fun utrAmount() = "A different amount was already submitted for this UTR / Transaction ID. Please enter the exact amount you paid."
        object title {
            fun pending(amt: Any?) = "Deposit ${inr(amt)} · verifying"
            fun review(amt: Any?) = "Deposit ${inr(amt)} · under review"
            fun success(amt: Any?) = "Deposit ${inr(amt)} · credited"
            fun failed(amt: Any?) = "Deposit ${inr(amt)} · not verified"
        }
        val verifying = TitleSub("Verifying your payment…", "We are matching your UTR / Transaction ID and amount with our bank record. This takes about 10 seconds — please do not close the app.")
        fun pending(amt: Any?) = TitleSub("Payment Pending", "We have not found your ${inr(amt)} payment yet. Banks can take a few minutes — we keep checking automatically and will credit your wallet the moment it arrives. You will get a notification.")
        val alreadyChecking = TitleSub("Still verifying…", "We are already checking this payment. Please wait a moment.")
        fun processingToast() = "Your payment is still being confirmed by the bank. We will keep checking for about a minute and notify you."
        fun success(amt: Any?) = TitleSub("Payment Verified!", "${inr(amt)} has been added to your Deposit Balance. You can use it to join matches right away.")
        fun successToast(amt: Any?) = "${inr(amt)} has been added to your wallet."
        fun successNotify(amt: Any?, utr: String) = TitleBody("Deposit Successful", "${inr(amt)} has been credited to your Deposit Balance (Ref: $utr). Good luck in your next match!")

        class Fail(val code: String, val title: String, val sub: String, val body: String, val toast: String)

        /** status / received come from the bank record we saw (both optional). */
        fun fail(amt: Any?, utr: String, seenStatus: String? = null, seenReceived: Double? = null): Fail {
            val code = if (seenStatus == "used") "utr_used" else if (seenReceived != null && !seenReceived.isNaN()) "amount_mismatch" else "utr_not_found"
            val extra = if (code == "amount_mismatch") " We received ${inr(seenReceived)} but you entered ${inr(amt)}." else ""
            return Fail(
                code,
                "Deposit Could Not Be Verified",
                "We could not verify your payment of ${inr(amt)}.$extra If money was debited, don't worry — contact support with your UTR and screenshot and we will resolve it.",
                "We could not verify your payment of ${inr(amt)} (UTR: $utr). ${reasonOf("deposit", code).text}$extra If the money was debited from your account, contact support with your UTR and a payment screenshot — verified payments are always credited or refunded.",
                "We could not verify your deposit. Please contact support — your money is safe.",
            )
        }
    }

    // ---------------------------------------------------------------- REFUND
    object refund {
        fun title(amt: Any?, kind: String? = null) = "Refund ${inr(amt)}" + (if (!kind.isNullOrEmpty()) " · $kind" else "")
        fun credited(amt: Any?, code: String?) = TitleBody("Refund Credited", "${inr(amt)} has been credited back to your wallet. ${(reasons["refund"]!![code ?: ""] ?: reasons["refund"]!!["other"]!!).text}")
    }

    // ---------------------------------------------------------------- LIVE (realtime top-right cards)
    object live {
        fun depositCredited(amt: Any?) = TitleBody("Deposit Credited", "${inr(amt)} has been added to your Deposit Balance.")
        fun balanceCredited(amt: Any?) = TitleBody("Balance Credited", "${inr(amt)} has been added to your Withdrawal Balance.")
        fun withdrawPaid(t: Doc?): TitleBody =
            if (t != null && t.s("method").uppercase() == "GIFTCARD")
                TitleBody("Gift Code Ready", "Your Google Play gift code of ${inr(if (t.has("amount")) t.s("amount").replace(Regex("[^0-9.]"), "") else "")} is ready. Open it from Wallet or Notifications and tap Copy.")
            else TitleBody("Withdrawal Successful", "${inr(if (t != null && t.has("net")) t["net"] else t?.get("amount"))} has been sent to your ${destOf(t)}.")
    }

    // ---------------------------------------------------------------- notifications default text
    object notif {
        fun emptyBody() = "You have a new update on your account."
        fun claimBody() = "Tap claim to add this amount to your wallet."
        fun claimInfo() = "Rewards are credited to your wallet by our team. Nothing more is needed from you."
        fun clearConfirm() = "Delete all notifications permanently? This cannot be undone."
        fun loadFailed() = "Could not load notifications. Please check your connection."
        fun title() = "Notifications"
        fun emptyTitle() = "You're all caught up"
        fun emptySub() = "No notifications yet. New updates will appear here."
        fun clearTitle() = "Clear all notifications?"
        fun clearYes() = "Yes, delete all"
        fun clearNo() = "Keep them"
        fun clearNothing() = "There is nothing to clear."
        fun cleared() = "All notifications have been deleted."
    }

    // ---------------------------------------------------------------- describe(t)
    class Described(
        val status: String, val label: String, val tone: String, val icon: String,
        var headline: String = "", var message: String = "", var reason: Reason? = null,
        var next: List<String> = emptyList(), var short: String = "",
    )

    /** Describe any wallet transaction for the UI (wallet row, detail sheet, notifications). */
    fun describe(t: Doc?): Described {
        val tt = t ?: Doc.EMPTY
        val type = tt.s("type").lowercase()
        val st = normStatus(tt["status"])
        val meta = STATUS[st]!!
        val amt = num(tt["amount"])
        val net = if (tt.has("net")) num(tt["net"]) else Math.max(0.0, amt - 2)
        val ref = refOf(tt)
        val out = Described(st, meta.label, meta.tone, meta.icon)
        val contact = "Need help? Contact support from the menu and share your reference ID" + (if (ref.isNotEmpty()) " ($ref)" else "") + "."

        if (type == "withdraw") {
            val d = destOf(tt)
            val gp = tt.s("method").uppercase() == "GIFTCARD"
            if (gp) {
                when (st) {
                    "pending", "processing" -> {
                        out.headline = "Gift code requested"
                        out.message = "Your request for a Google Play gift card of ${inr(amt)} is with the admin. Your code will appear here as soon as it is ready."
                        out.next = listOf("No action is needed from you.", "We will notify you when the code is ready.")
                        out.short = "Waiting for gift code"
                    }
                    "success" -> {
                        out.headline = "Your gift code is ready"
                        out.message = if (tt.s("giftCode").isNotEmpty()) "Your Google Play gift card of ${inr(amt)} is ready. Copy the code below and redeem it in the Google Play Store."
                        else "Your Google Play gift card of ${inr(amt)} was approved. Please contact support if you cannot see the code."
                        out.next = listOf("Open Google Play Store → Redeem gift code.", "Paste the code and tap Redeem.")
                        out.short = if (tt.s("giftCode").isNotEmpty()) "Gift code ready — tap to copy" else "Approved"
                    }
                    "refunded" -> {
                        out.headline = "Gift card request refunded"
                        out.message = "We could not send this gift code, so ${inr(amt)} has been returned to your Withdrawal Balance. You can place a new request any time."
                        out.reason = pickReason(tt, "withdraw") ?: reasons["withdraw"]!!["other"]
                        out.next = listOf("Read the note below and try again.")
                        out.short = "Returned to wallet"
                    }
                    else -> {
                        out.headline = "Gift card request rejected"
                        out.message = "The admin could not approve this gift card request of ${inr(amt)}."
                        out.reason = pickReason(tt, "withdraw") ?: reasons["withdraw"]!!["other"]
                        out.next = listOf("Read the note below.", contact)
                        out.short = "Rejected"
                    }
                }
                return out
            }
            when (st) {
                "pending" -> {
                    out.headline = "Withdrawal request received"
                    out.message = "Your request to withdraw ${inr(amt)} is in our payout queue. Every request is reviewed for your safety, and ${inr(net)} (after the ₹2 fee) will reach your $d within 1–3 working days."
                    out.next = listOf("No action is needed from you.", "We will notify you as soon as the payment is sent.")
                    out.short = "Awaiting payout"
                }
                "processing" -> {
                    out.headline = "Payment in progress"
                    out.message = "We have started sending ${inr(net)} to your $d. Depending on your bank it can take a few hours to show up."
                    out.next = listOf("Keep an eye on your bank statement or wallet.")
                    out.short = "Sending to your $d"
                }
                "success" -> {
                    out.headline = "Withdrawal paid"
                    out.message = "${inr(net)} has been sent to your $d. If you don't see it within 24 hours, please check your statement or contact support."
                    out.next = listOf(contact)
                    out.short = "Paid to your $d"
                }
                "refunded" -> {
                    out.headline = "Withdrawal refunded"
                    out.message = "This withdrawal could not be completed, so ${inr(amt)} has been returned to your Withdrawal Balance. You can place a new request any time."
                    out.reason = pickReason(tt, "withdraw") ?: reasons["withdraw"]!!["other"]
                    out.next = listOf("Check the reason below, fix the issue and try again.")
                    out.short = "Returned to wallet"
                }
                "cancelled" -> {
                    out.headline = "Withdrawal cancelled"
                    out.message = "This withdrawal request was cancelled and ${inr(amt)} is back in your Withdrawal Balance."
                    out.reason = pickReason(tt, "withdraw")
                    out.short = "Cancelled"
                }
                else -> {
                    out.headline = "Withdrawal could not be completed"
                    out.message = "We were unable to complete this withdrawal. Your ${inr(amt)} is safe and is returned to your Withdrawal Balance — if you don't see it within 24 hours, contact support."
                    out.reason = pickReason(tt, "withdraw") ?: reasons["withdraw"]!!["other"]
                    out.next = listOf("Review the reason below and place a new request.", contact)
                    out.short = out.reason!!.label
                }
            }
        } else if (type == "deposit") {
            val crypto = tt.s("method").uppercase() == "CRYPTO"
            when (st) {
                "pending", "processing" -> {
                    out.headline = if (crypto) "Waiting for network confirmation" else "Verifying your payment"
                    out.message = if (crypto) "We received your request to add ${inr(amt)}. It will be credited as soon as our team confirms your transfer on the blockchain."
                    else "We are matching your payment of ${inr(amt)} with our bank record. UPI payments are usually confirmed within a minute."
                    out.next = listOf("No action is needed — we keep checking automatically.", "You will be notified once the amount is credited.")
                    out.short = if (crypto) "Awaiting confirmation" else "Verifying payment"
                }
                "success" -> {
                    out.headline = "Deposit successful"
                    out.message = "${inr(amt)} has been added to your Deposit Balance and is ready to use for joining matches."
                    out.short = "Added to wallet"
                }
                "refunded" -> {
                    out.headline = "Deposit refunded"
                    out.message = "Your payment of ${inr(amt)} has been refunded. It usually reaches your original payment source within 5–7 working days."
                    out.reason = pickReason(tt, "deposit") ?: pickReason(tt, "refund")
                    out.short = "Refunded"
                }
                "cancelled" -> {
                    out.headline = "Deposit cancelled"
                    out.message = "This deposit request of ${inr(amt)} was cancelled. No money was added to your wallet."
                    out.reason = pickReason(tt, "deposit")
                    out.short = "Cancelled"
                }
                else -> {
                    out.headline = "Deposit could not be verified"
                    out.message = "We could not verify your payment of ${inr(amt)}, so nothing was added to your wallet yet. If the money was debited from your account, it is safe — we will credit or refund it after checking."
                    out.reason = pickReason(tt, "deposit") ?: reasons["deposit"]!!["utr_not_found"]
                    out.next = listOf("Contact support with your UTR / hash and a payment screenshot.", "Do not pay again for the same amount until this is resolved.")
                    out.short = out.reason!!.label
                }
            }
        } else if (type == "refund" || st == "refunded") {
            out.headline = "Refund credited"
            out.message = "${inr(amt)} has been credited back to your wallet."
            out.reason = pickReason(tt, "refund") ?: reasons["refund"]!!["other"]
            out.short = out.reason!!.label
        } else if (type == "game") {
            out.headline = "Match entry"
            out.message = "${inr(amt)} was used as the entry fee for this match."
            out.short = ""
        }
        return out
    }
}
