package com.ffcashbattle.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.R
import com.ffcashbattle.app.data.GameArt
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.Coin
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.screens.wallet.TrxRow
import com.ffcashbattle.app.ui.screens.wallet.TrxSeen
import com.ffcashbattle.app.ui.screens.wallet.color
import com.ffcashbattle.app.ui.screens.wallet.toFixed
import com.ffcashbattle.app.ui.screens.wallet.tweenNumber
import com.ffcashbattle.app.ui.screens.wallet.tweenPop
import com.ffcashbattle.app.ui.screens.wallet.walletRows
import com.ffcashbattle.app.ui.shell.LocalPagePadding
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem

/** `#page-wallet` — "My Wallet": gradient balance card, action buttons, last 7 days of transactions. */
@Composable
fun WalletPage() {
    val c = FF.c
    val rows = remember(AppStore.trx) { walletRows(AppStore.trx) }
    val fresh = remember(rows.map { it.id }) { TrxSeen.diff(rows.map { it.id }) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = LocalPagePadding.current) {
        item(key = "head") {
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 15.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                FText("My Wallet", size = rem(1.17), weight = FontWeight.ExtraBold)
                Row(
                    Modifier.press(0.95f) { AppStore.openModal("modal-wallet-history") }
                        .clip(RoundedCornerShape(30.dp)).background(c.bgCard).border(1.dp, c.border, RoundedCornerShape(30.dp))
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    FaIcon("fa-solid fa-clock-rotate-left", rem(0.78).value.dp, c.primary)
                    FText("History", size = rem(0.78), weight = FontWeight.Bold, color = c.primary)
                }
            }
        }
        item(key = "card") { CreditCard() }
        item(key = "actions") { WalletActions() }
        item(key = "ttl") {
            Column(Modifier.fillMaxWidth().padding(start = 25.dp, end = 25.dp, bottom = 10.dp)) {
                FText("Transactions", size = rem(1.17), weight = FontWeight.Bold, modifier = Modifier.padding(vertical = 16.dp))
            }
        }
        if (AppStore.trx.isEmpty()) {
            item(key = "none") {
                Box(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 20.dp)) {
                    FText("No transactions yet. Add money or play a match to get started.", color = Color(0xFFAAAAAA), align = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(10.dp))
                }
            }
        } else if (rows.isEmpty()) {
            item(key = "empty") { WalletEmpty() }
        } else {
            items(rows, key = { it.id }) { t ->
                Box(Modifier.padding(start = 20.dp, end = 20.dp)) { TrxRow(t, t.id in fresh) }
            }
            item(key = "tail") { Box(Modifier.padding(bottom = 20.dp)) }
        }
    }
}

// =============================================================================================== credit card

@Composable
private fun CreditCard() {
    val c = FF.c
    val shape = RoundedCornerShape(24.dp)
    val dep = AppStore.depositBalance
    val wd = AppStore.withdrawBalance
    val tot = dep + wd
    val bal = tweenNumber(tot, 2)
    val dBal = tweenNumber(dep, 2)
    val wBal = tweenNumber(wd, 2)
    val totalDep = AppStore.user.n("totalDeposited")
    val totalWd = AppStore.user.n("totalWithdrawn")

    // fx-pop entrance (.6s)
    val pop = remember { Animatable(0f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, keyframes { durationMillis = 600; 0f at 0; 0.6f at 360; 1f at 600 }) }

    val inf = rememberInfiniteTransition(label = "card")
    val flow by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(4500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "flow")
    val float by inf.animateFloat(0f, -4f, infiniteRepeatable(tween(3000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "float")
    val shine by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(5000, easing = LinearEasing), RepeatMode.Restart, StartOffset(1000)), label = "shine")
    val colors = if (c.isDark) listOf(Color(0xFF312E81), Color(0xFF3F3AB4), Color(0xFF4F46E5)) else listOf(Color(0xFF4F46E5), Color(0xFF7C3AED), Color(0xFFF43F5E))
    val stops = if (c.isDark) floatArrayOf(0f, 0.5f, 1f) else floatArrayOf(0f, 0.55f, 1f)
    val shadowCol = if (c.isDark) Color(0x594F46E5) else Color(0x8C7C3AED)

    Box(
        Modifier.padding(20.dp).fillMaxWidth()
            .graphicsLayer {
                val k = pop.value
                val sc = if (k < 0.6f) 0.88f + 0.16f * (k / 0.6f) else 1.04f - 0.04f * ((k - 0.6f) / 0.4f)
                scaleX = sc; scaleY = sc; alpha = minOf(1f, k * 2f)
            }
            .boxShadow(40.dp, shadowCol, shape)
            .clip(shape)
            .drawBehind {
                val w = size.width; val h = size.height
                val ox = -0.8f * w * flow; val oy = -0.4f * h
                drawRect(
                    Brush.linearGradient(
                        colorStops = arrayOf(stops[0] to colors[0], stops[1] to colors[1], stops[2] to colors[2]),
                        start = Offset(ox, oy), end = Offset(ox + 1.8f * w, oy + 1.8f * h),
                    ),
                )
                // ::before — 150px circle, top/right -50, floating
                drawCircle(Color(0x1AFFFFFF), radius = 75.dp.toPx(), center = Offset(w + 50.dp.toPx() - 75.dp.toPx(), -50.dp.toPx() + 75.dp.toPx() + float.dp.toPx()))
                // ::after — a soft shine band sweeping across the card (35% wide, skewed)
                val bw = w * 0.35f
                val p = minOf(1f, shine / 0.6f)
                val x = (-1.3f + 3.5f * p) * bw
                val off = h * 0.182f
                val band = androidx.compose.ui.graphics.Path().apply {
                    moveTo(x + off, 0f); lineTo(x + bw + off, 0f); lineTo(x + bw - off, h); lineTo(x - off, h); close()
                }
                drawPath(band, Brush.horizontalGradient(listOf(Color.Transparent, Color(0x2EFFFFFF), Color.Transparent), startX = x, endX = x + bw))
            }
            .padding(25.dp),
    ) {
        Column(Modifier.fillMaxWidth().heightIn(min = 130.dp), verticalArrangement = Arrangement.SpaceBetween) {
            FText("Total Balance", size = rem(0.85), color = Color.White.copy(alpha = 0.8f))
            Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Coin(28.dp)
                Spacer(Modifier.width(4.dp))
                FText(bal.text, size = rem(2.5), weight = FontWeight.Black, color = bal.color(Color.White), maxLines = 1, modifier = Modifier.tweenPop(bal))
            }
            Row(Modifier.padding(vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigTile("Deposit Balance", dBal.text, Modifier.weight(1f))
                BigTile("Withdrawal Balance", wBal.text, Modifier.weight(1f))
            }
            Row(Modifier.padding(bottom = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallTile("Total Deposit", toFixed(totalDep, 0), Modifier.weight(1f))
                SmallTile("Total Withdrawal", toFixed(totalWd, 0), Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                Box(Modifier.clip(RoundedCornerShape(50.dp)).background(Color(0x33FFFFFF)).padding(horizontal = 12.dp, vertical = 5.dp)) {
                    FText("UID: " + AppStore.playerId, size = rem(0.75), color = Color.White, maxLines = 1)
                }
                GiftButton()
            }
        }
    }
}

@Composable
private fun BigTile(label: String, value: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(Color(0x26FFFFFF)).padding(10.dp)) {
        FText(label, size = rem(0.68), color = Color.White.copy(alpha = 0.85f), maxLines = 1)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Coin(15.dp, Modifier.padding(end = 3.dp))
            FText(value, weight = FontWeight.ExtraBold, color = Color.White, maxLines = 1)
        }
    }
}

@Composable
private fun SmallTile(label: String, value: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(Color(0x1AFFFFFF)).padding(horizontal = 10.dp, vertical = 8.dp)) {
        FText(label, size = rem(0.65), color = Color.White.copy(alpha = 0.8f), maxLines = 1)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Coin(15.dp, Modifier.padding(end = 3.dp))
            FText(value, size = rem(0.9), weight = FontWeight.Bold, color = Color.White, maxLines = 1)
        }
    }
}

/** `.gift-btn` — glass pill with a glowing ring and a wiggling gift icon. */
@Composable
private fun GiftButton() {
    val inf = rememberInfiniteTransition(label = "gift")
    val glow by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "glow")
    val wig by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart), label = "wig")
    // giftWiggle: 0-70% rest, 78% -14deg, 86% 12deg, 94% -6deg, 100% 0
    val rot = when {
        wig < 0.70f -> 0f
        wig < 0.78f -> -14f * ((wig - 0.70f) / 0.08f)
        wig < 0.86f -> -14f + 26f * ((wig - 0.78f) / 0.08f)
        wig < 0.94f -> 12f - 18f * ((wig - 0.86f) / 0.08f)
        else -> -6f + 6f * ((wig - 0.94f) / 0.06f)
    }
    val shape = RoundedCornerShape(30.dp)
    Row(
        Modifier
            .drawBehind {
                val g = if (glow < 0.5f) glow * 2f else (1f - glow) * 2f
                val r = 8.dp.toPx() * (1f - g)
                // ring: 0 0 0 0 → 8px fading out
                drawRoundRect(Color.White.copy(alpha = 0.45f * g), topLeft = Offset(-r, -r), size = Size(size.width + 2 * r, size.height + 2 * r), cornerRadius = CornerRadius(size.height / 2f + r))
            }
            .press(0.92f) { AppStore.checkLogin { AppStore.openModal("modal-gift") } }
            .clip(shape).background(Color(0x2EFFFFFF)).border(1.dp, Color(0x59FFFFFF), shape)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        FaIcon("fa-solid fa-gift", rem(0.78).value.dp, Color.White, Modifier.graphicsLayer { rotationZ = rot })
        FText("Gift Code", size = rem(0.78), weight = FontWeight.ExtraBold, color = Color.White)
    }
}

// =============================================================================================== actions

@Composable
private fun WalletActions() {
    val c = FF.c
    Row(
        Modifier.fillMaxWidth().then(if (c.isDark) Modifier.background(c.bgCard) else Modifier).padding(start = 20.dp, end = 20.dp, bottom = 25.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // the website keeps a 4-column grid: Add Money · Withdraw · Support, the 4th (Transfer) cell is hidden
        ActionBtn(0, "fa-solid fa-plus", "Add Money", Modifier.weight(1f)) { AppStore.checkLogin { AppStore.openModal("modal-deposit") } }
        ActionBtn(1, "fa-solid fa-arrow-down-long", "Withdraw", Modifier.weight(1f)) { AppStore.checkLogin { AppStore.openModal("modal-withdraw") } }
        ActionBtn(3, "fa-brands fa-whatsapp", "Support", Modifier.weight(1f)) { AppStore.openWhatsApp() }
        Box(Modifier.weight(1f))
    }
}

@Composable
private fun ActionBtn(i: Int, icon: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    val c = FF.c
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(i * 70L); a.animateTo(1f, keyframes { durationMillis = 500; 0f at 0; 0.6f at 300; 1f at 500 }) }
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.graphicsLayer {
            val k = a.value
            val sc = if (k < 0.6f) 0.88f + 0.16f * (k / 0.6f) else 1.04f - 0.04f * ((k - 0.6f) / 0.4f)
            scaleX = sc; scaleY = sc; alpha = minOf(1f, k * 2f)
        },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            Modifier.press(0.88f) { onClick() }
                .boxShadow(15.dp, Color(0x0D000000), shape)
                .size(50.dp).clip(shape).background(if (c.isDark) c.bgBody else c.bgCard).border(1.dp, c.border, shape),
            contentAlignment = Alignment.Center,
        ) { FaIcon(icon, rem(1.2).value.dp, c.primary) }
        FText(label, size = rem(0.75), weight = FontWeight.SemiBold, color = c.textMuted, maxLines = 1)
    }
}

// =============================================================================================== empty art

@Composable
private fun WalletEmpty() {
    val c = FF.c
    val inf = rememberInfiniteTransition(label = "wempty")
    val fl by inf.animateFloat(0f, -8f, infiniteRepeatable(tween(2000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "fl")
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(500)) }
    Column(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 20.dp)
            .graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 14.dp.toPx() }
            .padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 30.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        androidx.compose.foundation.Image(
            painterResource(GameArt.empty("matches")), null,
            Modifier.fillMaxWidth(0.7f).widthIn260().graphicsLayer { translationY = fl.dp.toPx() }.padding(bottom = 6.dp),
            contentScale = ContentScale.Fit,
        )
        FText("No activity yet", size = rem(1.05), weight = FontWeight.Bold)
        FText("Deposits, withdrawals, gift codes and game wins from the last 7 days appear here.", size = rem(0.82), color = c.textMuted, align = TextAlign.Center, lineHeight = rem(0.82) * 1.5f, modifier = Modifier.widthIn(max = 280.dp))
    }
}

private fun Modifier.widthIn260(): Modifier = this.then(Modifier.widthIn(max = 260.dp))
