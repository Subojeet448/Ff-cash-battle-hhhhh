package com.ffcashbattle.app.ui.modals

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.State
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.Cfg
import com.ffcashbattle.app.data.Faq
import com.ffcashbattle.app.data.RefCard
import com.ffcashbattle.app.data.RefInfo
import com.ffcashbattle.app.data.Refer
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FRich
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.InputBox
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.SpinIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val UP = CubicBezierEasing(0.2f, 0.9f, 0.3f, 1f)
private val Pink = Color(0xFFEC4899)

/** Website `#modal-refer`: Refer & Earn page (code, share, progress, stats, friends, scratch cards, claim, steps, terms). */
@Composable
fun ReferModal() {
    val c = FF.c
    val arg = AppStore.modalArg as? String
    var scratchId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        Refer.load(Refer.info == null)
        // opened from a notification / gift popup ("scratch:<id>") -> straight into that card
        if (arg != null && arg.startsWith("scratch:")) {
            val id = arg.removePrefix("scratch:")
            val x = Refer.info?.cards?.firstOrNull { it.id == id }
            if (x != null) when (x.status) {
                "new" -> scratchId = id
                "cancelled" -> AppStore.toast("This card was cancelled")
                else -> AppStore.toast("You already scratched this card")
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        ModalSheet(handle = false, padding = PaddingValues(0.dp), maxHeightFraction = 0.94f, scroll = false, containerColor = c.bgBody) {
            // sticky handle
            Box(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.width(44.dp).height(5.dp).clip(RoundedCornerShape(5.dp)).background(c.border))
            }
            Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, bottom = 34.dp)) {
                val d = Refer.info
                when {
                    d != null -> ReferBody(d) { scratchId = it }
                    Refer.loading || Refer.error == null -> Loading()
                    else -> Failed(Refer.error ?: "Could not load")
                }
            }
        }
        scratchId?.let { id -> ScratchOverlay(id) { scratchId = null } }
    }
}

// ------------------------------------------------------------------------------------------ states

@Composable
private fun Loading() {
    val c = FF.c
    val inf = rememberInfiniteTransition(label = "ld")
    val b by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(700, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    Column(Modifier.fillMaxWidth().padding(vertical = 60.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        FaIcon("fa-solid fa-gift", rem(2.0).value.dp, c.primary, Modifier.graphicsLayer { translationY = -14.dp.toPx() * b })
        FText("Loading your rewards…", weight = FontWeight.SemiBold, color = c.textMuted)
    }
}

@Composable
private fun Failed(msg: String) {
    val c = FF.c
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxWidth().padding(vertical = 18.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        FaIcon("fa-solid fa-cloud-exclamation", rem(2.1).value.dp, c.textMuted.copy(alpha = 0.55f), Modifier.padding(bottom = 6.dp))
        FText(msg, size = rem(0.84), color = c.textMuted, align = TextAlign.Center, lineHeight = rem(0.84) * 1.5f)
        Spacer(Modifier.height(16.dp))
        BtnMain("Try again", { scope.launch { Refer.load(true) } }, small = true)
    }
}

// ------------------------------------------------------------------------------------------ page

/** Entrance of each block on first open (`.ref-in>*`: slide up + fade, 70 ms apart). */
@Composable
private fun RefIn(index: Int, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(if (index <= 6) index * 70L else 480L); a.animateTo(1f, tween(550, easing = UP)) }
    Box(modifier.graphicsLayer { val v = a.value; alpha = v; translationY = (1f - v) * 18.dp.toPx(); val k = 0.97f + 0.03f * v; scaleX = k; scaleY = k }) { content() }
}

@Composable
private fun RefCardBox(modifier: Modifier = Modifier, top: Dp = 14.dp, content: @Composable () -> Unit) {
    val c = FF.c
    val shape = RoundedCornerShape(18.dp)
    Column(modifier.fillMaxWidth().padding(top = top).boxShadow(10.dp, Color(0x0D0F172A), shape).clip(shape).background(c.bgCard).border(1.dp, c.border, shape).padding(16.dp)) { content() }
}

@Composable
private fun H3(icon: String, tint: Color, text: String, pill: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FaIcon(icon, rem(1.0).value.dp, tint)
        FText(text, size = rem(1.0), weight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
        pill?.invoke()
    }
}

@Composable
private fun Pill(text: String, brush: Brush) {
    Box(Modifier.clip(RoundedCornerShape(99.dp)).background(brush).padding(horizontal = 9.dp, vertical = 3.dp)) {
        FText(text, size = rem(0.68), weight = FontWeight.ExtraBold, color = Color.White)
    }
}

@Composable
private fun ReferBody(d: RefInfo, openCard: (String) -> Unit) {
    val c = FF.c
    val cfg = d.cfg
    val scope = rememberCoroutineScope()
    val inf = rememberInfiniteTransition(label = "ref")
    val bob = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Reverse), label = "bob")
    val shine = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart), label = "shine")
    val wig = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart), label = "wig")
    val blink = inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Reverse), label = "blink")
    var idx = 0

    // ---- hero
    RefIn(idx++) { Hero(cfg.enabled, Refer.perTxt(cfg)) }

    // ---- code + share
    RefIn(idx++) {
        RefCardBox {
            H3("fa-solid fa-ticket", c.primary, "Your referral code")
            val glow by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2800, easing = LinearEasing), RepeatMode.Reverse), label = "glow")
            val box = RoundedCornerShape(14.dp)
            Row(
                Modifier.fillMaxWidth().drawBehind { drawRoundRect(c.primary.copy(alpha = 0.12f * glow), cornerRadius = CornerRadius(14.dp.toPx() + 6.dp.toPx()), topLeft = Offset(-6.dp.toPx(), -6.dp.toPx()), size = Size(size.width + 12.dp.toPx(), size.height + 12.dp.toPx()), style = Stroke(6.dp.toPx())) }
                    .clip(box).background(c.bgInput)
                    .drawBehind { drawRoundRect(c.primary, cornerRadius = CornerRadius(14.dp.toPx()), style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8.dp.toPx(), 5.dp.toPx())))) }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically,
            ) {
                FText(d.code.ifEmpty { "—" }, size = rem(1.7), weight = FontWeight.Black, color = c.primary, letterSpacing = 5.sp, mono = false, modifier = Modifier.weight(1f), maxLines = 1)
                Row(
                    Modifier.clip(RoundedCornerShape(11.dp)).background(c.primary).press(0.9f) { copyCode(d.code) }.padding(horizontal = 14.dp, vertical = 9.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    FaIcon("fa-regular fa-copy", rem(0.9).value.dp, Color.White)
                    FText("Copy", weight = FontWeight.ExtraBold, color = Color.White)
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val wa by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart), label = "wa")
                ShareBtn("fa-brands fa-whatsapp", "WhatsApp", Color(0xFF25D366), Color.White, Modifier.weight(1f).drawBehind {
                    val p = (wa / 0.6f).coerceIn(0f, 1f)
                    if (p < 1f) drawRoundRect(Color(0xFF25D366).copy(alpha = 0.45f * (1f - p)), cornerRadius = CornerRadius(13.dp.toPx() + 9.dp.toPx() * p), topLeft = Offset(-9.dp.toPx() * p, -9.dp.toPx() * p), size = Size(size.width + 18.dp.toPx() * p, size.height + 18.dp.toPx() * p), style = Stroke(2.dp.toPx() + 6.dp.toPx() * p))
                }) { AppStore.openUrl("https://wa.me/?text=" + Uri.encode(Refer.shareText(d.code) + " " + d.link)) }
                ShareBtn("fa-solid fa-share-nodes", "Share link", c.primaryLight, c.primary, Modifier.weight(1f)) { shareLink(d.code, d.link) }
            }
        }
    }

    // ---- next card progress
    if (cfg.enabled) RefIn(idx++) {
        RefCardBox(top = 2.dp) {
            val bolt by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Reverse), label = "bolt")
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FaIcon("fa-solid fa-bolt", rem(1.0).value.dp, Color(0xFFF59E0B), Modifier.graphicsLayer { val k = 1f + 0.25f * bolt; scaleX = k; scaleY = k; rotationZ = -12f * bolt })
                FText("Next scratch card", size = rem(1.0), weight = FontWeight.ExtraBold)
            }
            val s = if (d.per > 1) "s" else ""
            val s2 = if (d.toNext > 1) "s" else ""
            FText(
                if (d.toNext == d.per) "Invite ${d.per} friend$s to unlock the next card" else "${d.toNext} more friend$s2 to unlock the next card",
                size = rem(0.92), weight = FontWeight.Bold,
            )
            Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (i in 0 until d.per) Segment(i < d.have, i, Modifier.weight(1f))
            }
            FText(
                if (cfg.depositRequired > 0) "A friend counts when they join with your code and deposit ${Refer.money(cfg.depositRequired)} or more." else "A friend counts as soon as they join with your code.",
                size = rem(0.76), color = c.textMuted, lineHeight = rem(0.76) * 1.45f,
            )
        }
    }

    // ---- stats
    RefIn(idx++) {
        Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat(d.joined.toDouble(), false, "Friends", 0, Modifier.weight(1f))
            Stat(d.qualified.toDouble(), false, "Qualified", 1, Modifier.weight(1f))
            Stat(d.cardCount.toDouble(), false, "Cards", 2, Modifier.weight(1f))
            Stat(d.earned, true, "Earned", 3, Modifier.weight(1f))
        }
    }

    // ---- friends
    RefIn(idx++) {
        RefCardBox {
            H3("fa-solid fa-users", c.primary, "Invited friends", if (d.friends.isNotEmpty()) ({ Pill("${d.friends.size}", Brush.linearGradient(listOf(c.primary, c.primary))) }) else null)
            if (d.friends.isEmpty()) Empty(bob, "fa-solid fa-user-plus", "Your invited friends will show here.")
            else d.friends.forEachIndexed { i, f -> Friend(i, f.name, f.status, cfg.depositRequired > 0, blink, last = i == d.friends.lastIndex) }
        }
    }

    // ---- scratch cards
    RefIn(idx++) {
        RefCardBox {
            val fresh = d.fresh
            H3("fa-solid fa-gift", Pink, "Your scratch cards", if (fresh > 0) ({ Pill("$fresh NEW", Brush.horizontalGradient(listOf(Color(0xFFF59E0B), Color(0xFFEF4444)))) }) else null)
            if (d.cards.isEmpty()) Empty(bob, "fa-solid fa-ticket", "No scratch cards yet.\nInvite a friend to win your first one!")
            else Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                d.cards.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        for (x in row) Tile(x, bob, shine, wig, Modifier.weight(1f)) { openCard(x.id) }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }

    // ---- have a code?
    RefIn(idx++) {
        RefCardBox {
            H3("fa-solid fa-user-group", c.primary, "Have a referral code?")
            ClaimBlock(d, scope)
        }
    }

    // ---- how it works
    RefIn(idx++) {
        RefCardBox {
            H3("fa-solid fa-route", c.primary, "How it works")
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Step(1, "Share your code", "Send your link on WhatsApp or tell friends your referral code.")
                Step(
                    2, if (cfg.depositRequired > 0) "Friend joins & deposits ${Refer.money(cfg.depositRequired)}" else "Your friend joins",
                    "They sign up with your code" + (if (cfg.depositRequired > 0) " and add money to their wallet" else "") + ".",
                )
                Step(
                    3, "Scratch & win real cash",
                    (if (cfg.referralsPerCard > 1) "Every ${cfg.referralsPerCard} friends give you 1 scratch card." else "Every friend gives you 1 scratch card.") + " The prize goes straight to your ${Refer.walletTxt(cfg)}.",
                )
            }
        }
    }

    // ---- terms
    RefIn(idx) {
        RefCardBox {
            H3("fa-solid fa-file-contract", c.primary, "Referral terms")
            Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                Bullet { FRich("Your referral code is your Player ID. Every account can use [one] referral code, once.", size = rem(0.78), color = c.textMuted, boldColor = c.textMuted, lineHeight = rem(0.78) * 1.6f) }
                Bullet { FText("Rewards are only for genuine new users. Self-referrals, duplicate or fake accounts and any misuse are cancelled and may lead to account restriction.", size = rem(0.78), color = c.textMuted, lineHeight = rem(0.78) * 1.6f) }
                Bullet { FText("The value of a scratch card is chosen by the system when you scratch it and is not guaranteed.", size = rem(0.78), color = c.textMuted, lineHeight = rem(0.78) * 1.6f) }
                Bullet { FText("FF Cash Battle may change, pause or stop Refer & Earn at any time. Unscratched cards follow the rules active at that time.", size = rem(0.78), color = c.textMuted, lineHeight = rem(0.78) * 1.6f) }
                Bullet {
                    Row {
                        FText("Read the full ", size = rem(0.78), color = c.textMuted, lineHeight = rem(0.78) * 1.6f)
                        FText("Terms of Service", size = rem(0.78), weight = FontWeight.ExtraBold, color = c.primary, lineHeight = rem(0.78) * 1.6f, modifier = Modifier.press(0.96f) { AppStore.openWeb(Cfg.TERMS_URL + "#s16", "Terms") })
                        FText(".", size = rem(0.78), color = c.textMuted, lineHeight = rem(0.78) * 1.6f)
                    }
                }
            }
        }
    }
}

@Composable
private fun Bullet(content: @Composable () -> Unit) {
    Row {
        FText("•", size = rem(0.78), color = FF.c.textMuted, lineHeight = rem(0.78) * 1.6f, modifier = Modifier.width(18.dp).padding(start = 4.dp))
        Box(Modifier.weight(1f)) { content() }
    }
}

// ------------------------------------------------------------------------------------------ hero

@Composable
private fun Hero(enabled: Boolean, per: String) {
    val inf = rememberInfiniteTransition(label = "hero")
    val grad by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "g")
    val sweep by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(5000, easing = LinearEasing), RepeatMode.Restart), label = "s")
    val flt by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Reverse), label = "f")
    val pulse by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart), label = "p")
    val shape = RoundedCornerShape(22.dp)
    Box(
        Modifier.fillMaxWidth().boxShadow(28.dp, Color(0x596346E5), shape).clip(shape)
            .drawBehind {
                val x0 = -size.width * 1.2f * grad
                drawRect(Brush.linearGradient(listOf(Color(0xFF4F46E5), Color(0xFF7C3AED), Color(0xFFEC4899)), Offset(x0, 0f), Offset(x0 + size.width * 2.2f, size.height * 2.2f)))
                // soft glow at the top-right corner
                val r = 120.dp.toPx()
                val cx = size.width * 1.2f - r; val cy = -size.height * 0.4f + r
                drawCircle(Brush.radialGradient(listOf(Color(0x47FFFFFF), Color.Transparent), Offset(cx, cy), r * 1.3f), r * 1.3f, Offset(cx, cy))
                // light sweep (idle for the first 55 % of the cycle)
                val sp = ((sweep - 0.55f) / 0.45f).coerceIn(0f, 1f)
                if (sp > 0f && sp < 1f) {
                    val bw = size.width * 0.38f
                    val left = -size.width * 0.6f + (size.width * 2.0f) * sp
                    drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color(0x3DFFFFFF), Color.Transparent), left, left + bw), Offset(left, 0f), Size(bw, size.height))
                }
            }
            .padding(start = 18.dp, top = 20.dp, end = 18.dp, bottom = 18.dp),
    ) {
        FText("🎁", size = rem(4.2), modifier = Modifier.align(Alignment.TopEnd).graphicsLayer { translationX = 6.dp.toPx(); translationY = -10.dp.toPx() - 8.dp.toPx() * flt; rotationZ = -6f + 12f * flt })
        Column {
            FText("Refer & Earn", size = rem(1.45), weight = FontWeight.Black, color = Color.White, letterSpacing = (-0.3).sp, modifier = Modifier.padding(bottom = 4.dp))
            Box(Modifier.fillMaxWidth(0.78f)) {
                if (enabled) FRich("Invite friends — $per gives you a [Scratch Card].", size = rem(0.84), color = Color.White.copy(alpha = 0.93f), boldColor = Color.White, lineHeight = rem(0.84) * 1.5f)
                else FText("Refer & Earn is paused right now. Your cards and codes are safe.", size = rem(0.84), color = Color.White.copy(alpha = 0.93f), lineHeight = rem(0.84) * 1.5f)
            }
            Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                if (enabled) {
                    val ps = RoundedCornerShape(99.dp)
                    Row(
                        Modifier.drawBehind { if (pulse < 1f) drawRoundRect(Color.White.copy(alpha = 0.35f * (1f - pulse)), cornerRadius = CornerRadius(99.dp.toPx()), topLeft = Offset(-7.dp.toPx() * pulse, -7.dp.toPx() * pulse), size = Size(size.width + 14.dp.toPx() * pulse, size.height + 14.dp.toPx() * pulse), style = Stroke(2.dp.toPx())) }
                            .clip(ps).background(Color(0x2EFFFFFF)).border(1.dp, Color(0x59FFFFFF), ps).padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
                    ) {
                        FaIcon("fa-solid fa-sack-dollar", rem(0.86).value.dp, Color.White)
                        FText("Win real cash in every card", size = rem(0.86), weight = FontWeight.ExtraBold, color = Color.White)
                    }
                } else Spacer(Modifier.width(1.dp))
                val fs = RoundedCornerShape(99.dp)
                Row(
                    Modifier.clip(fs).background(Color(0x29FFFFFF)).border(1.dp, Color(0x66FFFFFF), fs).press(0.93f) { Faq.open("refer") }.height(30.dp).padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    FaIcon("fa-solid fa-circle-question", rem(0.72).value.dp, Color.White)
                    FText("FAQ", size = rem(0.72), weight = FontWeight.ExtraBold, color = Color.White)
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------ pieces

@Composable
private fun ShareBtn(icon: String, label: String, bg: Color, fg: Color, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(13.dp)).background(bg).press(0.95f) { onClick() }.padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically,
    ) {
        FaIcon(icon, rem(0.86).value.dp, fg)
        FText(label, size = rem(0.86), weight = FontWeight.ExtraBold, color = fg)
    }
}

@Composable
private fun Segment(on: Boolean, i: Int, modifier: Modifier) {
    val c = FF.c
    val fill = remember { Animatable(if (on) 0f else 1f) }
    LaunchedEffect(on) { if (on) { fill.snapTo(0f); delay(i * 80L); fill.animateTo(1f, tween(800, easing = UP)) } }
    val sw = remember { Animatable(0f) }
    LaunchedEffect(on) { if (on) while (true) { sw.snapTo(0f); sw.animateTo(1f, tween(2400, easing = LinearEasing)) } }
    val shape = RoundedCornerShape(99.dp)
    Box(Modifier.height(10.dp).then(modifier).clip(shape).background(c.bgInput)) {
        if (on) Box(
            Modifier.fillMaxSize().graphicsLayer { scaleX = fill.value; transformOrigin = TransformOrigin(0f, 0.5f) }
                .background(Brush.horizontalGradient(listOf(Color(0xFF10B981), Color(0xFF34D399))))
                .drawBehind {
                    val x = -size.width * 0.4f + size.width * 1.4f * sw.value
                    drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color(0xA6FFFFFF), Color.Transparent), x, x + size.width * 0.4f), Offset(x, 0f), Size(size.width * 0.4f, size.height))
                },
        )
    }
}

@Composable
private fun Stat(value: Double, isMoney: Boolean, label: String, index: Int, modifier: Modifier) {
    val c = FF.c
    val pop = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(300L + 60L * index); pop.animateTo(1f, tween(500, easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f))) }
    val cnt = remember { Animatable(0f) }
    LaunchedEffect(Unit) { cnt.animateTo(1f, tween(900, easing = CubicBezierEasing(0.215f, 0.61f, 0.355f, 1f))) }
    val shape = RoundedCornerShape(14.dp)
    val shown = value * cnt.value
    Column(
        modifier.graphicsLayer { val p = pop.value.coerceAtLeast(0f); alpha = p.coerceAtMost(1f); val k = 0.7f + 0.3f * p; scaleX = k; scaleY = k }
            .clip(shape).background(c.bgCard).border(1.dp, c.border, shape).padding(horizontal = 4.dp, vertical = 11.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        FText(if (isMoney) Refer.money(shown) else Math.round(shown).toString(), size = rem(1.15), weight = FontWeight.Black, maxLines = 1, softWrap = false)
        FText(label.uppercase(), size = rem(0.62), weight = FontWeight.Bold, color = c.textMuted, letterSpacing = 0.4.sp, maxLines = 1)
    }
}

@Composable
private fun Empty(bob: State<Float>, icon: String, text: String) {
    val c = FF.c
    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        FaIcon(icon, rem(2.1).value.dp, c.textMuted.copy(alpha = 0.55f), Modifier.padding(bottom = 6.dp).graphicsLayer { translationY = -5.dp.toPx() * bob.value })
        FText(text, size = rem(0.84), color = c.textMuted, align = TextAlign.Center, lineHeight = rem(0.84) * 1.5f)
    }
}

@Composable
private fun Friend(i: Int, name: String, status: String, needsDeposit: Boolean, blink: State<Float>, last: Boolean) {
    val c = FF.c
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(i * 60L); a.animateTo(1f, tween(450, easing = UP)) }
    val (chipBg, chipFg, chipText) = when (status) {
        "qualified" -> Triple(Color(0x2610B981), Color(0xFF059669), "Qualified ✓")
        "void" -> Triple(Color(0x24EF4444), Color(0xFFDC2626), "Cancelled")
        else -> Triple(Color(0x29F59E0B), Color(0xFFB45309), if (needsDeposit) "Joined · deposit pending" else "Joined")
    }
    Row(
        Modifier.fillMaxWidth().graphicsLayer { alpha = a.value; translationX = (a.value - 1f) * 18.dp.toPx() }
            .drawBehind { if (!last) drawRect(c.border, Offset(0f, size.height - 1.dp.toPx()), Size(size.width, 1.dp.toPx())) }
            .padding(vertical = 9.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(34.dp).clip(CircleShape).background(c.primaryLight), contentAlignment = Alignment.Center) {
            FText(name.take(1).uppercase().ifEmpty { "P" }, weight = FontWeight.Black, color = c.primary)
        }
        FText(name, size = rem(0.86), weight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
        val pending = status != "qualified" && status != "void"
        Row(Modifier.clip(RoundedCornerShape(99.dp)).background(chipBg).padding(start = if (pending) 16.dp else 9.dp, end = 9.dp, top = 3.dp, bottom = 3.dp)) {
            Box(contentAlignment = Alignment.CenterStart) {
                if (pending) Box(Modifier.offset9().size(5.dp).graphicsLayer { val b = blink.value; alpha = 1f - 0.75f * b; scaleX = 1f - 0.4f * b; scaleY = 1f - 0.4f * b }.clip(CircleShape).background(Color(0xFFF59E0B)))
                FText(chipText, size = rem(0.66), weight = FontWeight.ExtraBold, color = chipFg, maxLines = 1, softWrap = false)
            }
        }
    }
}

/** The blinking dot of a pending friend sits 7dp from the chip edge (inside the 16dp left padding): shifted by -9dp from the text. */
private fun Modifier.offset9(): Modifier = this.then(Modifier.graphicsLayer { translationX = -9.dp.toPx() })

@Composable
private fun Tile(x: RefCard, bob: State<Float>, shine: State<Float>, wig: State<Float>, modifier: Modifier, onOpen: () -> Unit) {
    val c = FF.c
    val shape = RoundedCornerShape(16.dp)
    when (x.status) {
        "new" -> Column(
            modifier.heightIn(min = 112.dp).graphicsLayer { translationY = -5.dp.toPx() * bob.value }
                .boxShadow(18.dp, Color(0x73E0A11B), shape).clip(shape)
                .background(Brush.linearGradient(0f to Color(0xFFFFF3B0), 0.3f to Color(0xFFF7C548), 0.55f to Color(0xFFE0A11B), 0.78f to Color(0xFFFFE58A), 1f to Color(0xFFCF8F12)))
                .border(2.dp, Color(0xFFFFF3B8), shape)
                .drawBehind {
                    val p = (shine.value / 0.55f).coerceIn(0f, 1f)
                    if (shine.value < 0.55f) {
                        val bw = size.width * 0.4f
                        val x0 = -size.width * 0.6f + size.width * 1.9f * p
                        drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color(0xBFFFFFFF), Color.Transparent), x0, x0 + bw), Offset(x0, 0f), Size(bw, size.height))
                    }
                }
                .press(0.96f) { onOpen() }.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterVertically),
        ) {
            FaIcon("fa-solid fa-gift", rem(1.7).value.dp, Color(0xFF5A3A00), Modifier.graphicsLayer { rotationZ = wiggle(wig.value) })
            FText("SCRATCH", size = rem(0.82), weight = FontWeight.Black, color = Color(0xFF5A3A00), letterSpacing = 0.5.sp)
            FText(
                when (x.src) { "gift" -> "Gift code · tap to open"; "admin" -> "From admin · tap to open"; "match" -> "🏆 Match reward · tap to open"; else -> "Tap to open" },
                size = rem(0.66), weight = FontWeight.Bold, color = Color(0xFF5A3A00).copy(alpha = 0.8f), align = TextAlign.Center,
            )
        }
        "cancelled" -> Column(
            modifier.heightIn(min = 112.dp).clip(shape).background(c.bgCard).border(1.dp, c.border, shape).padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterVertically),
        ) {
            FText("Cancelled", size = rem(0.95), weight = FontWeight.Black, color = c.textMuted)
            FText((if (x.src == "gift") "Gift card" else "Card") + " · cancelled by admin", size = rem(0.66), weight = FontWeight.Bold, color = c.textMuted, align = TextAlign.Center)
        }
        else -> Column(
            modifier.heightIn(min = 112.dp).clip(shape).background(c.bgCard).border(1.dp, c.border, shape).padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterVertically),
        ) {
            FText(Refer.money(x.amount), size = rem(1.5), weight = FontWeight.Black, color = c.success)
            FText((if (x.at > 0) SimpleDateFormat("dd MMM", Locale("en", "IN")).format(Date(x.at)) else "Won") + " · added", size = rem(0.66), weight = FontWeight.Bold, color = c.textMuted)
        }
    }
}

/** `refWiggle` keyframes. */
private fun wiggle(t: Float): Float = when {
    t < 0.70f -> 0f
    t < 0.78f -> -12f * ((t - 0.70f) / 0.08f)
    t < 0.86f -> -12f + 22f * ((t - 0.78f) / 0.08f)
    t < 0.94f -> 10f - 16f * ((t - 0.86f) / 0.08f)
    else -> -6f + 6f * ((t - 0.94f) / 0.06f)
}

@Composable
private fun ClaimBlock(d: RefInfo, scope: CoroutineScope) {
    val c = FF.c
    val cfg = d.cfg
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    if (d.referredByCode != null) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Top) {
            FaIcon("fa-solid fa-circle-check", rem(0.76).value.dp, c.success, Modifier.padding(top = 2.dp))
            FRich("You joined with code [${d.referredByCode}] (${d.referredByName}).", size = rem(0.76), color = c.textMuted, boldColor = c.textMain, lineHeight = rem(0.76) * 1.5f)
        }
    } else if (d.canClaim) {
        val apply: () -> Unit = {
            if (code.length < 4) AppStore.toast("Enter a valid referral code")
            else if (!busy) {
                busy = true
                scope.launch {
                    val r = Refer.claim(code)
                    busy = false
                    if (!r.ok) AppStore.toast(r.error.ifEmpty { "Could not apply the code" })
                    else {
                        AppStore.toast(if (r.qualified) "Code applied ✓" else "Code applied ✓ — your friend gets credit after your first deposit")
                        code = ""; Refer.load(false)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            InputBox(
                code, { code = it.filter { ch -> ch.isDigit() }.take(12) }, Modifier.weight(1f), placeholder = "Referral code", keyboardType = KeyboardType.Number,
                maxLength = 12, textAlign = TextAlign.Center, weight = FontWeight.ExtraBold, letterSpacing = 3.sp, imeAction = ImeAction.Done, onDone = apply,
            )
            Box(
                Modifier.fillMaxHeight().heightIn(min = 48.dp).clip(RoundedCornerShape(12.dp)).background(c.primary).press(0.94f) { apply() }.padding(horizontal = 18.dp),
                contentAlignment = Alignment.Center,
            ) { if (busy) SpinIcon(rem(1.0).value.dp, Color.White) else FText("Apply", weight = FontWeight.ExtraBold, color = Color.White) }
        }
        FText("You can add a friend's code within ${cfg.claimWindowHrs} hours of joining. It can be used only once.", size = rem(0.76), color = c.textMuted, lineHeight = rem(0.76) * 1.5f, modifier = Modifier.padding(top = 8.dp))
    } else {
        FText("Referral codes can only be added within ${cfg.claimWindowHrs} hours of creating an account.", size = rem(0.76), color = c.textMuted, lineHeight = rem(0.76) * 1.5f)
    }
}

@Composable
private fun Step(n: Int, title: String, text: String) {
    val c = FF.c
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
        Box(Modifier.size(32.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF4F46E5), Pink))), contentAlignment = Alignment.Center) {
            FText("$n", size = rem(0.9), weight = FontWeight.Black, color = Color.White)
        }
        Column(Modifier.weight(1f)) {
            FText(title, size = rem(0.9), weight = FontWeight.Bold)
            FText(text, size = rem(0.78), color = c.textMuted, lineHeight = rem(0.78) * 1.45f)
        }
    }
}

// ------------------------------------------------------------------------------------------ share

private fun copyCode(code: String) {
    if (code.isEmpty()) return
    try {
        val cm = AppStore.app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Referral code", code))
        AppStore.toast("Referral code copied ✓")
    } catch (_: Exception) { AppStore.toast("Could not copy") }
}

private fun shareLink(code: String, link: String) {
    try {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "FF Cash Battle")
            putExtra(Intent.EXTRA_TEXT, Refer.shareText(code) + " " + link)
        }
        AppStore.app.startActivity(Intent.createChooser(send, "FF Cash Battle").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) { AppStore.toast("Could not share") }
}
