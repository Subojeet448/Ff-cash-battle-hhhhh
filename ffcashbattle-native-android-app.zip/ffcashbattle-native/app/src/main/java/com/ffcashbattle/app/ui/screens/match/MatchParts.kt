package com.ffcashbattle.app.ui.screens.match

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.Placeable
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.R
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.Coin
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ================================================================================== formatting (home.js helpers)

private val IN = Locale("en", "IN")

/** `_nf`: Number.toLocaleString('en-IN', { maximumFractionDigits: 2 }). */
fun nfIN(v: Double): String {
    val f = NumberFormat.getNumberInstance(IN)
    f.maximumFractionDigits = 2
    f.minimumFractionDigits = 0
    return f.format(v)
}

/** `_fmtDT`: "16 Nov, 07:30 pm". */
fun fmtDT(v: Any?): String {
    val ms = Doc.toMs(v)
    if (ms <= 0L) return ""
    return try { SimpleDateFormat("dd MMM, hh:mm a", IN).format(Date(ms)).replace("AM", "am").replace("PM", "pm") } catch (_: Exception) { "" }
}

/** `_formatLabel`. */
fun formatLabel(m: Doc): String {
    val short = m.s("modeShort")
    if (short.isNotEmpty()) return short + " • " + m.s("subMode").replace("v", " v ")
    return when (m.s("matchType")) {
        "per_kill" -> "Per Kill"
        "team_win" -> m.s("teamMode").ifEmpty { "Team" }
        else -> "Win Prize"
    }
}

fun matchCode(m: Doc): String = m.s("matchCode").ifEmpty { m.id.take(8).uppercase() }

@Suppress("UNCHECKED_CAST")
fun asMap(x: Any?): Map<String, Any?> = (x as? Map<String, Any?>) ?: emptyMap()

/** JS `String(number)`: 10 -> "10", 10.5 -> "10.5". */
fun jsNum(d: Double): String = if (d % 1.0 == 0.0) d.toLong().toString() else d.toString()

fun dbl(x: Any?): Double = when (x) { is Number -> x.toDouble(); is String -> x.toDoubleOrNull() ?: 0.0; else -> 0.0 }

/** Object.keys order for numeric-like keys: ascending numbers first, then the others alphabetically. */
fun jsKeyOrder(keys: Collection<String>): List<String> =
    keys.sortedWith(compareBy<String>({ it.toIntOrNull() == null }, { it.toIntOrNull() ?: 0 }, { it }))

// ================================================================================== reward model (_rwVal / _prizeInfo)

sealed class Rw {
    class Amt(val amt: Double, val perKill: Boolean = false) : Rw()
    class Card(val min: Double, val max: Double, val perKill: Boolean = false) : Rw()
    object Random : Rw()
}

class Chip(val emoji: String, val rw: Rw)
class PrizeInfo(val big: Rw, val lbl: String, val chips: List<Chip>)

private fun rwVal(o: Map<String, Any?>, perKill: Boolean = false): Rw? = when (o["t"]) {
    "card" -> Rw.Card(dbl(o["min"]), dbl(o["max"]), perKill)
    "coin" -> Rw.Amt(dbl(o["amt"]), perKill)
    else -> null
}

private val MEDALS = mapOf("1" to "🥇", "2" to "🥈", "3" to "🥉")

fun prizeInfo(m: Doc): PrizeInfo {
    val perKillMode = m.s("matchType") == "per_kill"
    val pm = m.s("prizeMode").ifEmpty { if (perKillMode) "per_kill" else "match_win" }
    val pr = asMap(m["prizes"])
    val rwp = asMap(asMap(m["rewards"])["places"])
    val hasRw = m["rewards"] != null && asMap(m["rewards"])["places"] != null
    val teamed = m.i("teamSize", 1) > 1
    if (hasRw) {
        if (pm == "per_kill") {
            val kMap = asMap(rwp["K"])
            val k: Rw = if (rwp["K"] != null) (rwVal(kMap) ?: Rw.Amt(0.0)) else Rw.Amt(dbl(pr["1"]).takeIf { it != 0.0 } ?: m.n("prize"))
            val chips = ArrayList<Chip>()
            val r = asMap(rwp["R"])
            if (rwp["R"] != null && r["t"] != "none") rwVal(r)?.let { chips.add(Chip("👥", it)) }
            val isCard = k is Rw.Card
            return PrizeInfo(k, if (isCard) "Card per Kill" else "Per Kill", chips)
        }
        val ks = jsKeyOrder(rwp.keys.filter { it != "R" && it != "K" && asMap(rwp[it])["t"] != "none" })
        val chips = ArrayList<Chip>()
        for (k in ks) rwVal(asMap(rwp[k]))?.let { chips.add(Chip(MEDALS[k] ?: "🏅", it)) }
        val r = asMap(rwp["R"])
        val hasR = rwp["R"] != null && r["t"] != "none"
        if (hasR) rwVal(r)?.let { chips.add(Chip("👥", it)) }
        val allCard = ks.isNotEmpty() && ks.all { asMap(rwp[it])["t"] == "card" }
        val big: Rw = if (allCard) Rw.Random else Rw.Amt(m.n("prize"))
        val lbl = if (allCard) (if (ks.size > 1) "Win cards" else "Win a card")
        else if (ks.size > 1) "Total Prize"
        else if (pm == "match_win") (if (teamed) "Team Prize" else "Match Win") else "1st Prize"
        val showChips = !allCard && (chips.size > 1 || (chips.size == 1 && hasR))
        return PrizeInfo(big, lbl, if (showChips) chips else emptyList())
    }
    if (pm == "per_kill") return PrizeInfo(Rw.Amt(dbl(pr["1"]).takeIf { it != 0.0 } ?: m.n("prize")), "Per Kill", emptyList())
    val ranks = jsKeyOrder(pr.keys.filter { dbl(pr[it]) > 0 })
    val chips = if (ranks.size > 1) ranks.map { Chip(MEDALS[it] ?: "🏅", Rw.Amt(dbl(pr[it]))) } else emptyList()
    val lbl = if (ranks.size > 1) "Total Prize" else if (pm == "match_win") (if (teamed) "Team Prize" else "Match Win") else "1st Prize"
    return PrizeInfo(Rw.Amt(m.n("prize")), lbl, chips)
}

/** `_rwRows`: "who gets what" list used by the Join sheet (empty when the plan is secret scratch cards). */
fun rwListEntries(m: Doc): List<Pair<String, Rw>> {
    val rp = asMap(asMap(m["rewards"])["places"])
    if (rp.isEmpty()) return emptyList()
    val pm = m.s("prizeMode").ifEmpty { if (m.s("matchType") == "per_kill") "per_kill" else "match_win" }
    val team = m.i("teamSize", 1) > 1
    fun lab(k: String) = when {
        k == "K" -> "🎯 Per kill"
        k == "R" -> if (pm == "per_kill") "👥 Everyone who joined" else "👥 Everyone else"
        pm == "match_win" -> if (team) "🏆 Winning team" else "🏆 Winner"
        else -> mapOf("1" to "🥇 1st", "2" to "🥈 2nd", "3" to "🥉 3rd")[k] ?: k
    }
    val keys = jsKeyOrder(rp.keys.filter { asMap(rp[it])["t"] != "none" }).sortedBy { if (it == "R") 1 else 0 }
    if (keys.isEmpty() || keys.all { asMap(rp[it])["t"] == "card" }) return emptyList()
    return keys.mapNotNull { k -> rwVal(asMap(rp[k]), k == "K")?.let { lab(k) to it } }
}

// ================================================================================== reward views

/** `_rwVal` / `coinHtml`: a coin (or scratch card) followed by the value. */
@Composable
fun RwView(rw: Rw, size: androidx.compose.ui.unit.TextUnit, weight: FontWeight, color: Color, cardH: Dp = 22.dp) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        when (rw) {
            is Rw.Amt -> {
                Coin(15.dp)
                Spacer(Modifier.width(3.dp))
                FText(nfIN(rw.amt) + (if (rw.perKill) " / kill" else ""), size = size, weight = weight, color = color, maxLines = 1)
            }
            is Rw.Card -> {
                Image(painterResource(R.drawable.scratch_card), null, Modifier.height(cardH), contentScale = ContentScale.Fit)
                Spacer(Modifier.width(4.dp))
                val t = if (rw.min == rw.max) "₹" + nfIN(rw.min) else "₹" + nfIN(rw.min) + "–" + nfIN(rw.max)
                FText(t + (if (rw.perKill) " / kill" else ""), size = size, weight = weight, color = color, maxLines = 1)
            }
            Rw.Random -> {
                Image(painterResource(R.drawable.scratch_card), null, Modifier.height(cardH), contentScale = ContentScale.Fit)
                Spacer(Modifier.width(4.dp))
                FText("Random", size = size, weight = weight, color = color, maxLines = 1)
            }
        }
    }
}

/** `.pz-chip` — amber pill with a pop-in. */
@Composable
fun PrizeChip(chip: Chip, index: Int) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(index * 80L); a.animateTo(1f, tween(450, easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f))) }
    Row(
        Modifier.graphicsLayer { val s = 0.6f + 0.4f * a.value; scaleX = s; scaleY = s; alpha = minOf(1f, a.value * 1.4f) }
            .clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(Color(0xFFFEF3C7), Color(0xFFFDE68A))))
            .padding(horizontal = 12.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        FText(chip.emoji, size = rem(0.78), weight = FontWeight.ExtraBold, color = Color(0xFF92400E))
        RwView(chip.rw, rem(0.78), FontWeight.ExtraBold, Color(0xFF92400E), cardH = 18.dp)
    }
}

// ================================================================================== layout helper

/** Centered, wrapping row (CSS `display:flex; flex-wrap:wrap; justify-content:center`). */
@Composable
fun CenterFlow(hGap: Dp, vGap: Dp, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Layout(content = content, modifier = modifier) { measurables, constraints ->
        val hg = hGap.roundToPx()
        val vg = vGap.roundToPx()
        val loose = constraints.copy(minWidth = 0, minHeight = 0)
        val placeables = measurables.map { it.measure(loose) }
        val rows = ArrayList<List<Placeable>>()
        var cur = ArrayList<Placeable>()
        var w = 0
        for (p in placeables) {
            if (cur.isNotEmpty() && w + hg + p.width > constraints.maxWidth) { rows.add(cur); cur = ArrayList(); w = 0 }
            w += (if (cur.isEmpty()) 0 else hg) + p.width
            cur.add(p)
        }
        if (cur.isNotEmpty()) rows.add(cur)
        val rowH = rows.map { r -> r.maxOf { it.height } }
        val height = rowH.sum() + vg * (rows.size - 1).coerceAtLeast(0)
        val width = if (constraints.hasBoundedWidth) constraints.maxWidth else (rows.maxOfOrNull { r -> r.sumOf { it.width } + hg * (r.size - 1) } ?: 0)
        layout(width, height.coerceIn(constraints.minHeight, constraints.maxHeight)) {
            var y = 0
            rows.forEachIndexed { i, r ->
                val rw = r.sumOf { it.width } + hg * (r.size - 1)
                var x = (width - rw) / 2
                for (p in r) { p.placeRelative(x, y + (rowH[i] - p.height) / 2); x += p.width + hg }
                y += rowH[i] + vg
            }
        }
    }
}

// ================================================================================== countdown (timers.js + .cd-*)

/** One shared 1-second clock for a page (drives every countdown). */
@Composable
fun rememberNow(): State<Long> {
    val s = remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(1000); s.longValue = System.currentTimeMillis() } }
    return s
}

private fun p2(n: Long) = if (n < 10) "0$n" else n.toString()

@Composable
private fun CdSeg(v: String, label: String, urgent: Boolean, numColor: Color) {
    Column(
        Modifier.defaultMinSize(minWidth = 30.dp).clip(RoundedCornerShape(8.dp))
            .background(if (urgent) Color(0xCC7F1D1D) else Color(0xB80F172A))
            .border(1.dp, if (urgent) Color(0x80FCA5A5) else Color(0x2EFFFFFF), RoundedCornerShape(8.dp))
            .padding(horizontal = 5.dp, vertical = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        FText(v, size = rem(0.82), weight = FontWeight.Black, color = numColor, lineHeight = rem(0.82))
        FText(label, size = rem(0.5), weight = FontWeight.ExtraBold, color = Color(0xFFCBD5E1), letterSpacing = 0.6.sp, lineHeight = rem(0.5), modifier = Modifier.padding(top = 2.dp))
    }
}

/** `.countdown-timer`: DAY / HR / MIN / SEC chips, or the green "LIVE / ENDED" pill once started. */
@Composable
fun Countdown(target: Long, now: Long) {
    val dist = target - now
    if (dist < 0) {
        val inf = rememberInfiniteTransition(label = "cdend")
        val pulse by inf.animateFloat(1f, 0.72f, infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
        Row(
            Modifier.graphicsLayer { alpha = pulse }.clip(RoundedCornerShape(20.dp)).background(Color(0xFF10B981)).padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            FaIcon("fa-solid fa-circle-play", rem(0.72).value.dp, Color.White)
            FText("LIVE / ENDED", size = rem(0.72), weight = FontWeight.ExtraBold, color = Color.White)
        }
        return
    }
    val d = dist / 86_400_000L
    val h = (dist % 86_400_000L) / 3_600_000L
    val mi = (dist % 3_600_000L) / 60_000L
    val s = (dist % 60_000L) / 1000L
    val urgent = dist < 3_600_000L
    val numColor = if (urgent) Color(0xFFFECACA) else if (dist < 86_400_000L) Color(0xFFFDBA74) else Color(0xFFFDE68A)
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        if (d > 0) CdSeg(p2(d), "DAY", urgent, numColor)
        CdSeg(p2(h), "HR", urgent, numColor)
        CdSeg(p2(mi), "MIN", urgent, numColor)
        CdSeg(p2(s), "SEC", urgent, numColor)
    }
}

// ================================================================================== strips

/** CS / Lone Wolf "TEAM A  VS  TEAM B" slot strip (empty for Battle Royale). */
@Composable
fun SlotStrip(m: Doc) {
    val mode = m.s("mode")
    if (mode != "CS" && mode != "LW") return
    val taken = m.list("takenSlots").mapNotNull { (it as? Number)?.toInt() ?: it?.toString()?.toIntOrNull() }.toSet()
    val size = m.i("teamSize", 1).coerceAtLeast(1)
    val inf = rememberInfiniteTransition(label = "vs")
    val pulse by inf.animateFloat(1f, 1.14f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "vsP")
    Row(
        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF0F172A)).padding(horizontal = 10.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        @Composable
        fun Side(from: Int, a: Boolean, mod: Modifier) {
            Column(mod, horizontalAlignment = Alignment.CenterHorizontally) {
                FText(if (a) "TEAM A" else "TEAM B", size = rem(0.62), weight = FontWeight.ExtraBold, color = Color(0xFF94A3B8), letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 6.dp))
                CenterFlow(5.dp, 5.dp, Modifier.fillMaxWidth()) {
                    for (i in 0 until size) {
                        val on = (from + i) in taken
                        val bg = if (on) (if (a) Color(0xFF6366F1) else Color(0xFFF43F5E)) else Color(0xFF1E293B)
                        val bd = if (on) (if (a) Color(0xFF818CF8) else Color(0xFFFB7185)) else Color(0xFF334155)
                        val glow = if (on) (if (a) Color(0xB36366F1) else Color(0xB3F43F5E)) else Color.Transparent
                        Box(
                            Modifier.defaultMinSize(minWidth = 26.dp, minHeight = 26.dp)
                                .then(if (on) Modifier.drawBehind { drawCircle(Brush.radialGradient(listOf(glow, Color.Transparent), radius = 26.dp.toPx()), radius = 26.dp.toPx()) } else Modifier)
                                .clip(RoundedCornerShape(8.dp)).background(bg).border(1.5.dp, bd, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center,
                        ) { FText((from + i).toString(), size = rem(0.66), weight = FontWeight.ExtraBold, color = if (on) Color.White else Color(0xFF64748B)) }
                    }
                }
            }
        }
        Side(1, true, Modifier.weight(1f))
        Box(
            Modifier.graphicsLayer { scaleX = pulse; scaleY = pulse }.size(38.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF6366F1), Color(0xFFF43F5E)))),
            contentAlignment = Alignment.Center,
        ) { FText("VS", size = rem(0.8), weight = FontWeight.Black, color = Color.White) }
        Side(size + 1, false, Modifier.weight(1f))
    }
}

/** `_winnersStrip` — shown on completed matches. */
@Composable
fun WinnersStrip(m: Doc) {
    val winners = m.maps("winners")
    if (winners.isEmpty() && m.s("winnerName").isEmpty()) return
    val medals = mapOf(1 to "🥇", 2 to "🥈", 3 to "🥉")
    Column(
        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(listOf(Color(0xFFFFFBEB), Color(0xFFFEF3C7))))
            .border(1.dp, Color(0xFFFDE68A), RoundedCornerShape(14.dp)).padding(12.dp),
    ) {
        Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            FaIcon("fa-solid fa-crown", rem(0.7).value.dp, Color(0xFFB45309))
            FText("WINNERS", size = rem(0.7), weight = FontWeight.Black, color = Color(0xFFB45309), letterSpacing = 1.2.sp)
        }
        if (winners.isNotEmpty()) {
            winners.forEachIndexed { i, w ->
                if (i > 0) Box(Modifier.fillMaxWidth().height(1.dp).drawBehind {
                    val dash = 4.dp.toPx()
                    var x = 0f
                    while (x < size.width) { drawLine(Color(0xFFFCD34D), Offset(x, 0f), Offset(minOf(x + dash, size.width), 0f), 1.dp.toPx()); x += dash * 2 }
                })
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    FText(medals[dbl(w["rank"]).toInt()] ?: "🏅", size = rem(1.15))
                    val names = (w["names"] as? List<*>)?.joinToString(", ") { it.toString() } ?: ""
                    FText(names, size = rem(0.88), weight = FontWeight.Bold, color = Color(0xFF78350F), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    val amount = dbl(w["amount"])
                    if (amount != 0.0) { Coin(15.dp); FText(nfIN(amount), size = rem(0.88), weight = FontWeight.ExtraBold, color = Color(0xFF15803D)) }
                    val kills = dbl(w["kills"])
                    if (kills != 0.0) FText(nfIN(kills) + " kills", size = rem(0.88), weight = FontWeight.Bold, color = Color(0xFF92400E))
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FText("🏆", size = rem(1.15))
                FText(m.s("winnerName"), size = rem(0.88), weight = FontWeight.Bold, color = Color(0xFF78350F), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            }
        }
    }
}

/** `app.rosterBtn(m)` — "Players & slots 12/48" dashed button that opens the roster sheet. */
@Composable
fun RosterButton(m: Doc) {
    val c = FF.c
    val joined = m.i("joined").takeIf { it > 0 } ?: m.list("participants").size
    val total = m.i("total").takeIf { it > 0 } ?: 48
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().padding(top = 10.dp).press(0.97f) { AppStore.openModal("modal-roster", m.id) }
            .clip(shape).background(Color(0x0F6366F1))
            .drawBehind {
                val sw = 1.5.dp.toPx()
                drawRoundRect(
                    Color(0x666366F1), topLeft = Offset(sw / 2f, sw / 2f), size = androidx.compose.ui.geometry.Size(size.width - sw, size.height - sw),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(14.dp.toPx()),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(sw, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(5.dp.toPx(), 4.dp.toPx()))),
                )
            }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically,
    ) {
        FaIcon("fa-solid fa-users", rem(0.8).value.dp, c.primary)
        FText("Players & slots", size = rem(0.8), weight = FontWeight.ExtraBold, color = c.primary)
        Box(Modifier.clip(RoundedCornerShape(10.dp)).background(c.primary).padding(horizontal = 8.dp, vertical = 1.dp)) {
            FText("$joined/$total", size = rem(0.68), weight = FontWeight.ExtraBold, color = Color.White)
        }
    }
}
