package com.ffcashbattle.app.ui.modals

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.data.Msg
import com.ffcashbattle.app.data.Prefs
import com.ffcashbattle.app.data.Repo
import com.ffcashbattle.app.data.fsNum
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.Coin
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.InputBox
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.NamedImage
import com.ffcashbattle.app.ui.comp.SpinIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.screens.match.jsNum
import com.ffcashbattle.app.ui.screens.FaqChip
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.util.Locale

private const val UPI_FEE = 2.0
private val UPI_RE = Regex("^[a-z0-9.\\-_]{2,64}@[a-z][a-z0-9]{1,30}$")

private fun fmt2(v: Double) = String.format(Locale.US, "%.2f", v)

/** Per-user "Saved UPI details" kept on this device only (website: localStorage `ff_wd_<uid>`). */
private object WdStore {
    private fun key(uid: String) = "ff_wd_" + uid.ifEmpty { "guest" }
    fun load(uid: String): JSONObject = try { JSONObject(Prefs.str(key(uid), "{}")) } catch (e: Exception) { JSONObject() }
    fun save(uid: String, o: JSONObject) { try { Prefs.put(key(uid), o.toString()) } catch (_: Exception) { } }
}

/** Website `#modal-withdraw` — UPI or Google Play gift card, winnings only, ₹2 fee on UPI. */
@Composable
fun WithdrawModal() {
    val c = FF.c
    val uid = AppStore.uid ?: ""
    val saved0 = remember { WdStore.load(uid) }
    val su = saved0.optJSONObject("upi")
    var savedName by remember { mutableStateOf(su?.optString("name").orEmpty()) }
    var savedId by remember { mutableStateOf(su?.optString("id").orEmpty()) }
    var hasSaved by remember { mutableStateOf(su != null) }
    var method by remember { mutableStateOf(saved0.optString("last").takeIf { it == "upi" || it == "gp" }) }
    var name by remember { mutableStateOf(savedName) }
    var upiId by remember { mutableStateOf(savedId.replace(Regex("\\s"), "").lowercase()) }
    var upiAmt by remember { mutableStateOf("") }
    var keep by remember { mutableStateOf(true) }
    var gpAmt by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { AppStore.refreshFlags() }
    val allOff = AppStore.flagOff("wd")
    val minWd = AppStore.minWd()

    ModalSheet {
        val close = LocalSheetClose.current
        Row(Modifier.fillMaxWidth().padding(bottom = 15.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            FText("Withdraw", size = rem(1.5), weight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                FaqChip("withdraw")
                Box(Modifier.press(0.9f) { close() }) { FaIcon("fa-solid fa-xmark", rem(1.5).value.dp, c.textMuted) }
            }
        }

        // .wd-balance-box — withdrawals only come out of the withdrawal (winnings) balance
        Column(
            Modifier.fillMaxWidth().padding(bottom = 15.dp).clip(RoundedCornerShape(10.dp)).background(c.bgInput)
                .border(1.dp, Color(0xFFBAE6FD), RoundedCornerShape(10.dp)).padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            FText("Available Balance", size = rem(0.75), color = c.textMuted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Coin(18.dp)
                FText(fmt2(AppStore.withdrawBalance), size = rem(1.3), weight = FontWeight.Black, color = c.primary)
            }
        }

        if (allOff) { OffBox("Withdrawal Disabled", AppStore.flagMsg("wd")); return@ModalSheet }

        FText("SELECT METHOD", size = rem(0.8), weight = FontWeight.Bold, color = c.textMuted, letterSpacing = 0.5.sp, modifier = Modifier.padding(bottom = 10.dp))
        Row(Modifier.fillMaxWidth().padding(bottom = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MethodCard("UPI", "GPay / PhonePe / Paytm", method == "upi", AppStore.flagOff("upi"), Modifier.weight(1f), { method = "upi" }) {
                NamedImage("wallet_upi", Modifier.size(60.dp, 30.dp).clip(RoundedCornerShape(6.dp)))
            }
            MethodCard("Google Play", "Gift Card Code", method == "gp", AppStore.flagOff("gp"), Modifier.weight(1f), { method = "gp" }) {
                NamedImage("wallet_google_play", Modifier.size(34.dp))
            }
        }

        // ------------------------------------------------------------ submit (shared by UPI + Google Play)
        fun submit(kind: String, amt: Double, method0: String, masked: String, noFee: Boolean, fields: Map<String, Any?>, save: JSONObject?) {
            if (busy) return
            AppStore.scope.launch {
                submitWithdraw(kind, amt, method0, masked, noFee, fields, save, { close() }) { busy = it }
            }
        }

        when (method) {
            "upi" -> SectionIn("upi") {
                if (AppStore.flagOff("upi")) { OffBox("UPI Withdrawal Disabled", AppStore.flagMsg("upi")); return@SectionIn }
                GpHead("UPI Withdrawal", "Money is sent to your UPI ID") { NamedImage("wallet_upi", Modifier.size(66.dp, 33.dp).clip(RoundedCornerShape(6.dp))) }
                InfoBox(minWd, "₹ 2 deducted", c.danger)

                if (hasSaved) SavedStrip((if (savedName.isNotEmpty()) "$savedName · " else "") + savedId) {
                    val sv = WdStore.load(uid); sv.remove("upi"); if (sv.optString("last") == "upi") sv.remove("last"); WdStore.save(uid, sv)
                    hasSaved = false; savedName = ""; savedId = ""; name = ""; upiId = ""
                    AppStore.toast("Saved UPI details removed from this device.")
                }

                WdField("Name (as per UPI)") {
                    InputBox(name, { name = it.take(60) }, Modifier.fillMaxWidth(), placeholder = "Your full name", leading = { LeadIcon("fa-solid fa-user") })
                }
                val idOk = UPI_RE.matches(upiId)
                WdField("UPI ID") {
                    InputBox(
                        upiId, { upiId = it.replace(Regex("\\s"), "").lowercase().take(80) }, Modifier.fillMaxWidth(), placeholder = "e.g. name@okhdfcbank",
                        leading = { LeadIcon("fa-solid fa-at") }, ring = false,
                        accent = if (upiId.isEmpty()) null else if (idOk) c.success else c.danger,
                    )
                    FText(
                        if (upiId.isEmpty()) "Format: name@bank" else if (idOk) "Valid UPI ID" else "Enter a valid UPI ID, e.g. name@okhdfcbank",
                        size = rem(0.7), color = if (upiId.isEmpty()) c.textMuted else if (idOk) c.success else c.danger,
                        modifier = Modifier.padding(top = 5.dp).heightIn(min = 14.dp),
                    )
                }
                WdField("Amount") {
                    InputBox(upiAmt, { upiAmt = cleanAmount(it) }, Modifier.fillMaxWidth(), placeholder = "Min ₹$minWd", keyboardType = KeyboardType.Decimal, leading = { LeadCoin() })
                }
                val a = upiAmt.toDoubleOrNull() ?: 0.0
                if (a >= minWd) NetLine("You will receive: ₹" + fmt2(a - UPI_FEE))
                CheckRow(keep) { keep = it }
                BtnMain(
                    onClick = {
                        val amt = upiAmt.toDoubleOrNull() ?: 0.0
                        val nm = name.trim(); val id = upiId.trim().lowercase()
                        if (nm.isEmpty() || id.isEmpty() || amt == 0.0) { AppStore.toast(Msg.withdraw.fillAll()); return@BtnMain }
                        if (nm.length < 3) { AppStore.toast(Msg.withdraw.shortName()); return@BtnMain }
                        if (!UPI_RE.matches(id)) { AppStore.toast(Msg.withdraw.badUpi()); return@BtnMain }
                        val masked = "UPI " + (if (id.length > 6) id.take(2) + "xxxx" + id.substring(id.indexOf('@')) else id)
                        submit("upi", amt, "UPI", masked, false, mapOf("accountName" to nm, "upiId" to id), if (keep) JSONObject().put("name", nm).put("id", id) else null)
                    },
                    modifier = Modifier.fillMaxWidth(), enabled = !busy,
                ) {
                    if (busy) SpinIcon(rem(1.0).value.dp, Color(0xFF94A3B8)) else FaIcon("fa-solid fa-paper-plane", rem(1.0).value.dp, Color.White)
                    Spacer(Modifier.width(6.dp))
                    FText("Submit UPI Withdrawal", weight = FontWeight.Bold, color = if (busy) Color(0xFF94A3B8) else Color.White)
                }
            }

            "gp" -> SectionIn("gp") {
                if (AppStore.flagOff("gp")) { OffBox("Google Play Withdrawal Disabled", AppStore.flagMsg("gp")); return@SectionIn }
                GpHead("Google Play Gift Card", "Admin will send your redeem code here in the app") { NamedImage("wallet_google_play", Modifier.size(44.dp)) }
                InfoBox(minWd, "₹ 0 (Free)", c.success)
                WdField("How much gift code do you want?") {
                    InputBox(gpAmt, { gpAmt = cleanAmount(it) }, Modifier.fillMaxWidth(), placeholder = "Min ₹$minWd", keyboardType = KeyboardType.Decimal, leading = { LeadCoin() })
                }
                val chips = listOf(20, 50, 100, 200, 500).filter { it >= minWd }
                if (chips.isNotEmpty()) FlexChips(chips) { gpAmt = it.toString() }
                val a = gpAmt.toDoubleOrNull() ?: 0.0
                if (a >= minWd) NetLine("Gift card value: ₹" + fmt2(a))
                BtnMain(
                    onClick = {
                        val amt = gpAmt.toDoubleOrNull() ?: 0.0
                        if (amt == 0.0) { AppStore.toast("Enter how much gift code you want."); return@BtnMain }
                        submit("gp", amt, "GIFTCARD", "Google Play Gift Card", true, mapOf("giftCard" to "Google Play", "giftValue" to fsNum(amt)), null)
                    },
                    modifier = Modifier.fillMaxWidth(), enabled = !busy,
                ) {
                    if (busy) SpinIcon(rem(1.0).value.dp, Color(0xFF94A3B8)) else FaIcon("fa-solid fa-gift", rem(1.0).value.dp, Color.White)
                    Spacer(Modifier.width(6.dp))
                    FText("Request Google Play Code", weight = FontWeight.Bold, color = if (busy) Color(0xFF94A3B8) else Color.White)
                }
            }
        }
    }
}

// ====================================================================== submit

/** `app._submitWithdraw`: runs in [AppStore.scope] so it survives the sheet closing (coin animation + success popup follow). */
private suspend fun submitWithdraw(
    kind: String, amt: Double, method: String, masked: String, noFee: Boolean,
    fields: Map<String, Any?>, save: JSONObject?, close: () -> Unit, setBusy: (Boolean) -> Unit,
) {
    val uid = AppStore.uid ?: return
    if (AppStore.flagOff("wd")) { AppStore.toast(AppStore.flagMsg("wd")); return }
    if (AppStore.flagOff(kind)) { AppStore.toast(AppStore.flagMsg(kind)); return }
    if (amt < AppStore.minWd()) { AppStore.toast(Msg.withdraw.minAmount()); return }
    if (amt > AppStore.withdrawBalance) { AppStore.toast(Msg.withdraw.insufficient(AppStore.withdrawBalance)); return }
    if (!AppStore.rateLimit("withdraw", 60_000L)) return
    setBusy(true)
    AppStore.toast(Msg.withdraw.processing())
    var done: WdSuccessInfo? = null
    var newBal = 0.0
    try {
        // Re-read the latest balance right before the debit (blocks over-withdraw through rapid taps)
        val cur = Repo.getDoc("users", uid) ?: Doc.EMPTY
        val curWd = cur.n("withdrawBalance")
        if (amt > curWd) { AppStore.endAction("withdraw", false); AppStore.toast(Msg.withdraw.insufficient(curWd)); return }
        val curDep = if (cur.has("depositBalance")) cur.n("depositBalance") else cur.n("balance")
        val net = if (noFee) amt else amt - UPI_FEE
        // ATOMIC: balance debit + withdrawal request in one commit
        val batch = Repo.db.batch()
        val ref = Repo.col("users", uid, "transactions").document()
        batch.update(Repo.doc("users", uid), mapOf("withdrawBalance" to fsNum(curWd - amt)))
        val trx = HashMap<String, Any?>()
        trx["title"] = Msg.withdraw.title(amt, masked)
        trx["amount"] = "-₹" + jsNum(amt)
        trx["net"] = "₹" + fmt2(net)
        trx["type"] = "withdraw"; trx["status"] = "pending"; trx["method"] = method; trx["balanceType"] = "withdraw"
        trx.putAll(fields)
        trx["date"] = java.text.DateFormat.getDateInstance(java.text.DateFormat.SHORT).format(java.util.Date())
        trx["createdAt"] = System.currentTimeMillis()
        trx["timestamp"] = Repo.serverTs()
        batch.set(ref, trx)
        batch.commit().await()
        // remember on this device (if ticked)
        val sv = WdStore.load(uid)
        if (save != null) { sv.put(kind, save); sv.put("last", kind); WdStore.save(uid, sv) }
        else if (kind == "gp") { sv.put("last", "gp"); WdStore.save(uid, sv) }
        close()
        AppStore.endAction("withdraw", true)
        newBal = curDep + (curWd - amt)
        done = WdSuccessInfo(amt, method, net, ref.id.take(8).uppercase())
    } catch (e: Exception) {
        AppStore.endAction("withdraw", false)
        // Admin switched withdrawals OFF after this sheet opened -> show the admin's note, not a raw error
        if ((e as? FirebaseFirestoreException)?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
            AppStore.refreshFlags()
            delay(500)
            if (AppStore.flagOff("wd")) { AppStore.toast(AppStore.flagMsg("wd")); return }
            if (AppStore.flagOff(kind)) { AppStore.toast(AppStore.flagMsg(kind)); return }
        }
        AppStore.toast("Error: " + (e.message ?: ""))
    } finally {
        setBusy(false)
    }
    val info = done ?: return
    // 3 s coin animation (balance goes down) -> success sheet
    AppStore.playWalletFx("withdraw", amt, newBal)
    var waited = 0
    while (AppStore.walletFx != null && waited < 6000) { delay(100); waited += 100 }
    AppStore.openModal("modal-wd-success", info)
}

// ====================================================================== pieces

/** `.wd-method-card` (+ `.selected`, `.is-off`). */
@Composable
private fun MethodCard(title: String, sub: String, selected: Boolean, off: Boolean, modifier: Modifier, onClick: () -> Unit, icon: @Composable () -> Unit) {
    val c = FF.c
    val shape = RoundedCornerShape(16.dp)
    val lift by animateDpAsState(if (selected) (-2).dp else 0.dp, tween(200), label = "lift")
    val pop = remember { Animatable(1f) }
    LaunchedEffect(selected) { if (selected) { pop.snapTo(0f); pop.animateTo(1f, tween(500, easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f))) } }
    val bg = if (selected) (if (c.isDark) Color(0xFF1E1A4E) else c.primaryLight) else c.bgCard
    Box(
        modifier.graphicsLayer { translationY = lift.toPx(); alpha = if (off) 0.6f else 1f }
            .then(if (selected) Modifier.boxShadow(22.dp, c.primary.copy(alpha = 0.35f), shape) else Modifier)
            .press(0.96f) { onClick() }
            .clip(shape).background(bg).border(2.dp, if (selected) c.primary else c.border, shape).padding(16.dp),
    ) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.height(36.dp).padding(bottom = 0.dp).graphicsLayer { val k = pop.value; val s = 0.6f + 0.4f * k; scaleX = s; scaleY = s; rotationZ = -12f * (1f - k) }, contentAlignment = Alignment.Center) { icon() }
            Spacer(Modifier.height(8.dp))
            FText(title, size = rem(0.9), weight = FontWeight.Bold, align = TextAlign.Center)
            FText(sub, size = rem(0.7), color = c.textMuted, align = TextAlign.Center, modifier = Modifier.padding(top = 2.dp))
        }
        if (off) {
            Box(Modifier.align(Alignment.TopEnd).offset(10.dp, (-10).dp).clip(RoundedCornerShape(20.dp)).background(c.danger).padding(horizontal = 7.dp, vertical = 2.dp)) {
                FText("Disabled", size = rem(0.6), weight = FontWeight.ExtraBold, color = Color.White)
            }
        }
    }
}

/** `.wd-section.active` — fades/slides in (wdIn .35s). */
@Composable
private fun SectionIn(key: String, content: @Composable () -> Unit) {
    val k = remember(key) { Animatable(0f) }
    LaunchedEffect(key) { k.animateTo(1f, tween(350, easing = CubicBezierEasing(0.16f, 1f, 0.3f, 1f))) }
    Column(Modifier.fillMaxWidth().graphicsLayer { alpha = k.value; translationY = (1f - k.value) * 12.dp.toPx() }) { content() }
}

/** `.wd-gp-head` */
@Composable
private fun GpHead(title: String, sub: String, logo: @Composable () -> Unit) {
    val c = FF.c
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(shape).background(c.bgInput).border(1.dp, c.border, shape).padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        logo()
        Column(Modifier.weight(1f)) {
            FText(title, size = rem(0.92), weight = FontWeight.Bold)
            FText(sub, size = rem(0.72), color = c.textMuted, lineHeight = rem(0.72) * 1.4f, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

/** `.wd-info-box` — Min Amount / Processing Time / Service Fee. */
@Composable
private fun InfoBox(minWd: Int, fee: String, feeColor: Color) {
    val c = FF.c
    val shape = RoundedCornerShape(12.dp)
    Column(Modifier.fillMaxWidth().padding(bottom = 15.dp).clip(shape).background(if (c.isDark) c.bgBody else c.bgInput).border(1.dp, c.border, shape).padding(14.dp)) {
        InfoRow("Min Amount", "₹ $minWd", c.warning, false)
        InfoRow("Processing Time", "15 – 20 min", c.success, false)
        InfoRow("Service Fee", fee, feeColor, true)
    }
}

@Composable
private fun InfoRow(label: String, value: String, color: Color, last: Boolean) {
    val c = FF.c
    Column {
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            FText(label, size = rem(0.82), color = c.textMuted)
            FText(value, size = rem(0.82), weight = FontWeight.Bold, color = color)
        }
        if (!last) Box(Modifier.fillMaxWidth().height(1.dp).background(c.border))
    }
}

/** `.wd-saved` */
@Composable
private fun SavedStrip(text: String, onRemove: () -> Unit) {
    val c = FF.c
    val shape = RoundedCornerShape(14.dp)
    val bg = if (c.isDark) Brush.linearGradient(listOf(c.bgInput, c.bgInput)) else Brush.linearGradient(listOf(Color(0xFFEEF2FF), Color(0xFFFDF2F8)))
    Row(
        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(shape).background(bg).border(1.dp, c.border, shape).padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(c.primary), contentAlignment = Alignment.Center) {
            FaIcon("fa-solid fa-bookmark", rem(1.0).value.dp, Color.White)
        }
        Column(Modifier.weight(1f)) {
            FText("Saved UPI details", size = rem(0.82), weight = FontWeight.Bold)
            FText(text, size = rem(0.72), color = c.textMuted, mono = true, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
        }
        Row(
            Modifier.press(0.93f) { onRemove() }.clip(RoundedCornerShape(10.dp)).background(Color(0xFFFEE2E2)).padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            FaIcon("fa-solid fa-trash", rem(0.72).value.dp, Color(0xFFB91C1C))
            FText("Remove", size = rem(0.72), weight = FontWeight.ExtraBold, color = Color(0xFFB91C1C))
        }
    }
}

/** `.wd-field` + `.wd-label` */
@Composable
private fun WdField(label: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
        FText(label.uppercase(), size = rem(0.72), weight = FontWeight.Bold, color = FF.c.textMuted, letterSpacing = 0.4.sp, modifier = Modifier.padding(bottom = 6.dp))
        content()
    }
}

/** Icon slot so the text starts 46px in, like `.wd-input .input-box { padding-left:44px }`. */
@Composable
private fun LeadIcon(icon: String) {
    Box(Modifier.width(18.dp)) { FaIcon(icon, rem(0.95).value.dp, FF.c.textMuted, Modifier.offset((-3).dp, 0.dp)) }
}

@Composable
private fun LeadCoin() {
    Box(Modifier.width(18.dp)) { Coin(15.dp, Modifier.offset((-2).dp, 0.dp)) }
}

/** `.wd-net` */
@Composable
private fun NetLine(text: String) {
    FText(text, size = rem(0.82), weight = FontWeight.Bold, color = FF.c.success, align = TextAlign.End, modifier = Modifier.fillMaxWidth().padding(top = 0.dp, bottom = 14.dp))
}

/** `.wd-save-chk` */
@Composable
private fun CheckRow(checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = FF.c
    Row(
        Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 12.dp).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onChange(!checked) },
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(18.dp).clip(RoundedCornerShape(4.dp)).background(if (checked) c.primary else Color.Transparent)
                .border(if (checked) 0.dp else 2.dp, c.border, RoundedCornerShape(4.dp)),
            contentAlignment = Alignment.Center,
        ) { if (checked) FaIcon("fa-solid fa-check", 11.dp, Color.White) }
        FText("Save these details on this device for next time", size = rem(0.78), color = c.textMuted)
    }
}

/** `.wd-gp-chips` — wrapping row; each chip is at least 56px and grows to fill its row. */
@Composable
private fun FlexChips(values: List<Int>, onPick: (Int) -> Unit) {
    val gap = 8.dp
    Layout(
        content = { values.forEach { v -> Chip(v, onPick) } },
        modifier = Modifier.fillMaxWidth().padding(top = 0.dp, bottom = 14.dp),
    ) { measurables, constraints ->
        val g = gap.roundToPx()
        val minW = 56.dp.roundToPx()
        val maxW = constraints.maxWidth
        val basis = measurables.map { maxOf(minW, it.maxIntrinsicWidth(Int.MAX_VALUE)).coerceAtMost(maxW) }
        // greedy wrap
        val rows = ArrayList<MutableList<Int>>()
        var cur = ArrayList<Int>(); var used = 0
        for (i in measurables.indices) {
            val need = basis[i] + if (cur.isEmpty()) 0 else g
            if (cur.isNotEmpty() && used + need > maxW) { rows.add(cur); cur = ArrayList(); used = 0 }
            used += basis[i] + if (cur.isEmpty()) 0 else g
            cur.add(i)
        }
        if (cur.isNotEmpty()) rows.add(cur)
        val placeables = arrayOfNulls<androidx.compose.ui.layout.Placeable>(measurables.size)
        val pos = arrayOfNulls<IntArray>(measurables.size)
        var y = 0
        for (row in rows) {
            val total = row.sumOf { basis[it] } + g * (row.size - 1)
            val extra = (maxW - total).coerceAtLeast(0) / row.size
            var x = 0
            var rowH = 0
            for (i in row) {
                val w = basis[i] + extra
                val p = measurables[i].measure(androidx.compose.ui.unit.Constraints.fixedWidth(w))
                placeables[i] = p; pos[i] = intArrayOf(x, y)
                x += w + g; rowH = maxOf(rowH, p.height)
            }
            y += rowH + g
        }
        val h = (y - g).coerceAtLeast(0)
        layout(maxW, h) { for (i in measurables.indices) placeables[i]?.place(pos[i]!![0], pos[i]!![1]) }
    }
}

@Composable
private fun Chip(v: Int, onPick: (Int) -> Unit) {
    val c = FF.c
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val shape = RoundedCornerShape(30.dp)
    Box(
        Modifier.graphicsLayer { val s = if (pressed) 0.94f else 1f; scaleX = s; scaleY = s }
            .clip(shape).background(if (pressed) c.primaryLight else c.bgCard)
            .border(1.5.dp, if (pressed) c.primary else c.border, shape)
            .clickable(interactionSource = src, indication = null) { onPick(v) }
            .padding(horizontal = 10.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) { FText("₹$v", size = rem(0.8), weight = FontWeight.ExtraBold, align = TextAlign.Center) }
}
