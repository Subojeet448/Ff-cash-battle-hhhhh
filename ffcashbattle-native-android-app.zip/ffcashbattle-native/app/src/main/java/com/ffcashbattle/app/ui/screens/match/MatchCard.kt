package com.ffcashbattle.app.ui.screens.match

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.data.GameArt
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay

/** Match banner picture: `m.img` (URL) or the generated mode art. */
@Composable
fun MatchBanner(m: Doc, modifier: Modifier) {
    val img = m.s("img")
    if (img.isNotBlank()) AsyncImage(img, null, modifier, contentScale = ContentScale.Crop)
    else Image(painterResource(GameArt.banner(m)), null, modifier, contentScale = ContentScale.Crop)
}

/** `.btn-main` look for the greyed states of the match button (`background:#e2e8f0; color:#64748b; box-shadow:none`). */
@Composable
private fun GreyBtn(content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFFE2E8F0)).padding(14.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

/**
 * Home-page match card (`.match-card.gm-card` built by `renderMatches`): banner with badges/title/countdown, stats grid,
 * prize chips, VS strip, roster button, payout time, progress bar or winners, and the JOIN button.
 */
@Composable
fun MatchCard(m: Doc, index: Int, now: Long) {
    val c = FF.c
    val done = m.s("status") == "completed"
    val total = m.i("total")
    val joinedN = m.i("joined")
    val p = if (total > 0) (joinedN.toFloat() / total).coerceIn(0f, 1f) else 0f
    val full = joinedN >= total
    val joined = m.id in AppStore.joinedIds
    val locked = !joined && !done && (m.s("status") == "live" || m.s("password").trim().isNotEmpty())
    val startMs = m.ms("startTime")
    val pi = remember(m) { prizeInfo(m) }
    val shape = RoundedCornerShape(22.dp)

    // gm-in entrance
    val enter = remember(m.id) { Animatable(0f) }
    LaunchedEffect(m.id) { delay(minOf(index * 70L, 420L)); enter.animateTo(1f, tween(500, easing = CubicBezierEasing(0.16f, 1f, 0.3f, 1f))) }

    // 3dp gradient bar sliding (pl-grad 6s linear infinite)
    val inf = rememberInfiniteTransition(label = "card")
    val slide by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(6000, easing = LinearEasing), RepeatMode.Restart), label = "slide")
    val glow by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2000, easing = LinearEasing), RepeatMode.Restart), label = "glow")

    Box(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 25.dp)
            .graphicsLayer { val e = enter.value; alpha = e; translationY = (1f - e) * 18.dp.toPx(); val s = 0.97f + 0.03f * e; scaleX = s; scaleY = s }
            .boxShadow(30.dp, if (c.isDark) Color(0xB3000000) else Color(0x2E0F172A), shape)
            .clip(shape).background(c.bgCard).border(1.dp, c.border, shape),
    ) {
        Column {
            // ---------------------------------------------------------------- banner
            Box(Modifier.fillMaxWidth().height(200.dp).background(Color(0xFFEEEEEE))) {
                MatchBanner(m, Modifier.fillMaxSize())
                Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(120.dp).background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))))

                // badge-type (left)
                Box(
                    Modifier.align(Alignment.TopStart).padding(start = 12.dp, top = 12.dp)
                        .boxShadow(5.dp, Color(0x33000000), RoundedCornerShape(30.dp)).clip(RoundedCornerShape(30.dp))
                        .background(Color(0xF2FFFFFF)).padding(horizontal = 12.dp, vertical = 5.dp),
                ) {
                    FText(formatLabel(m) + " • " + m.s("map").ifEmpty { "Bermuda" }, size = rem(0.75), weight = FontWeight.Bold, color = if (c.isDark) Color(0xFF0F172A) else c.textMain, maxLines = 1)
                }
                // badge-live (right)
                Box(
                    Modifier.align(Alignment.TopEnd).padding(end = 12.dp, top = 12.dp)
                        .drawBehind {
                            val r = 10.dp.toPx() * glow
                            drawRoundRect(Color(0xFF10B981).copy(alpha = 0.55f * (1f - glow)), topLeft = Offset(-r, -r), size = Size(size.width + 2 * r, size.height + 2 * r), cornerRadius = androidx.compose.ui.geometry.CornerRadius(30.dp.toPx() + r))
                        }
                        .clip(RoundedCornerShape(30.dp)).background(Color(0x99000000)).border(1.dp, Color(0x6610B981), RoundedCornerShape(30.dp))
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                ) {
                    FText(if (done) "ENDED" else "LIVE", size = rem(0.75), weight = FontWeight.Bold, color = if (done) Color(0xFFFBBF24) else Color(0xFF10B981))
                }
                // title + meta
                Column(Modifier.align(Alignment.BottomStart).padding(start = 15.dp, bottom = 12.dp, end = 20.dp)) {
                    FText(
                        (if (m.b("pinned")) "📌 " else "") + m.s("title"),
                        size = rem(1.2), weight = FontWeight.Bold, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(bottom = 2.dp),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0x8C000000)).border(1.dp, Color(0x59FDE68A), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 2.dp)) {
                            FText("#" + matchCode(m), size = rem(0.7), weight = FontWeight.ExtraBold, color = Color(0xFFFDE68A), letterSpacing = 1.sp, mono = true)
                        }
                        if (startMs > 0) {
                            if (done) FText(fmtDT(m["startTime"]), size = rem(0.8), color = Color.White.copy(alpha = 0.9f))
                            else Countdown(startMs, now)
                        } else FText("TBD", size = rem(0.8), color = Color.White.copy(alpha = 0.9f))
                    }
                }
            }

            // ---------------------------------------------------------------- body
            Column(Modifier.padding(start = 15.dp, end = 15.dp, top = 15.dp, bottom = 20.dp)) {
                // stats grid
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 15.dp).clip(RoundedCornerShape(16.dp))
                        .background(Brush.linearGradient(if (c.isDark) listOf(c.bgBody, Color(0xFF1A2144)) else listOf(Color(0xFFF8FAFC), Color(0xFFEEF2FF))))
                        .border(1.dp, c.border, RoundedCornerShape(16.dp)).padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    StatCell(Modifier.weight(1f), pi.lbl, false) { RwView(pi.big, rem(1.1), FontWeight.ExtraBold, c.primary, cardH = 22.dp) }
                    StatCell(Modifier.weight(1f), "Fee", true) { RwView(Rw.Amt(m.n("fee")), rem(1.1), FontWeight.ExtraBold, c.textMain) }
                    StatCell(Modifier.weight(1f), "Slots", true) { FText(total.toString(), size = rem(1.1), weight = FontWeight.ExtraBold, letterSpacing = (-0.2).sp) }
                }
                if (pi.chips.isNotEmpty()) {
                    CenterFlow(8.dp, 8.dp, Modifier.fillMaxWidth().padding(top = 0.dp, bottom = 14.dp)) {
                        pi.chips.forEachIndexed { i, ch -> PrizeChip(ch, i) }
                    }
                }
                SlotStrip(m)
                RosterButton(m)
                if (!done && m["prizeTime"] != null && fmtDT(m["prizeTime"]).isNotEmpty()) {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 10.dp).clip(RoundedCornerShape(10.dp))
                            .background(if (c.isDark) c.bgBody else Color(0xFFF8FAFC)).border(1.dp, c.border, RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically,
                    ) {
                        FaIcon("fa-solid fa-clock", rem(0.78).value.dp, Color(0xFFF59E0B))
                        FText("Prize payout: ", size = rem(0.78), color = c.textMuted)
                        FText(fmtDT(m["prizeTime"]), size = rem(0.78), weight = FontWeight.Bold, color = c.textMain)
                    }
                }
                Box(Modifier.height(14.dp))
                if (done) WinnersStrip(m)
                else {
                    Column(Modifier.fillMaxWidth().padding(bottom = 15.dp)) {
                        Box(Modifier.fillMaxWidth().padding(bottom = 6.dp).height(9.dp).clip(RoundedCornerShape(10.dp)).background(c.bgInput)) {
                            Box(Modifier.fillMaxWidth(p).height(9.dp).clip(RoundedCornerShape(10.dp)).background(c.primary))
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            FText("$joinedN/$total Joined", size = rem(0.8), weight = FontWeight.Medium, color = c.textMuted)
                            FText((total - joinedN).toString() + " Left", size = rem(0.8), weight = FontWeight.Medium, color = c.textMuted)
                        }
                    }
                }
                // ---------------------------------------------------------------- button
                when {
                    done -> GreyBtn { FText("COMPLETED", weight = FontWeight.Bold, color = Color(0xFF64748B)) }
                    joined -> GreyBtn { FText("JOINED ✅", weight = FontWeight.Bold, color = Color(0xFF64748B)) }
                    locked -> GreyBtn {
                        FaIcon("fa-solid fa-lock", rem(1.0).value.dp, Color(0xFF64748B))
                        FText("MATCH STARTED — TRY NEXT MATCH", weight = FontWeight.Bold, color = Color(0xFF64748B), align = TextAlign.Center)
                    }
                    full -> GreyBtn { FText("FULL", weight = FontWeight.Bold, color = Color(0xFF64748B)) }
                    else -> BtnMain("JOIN NOW", { AppStore.checkLogin { AppStore.openJoin(m) } }, Modifier.fillMaxWidth())
                }
            }
        }
        // 3dp animated gradient bar (.match-card::before)
        Box(
            Modifier.fillMaxWidth().height(3.dp).drawBehind {
                val w = size.width
                val shift = w * 2f * slide
                drawRect(
                    Brush.horizontalGradient(listOf(c.primary, Color(0xFF7C3AED), Color(0xFFF43F5E), c.primary), startX = -shift, endX = w * 2f - shift, tileMode = TileMode.Repeated),
                )
            },
        )
    }
}

@Composable
private fun StatCell(modifier: Modifier, label: String, divider: Boolean, value: @Composable () -> Unit) {
    val c = FF.c
    Column(
        modifier.drawBehind {
            if (divider) drawLine(c.border, Offset(-5.dp.toPx(), size.height * 0.15f), Offset(-5.dp.toPx(), size.height * 0.85f), 1.dp.toPx())
        },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        value()
        FText(label.uppercase(), size = rem(0.7), weight = FontWeight.SemiBold, color = c.textMuted, align = TextAlign.Center)
    }
}
