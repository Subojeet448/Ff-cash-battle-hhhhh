package com.ffcashbattle.app.ui.screens.chat

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.AskOpts
import com.ffcashbattle.app.data.AskResult
import com.ffcashbattle.app.data.Chat
import com.ffcashbattle.app.data.ChatKeep
import com.ffcashbattle.app.data.ChatSheet
import com.ffcashbattle.app.data.ChatStore
import com.ffcashbattle.app.data.ChatUi
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.SpinIcon
import com.ffcashbattle.app.ui.comp.VerifiedName
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.screens.match.HistoryCard
import com.ffcashbattle.app.ui.screens.match.HistorySummary
import com.ffcashbattle.app.ui.screens.match.matchStartMs
import com.ffcashbattle.app.ui.screens.match.rememberNow
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.Inter
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun csIcon(i: String): String {
    if (i == "fa-user-xmark") return "fa-solid fa-user-minus"
    return if (i.contains(' ')) i else "fa-solid " + (if (i.startsWith("fa-")) i else "fa-$i")
}

private val dtFmt by lazy { SimpleDateFormat("d MMM, hh:mm a", Locale("en", "IN")) }
private fun fmtDT(ms: Long): String = try { synchronized(dtFmt) { dtFmt.format(Date(ms)).lowercase() } } catch (_: Exception) { "" }

// ==================================================================================== host

/** The chat's bottom sheet (website `#cs`): one sheet at a time, swipe/tap outside/✕ to close. */
@Composable
internal fun ChatSheetHost() {
    val s = ChatUi.sheet ?: return
    key(s) {
        ModalSheet(
            onDismiss = { ChatUi.dismissed(s) }, handle = false,
            padding = PaddingValues(start = 18.dp, top = 10.dp, end = 18.dp, bottom = 20.dp), maxHeightFraction = 0.88f,
        ) {
            val close = LocalSheetClose.current
            val own = s is ChatSheet.History || s is ChatSheet.Saved     // these draw their own title row with ✕
            Box(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth()) {
                    Box(Modifier.fillMaxWidth().padding(bottom = 14.dp), contentAlignment = Alignment.Center) {
                        Box(Modifier.width(42.dp).height(5.dp).clip(RoundedCornerShape(5.dp)).background(FF.c.border))
                    }
                    when (s) {
                        is ChatSheet.Ask -> AskSheet(s, close)
                        is ChatSheet.Onboard -> OnboardSheet(close)
                        is ChatSheet.MsgMenu -> MsgMenuSheet(s, close)
                        is ChatSheet.UserCard -> UserCardSheet(s, close)
                        is ChatSheet.NewGroup -> NewGroupSheet(close)
                        is ChatSheet.GroupInfo -> GroupInfoSheet(s)
                        is ChatSheet.History -> HistorySheet(s, close)
                        is ChatSheet.Saved -> SavedSheet(close)
                    }
                }
                if (!own) Box(
                    Modifier.align(Alignment.TopEnd).offset(y = (-2).dp).size(32.dp).press(0.88f, onClick = close).clip(CircleShape).background(FF.c.bgInput),
                    contentAlignment = Alignment.Center,
                ) { FaIcon("fa-solid fa-xmark", rem(0.9).value.dp, FF.c.textMuted) }
            }
        }
    }
}

// ==================================================================================== small pieces

@Composable
private fun CsInput(value: TextFieldValue, onChange: (TextFieldValue) -> Unit, placeholder: String, modifier: Modifier = Modifier, lines: Int = 1, autoFocus: Boolean = false, caps: KeyboardCapitalization = KeyboardCapitalization.Sentences, autoCorrect: Boolean = true) {
    val c = FF.c
    var focused by remember { mutableStateOf(false) }
    val fr = remember { FocusRequester() }
    if (autoFocus) LaunchedEffect(Unit) { kotlinx.coroutines.delay(350); try { fr.requestFocus() } catch (_: Exception) { } }
    val shape = RoundedCornerShape(16.dp)
    Box(modifier.fillMaxWidth().padding(bottom = 12.dp).clip(shape).background(c.bgInput).border(2.dp, if (focused) Cx6366 else c.border, shape).padding(horizontal = 15.dp, vertical = 13.dp)) {
        BasicTextField(
            value, onChange, Modifier.fillMaxWidth().then(if (lines > 1) Modifier.heightIn(min = (lines * 22).dp) else Modifier).focusRequester(fr).onFocusChanged { focused = it.isFocused },
            singleLine = lines == 1, minLines = lines, maxLines = if (lines == 1) 1 else lines + 2,
            textStyle = TextStyle(color = c.textMain, fontSize = rem(0.95), fontFamily = Inter),
            cursorBrush = SolidColor(Cx6366), keyboardOptions = KeyboardOptions(capitalization = caps, autoCorrectEnabled = autoCorrect),
            decorationBox = { inner -> Box { if (value.text.isEmpty()) FText(placeholder, size = rem(0.95), color = c.textMuted); inner() } },
        )
    }
}

@Composable
private fun CsIco(icon: String, red: Boolean) {
    val shape = RoundedCornerShape(20.dp)
    val col = if (red) CxRed else Cx6366
    Box(
        Modifier.padding(top = 4.dp, bottom = 12.dp).size(62.dp).boxShadow(24.dp, col.copy(alpha = 0.6f), shape).clip(shape).background(if (red) cxRedBrush() else Brush.linearGradient(listOf(Cx6366, CxViolet))),
        contentAlignment = Alignment.Center,
    ) { FaIcon(csIcon(icon), rem(1.6).value.dp, Color.White) }
}

@Composable
private fun CsTitle(text: String, center: Boolean = false) = FText(text, Modifier.fillMaxWidth().padding(bottom = 6.dp), size = rem(1.08), weight = FontWeight.Black, align = if (center) TextAlign.Center else TextAlign.Start)

@Composable
private fun CsText(text: String, center: Boolean = false) = FText(text, Modifier.fillMaxWidth().padding(bottom = 14.dp), size = rem(0.84), color = FF.c.textMuted, lineHeight = rem(0.84) * 1.55f, align = if (center) TextAlign.Center else TextAlign.Start)

@Composable
private fun ListBtn(icon: String, text: String, tint: Color? = null, pri: Boolean = false, red: Boolean = false, on: Boolean = false, small: String? = null, onClick: () -> Unit) {
    val c = FF.c
    val shape = RoundedCornerShape(16.dp)
    var m = Modifier.fillMaxWidth().press(0.97f, onClick = onClick)
    m = if (pri) m.boxShadow(18.dp, Cx6366.copy(alpha = 0.55f), shape).clip(shape).background(Brush.linearGradient(listOf(Cx6366, CxViolet)))
    else m.clip(shape).background(if (on) CxAmber.copy(alpha = 0.14f) else c.bgInput)
    Row(m.padding(horizontal = 16.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
        FaIcon(icon, rem(0.9).value.dp, if (pri) Color.White else tint ?: if (red) CxRed else c.textMain)
        FText(text, Modifier.weight(1f), size = rem(0.9), weight = FontWeight.ExtraBold, color = if (pri) Color.White else if (red) CxRed else c.textMain)
        if (small != null) FText(small, size = rem(0.8), weight = FontWeight.Bold, color = c.textMuted)
    }
}

@Composable
private fun TitleRow(title: String, icon: String? = null, iconTint: Color = CxAmber, onClose: () -> Unit) {
    val c = FF.c
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) FaIcon(icon, rem(1.1).value.dp, iconTint)
            FText(title, size = rem(1.2), weight = FontWeight.Black)
        }
        Box(Modifier.size(36.dp).press(0.85f, onClick = onClose).clip(CircleShape).background(c.bgInput), contentAlignment = Alignment.Center) { FaIcon("fa-solid fa-xmark", rem(1.0).value.dp, c.textMuted) }
    }
}

// ==================================================================================== Ask (confirm / input / chips)

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AskSheet(s: ChatSheet.Ask, close: () -> Unit) {
    val o = s.o
    var text by remember { mutableStateOf(TextFieldValue(o.input ?: "", TextRange(0, (o.input ?: "").length))) }
    var area by remember { mutableStateOf(TextFieldValue("")) }
    var chip by remember { mutableStateOf(o.chips.firstOrNull() ?: "") }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        CsIco(o.icon, o.danger)
        CsTitle(o.title, true)
        if (o.text.isNotEmpty()) CsText(o.text, true)
        if (o.input != null) CsInput(text, { if (it.text.length <= o.max) text = it }, o.placeholder, autoFocus = true)
        if (o.chips.isNotEmpty()) FlowRow(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            o.chips.forEach { ch ->
                val on = ch == chip
                val sh = RoundedCornerShape(20.dp)
                Box(Modifier.graphicsLayer { val sc = if (on) 1.04f else 1f; scaleX = sc; scaleY = sc }.press(0.94f) { chip = ch }.clip(sh).background(if (on) Cx6366 else Color.Transparent).border(2.dp, if (on) Cx6366 else FF.c.border, sh).padding(horizontal = 14.dp, vertical = 8.dp)) {
                    FText(ch, size = rem(0.78), weight = FontWeight.ExtraBold, color = if (on) Color.White else FF.c.textMuted)
                }
            }
        }
        if (o.area != null) CsInput(area, { if (it.text.length <= 300) area = it }, o.area, lines = 3)
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CsBtn(o.no, close, Modifier.weight(1f), yes = false)
            CsBtn(o.yes, {
                val v = if (o.input != null) text.text.trim() else if (o.chips.isNotEmpty()) chip else ""
                s.done.complete(AskResult(v, area.text.trim())); close()
            }, Modifier.weight(1f), yes = true, red = o.danger)
        }
    }
}

// ==================================================================================== Onboard (choose a username)

@Composable
private fun OnboardSheet(close: () -> Unit) {
    val scope = rememberCoroutineScope()
    val sug = remember {
        val base = AppStore.user.s("appName").ifEmpty { "player" }.lowercase().filter { it in 'a'..'z' || it in '0'..'9' }.take(12).ifEmpty { "player" }
        base + (100 + (Math.random() * 900).toInt())
    }
    var v by remember { mutableStateOf(TextFieldValue(sug, TextRange(sug.length))) }
    var busy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        CsIco("fa-solid fa-at", false)
        CsTitle("Choose your username", true)
        CsText("Friends will find you with this name. It cannot be changed later.", true)
        CsInput(v, { n -> val t = n.text.lowercase().filter { it in 'a'..'z' || it in '0'..'9' || it == '_' }.take(20); v = n.copy(text = t, selection = TextRange(minOf(n.selection.start, t.length), minOf(n.selection.end, t.length))) }, "username", autoFocus = false, caps = KeyboardCapitalization.None, autoCorrect = false)
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CsBtn("Not now", { close(); ChatKeep.closeApp() }, Modifier.weight(1f), yes = false)
            Box(Modifier.weight(1f)) {
                if (busy) Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cxBtnBrush()).padding(14.dp), contentAlignment = Alignment.Center) { SpinIcon(rem(0.92).value.dp, Color.White, icon = "fa-solid fa-spinner") }
                else CsBtn("Continue", {
                    busy = true
                    scope.launch {
                        val ok = Chat.createProfile(v.text)
                        busy = false
                        if (ok) { close(); AppStore.toast("Welcome to ${Chat.world.name} 🔥") }
                    }
                }, Modifier.fillMaxWidth(), yes = true)
            }
        }
    }
}

// ==================================================================================== tap a message

@Composable
private fun MsgMenuSheet(s: ChatSheet.MsgMenu, close: () -> Unit) {
    val c = FF.c
    val scope = rememberCoroutineScope()
    ChatStore.version
    val th = Chat.thread
    val m = Chat.msgs.firstOrNull { it.id == s.id }
    if (m == null || th == null || m.b("deleted")) { LaunchedEffect(Unit) { close() }; return }
    val uid = Chat.uid ?: ""
    val from = m.s("from")
    val mine = from == uid
    val left = Chat.EDIT_MS - (System.currentTimeMillis() - m.l("at"))
    val saved = ChatKeep.isSaved(m)
    val txt = Chat.parseMsg(m).text
    val world = th.kind == "world"
    val nm = m.s("name").ifEmpty { Chat.friendName(from) }
    Column(Modifier.fillMaxWidth()) {
        FText(if (mine) "Your message" else nm, Modifier.fillMaxWidth().padding(bottom = 6.dp), size = rem(1.08), weight = FontWeight.Black, align = TextAlign.Center)
        Box(Modifier.padding(bottom = 10.dp).fillMaxWidth().heightIn(max = 90.dp).clip(RoundedCornerShape(14.dp)).background(c.bgInput).verticalScroll(rememberScrollState()).padding(12.dp)) {
            FText(txt, size = rem(0.86))
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
            FaIcon("fa-regular fa-hourglass-half", rem(0.74).value.dp, CxAmber)
            FText((if (th.kind == "dm") "Kept on your device · server copy removed in " else "Disappears from server in ") + ChatKeep.leftText(m, th.kind), size = rem(0.74), weight = FontWeight.ExtraBold, color = c.textMuted)
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ListBtn("fa-solid fa-reply", "Reply", pri = true) { Chat.replyTo(m.id) }
            if (!mine && world) ListBtn("fa-solid fa-paper-plane", "Message $nm", tint = Cx6366) { scope.launch { Chat.openDm(from) } }
            ListBtn("fa-regular fa-copy", "Copy text") { AppStore.copy(txt); close() }
            ListBtn(if (saved) "fa-solid fa-bookmark" else "fa-regular fa-bookmark", if (saved) "Remove from saved" else "Save on this device", tint = CxAmber, on = saved) {
                if (saved) ChatKeep.unsaveMsg(m.id) else ChatKeep.saveMsg(m.id); close()
            }
            if (mine && left > 0) {
                ListBtn("fa-solid fa-pen", "Edit message", small = "${left / 60000}m left") { Chat.editStart(m.id) }
                ListBtn("fa-solid fa-trash", "Delete message", red = true) { scope.launch { Chat.delMsg(m.id) } }
            }
            if (Chat.canMod(m)) {
                Row(Modifier.fillMaxWidth().padding(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
                    FaIcon("fa-solid fa-circle-check", rem(0.74).value.dp, Color(0xFF1D9BF0))
                    FText("Verified moderator tools", size = rem(0.74), weight = FontWeight.ExtraBold, color = Color(0xFF0A84FF))
                }
                ListBtn("fa-solid fa-pen", "Edit this message") { Chat.editStart(m.id) }
                ListBtn("fa-solid fa-trash", "Delete this message", red = true) { scope.launch { Chat.delMsg(m.id) } }
            }
            if (mine && left <= 0) Row(Modifier.fillMaxWidth().padding(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
                FaIcon("fa-regular fa-clock", rem(0.74).value.dp, c.textMuted)
                FText("Edit / delete works for 10 minutes after sending", size = rem(0.74), color = c.textMuted)
            }
        }
    }
}

// ==================================================================================== user card (World)

@Composable
private fun UserCardSheet(s: ChatSheet.UserCard, close: () -> Unit) {
    val c = FF.c
    val scope = rememberCoroutineScope()
    var p by remember { mutableStateOf(Chat.prof[s.uid]) }
    LaunchedEffect(s.uid) { if (p == null) p = try { Chat.getProf(s.uid) } catch (_: Exception) { null } }
    val prof = p
    if (prof == null) { LoadingDots(Modifier.padding(vertical = 16.dp)); return }
    val uid = s.uid
    val nm = prof.s("name").ifEmpty { s.name.ifEmpty { Chat.friendName(uid) } }
    val friend = Chat.isFriend(uid)
    val priv = prof.b("isPrivate") && !friend
    val reqOut = Chat.outgoing.any { it.s("to") == uid }
    val reqIn = Chat.incoming.any { it.s("from") == uid }
    val blocked = Chat.isBlocked(uid)
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box {
            Box(Modifier.boxShadow(28.dp, Cx6366.copy(alpha = 0.7f), CircleShape).border(4.dp, Color.White, CircleShape).clip(CircleShape)) { ChatAv(nm, prof.s("photo").ifEmpty { s.photo }, 80.dp) }
            if (prof.b("online")) Box(Modifier.align(Alignment.BottomEnd).offset(x = (-2).dp, y = (-2).dp).size(18.dp).clip(CircleShape).background(Color(0xFF10B981)).border(3.dp, c.bgCard, CircleShape))
        }
        Box(Modifier.padding(top = 8.dp)) { VerifiedName(nm, uid, rem(1.2), weight = FontWeight.Black, force = Chat.isVer(uid) || prof.b("verified")) }
        if (prof.s("username").isNotEmpty()) FText("@" + prof.s("username"), size = rem(0.85), weight = FontWeight.ExtraBold, color = Cx6366)
        FlowRowTags(prof, friend)
        if (priv) FText("This profile is private.", Modifier.padding(horizontal = 12.dp).padding(top = 6.dp, bottom = 14.dp), size = rem(0.84), color = c.textMuted, align = TextAlign.Center)
        else if (prof.s("bio").isNotEmpty()) FText(prof.s("bio"), Modifier.padding(horizontal = 12.dp).padding(top = 6.dp, bottom = 14.dp), size = rem(0.84), color = c.textMuted, lineHeight = rem(0.84) * 1.5f, align = TextAlign.Center)
        else FText("No bio yet", Modifier.padding(horizontal = 12.dp).padding(top = 6.dp, bottom = 14.dp), size = rem(0.84), color = c.textMuted, italic = true, align = TextAlign.Center)
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            UcBtn("fa-solid fa-paper-plane", if (priv) "Message (needs friend)" else "Message", main = true, enabled = !blocked) { scope.launch { Chat.openDm(uid) } }
            if (!friend) {
                if (reqIn) UcBtn("fa-solid fa-inbox", "Respond to request") { Chat.tab = "profile"; ChatUi.historyTab = "requests"; ChatUi.show(ChatSheet.History("requests")) }
                else UcBtn("fa-solid fa-user-plus", if (reqOut) "Request sent" else "Add friend", enabled = !reqOut) { scope.launch { Chat.sendRequest(uid) }; close() }
            }
            UcBtn("fa-solid fa-flag", "Report", red = true) { scope.launch { Chat.reportWorldUser(uid, nm.replace("'", "")) } }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FlowRowTags(p: Doc, friend: Boolean) {
    val c = FF.c
    @Composable fun tag(icon: String?, text: String, green: Boolean = false, blue: Boolean = false) {
        Row(
            Modifier.clip(RoundedCornerShape(12.dp)).background(if (green) (if (c.isDark) Color(0x3310B981) else Color(0xFFD1FAE5)) else if (blue) Color(0x1F0A84FF) else c.bgInput).padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            val col = if (green) (if (c.isDark) Color(0xFF6EE7B7) else Color(0xFF047857)) else if (blue) Color(0xFF0A84FF) else c.textMuted
            if (icon != null) FaIcon(icon, rem(0.66).value.dp, col)
            FText(text, size = rem(0.66), weight = FontWeight.ExtraBold, color = col)
        }
    }
    FlowRow(Modifier.padding(top = 10.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (p.b("verified")) tag("fa-solid fa-circle-check", "Verified", blue = true)
        if (friend) tag("fa-solid fa-user-check", "Friend", green = true)
        if (p.b("isPrivate")) tag("fa-solid fa-lock", "Private") else tag("fa-solid fa-earth-asia", "Public")
        if (p.b("online")) tag(null, "Online", green = true)
    }
}

@Composable
private fun UcBtn(icon: String, text: String, main: Boolean = false, red: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val c = FF.c
    val shape = RoundedCornerShape(16.dp)
    var m = Modifier.fillMaxWidth().press(0.96f, enabled, onClick)
    if (main && enabled) m = m.boxShadow(20.dp, Cx6366.copy(alpha = 0.6f), shape)
    m = m.clip(shape).background(if (main) Brush.linearGradient(listOf(Cx6366, CxViolet)) else Brush.linearGradient(listOf(c.bgInput, c.bgInput)))
    Row(m.graphicsLayer { alpha = if (enabled) 1f else 0.5f }.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
        FaIcon(icon, rem(0.9).value.dp, if (main) Color.White else if (red) CxRed else c.textMain)
        FText(text, size = rem(0.9), weight = FontWeight.ExtraBold, color = if (main) Color.White else if (red) CxRed else c.textMain)
    }
}

// ==================================================================================== new group / group info

@Composable
private fun MemberRow(name: String, uid: String, photo: String?, pick: Boolean = false, on: Boolean = false, owner: Boolean = false, you: Boolean = false, onClick: (() -> Unit)? = null) {
    val c = FF.c
    val shape = RoundedCornerShape(14.dp)
    var m = Modifier.fillMaxWidth()
    if (onClick != null) m = m.press(0.98f, onClick = onClick)
    if (pick) m = m.clip(shape).background(if (on) Cx6366.copy(alpha = 0.08f) else Color.Transparent).border(2.dp, if (on) Cx6366 else Color.Transparent, shape)
    Row(m.padding(horizontal = 6.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
        ChatAv(name, photo, 38.dp)
        Box(Modifier.weight(1f)) { VerifiedName(if (you) "You" else name, uid, rem(0.9), weight = FontWeight.Bold, force = Chat.isVer(uid)) }
        if (owner) Box(Modifier.clip(RoundedCornerShape(10.dp)).background(if (c.isDark) Cx6366.copy(alpha = 0.25f) else Color(0xFFEEF2FF)).padding(horizontal = 8.dp, vertical = 2.dp)) { FText("owner", size = rem(0.62), weight = FontWeight.ExtraBold, color = if (c.isDark) CxSoft else CxIndigo) }
        if (pick) {
            if (on) FaIcon("fa-solid fa-circle-check", rem(1.1).value.dp, Cx6366)
            else Box(Modifier.size(rem(1.1).value.dp).border(2.dp, Color(0xFFCBD5E1), CircleShape))
        }
    }
}

@Composable
private fun NewGroupSheet(close: () -> Unit) {
    val c = FF.c
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(TextFieldValue("")) }
    var picked by remember { mutableStateOf<Set<String>>(emptySet()) }
    var busy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        CsTitle("New group")
        CsInput(name, { if (it.text.length <= 30) name = it }, "Group name")
        FText("Add friends", Modifier.padding(top = 0.dp, bottom = 6.dp), size = rem(0.84), color = c.textMuted)
        Column(Modifier.padding(bottom = 12.dp).fillMaxWidth().heightIn(max = 240.dp).verticalScroll(rememberScrollState())) {
            Chat.friends.list.forEach { f ->
                val on = f in picked
                MemberRow(Chat.friendName(f), f, Chat.prof[f]?.s("photo"), pick = true, on = on) {
                    picked = if (on) picked - f else if (picked.size >= 29) picked else picked + f
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CsBtn("Cancel", close, Modifier.weight(1f), yes = false)
            CsBtn("Create", { if (!busy) { busy = true; scope.launch { Chat.makeGroup(name.text, picked); busy = false } } }, Modifier.weight(1f), yes = true, enabled = !busy)
        }
    }
}

@Composable
private fun GroupInfoSheet(s: ChatSheet.GroupInfo) {
    val g = Chat.groups[s.gid]
    if (g == null) return
    val members = g.strList("members")
    Column(Modifier.fillMaxWidth()) {
        CsTitle((g.s("emoji").ifEmpty { "👥" }) + " " + g.s("name"))
        CsText("${members.size} members")
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            members.forEach { m ->
                Chat.loadProf(m)
                MemberRow(Chat.friendName(m), m, Chat.prof[m]?.s("photo"), owner = m == g.s("owner"), you = m == Chat.uid)
            }
        }
    }
}

// ==================================================================================== History (match history + friend requests)

@Composable
private fun HistorySheet(s: ChatSheet.History, close: () -> Unit) {
    val c = FF.c
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(s.tab) }
    val inc = Chat.incoming
    Column(Modifier.fillMaxWidth().heightIn(min = (androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp * 0.55f).dp)) {
        TitleRow("History", onClose = close)
        val x by animateFloatAsState(if (tab == "requests") 1f else 0f, spring(dampingRatio = 0.7f, stiffness = 350f), label = "hsInd")
        val tabShape = RoundedCornerShape(16.dp)
        androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(tabShape).background(c.bgInput).padding(4.dp)) {
            val half = (maxWidth) / 2
            Box(Modifier.offset(x = half * x).width(half).height(42.dp).boxShadow(12.dp, Color(0x1A000000), RoundedCornerShape(13.dp)).clip(RoundedCornerShape(13.dp)).background(c.bgCard))
            Row(Modifier.fillMaxWidth().height(42.dp)) {
                for ((k, label, icon) in listOf(Triple("matches", "Match History", "fa-solid fa-gamepad"), Triple("requests", "Requests", "fa-solid fa-user-plus"))) {
                    val on = tab == k
                    Row(Modifier.weight(1f).fillMaxSize().tap { tab = k; ChatUi.historyTab = k }, horizontalArrangement = Arrangement.spacedBy(7.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
                        FaIcon(icon, rem(0.78).value.dp, if (on) c.primary else c.textMuted)
                        FText(label, size = rem(0.78), weight = FontWeight.ExtraBold, color = if (on) c.primary else c.textMuted)
                        if (k == "requests" && inc.isNotEmpty()) Box(Modifier.widthIn(min = 17.dp).height(17.dp).clip(RoundedCornerShape(20.dp)).background(CxRed).padding(horizontal = 4.dp), contentAlignment = Alignment.Center) { FText(inc.size.toString(), size = rem(0.62), weight = FontWeight.Bold, color = Color.White) }
                    }
                }
            }
        }
        if (tab == "matches") {
            LaunchedEffect(Unit) { AppStore.loadMyCompleted() }
            val now by rememberNow()
            val myUid = AppStore.uid ?: ""
            val mine = AppStore.matches.filter { it.id in AppStore.joinedIds && it.s("status") == "completed" }.sortedByDescending { matchStartMs(it) }
            if (mine.isEmpty()) ChatEmpty("fa-solid fa-gamepad", "No game history yet", "Your completed matches will show up here.", small = true)
            else {
                HistorySummary(mine, myUid)
                mine.take(30).forEachIndexed { i, m -> HistoryCard(m, myUid, i, now) }
            }
        } else {
            if (inc.isEmpty()) ChatEmpty("fa-solid fa-user-plus", "No pending requests", null, small = true)
            inc.forEach { r ->
                RqRow(r.s("fromName"), r.s("fromPhoto"), r.s("from"), "@" + r.s("fromUsername") + " wants to be friends") {
                    RqBtn("fa-solid fa-check", false) { scope.launch { Chat.acceptRequest(r) } }
                    RqBtn("fa-solid fa-xmark", true) {
                        scope.launch {
                            ChatUi.ask(AskOpts(icon = "fa-user-xmark", title = "Reject ${r.s("fromName")}?", yes = "Reject", danger = true)) ?: return@launch
                            Chat.rejectRequest(r); ChatUi.show(ChatSheet.History("requests"))
                        }
                    }
                }
            }
            val sent = Chat.outgoing.filter { it.s("status") == "pending" }
            if (sent.isNotEmpty()) SecHeader("Sent")
            sent.forEach { r ->
                val u = r.s("to")
                RqRow(Chat.prof[u]?.s("name")?.ifEmpty { "Player" } ?: "Player", Chat.prof[u]?.s("photo"), u, "Waiting for reply…") {
                    RqBtn("fa-solid fa-xmark", true) { scope.launch { Chat.cancelRequest(r.id) } }
                }
            }
        }
    }
}

@Composable
private fun RqRow(name: String, photo: String?, uid: String, sub: String, buttons: @Composable () -> Unit) {
    val c = FF.c
    Row(Modifier.padding(bottom = 8.dp).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(c.bgInput).padding(horizontal = 12.dp, vertical = 11.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
        ChatAv(name, photo, 46.dp)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            VerifiedName(name, uid, rem(0.92), weight = FontWeight.Bold, force = Chat.isVer(uid))
            FText(sub, size = rem(0.75), color = c.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        buttons()
    }
}

@Composable
private fun RqBtn(icon: String, no: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(38.dp).press(0.88f, onClick = onClick).clip(CircleShape).background(if (no) CxRed.copy(alpha = 0.12f) else Color(0xFF10B981).copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center,
    ) { FaIcon(icon, rem(0.9).value.dp, if (no) CxRed else Color(0xFF10B981)) }
}

// ==================================================================================== Saved on this device

@Composable
private fun SavedSheet(close: () -> Unit) {
    val c = FF.c
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    ChatStore.version; ChatKeep.prefVer
    val backup = rememberBackupActions()
    val rows = ChatStore.all().sortedBy { it.at }
    val groups = LinkedHashMap<String, MutableList<com.ffcashbattle.app.data.SavedMsg>>()
    rows.forEach { groups.getOrPut(it.room) { ArrayList() }.add(it) }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) scope.launch {
            val list = ChatStore.all().sortedWith(compareBy({ it.room }, { it.at }))
            val sb = StringBuilder("FF Cash Battle — saved chat messages\nExported " + fmtDT(System.currentTimeMillis()) + "\n")
            var cur = ""
            list.forEach { r -> if (r.room != cur) { cur = r.room; sb.append("\n=== ").append(r.roomName).append(" ===\n") }; sb.append("[").append(fmtDT(r.at)).append("] ").append(r.name).append(": ").append(r.text).append("\n") }
            val ok = withContext(Dispatchers.IO) { try { ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(sb.toString().toByteArray(Charsets.UTF_8)) }; true } catch (_: Exception) { false } }
            AppStore.toast(if (ok) "Exported ✓" else "Could not save the file")
        }
    }
    Column(Modifier.fillMaxWidth()) {
        TitleRow("Saved on this device", "fa-solid fa-bookmark", CxAmber, close)
        Row(
            Modifier.padding(bottom = 12.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Cx6366.copy(alpha = if (c.isDark) 0.14f else 0.08f)).padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Top,
        ) {
            FaIcon("fa-solid fa-circle-info", rem(0.74).value.dp, Cx6366, Modifier.padding(top = 2.dp))
            FText("World & group messages vanish from the server after ${ChatKeep.ttlLabel("world")}, friend chats (DM) after 7 days. Copies saved here stay on this phone until you delete them.", size = rem(0.74), color = c.textMuted, lineHeight = rem(0.74) * 1.45f)
        }
        if (rows.isEmpty()) ChatEmpty("fa-regular fa-bookmark", "Nothing saved yet", "Tap any message → Save on this device, or turn on Keep a copy in a chat's ⋮ menu.", small = true)
        groups.forEach { (rk, list) ->
            val first = list.first()
            Column(Modifier.padding(bottom = 14.dp)) {
                Row(Modifier.fillMaxWidth().padding(start = 2.dp, end = 2.dp, top = 6.dp, bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    FaIcon(if (first.kind == "dm") "fa-solid fa-user" else if (first.kind == "group") "fa-solid fa-users" else "fa-solid fa-earth-asia", rem(0.82).value.dp, c.primary)
                    FText(first.roomName, Modifier.weight(1f, fill = false), size = rem(0.82), weight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Box(Modifier.clip(RoundedCornerShape(10.dp)).background(if (c.isDark) Cx6366.copy(alpha = 0.25f) else Color(0xFFEEF2FF)).padding(horizontal = 8.dp, vertical = 2.dp)) { FText(list.size.toString(), size = rem(0.62), weight = FontWeight.ExtraBold, color = if (c.isDark) CxSoft else CxIndigo) }
                    if (ChatKeep.inList("auto", rk)) {
                        Spacer(Modifier.weight(1f))
                        Row(Modifier.clip(RoundedCornerShape(10.dp)).background(if (c.isDark) Color(0x3310B981) else Color(0xFFD1FAE5)).padding(horizontal = 8.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                            FaIcon("fa-solid fa-floppy-disk", rem(0.62).value.dp, if (c.isDark) Color(0xFF6EE7B7) else Color(0xFF059669))
                            FText("auto", size = rem(0.62), weight = FontWeight.ExtraBold, color = if (c.isDark) Color(0xFF6EE7B7) else Color(0xFF059669))
                        }
                    }
                }
                list.forEach { r ->
                    val sh = RoundedCornerShape(16.dp)
                    Row(Modifier.padding(bottom = 8.dp).fillMaxWidth().clip(sh).background(c.bgCard).border(1.dp, c.border, sh).padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            FText(r.name, size = rem(0.74), weight = FontWeight.Bold, color = c.primary)
                            FText(r.text, Modifier.padding(vertical = 2.dp), size = rem(0.86))
                            FText(fmtDT(r.at), size = rem(0.62), color = c.textMuted)
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            SvBtn("fa-regular fa-copy", false) { AppStore.copy(r.text) }
                            SvBtn("fa-solid fa-trash", true) { ChatStore.del(listOf(r.k)) }
                        }
                    }
                }
            }
        }
        Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CsBtn("Backup", backup.backup, Modifier.weight(1f), yes = false, icon = "fa-solid fa-cloud-arrow-down")
                CsBtn("Restore", backup.restore, Modifier.weight(1f), yes = false, icon = "fa-solid fa-cloud-arrow-up")
            }
            if (rows.isNotEmpty()) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CsBtn("Export .txt", { export.launch("ff-chat-saved.txt") }, Modifier.weight(1f), yes = false, icon = "fa-solid fa-file-arrow-down")
                CsBtn("Delete all", {
                    scope.launch {
                        ChatUi.ask(AskOpts(icon = "fa-trash", title = "Delete all saved messages?", text = "This removes every copy stored on this device, including your friend chats (take a Backup first if you want to keep them). It cannot be undone.", yes = "Delete all", danger = true)) ?: return@launch
                        ChatStore.clear(); AppStore.toast("Cleared"); ChatUi.show(ChatSheet.Saved())
                    }
                }, Modifier.weight(1f), yes = true, red = true)
            }
        }
    }
}

@Composable
private fun SvBtn(icon: String, red: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(32.dp).press(0.88f, onClick = onClick).clip(RoundedCornerShape(10.dp)).background(FF.c.bgInput), contentAlignment = Alignment.Center) {
        FaIcon(icon, rem(0.85).value.dp, if (red) CxRed else FF.c.textMuted)
    }
}
