package com.ffcashbattle.app.ui.modals

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.Cfg
import com.ffcashbattle.app.data.Repo
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.InputBox
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.NamedImage
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.launch

/**
 * `#modal-settings` — "Security & Payment": payment info, Proofs entry (-> ffcashbattle.in/proof), Terms of Service,
 * the app's Website link, and the support contacts configured by the admin (WhatsApp / Telegram).
 */
@Composable
fun SettingsModal() {
    val c = FF.c
    val d = AppStore.user
    var method by remember { mutableStateOf(d.s("paymentMethod")) }
    var name by remember { mutableStateOf(d.s("paymentName")) }
    var saving by remember { mutableStateOf(false) }
    val close = LocalSheetClose.current

    ModalSheet {
        FText("Security & Payment", size = rem(1.5), weight = FontWeight.Bold, modifier = Modifier.padding(bottom = 20.dp))
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            InputBox(method, { method = it }, Modifier.fillMaxWidth(), placeholder = "UPI / Account Number")
            InputBox(name, { name = it }, Modifier.fillMaxWidth(), placeholder = "Account Holder Name")
        }
        BtnMain(
            if (saving) "Saving…" else "Update Payment Info",
            onClick = {
                if (saving) return@BtnMain
                if (method.isEmpty()) { AppStore.toast("Add Number"); return@BtnMain }
                val uid = AppStore.uid ?: ""
                if (uid.isEmpty()) { AppStore.toast("Please login first"); return@BtnMain }
                saving = true
                AppStore.scope.launch {
                    try {
                        Repo.update(listOf("users", uid), mapOf("paymentMethod" to method, "paymentName" to name))
                        AppStore.toast("Saved")
                        close()
                    } catch (e: Exception) {
                        AppStore.toast("Error Saving")
                    } finally { saving = false }
                }
            },
            small = true, enabled = !saving, modifier = Modifier.padding(top = 10.dp).fillMaxWidth(),
        )

        // .prf-entry — Proofs (payment feed) lives on the website
        val ink = Color(0xFF3B2A1A)
        Row(
            Modifier.padding(top = 12.dp).fillMaxWidth()
                .drawBehind { drawRoundRect(ink, topLeft = Offset(3.dp.toPx(), 3.dp.toPx()), size = size, cornerRadius = CornerRadius(14.dp.toPx())) }
                .press(0.98f) { AppStore.openProof() }
                .clip(RoundedCornerShape(14.dp)).background(Color(0xFFFFF4D6)).border(3.dp, ink, RoundedCornerShape(14.dp))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            NamedImage("proof_proof", Modifier.size(28.dp))
            FText("Proofs (payment feed)", weight = FontWeight.ExtraBold, color = ink, modifier = Modifier.weight(1f))
            FaIcon("fa-solid fa-chevron-right", rem(1.0).value.dp, ink.copy(alpha = 0.5f))
        }

        LinkRow("fa-solid fa-file-contract", "Terms of Service", 22.dp) { AppStore.openWeb(Cfg.TERMS_URL, "Terms of Service") }
        LinkRow("fa-solid fa-globe", "Visit Website  ·  ffcashbattle.in", 12.dp) { AppStore.openUrl(Cfg.SITE) }

        // support
        Column(
            Modifier.padding(top = 22.dp).fillMaxWidth()
                .drawBehind { drawRect(c.border, size = androidx.compose.ui.geometry.Size(size.width, 1.dp.toPx())) }
                .padding(top = 16.dp),
        ) {
            FText("Need Help? Contact Support", size = rem(1.0), weight = FontWeight.ExtraBold, modifier = Modifier.padding(bottom = 12.dp))
            val w = AppStore.whatsapp
            val t = AppStore.telegram
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (w.second.trim().isNotEmpty()) SupportRow("fa-brands fa-whatsapp", Color(0xFFDCFCE7), Color(0xFF16A34A), w.first.ifEmpty { "WhatsApp Support" }, w.second) { AppStore.openWhatsApp() }
                if (t.second.trim().isNotEmpty()) SupportRow("fa-brands fa-telegram", Color(0xFFE0E7FF), Color(0xFF4F46E5), t.first.ifEmpty { "Telegram Support" }, t.second) { AppStore.openTelegram() }
                if (w.second.trim().isEmpty() && t.second.trim().isEmpty()) FText("No support contacts configured yet.", size = rem(0.85), color = c.textMuted)
            }
        }
    }
}

@Composable
private fun LinkRow(icon: String, label: String, top: androidx.compose.ui.unit.Dp, onClick: () -> Unit) {
    val c = FF.c
    Row(
        Modifier.padding(top = top).fillMaxWidth()
            .press(0.98f) { onClick() }
            .clip(RoundedCornerShape(14.dp)).border(1.dp, c.border, RoundedCornerShape(14.dp))
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        FaIcon(icon, rem(1.0).value.dp, c.primary)
        FText(label, weight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        FaIcon("fa-solid fa-chevron-right", rem(0.8).value.dp, c.textMain.copy(alpha = 0.45f))
    }
}

@Composable
private fun SupportRow(icon: String, bg: Color, fg: Color, title: String, link: String, onClick: () -> Unit) {
    val c = FF.c
    Row(
        Modifier.fillMaxWidth().press(0.98f) { onClick() }.clip(RoundedCornerShape(12.dp)).background(c.bgInput).padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(if (c.isDark) bg.copy(alpha = 0.16f) else bg), contentAlignment = Alignment.Center) {
            FaIcon(icon, rem(1.2).value.dp, fg)
        }
        Column(Modifier.weight(1f)) {
            FText(title, size = rem(0.92), weight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            FText(link, size = rem(0.78), color = c.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        FaIcon("fa-solid fa-arrow-up-right-from-square", rem(1.0).value.dp, c.textMuted)
    }
}
