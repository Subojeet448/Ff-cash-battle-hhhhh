package com.ffcashbattle.app.ui.shell

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.Cfg
import com.ffcashbattle.app.data.GameArt
import com.ffcashbattle.app.data.Repo
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.state.Page
import com.ffcashbattle.app.ui.comp.Avatar
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.NamedImage
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.theme.Brand
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val DrawerEase = CubicBezierEasing(0.2f, 0.8f, 0.2f, 1f)
private val EaseOutCubic = CubicBezierEasing(0.215f, 0.61f, 0.355f, 1f)

private fun closeDrawer() { AppStore.drawerOpen = false }

/** CSS negative margin-top (Compose padding cannot be negative). */
private fun Modifier.negTop(amount: Dp): Modifier = layout { m, c ->
    val p = m.measure(c)
    val n = amount.roundToPx()
    layout(p.width, (p.height - n).coerceAtLeast(0)) { p.placeRelative(0, -n) }
}

/**
 * `#drawer-wrapper` — left drawer 85% wide (max 320), slides in 0.3s, dim overlay rgba(0,0,0,.4) (dark .6).
 * Guest: avatar + "Login / Sign Up". Logged in: cover, avatar, name, id chip, game name/UID, verify badges,
 * pull-out Total Balance card, stats, Shortcuts, Support & Settings, Account.
 */
@Composable
fun AppDrawer() {
    val c = FF.c
    val open = AppStore.drawerOpen
    val cfg = LocalConfiguration.current
    val dw = minOf(cfg.screenWidthDp * 0.85f, if (cfg.screenWidthDp >= 700) 340f else 320f).dp
    val progress by animateFloatAsState(if (open) 1f else 0f, tween(300, easing = DrawerEase), label = "drawer")
    if (progress <= 0.001f && !open) return

    // numbers count up from 0 every time the drawer opens (ui.drawerCount)
    val cu = remember { Animatable(1f) }
    LaunchedEffect(open) {
        if (open) { cu.snapTo(0f); cu.animateTo(1f, tween(700, easing = EaseOutCubic)) }
    }

    val overlay = if (c.isDark) Color(0x9902040C) else Color(0x66000000)
    val density = LocalDensity.current
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().graphicsLayer { alpha = progress }.background(overlay).tap(enabled = open) { closeDrawer() })
        Column(
            Modifier
                .width(dw).fillMaxHeight()
                .graphicsLayer { translationX = -(1f - progress) * with(density) { dw.toPx() } }
                .background(if (c.isDark) c.bgCard else c.bgBody)
                .tap { }
                .verticalScroll(rememberScrollState()),
        ) {
            ProfileSection(cu.value)
            DrawerMenu()
        }
    }
}

// --------------------------------------------------------------------------------------------- profile

@Composable
private fun ProfileSection(cu: Float) {
    val c = FF.c
    val inset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val loggedIn = AppStore.loggedIn
    Box(
        Modifier.fillMaxWidth().background(c.bgCard)
            .drawBehind { drawRect(c.border, topLeft = Offset(0f, size.height - 1.dp.toPx()), size = Size(size.width, 1.dp.toPx())) },
    ) {
        if (!loggedIn) GuestProfile(inset) else UserProfile(inset, cu)
    }
}

@Composable
private fun GuestProfile(inset: Dp) {
    val c = FF.c
    Column(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 30.dp + inset, bottom = 20.dp)) {
        Row(Modifier.padding(bottom = 15.dp), horizontalArrangement = Arrangement.spacedBy(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(68.dp).border(2.dp, Color(0xFFCCCCCC), CircleShape).padding(2.dp).clip(CircleShape).background(c.bgCard)) {
                NamedImage("avatar_9", Modifier.fillMaxSize(), androidx.compose.ui.layout.ContentScale.Crop)
            }
            Column {
                FText("Guest User", size = rem(1.1), weight = FontWeight.ExtraBold)
                FText("Login to participate", size = rem(0.8), color = c.textMuted, modifier = Modifier.padding(bottom = 6.dp))
            }
        }
        BtnMain("Login / Sign Up", onClick = { closeDrawer(); AppStore.authTab = "login"; AppStore.authOpen = true }, small = true, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun UserProfile(inset: Dp, cu: Float) {
    val c = FF.c
    val d = AppStore.user
    val fbUser = try { Repo.auth.currentUser } catch (_: Exception) { null }
    val name = d.s("appName").ifEmpty { fbUser?.displayName ?: "" }.ifEmpty { "User" }
    val ph = d.s("phone")
    val sub = if (ph.length > 5) ph.substring(0, 3) + "******" + ph.substring(ph.length - 2) else d.s("email").ifEmpty { fbUser?.email ?: "" }.ifEmpty { "Not Set" }
    val pid = AppStore.playerId
    val gameName = d.s("gameName").ifEmpty { "Not Set" }
    val gameUid = d.s("gameUid").ifEmpty { "---" }
    val phoneOk = ph.length >= 10
    val uidOk = d.b("isUidVerified") || d.s("gameUid").trim().length >= 6

    Box(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth()) {
            // .pf-cover (84dp + the status bar, it bleeds under it)
            Cover(84.dp + inset)
            Column(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 20.dp)) {
                // .profile-top  (margin-top -34)
                Row(Modifier.fillMaxWidth().negTop(34.dp).padding(bottom = 15.dp), horizontalArrangement = Arrangement.spacedBy(15.dp), verticalAlignment = Alignment.Top) {
                    // avatar: 3dp bg-card border + 2dp primary ring outside it
                    Box(Modifier.size(72.dp).boxShadow(18.dp, Color(0x4D4F46E5), CircleShape).border(2.dp, c.primary, CircleShape).padding(2.dp)) {
                        Box(Modifier.size(68.dp).clip(CircleShape).background(c.bgCard)) {
                            Avatar(GameArt.photoOf(d), GameArt.seedOf(d), 62.dp, Modifier.align(Alignment.Center))
                        }
                        Box(Modifier.align(Alignment.BottomEnd).padding(end = 1.dp, bottom = 1.dp).size(14.dp).clip(CircleShape).background(c.success).border(2.5.dp, c.bgCard, CircleShape))
                    }
                    Column(Modifier.weight(1f).padding(top = 40.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            FText(name, size = rem(1.1), weight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                            if (d.b("isVerified")) FaIcon("fa-solid fa-circle-check", rem(0.9).value.dp, Brand.verifiedBlue)
                        }
                        FText(sub, size = rem(0.8), color = c.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(bottom = 6.dp))
                        IdChip(pid)
                    }
                }
                // .p-game-details
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 15.dp).clip(RoundedCornerShape(10.dp)).background(c.bgInput).padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(Modifier.weight(1f)) {
                        FText("GAME NAME", size = rem(0.65), color = c.textMuted)
                        FText(gameName, size = rem(0.8), weight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        FText("UID", size = rem(0.65), color = c.textMuted)
                        FText(gameUid, size = rem(0.8), weight = FontWeight.Bold)
                    }
                }
                // .verify-row
                Row(Modifier.fillMaxWidth().padding(bottom = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    VBadge("Phone", phoneOk, Modifier.weight(1f))
                    VBadge("UID", uidOk, Modifier.weight(1f))
                }
                WalletCard(cu)
                // .dw-hint (margin -8 0 14)
                Row(Modifier.fillMaxWidth().negTop(8.dp).padding(bottom = 14.dp), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
                    FaIcon("fa-solid fa-hand-pointer", rem(0.65).value.dp, c.textMuted.copy(alpha = 0.85f))
                    FText("Pull the card out to open wallet", size = rem(0.65), color = c.textMuted.copy(alpha = 0.85f))
                }
                // .drawer-stats
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatBox(count(d.n("matchesPlayed"), cu), "Matches", Modifier.weight(1f))
                    StatBox(count(d.n("matchesWon"), cu), "Won", Modifier.weight(1f))
                    StatBox("₹" + count(d.n("totalEarned"), cu), "Earned", Modifier.weight(1f), valueColor = c.success)
                }
            }
        }
        // .p-edit-btn (top 14, right 14: glass pill over the cover)
        Row(
            Modifier.align(Alignment.TopEnd).padding(top = 14.dp + inset, end = 14.dp)
                .clip(RoundedCornerShape(20.dp)).background(Color(0x38FFFFFF)).border(1.dp, Color(0x59FFFFFF), RoundedCornerShape(20.dp))
                .tap { AppStore.openModal("modal-edit-profile") }.padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            FaIcon("fa-solid fa-pen", rem(0.72).value.dp, Color.White)
            FText("Edit", size = rem(0.72), weight = FontWeight.Bold, color = Color.White)
        }
    }
}

/** count-up helper: value shown while the drawer's numbers animate from 0. */
private fun count(v: Double, p: Float): String {
    val whole = v == Math.floor(v)
    val shown = v * p
    return if (whole) shown.roundToInt().toString() else String.format(Locale.US, "%.2f", shown).trimEnd('0').trimEnd('.')
}

@Composable
private fun Cover(height: Dp) {
    val c = FF.c
    val inf = rememberInfiniteTransition(label = "cover")
    val f1 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(4000, easing = androidx.compose.animation.core.FastOutSlowInEasing), RepeatMode.Reverse), label = "f1")
    val f2 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(4000, delayMillis = 1200, easing = androidx.compose.animation.core.FastOutSlowInEasing), RepeatMode.Reverse), label = "f2")
    Box(
        Modifier.fillMaxWidth().height(height).clip(androidx.compose.ui.graphics.RectangleShape)
            .background(Brush.linearGradient(0f to c.primary, 0.55f to Color(0xFF7C3AED), 1f to c.accent)),
    ) {
        Box(Modifier.align(Alignment.TopEnd).offset(x = 12.dp, y = (-18).dp + (f1 * 8f).dp).size(70.dp).clip(CircleShape).background(Color(0x29FFFFFF)))
        Box(Modifier.align(Alignment.BottomStart).padding(start = 140.dp).offset(y = 14.dp - (f2 * 8f).dp).size(36.dp).clip(CircleShape).background(Color(0x29FFFFFF)))
    }
}

@Composable
private fun IdChip(pid: String) {
    val c = FF.c
    var pressed by remember { mutableStateOf(false) }
    Row(
        Modifier
            .graphicsLayer { val s = if (pressed) 0.94f else 1f; scaleX = s; scaleY = s }
            .clip(RoundedCornerShape(20.dp)).background(if (pressed) c.primaryLight else c.bgInput)
            .pointerInput(pid) { detectTapGestures(onPress = { pressed = true; tryAwaitRelease(); pressed = false }, onTap = { AppStore.copy(pid) }) }
            .padding(horizontal = 9.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        FaIcon("fa-regular fa-id-badge", rem(0.68).value.dp, c.textMuted)
        FText("ID", size = rem(0.68), weight = FontWeight.SemiBold, color = c.textMuted)
        FText(pid, size = rem(0.68), weight = FontWeight.Bold, mono = true, letterSpacing = 0.5.sp, maxLines = 1)
        FaIcon("fa-regular fa-copy", rem(0.68).value.dp, c.textMuted)
    }
}

@Composable
private fun VBadge(label: String, ok: Boolean, modifier: Modifier) {
    val c = FF.c
    val (bg, fg, bd) = if (ok) {
        if (c.isDark) Triple(Color(0x2410B981), Color(0xFF34D399), Color(0x4D10B981)) else Triple(Color(0xFFDCFCE7), Color(0xFF16A34A), Color(0xFFBBF7D0))
    } else {
        if (c.isDark) Triple(Color(0x24EF4444), Color(0xFFF87171), Color(0x4DEF4444)) else Triple(Color(0xFFFEE2E2), Color(0xFFEF4444), Color(0xFFFECACA))
    }
    Row(
        modifier.clip(RoundedCornerShape(8.dp)).background(bg).border(1.dp, bd, RoundedCornerShape(8.dp)).padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically,
    ) {
        FaIcon(if (ok) "fa-solid fa-circle-check" else "fa-solid fa-circle-xmark", rem(0.7).value.dp, fg)
        FText(label, size = rem(0.7), weight = FontWeight.Bold, color = fg)
    }
}

@Composable
private fun StatBox(value: String, label: String, modifier: Modifier, valueColor: Color = FF.c.textMain) {
    val c = FF.c
    Column(
        modifier.clip(RoundedCornerShape(10.dp)).background(if (c.isDark) c.bgBody else c.bgCard).border(1.dp, c.border, RoundedCornerShape(10.dp)).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        FText(value, size = rem(1.0), weight = FontWeight.ExtraBold, color = valueColor, maxLines = 1)
        FText(label, size = rem(0.65), weight = FontWeight.SemiBold, color = c.textMuted)
    }
}

// --------------------------------------------------------------------------------------------- pull-out wallet card

/** `.drawer-wallet` — drag it sideways: a copy lifts off, leaving a dashed slot; pull >= 80 (or flick) and it flies out to the Wallet page. */
@Composable
private fun WalletCard(cu: Float) {
    val c = FF.c
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val screenW = LocalConfiguration.current.screenWidthDp
    var dx by remember { mutableFloatStateOf(0f) }
    var flyP by remember { mutableFloatStateOf(0f) }
    var dragging by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val threshold = with(density) { 80.dp.toPx() }
    val p = (abs(dx) / threshold).coerceAtMost(1f)
    val ready = abs(dx) >= threshold

    val goWallet: () -> Unit = {
        closeDrawer()
        AppStore.checkLogin { AppStore.goto(Page.WALLET) }
    }

    Box(Modifier.fillMaxWidth().padding(bottom = 15.dp)) {
        if (dragging || busy) {
            Box(Modifier.matchParentSize().drawBehind {
                drawRoundRect(
                    c.primary, topLeft = Offset(1.dp.toPx(), 1.dp.toPx()), size = Size(size.width - 2.dp.toPx(), size.height - 2.dp.toPx()),
                    cornerRadius = CornerRadius(14.dp.toPx()), style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 9f))),
                )
            })
        }
        Row(
            Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    translationX = dx
                    rotationZ = if (flyP > 0f) (if (dx >= 0) 24f else -24f) * flyP else (dx * 0.05f).coerceIn(-10f, 10f)
                    val s = 1f + 0.04f * p
                    scaleX = s; scaleY = s
                    alpha = 1f - flyP
                }
                .then(if (dragging || busy) Modifier.boxShadow(if (ready) 50.dp else 40.dp, Color(if (ready) 0xA64F46E5 else 0x734F46E5), RoundedCornerShape(14.dp)) else Modifier)
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(listOf(c.primary, c.primaryDark)))
                .then(if (ready && dragging) Modifier.border(3.dp, Color(0x59FFFFFF), RoundedCornerShape(14.dp)) else Modifier)
                .pointerInput(Unit) {
                    var last = 0L
                    var v = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { if (!busy) { dragging = true; v = 0f; last = 0L } },
                        onHorizontalDrag = { ch, amt ->
                            if (!busy) {
                                dx += amt
                                val dt = (ch.uptimeMillis - ch.previousUptimeMillis).coerceAtLeast(1L)
                                v = amt / dt / density.density    // dp per ms
                                ch.consume()
                            }
                        },
                        onDragCancel = { if (!busy) { dragging = false; busy = true; scope.launch { animate(dx, 0f, animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)) { x, _ -> dx = x }; busy = false } } },
                        onDragEnd = {
                            if (!busy) {
                                val pulled = abs(dx) >= threshold || (abs(v) >= 0.6f && abs(dx) > with(density) { 30.dp.toPx() })
                                dragging = false; busy = true
                                if (pulled && AppStore.loggedIn) {
                                    val dir = if (dx >= 0) 1f else -1f
                                    scope.launch {
                                        coroutineScope {
                                            launch { delay(140); goWallet() }
                                            launch { animate(0f, 1f, animationSpec = tween(500, delayMillis = 100)) { f, _ -> flyP = f } }
                                            animate(dx, dir * with(density) { (screenW + 200).dp.toPx() }, animationSpec = tween(550, easing = CubicBezierEasing(0.5f, 0f, 0.9f, 0.4f))) { x, _ -> dx = x }
                                        }
                                        dx = 0f; flyP = 0f; busy = false
                                    }
                                } else {
                                    val needLogin = pulled && !AppStore.loggedIn
                                    scope.launch {
                                        animate(dx, 0f, animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)) { x, _ -> dx = x }
                                        busy = false
                                        if (needLogin) AppStore.checkLogin { }
                                    }
                                }
                            }
                        },
                    )
                }
                .padding(15.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                FText("Total Balance", size = rem(0.7), weight = FontWeight.Medium, color = Color.White.copy(alpha = 0.8f))
                FText("₹ " + String.format(Locale.US, "%.2f", AppStore.balance * cu), size = rem(1.4), weight = FontWeight.ExtraBold, color = Color.White)
            }
            Row(
                Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0x33FFFFFF)).tap { goWallet() }.padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically,
            ) {
                FText("Go to Wallet", size = rem(0.75), weight = FontWeight.SemiBold, color = Color.White)
                FaIcon("fa-solid fa-arrow-right", rem(0.75).value.dp, Color.White)
            }
        }
    }
}

// --------------------------------------------------------------------------------------------- menu

@Composable
private fun DrawerMenu() {
    val c = FF.c
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    Column(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 30.dp + navInset)) {
        DmGroup("Shortcuts") {
            DmItem("fa-regular fa-calendar", "My Matches", c.primary) {
                closeDrawer(); AppStore.checkLogin { AppStore.matchesTab = "join"; AppStore.goto(Page.MATCHES) }
            }
            DmItem("fa-solid fa-clock-rotate-left", "Match History", c.primary) {
                closeDrawer(); AppStore.checkLogin { AppStore.matchesTab = "history"; AppStore.goto(Page.MATCHES) }
            }
        }
        DmGroup("Support & Settings") {
            DmItem("fa-solid fa-gift", "Refer & Earn", Brand.pink, badge = "NEW") { closeDrawer(); AppStore.checkLogin { AppStore.openModal("modal-refer") } }
            DarkModeItem()
            DmItem("fa-solid fa-volume-high", "Sound", c.textMuted) { closeDrawer(); AppStore.openModal("modal-sound") }
            DmItem("fa-solid fa-shield-halved", "Security & Payment", c.textMuted) { closeDrawer(); AppStore.checkLogin { AppStore.openModal("modal-settings") } }
            DmItem("fa-solid fa-receipt", "Proofs", c.textMuted) { closeDrawer(); AppStore.openProof() }
            DmItem("fa-brands fa-whatsapp", "WhatsApp Support", c.success) { AppStore.openWhatsApp() }
            DmItem("fa-brands fa-telegram", "Telegram Community", c.primary) { AppStore.openTelegram() }
            DmItem("fa-solid fa-globe", "Website  ·  ffcashbattle.in", c.textMuted) { AppStore.openUrl(Cfg.SITE) }
            DmItem("fa-solid fa-scroll", "Match Rules", c.textMuted) { AppStore.openModal("modal-rules") }
        }
        if (AppStore.loggedIn) {
            DmGroup("Account") {
                DmItem("fa-solid fa-right-from-bracket", "Logout", c.danger, danger = true) { closeDrawer(); AppStore.openModal("modal-logout") }
            }
        }
    }
}

@Composable
private fun DmGroup(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
        FText(title.uppercase(), size = rem(0.7), weight = FontWeight.Bold, color = FF.c.textMuted, letterSpacing = 0.5.sp, modifier = Modifier.padding(bottom = 8.dp))
        content()
    }
}

@Composable
private fun DmItem(icon: String, label: String, iconTint: Color, danger: Boolean = false, badge: String? = null, trailing: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    val c = FF.c
    var pressed by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (pressed) 0.98f else 1f, tween(120), label = "dm")
    Row(
        Modifier.fillMaxWidth()
            .graphicsLayer { scaleX = s; scaleY = s }
            .clip(RoundedCornerShape(10.dp)).background(if (pressed) c.bgInput else Color.Transparent)
            .pointerInput(onClick) { detectTapGestures(onPress = { pressed = true; tryAwaitRelease(); pressed = false }, onTap = { onClick() }) }
            .padding(horizontal = 10.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(15.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(25.dp), contentAlignment = Alignment.Center) { FaIcon(icon, rem(1.1).value.dp, iconTint) }
        FText(label, weight = FontWeight.Medium, color = if (danger) c.danger else c.textMain, modifier = if (badge != null || trailing != null) Modifier else Modifier.weight(1f))
        if (badge != null) {
            Spacer(Modifier.weight(1f))
            Box(Modifier.clip(RoundedCornerShape(99.dp)).background(Brush.horizontalGradient(listOf(Color(0xFFF43F5E), Color(0xFFF59E0B)))).padding(horizontal = 8.dp, vertical = 2.dp)) {
                FText(badge, size = rem(0.6), weight = FontWeight.Black, color = Color.White, letterSpacing = 0.4.sp)
            }
        }
        trailing?.invoke()
    }
}

/** Dark Mode row: moon/sun icon swap + the sky-to-night toggle track (50x26). */
@Composable
private fun DarkModeItem() {
    val c = FF.c
    val dark = AppStore.dark
    val t by animateFloatAsState(if (dark) 1f else 0f, tween(500), label = "theme")
    val dot by animateDpAsState(if (dark) 27.dp else 3.dp, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow), label = "dot")
    var pressed by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(10.dp)).background(if (pressed) c.bgInput else Color.Transparent)
            .pointerInput(Unit) { detectTapGestures(onPress = { pressed = true; tryAwaitRelease(); pressed = false }, onTap = { AppStore.toggleDark() }) }
            .padding(horizontal = 10.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(15.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        // .theme-ico : moon (#6366f1) in light mode, sun (#f59e0b / #fbbf24) in dark mode, swapped with a spin
        Box(Modifier.size(25.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.graphicsLayer { alpha = 1f - t; rotationZ = 120f * t; val s = 1f - 0.8f * t; scaleX = s; scaleY = s }) {
                FaIcon("fa-solid fa-moon", rem(1.1).value.dp, Color(0xFF6366F1))
            }
            Box(Modifier.graphicsLayer { alpha = t; rotationZ = -120f * (1f - t); val s = 0.2f + 0.8f * t; scaleX = s; scaleY = s }) {
                FaIcon("fa-solid fa-sun", rem(1.1).value.dp, if (dark) Color(0xFFFBBF24) else Color(0xFFF59E0B))
            }
        }
        FText("Dark Mode", weight = FontWeight.Medium, modifier = Modifier.weight(1f))
        // .theme-track 50x26 : sky gradient -> night (#1e1b4b + stars); sun dot -> moon dot
        val shape = RoundedCornerShape(13.dp)
        Box(
            Modifier.size(width = 50.dp, height = 26.dp).clip(shape)
                .background(Brush.linearGradient(listOf(Color(0xFF7DD3FC), Color(0xFF38BDF8))))
                .drawBehind {
                    drawRect(Brush.linearGradient(listOf(Color(0xFF1E1B4B), Color(0xFF4338CA))), alpha = t)
                    val star = Color.White
                    drawCircle(star.copy(alpha = t), 1.dp.toPx(), Offset(13.dp.toPx(), 8.dp.toPx()))
                    drawCircle(star.copy(alpha = 0.7f * t), 1.dp.toPx(), Offset(21.dp.toPx(), 14.dp.toPx()))
                    drawCircle(star.copy(alpha = 0.8f * t), 1.dp.toPx(), Offset(16.dp.toPx(), 19.dp.toPx()))
                    drawCircle(star.copy(alpha = 0.7f * t), 1.dp.toPx(), Offset(27.dp.toPx(), 9.dp.toPx()))
                },
        ) {
            Box(
                Modifier.offset(x = dot, y = 3.dp).graphicsLayer { rotationZ = 360f * t }.size(20.dp)
                    .boxShadow(10.dp, if (dark) Color(0x59E2E8F0) else Color(0xB3FBBF24), CircleShape)
                    .clip(CircleShape)
                    .background(if (dark) Brush.linearGradient(listOf(Color(0xFFE2E8F0), Color(0xFFCBD5E1))) else Brush.radialGradient(listOf(Color(0xFFFEF08A), Color(0xFFFBBF24)))),
            ) {
                if (dark) Box(Modifier.align(Alignment.BottomEnd).padding(end = 3.dp, bottom = 3.dp).size(7.dp).clip(CircleShape).background(Color(0xFF94A3B8).copy(alpha = 0.55f)))
            }
        }
    }
}
