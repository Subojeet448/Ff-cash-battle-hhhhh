package com.ffcashbattle.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.Chat
import com.ffcashbattle.app.data.ChatKeep
import com.ffcashbattle.app.data.ChatSheet
import com.ffcashbattle.app.data.ChatThread
import com.ffcashbattle.app.data.ChatUi
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.screens.chat.ChatEmpty
import com.ffcashbattle.app.ui.screens.chat.ChatGamePane
import com.ffcashbattle.app.ui.screens.chat.ChatListPane
import com.ffcashbattle.app.ui.screens.chat.ChatProfilePane
import com.ffcashbattle.app.ui.screens.chat.ChatSearchPane
import com.ffcashbattle.app.ui.screens.chat.ChatSheetHost
import com.ffcashbattle.app.ui.screens.chat.ChatThreadScreen
import com.ffcashbattle.app.ui.screens.chat.CsBtn
import com.ffcashbattle.app.ui.screens.chat.CxRed
import com.ffcashbattle.app.ui.screens.chat.LoadingDots
import com.ffcashbattle.app.ui.screens.chat.cxBarBrush
import com.ffcashbattle.app.ui.screens.chat.cxFabBrush
import com.ffcashbattle.app.ui.screens.chat.easeOutBack
import com.ffcashbattle.app.ui.screens.chat.easeOutExpo
import com.ffcashbattle.app.ui.screens.chat.rememberBounce
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem

private val TABS = listOf("chat", "profile", "game", "search")

/** Full-screen chat app (the website's `#chat-app`): bar, four tabs, conversation and sheets. Shown while AppStore.chatOpen. */
@Composable
fun ChatAppOverlay() {
    AnimatedVisibility(
        AppStore.chatOpen,
        enter = slideInVertically(tween(500, easing = easeOutExpo)) { it / 2 } + fadeIn(tween(350)),
        exit = slideOutVertically(tween(300)) { it / 2 } + fadeOut(tween(250)),
    ) {
        ChatAppContent()
    }
}

@Composable
private fun ChatAppContent() {
    val c = FF.c
    BackHandler(true) {
        when {
            ChatUi.sheet != null -> ChatUi.closeSheet()
            ChatUi.emojiOpen -> ChatUi.emojiOpen = false
            ChatUi.menuOpen -> ChatUi.menuOpen = false
            Chat.thread != null -> Chat.closeThread()
            else -> ChatKeep.closeApp()
        }
    }
    var lastTh by remember { mutableStateOf<ChatThread?>(null) }
    val th = Chat.thread
    if (th != null) lastTh = th

    Box(Modifier.fillMaxSize().background(c.bgBody).tap { }) {
        Column(Modifier.fillMaxSize()) {
            AppBar()
            Box(Modifier.weight(1f).fillMaxWidth()) {
                Panes()
                if (Chat.tab == "game" && Chat.me != null) Fab(Modifier.align(Alignment.BottomStart))
            }
            TabsBar()
        }
        AnimatedVisibility(
            th != null,
            enter = slideInHorizontally(tween(380, easing = easeOutExpo)) { it } + fadeIn(tween(200)),
            exit = slideOutHorizontally(tween(300)) { it } + fadeOut(tween(250)),
        ) {
            val show = th ?: lastTh
            if (show != null) ChatThreadScreen(show)
        }
        ChatSheetHost()
    }
}

// ---------------------------------------------------------------- bar
@Composable
private fun AppBar() {
    val (ty, rot) = rememberBounce(2600, 4f)
    Row(
        Modifier.fillMaxWidth().boxShadow(24.dp, Color(0xCC4F46E5), RoundedCornerShape(0.dp)).background(cxBarBrush()).statusBarsPadding().padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(42.dp).press(0.86f) { ChatKeep.closeApp() }.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
            FaIcon("fa-solid fa-arrow-left", rem(1.05).value.dp, Color.White)
        }
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
            FText(Chat.world.emoji, Modifier.graphicsLayer { translationY = ty.dp.toPx(); rotationZ = rot }, size = rem(1.4))
            FText(Chat.world.name, Modifier.weight(1f, fill = false), size = rem(1.1), weight = FontWeight.Black, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (Chat.me != null) Box(Modifier.size(42.dp).press(0.85f) { ChatUi.show(ChatSheet.Saved()) }.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
            FaIcon("fa-solid fa-bookmark", rem(1.0).value.dp, Color.White)
        }
    }
}

// ---------------------------------------------------------------- panes
@Composable
private fun Panes() {
    AnimatedContent(
        targetState = Chat.tab,
        transitionSpec = {
            val dir = if (TABS.indexOf(targetState) > TABS.indexOf(initialState)) 1 else -1
            (fadeIn(tween(300)) + slideInHorizontally(tween(380, easing = easeOutExpo)) { dir * 34 }) togetherWith (fadeOut(tween(150)) + slideOutHorizontally(tween(300)) { -dir * 34 })
        },
        label = "chatTab",
    ) { tab ->
        Box(Modifier.fillMaxSize()) {
            when {
                tab == "game" -> ChatGamePane()
                ChatKeep.openError != null && Chat.me == null -> ChatEmpty("fa-solid fa-plug-circle-xmark", "Chat could not start", ChatKeep.openError) {
                    CsBtn("Go back", { ChatKeep.closeApp() }, Modifier.width(160.dp))
                }
                Chat.me == null && !Chat.ready -> LoadingDots(Modifier.padding(top = 60.dp))
                Chat.me == null -> ChatEmpty("fa-solid fa-at", "Pick a username to start", null) {
                    CsBtn("Choose username", { ChatUi.show(ChatSheet.Onboard()) }, Modifier.width(200.dp))
                }
                tab == "chat" -> ChatListPane()
                tab == "profile" -> ChatProfilePane()
                else -> ChatSearchPane()
            }
        }
    }
}

// ---------------------------------------------------------------- FAB (Game tab -> World chat)
@Composable
private fun Fab(modifier: Modifier) {
    val pop = remember { Animatable(0f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, tween(500, easing = easeOutBack)) }
    val inf = rememberInfiniteTransition(label = "fab")
    val p by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2400)), label = "ring")
    Box(modifier.padding(start = 18.dp, bottom = 20.dp)) {
        Box(Modifier.size(58.dp).graphicsLayer { val s = 1f + 0.28f * p; scaleX = s; scaleY = s; alpha = 0.5f * (1f - p) }.clip(CircleShape).background(Color(0xFF6366F1)))
        Box(
            Modifier.size(58.dp).graphicsLayer { scaleX = pop.value; scaleY = pop.value; rotationZ = (1f - pop.value) * -90f }
                .press(0.88f) { Chat.openThread("world", "world") }.boxShadow(28.dp, Color(0xCC6366F1), CircleShape).clip(CircleShape).background(cxFabBrush()),
            contentAlignment = Alignment.Center,
        ) { FaIcon("fa-solid fa-comment-dots", rem(1.4).value.dp, Color.White) }
    }
}

// ---------------------------------------------------------------- tab bar
@Composable
private fun TabsBar() {
    val c = FF.c
    val defs = listOf(Triple("chat", "fa-solid fa-comments", "Chat"), Triple("profile", "fa-solid fa-user", "Profile"), Triple("game", "fa-solid fa-gamepad", "Game"), Triple("search", "fa-solid fa-magnifying-glass", "Search"))
    val unread = ChatKeep.unreadMsgs(); val req = Chat.incoming.size
    val idx = TABS.indexOf(Chat.tab).coerceAtLeast(0)
    Column(Modifier.fillMaxWidth().boxShadow(30.dp, Color(0x40000000), RoundedCornerShape(0.dp)).background(c.bgCard).drawBehind { drawRect(c.border, size = Size(size.width, 1.dp.toPx())) }.navigationBarsPadding().padding(start = 6.dp, end = 6.dp, top = 6.dp, bottom = 8.dp)) {
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val w = maxWidth / 4
            val x by androidx.compose.animation.core.animateDpAsState(w * idx, androidx.compose.animation.core.spring(dampingRatio = 0.7f, stiffness = 300f), label = "tabInd")
            Box(Modifier.offset(x = x).width(w).height(54.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Color(0x246366F1), Color(0x1FEC4899)))))
            Row(Modifier.fillMaxWidth()) {
                defs.forEach { (k, icon, label) ->
                    val on = Chat.tab == k
                    val lift by androidx.compose.animation.core.animateFloatAsState(if (on) 1f else 0f, tween(350, easing = easeOutBack), label = "lift")
                    Box(Modifier.weight(1f).height(54.dp).press(0.92f) { Chat.tab = k }, contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            FaIcon(icon, rem(1.15).value.dp, if (on) c.primary else c.textMuted, Modifier.graphicsLayer { translationY = -3.dp.toPx() * lift; val s = 1f + 0.15f * lift; scaleX = s; scaleY = s })
                            FText(label, size = rem(0.68), weight = FontWeight.ExtraBold, color = if (on) c.primary else c.textMuted)
                        }
                        val n = if (k == "chat") unread else if (k == "profile") req else 0
                        if (n > 0) Box(Modifier.align(Alignment.TopCenter).offset(x = 14.dp, y = 2.dp).widthInMin().height(17.dp).clip(RoundedCornerShape(20.dp)).background(CxRed).padding(horizontal = 4.dp), contentAlignment = Alignment.Center) {
                            FText(if (n > 99) "99+" else n.toString(), size = rem(0.62), weight = FontWeight.Black, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

private fun Modifier.widthInMin(): Modifier = this.then(Modifier.defaultMinSize(minWidth = 17.dp))
