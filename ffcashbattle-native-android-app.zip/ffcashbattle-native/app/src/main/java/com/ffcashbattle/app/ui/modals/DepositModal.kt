package com.ffcashbattle.app.ui.modals

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ffcashbattle.app.data.Deposit
import com.ffcashbattle.app.data.Msg
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FRich
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.InputBox
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.SpinIcon
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.screens.FaqChip
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.launch

/** Website `#modal-deposit` — "Add Money": pay by UPI, then verify with the UTR or Transaction ID. */
@Composable
fun DepositModal() {
    val c = FF.c
    val scope = rememberCoroutineScope()
    var amount by remember { mutableStateOf("") }
    var utr by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val off = AppStore.flagOff("dep")
    val upi = AppStore.config.s("upi").ifEmpty { "Loading..." }
    val qr = AppStore.config.s("qrUrl")

    LaunchedEffect(Unit) { AppStore.refreshFlags() }

    ModalSheet {
        val close = LocalSheetClose.current
        Row(Modifier.fillMaxWidth().padding(bottom = 15.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            FText("Add Money", size = rem(1.5), weight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                FaqChip("deposit")
                Box(Modifier.press(0.9f) { close() }) { FaIcon("fa-solid fa-xmark", rem(1.5).value.dp, c.textMuted) }
            }
        }

        if (off) { OffBox("Deposit Disabled", AppStore.flagMsg("dep")); return@ModalSheet }

        if (qr.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().padding(bottom = 15.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                AsyncImage(qr, "Payment QR code", Modifier.size(160.dp).clip(RoundedCornerShape(12.dp)).border(2.dp, c.border, RoundedCornerShape(12.dp)), contentScale = ContentScale.Fit)
                FText("Scan to Pay", size = rem(0.75), color = c.textMuted, modifier = Modifier.padding(top = 5.dp))
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.Top) {
            FaIcon("fa-solid fa-circle-info", rem(0.8).value.dp, c.textMuted, Modifier.padding(top = 2.dp))
            FRich("Send money via UPI, then enter the amount and your [UTR] or [Transaction ID]. Either one works.", Modifier.weight(1f), size = rem(0.8), color = c.textMuted, lineHeight = rem(0.8) * 1.5f)
        }
        // .pay-copy-box
        val boxShape = RoundedCornerShape(12.dp)
        Row(
            Modifier.fillMaxWidth().padding(bottom = 15.dp).clip(boxShape).background(c.bgCard)
                .drawBehind { drawRoundRect(c.primary, topLeft = Offset(0.5.dp.toPx(), 0.5.dp.toPx()), size = Size(size.width - 1.dp.toPx(), size.height - 1.dp.toPx()), cornerRadius = CornerRadius(12.dp.toPx()), style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 3.dp.toPx())))) }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                FText("UPI ID", size = rem(0.7), color = c.textMuted, letterSpacing = 0.sp)
                FText(upi, size = rem(1.0), weight = FontWeight.ExtraBold, mono = true, letterSpacing = 1.sp)
            }
            Row(
                Modifier.padding(start = 8.dp).press(0.92f) { AppStore.copy(upi) }.clip(RoundedCornerShape(8.dp)).background(c.bgInput).padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically,
            ) {
                FaIcon("fa-regular fa-copy", rem(0.95).value.dp, c.primary)
                FText("Copy", weight = FontWeight.Bold, color = c.primary)
            }
        }

        InputBox(
            amount, { v -> amount = cleanAmount(v) }, Modifier.fillMaxWidth(), placeholder = "Amount Sent (Min ₹${AppStore.minDep()})",
            keyboardType = KeyboardType.Decimal,
        )
        // .ref-field
        val ref = Deposit.extractRef(utr)
        val has = utr.isNotBlank()
        Column(Modifier.fillMaxWidth().padding(top = 5.dp)) {
            Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                FaIcon("fa-solid fa-hashtag", rem(0.78).value.dp, c.textMuted)
                FText("UTR", size = rem(0.78), weight = FontWeight.ExtraBold, color = c.textMuted, letterSpacing = 0.4.sp)
                FText("or", size = rem(0.78), weight = FontWeight.SemiBold, color = c.textMuted.copy(alpha = 0.7f))
                FText("TRANSACTION ID", size = rem(0.78), weight = FontWeight.ExtraBold, color = c.textMuted, letterSpacing = 0.4.sp)
            }
            InputBox(
                utr, { utr = it.take(40) }, Modifier.fillMaxWidth(), placeholder = "e.g. 412345678901 or FMPIB6862334894",
                accent = if (has && ref.isNotEmpty()) Color(0xFF10B981) else if (has) Color(0xFFF59E0B) else null,
                mono = true, letterSpacing = 1.sp, capitalize = true,
            )
            RefDetect(has, ref)
        }

        BtnMain(
            onClick = {
                if (busy) return@BtnMain
                if (AppStore.flagOff("dep")) { AppStore.toast(AppStore.flagMsg("dep")); return@BtnMain }
                val amt = amount.toDoubleOrNull()
                val r = Deposit.extractRef(utr)
                if (amt == null || amt == 0.0 || amt.isNaN()) { AppStore.toast(Msg.deposit.enterAmount()); return@BtnMain }
                if (amt < AppStore.minDep()) { AppStore.toast(Msg.deposit.minAmount()); return@BtnMain }
                if (r.isEmpty()) { AppStore.toast(Msg.deposit.badUtr()); return@BtnMain }
                if (!AppStore.rateLimit("deposit_$r", 15_000L)) return@BtnMain
                busy = true
                scope.launch {
                    val ok = try { Deposit.submit(amt, r) } finally { busy = false }
                    if (ok) { amount = ""; utr = ""; close() }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 15.dp),
            enabled = !busy,
        ) {
            if (busy) SpinIcon(rem(1.0).value.dp, Color(0xFF94A3B8)) else FaIcon("fa-solid fa-shield-check", rem(1.0).value.dp, Color.White)
            Spacer(Modifier.width(6.dp))
            FText("Verify & Submit", weight = FontWeight.Bold, color = if (busy) Color(0xFF94A3B8) else Color.White)
        }
    }
}

/** `<input type=number min=0>` — digits and a single decimal point only. */
internal fun cleanAmount(v: String): String {
    var dot = false
    val sb = StringBuilder()
    for (ch in v) {
        if (ch.isDigit()) sb.append(ch) else if (ch == '.' && !dot) { dot = true; sb.append(ch) }
    }
    return sb.toString().take(10)
}

/** `.ref-detect`: grey hint -> amber warning -> green "UTR / Transaction ID detected". */
@Composable
private fun RefDetect(has: Boolean, ref: String) {
    val kind = Deposit.refKind(ref)
    val ok = has && ref.isNotEmpty()
    val warn = has && ref.isEmpty()
    val pop = remember(ok, ref) { Animatable(if (ok) 0f else 1f) }
    LaunchedEffect(ok, ref) { if (ok) pop.animateTo(1f, tween(350, easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f))) }
    val bg = if (ok) Color(0xFFDCFCE7) else if (warn) Color(0xFFFEF3C7) else Color(0xFFF1F5F9)
    val fg = if (ok) Color(0xFF15803D) else if (warn) Color(0xFF92400E) else FF.c.textMuted
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp)
            .graphicsLayer { val k = pop.value; val s = 0.94f + 0.06f * k; scaleX = s; scaleY = s; alpha = 0.5f + 0.5f * k }
            .clip(RoundedCornerShape(10.dp)).background(bg).padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        FaIcon(if (ok) "fa-solid fa-circle-check" else if (warn) "fa-solid fa-triangle-exclamation" else "fa-regular fa-circle", rem(0.78).value.dp, fg)
        if (ok) FRich((if (kind == "utr") "UTR detected — " else if (kind == "txn") "Transaction ID detected — " else "Reference detected — ") + "[$ref]", Modifier.weight(1f), size = rem(0.78), color = fg)
        else FText(if (warn) "Keep typing — UTR / Transaction ID is at least 8 characters" else "Paste your UTR or the Transaction ID from your payment app", size = rem(0.78), color = fg, modifier = Modifier.weight(1f))
    }
}

/** `.wd-off-box`: "Deposit Disabled" / "Withdrawals Disabled" note set by the admin. */
@Composable
internal fun OffBox(title: String, msg: String) {
    val c = FF.c
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.fillMaxWidth().padding(bottom = 6.dp).clip(shape).background(c.bgInput)
            .drawBehind { drawRoundRect(c.danger, topLeft = Offset(0.75.dp.toPx(), 0.75.dp.toPx()), size = Size(size.width - 1.5.dp.toPx(), size.height - 1.5.dp.toPx()), cornerRadius = CornerRadius(16.dp.toPx()), style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 4.dp.toPx())))) }
            .padding(horizontal = 16.dp, vertical = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        FaIcon("fa-solid fa-ban", rem(2.0).value.dp, c.danger, Modifier.padding(bottom = 8.dp))
        FText(title, size = rem(1.0), weight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
        FText(msg, size = rem(0.88), color = c.textMuted, lineHeight = rem(0.88) * 1.55f, align = TextAlign.Center)
    }
}
