package com.ffcashbattle.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import com.ffcashbattle.app.state.AppStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/** Server settings of the program (`d.cfg` of /api/ref/info). Every number shown to the user comes from here. */
class RefCfg(
    val enabled: Boolean, val creditTo: String, val depositRequired: Double, val referralsPerCard: Int, val claimWindowHrs: Int,
    val amountMode: String, val maxAmount: Double,
)

class RefCard(val id: String, val status: String, val src: String, val amount: Double, val at: Long, val min: Double, val max: Double, val mult: Double, val to: String)
class RefFriend(val name: String, val status: String)

class RefInfo(
    val code: String, val link: String, val cfg: RefCfg,
    val joined: Int, val qualified: Int, val cardCount: Int, val earned: Double, val fresh: Int,
    val per: Int, val have: Int, val toNext: Int,
    val cards: List<RefCard>, val friends: List<RefFriend>, val referredByCode: String?, val referredByName: String, val canClaim: Boolean,
)

/** Result of /api/ref/claim. */
class ClaimRes(val ok: Boolean, val error: String, val qualified: Boolean)

/**
 * Refer & Earn — app side of pages/refer/refer.js. All money and rules run on the server (the /api/ref endpoints);
 * the app only shows the page and the scratch card. The amount of a card is decided by the SERVER when scratching starts.
 */
object Refer {
    var info by mutableStateOf<RefInfo?>(null)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    private var claiming = false

    // ------------------------------------------------------------------ formatting
    /** `'₹' + n.toLocaleString('en-IN', { maximumFractionDigits: 2 })`. */
    fun money(v: Double): String = "₹" + groupIndian(v)

    fun groupIndian(v: Double): String {
        val neg = v < 0
        val s = DecimalFormat("0.##", DecimalFormatSymbols(Locale.US)).format(Math.abs(v))
        val ip = s.substringBefore('.'); val fp = if (s.contains('.')) "." + s.substringAfter('.') else ""
        val g = if (ip.length <= 3) ip else {
            val head = ip.dropLast(3); val tail = ip.takeLast(3)
            head.reversed().chunked(2).joinToString(",").reversed() + "," + tail
        }
        return (if (neg) "-" else "") + g + fp
    }

    // ------------------------------------------------------------------ server
    suspend fun api(path: String, body: JSONObject = JSONObject(), timeoutMs: Int = 30000): JSONObject {
        val base = Cfg.GAME_SERVER.trim().trimEnd('/')
        if (base.isEmpty()) throw Exception("Server is not set up yet")
        val u = Repo.auth.currentUser ?: throw Exception("Please log in first")
        val tok = u.getIdToken(false).await().token ?: throw Exception("Please log in first")
        return withContext(Dispatchers.IO) {
            val conn = URL("$base/api/ref/$path").openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = timeoutMs; conn.readTimeout = timeoutMs
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("Authorization", "Bearer $tok")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                val j = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
                if (code !in 200..299 && !j.has("error")) throw Exception("Server error $code")
                j
            } catch (e: SocketTimeoutException) {
                throw Exception("Server is waking up — try again in a minute")
            } catch (e: IOException) {
                throw Exception("Cannot reach the server")
            } finally { conn.disconnect() }
        }
    }

    private fun parse(r: JSONObject): RefInfo {
        val c = r.optJSONObject("cfg") ?: JSONObject()
        val st = r.optJSONObject("stats") ?: JSONObject()
        val pr = r.optJSONObject("progress") ?: JSONObject()
        val cfg = RefCfg(
            c.optBoolean("enabled", true), c.optString("creditTo", "deposit"), c.optDouble("depositRequired", 0.0).let { if (it.isNaN()) 0.0 else it },
            c.optInt("referralsPerCard", 1).coerceAtLeast(1), c.optInt("claimWindowHrs", 24), c.optString("amountMode", "fixed"),
            c.optDouble("maxAmount", 0.0).let { if (it.isNaN()) 0.0 else it },
        )
        val cards = ArrayList<RefCard>()
        r.optJSONArray("cards")?.let { a ->
            for (i in 0 until a.length()) {
                val x = a.optJSONObject(i) ?: continue
                val at = x.opt("at")
                cards.add(
                    RefCard(
                        x.optString("id"), x.optString("status"), x.optString("src", "ref"), x.optDouble("amount", 0.0).let { if (it.isNaN()) 0.0 else it },
                        when (at) { is Number -> at.toLong(); is String -> Doc.parseDate(at); else -> 0L },
                        x.optDouble("min", 0.0).let { if (it.isNaN()) 0.0 else it }, x.optDouble("max", 0.0).let { if (it.isNaN()) 0.0 else it },
                        x.optDouble("mult", 1.0).let { if (it.isNaN()) 1.0 else it }, x.optString("to", ""),
                    ),
                )
            }
        }
        val friends = ArrayList<RefFriend>()
        r.optJSONArray("friends")?.let { a ->
            for (i in 0 until a.length()) { val x = a.optJSONObject(i) ?: continue; friends.add(RefFriend(x.optString("name"), x.optString("status"))) }
        }
        val rb = r.optJSONObject("referredBy")
        return RefInfo(
            r.optString("code"), r.optString("link"), cfg,
            st.optInt("joined"), st.optInt("qualified"), st.optInt("cards"), st.optDouble("earned", 0.0).let { if (it.isNaN()) 0.0 else it }, st.optInt("fresh"),
            pr.optInt("per", cfg.referralsPerCard).coerceAtLeast(1), pr.optInt("have"), pr.optInt("toNext", cfg.referralsPerCard),
            cards, friends, rb?.optString("code"), rb?.optString("name").orEmpty(), r.optBoolean("canClaim"),
        )
    }

    /** `load(spin)`: shows the loading state when [spin], otherwise refreshes quietly. */
    suspend fun load(spin: Boolean) {
        if (spin) { loading = true; error = null }
        try {
            val r = api("info")
            if (!r.optBoolean("ok")) throw Exception(r.optString("error").ifEmpty { "Could not load" })
            info = parse(r); error = null
        } catch (e: Exception) {
            if (info == null) error = e.message ?: "Could not load" else AppStore.toast(e.message ?: "Could not load")
        } finally { loading = false }
    }

    /** Starts scratching: the server picks the amount and credits it right away. Throws with the server's message on failure. */
    suspend fun scratch(cardId: String): Double {
        val r = api("scratch", JSONObject().put("card", cardId))
        if (!r.optBoolean("ok")) throw Exception(r.optString("error").ifEmpty { "Could not open this card" })
        return r.optDouble("amount", 0.0).let { if (it.isNaN()) 0.0 else it }
    }

    suspend fun claim(code: String, timeoutMs: Int = 30000): ClaimRes = try {
        val r = api("claim", JSONObject().put("code", code), timeoutMs)
        ClaimRes(r.optBoolean("ok"), r.optString("error"), r.optBoolean("qualified"))
    } catch (e: Exception) { ClaimRes(false, e.message ?: "Could not apply the code", false) }

    private val FINAL = Regex("already used|own code|Invalid referral|cannot be used|hours of joining|reached its limit", RegexOption.IGNORE_CASE)
    fun isFinal(r: ClaimRes) = !r.ok && FINAL.containsMatchIn(r.error)

    // ------------------------------------------------------------------ share
    fun shareText(code: String) = "Join me on FF Cash Battle! Sign up with my referral code $code and play Free Fire tournaments & mini games."

    // ------------------------------------------------------------------ wiring
    /** Sign-up claims the code via [AuthFlow.referClaim]; a code left from an invite link (`ffcb_ref`) is retried 6 s after every login. */
    fun install() {
        AuthFlow.referClaim = { code -> val r = claim(code, 45000); r.ok || isFinal(r) }
        Faq.register("refer") { info?.let { faqList(it.cfg) } ?: emptyList() }
        AppStore.scope.launch {
            snapshotFlow { AppStore.uid }.collectLatest { uid ->
                if (uid == null) return@collectLatest
                delay(6000)
                val rc = Prefs.str("ffcb_ref")
                if (rc.isEmpty() || claiming) return@collectLatest
                claiming = true
                try { val r = claim(rc, 45000); if (r.ok || isFinal(r)) Prefs.remove("ffcb_ref") } catch (_: Exception) { } finally { claiming = false }
            }
        }
    }

    // ------------------------------------------------------------------ text helpers (numbers come from the server config)
    fun walletTxt(c: RefCfg) = if (c.creditTo == "withdraw") "Withdrawable balance" else "Deposit balance"
    fun condTxt(c: RefCfg) = if (c.depositRequired > 0) "joins with your code and adds ${money(c.depositRequired)} or more" else "joins with your code"
    fun perTxt(c: RefCfg) = if (c.referralsPerCard > 1) "every ${c.referralsPerCard} friends who ${condTxt(c)}" else "every friend who ${condTxt(c)}"

    /** The FAQ of the Refer page: (question, answer with [bold] markup). */
    fun faqList(c: RefCfg): List<Pair<String, String>> = listOf(
        "What is Refer & Earn?" to "Invite your friends to FF Cash Battle with your personal code. When ${perTxt(c)} [you win a Scratch Card] with real money inside.",
        "How do I invite a friend?" to "Tap [WhatsApp] or [Share] on this page to send your invite link, or just tell them your [Referral Code] (it is your Player ID). Your friend signs up through the link, or types your code in the Referral Code box while creating the account.",
        "When do I get a Scratch Card?" to if (c.depositRequired > 0)
            "A friend counts as [qualified] when they join with your code [and] their total deposit reaches ${money(c.depositRequired)}. ${if (c.referralsPerCard > 1) "You get 1 Scratch Card for every ${c.referralsPerCard} qualified friends." else "You get 1 Scratch Card for every qualified friend."} The card appears here automatically, usually within a couple of minutes after your friend's deposit is credited."
        else "A friend counts as qualified the moment they join with your code. ${if (c.referralsPerCard > 1) "You get 1 Scratch Card for every ${c.referralsPerCard} friends." else "You get 1 Scratch Card for every friend."}",
        "How much can I win?" to "Every Scratch Card holds real wallet money. It is a surprise — nobody knows the amount in advance, not even us. It is picked at the moment you start scratching.",
        "Where does the money go?" to "The reward is added instantly to your [${walletTxt(c)}]. ${if (c.creditTo == "withdraw") "You can use it to play or withdraw it, just like match winnings." else "Use it to join matches. Money you win in matches from it can be withdrawn as usual."} You will also see it in your wallet history as “Referral Scratch Card”.",
        "Why does my friend show “Waiting for deposit”?" to if (c.depositRequired > 0)
            "Your friend has joined, but their total deposit is still below ${money(c.depositRequired)}. As soon as it reaches the amount, the referral turns [Qualified] and your card is issued."
        else "This only appears when deposits are needed. Right now friends qualify as soon as they join.",
        "My friend forgot to enter my code. Can they add it later?" to "Yes — in [Refer & Earn → “Have a referral code?”] within [${c.claimWindowHrs} hours] of creating the account. A code can be used [only once] per account and cannot be changed afterwards.",
        "I closed the app while scratching. Did I lose my reward?" to "No. The reward is added to your wallet the moment you start scratching. Open [Refer & Earn] again — the card now shows the amount you won.",
        "Is there a limit on referrals or cards?" to "The program can have limits (for example a maximum number of friends per user). If you reach one, you will see a message when your friend tries to use your code.",
        "Do Scratch Cards expire?" to "Cards do not expire on their own. FF Cash Battle may change or stop the Refer & Earn program at any time; unscratched cards follow the rules that are active when you scratch them.",
        "Which friends count?" to "Only [genuine new users] who join using your code. Using your own code, creating extra or fake accounts, or any kind of abuse is not allowed — such referrals are cancelled, unscratched cards are removed and the account may be restricted.",
        "I can’t see my reward / card. What should I do?" to "Pull down the list by reopening this page. If your friend has deposited but the status is still “Waiting”, wait a few minutes. Still stuck? Contact support from the menu and share your [Player ID] and your friend’s name.",
        "Is Refer & Earn available in every state?" to "Rewards follow our Terms of Service. Users from restricted states can only take part in free-to-play activities.",
        "Is it really free to refer?" to "Yes. Sharing your code costs nothing and your friend does not pay anything extra to join with it.",
    )
}
