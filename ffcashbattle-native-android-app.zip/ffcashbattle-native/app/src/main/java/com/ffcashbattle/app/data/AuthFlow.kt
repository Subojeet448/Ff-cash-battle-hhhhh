package com.ffcashbattle.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.ffcashbattle.app.BuildConfig
import com.ffcashbattle.app.state.AppStore
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.ActionCodeSettings
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONObject

/** Result of [AuthFlow.login]. */
sealed class LoginRes {
    class Ok(val name: String) : LoginRes()
    class NeedsVerify(val sent: Boolean) : LoginRes()
    class Fail(val message: String) : LoginRes()
}

/** Result of [AuthFlow.google]. */
sealed class GoogleRes {
    class Ok(val name: String) : GoogleRes()
    object Cancelled : GoogleRes()
    class Fail(val message: String) : GoogleRes()
}

/** The "Verify your email" screen (website `#auth-verify`): state is "wait" | "ok" | "expired". */
class VerifyView(val state: String, val email: String, val deadline: Long)

/** The little welcome card that slides down after a login. */
class WelcomeInfo(val id: Long, val name: String, val title: String, val sub: String, val tag: String)

/**
 * Auth logic ported from the website (login.js / register.js / forgot.js / auth-state.js):
 *  - email/password + Google sign-in, e-mail verification (60 s window), profile creation, forgot/reset password.
 * Installs AppStore.authGate / onLogin / onLogout. Called before AppStore.start().
 */
object AuthFlow {
    /** Only email/password accounts created AFTER this date must verify (older users are not locked out). 2026-10-04T00:00:00Z */
    const val VERIFY_FROM = 1791072000000L
    private const val WINDOW_MS = 60_000L
    private const val PKEY = "pending_reg"           // { uid, name, phone, email, ref, ts } — the password is never stored
    private const val COOLDOWN = 180_000L              // forgot-password resend wait

    /** True while register() runs, so the auth listener does not treat the new (unverified) account as a leftover. */
    @Volatile var registering = false

    // ------------------------------------------------------------------ observable UI state
    var verify by mutableStateOf<VerifyView?>(null)
    var verifyLeft by mutableLongStateOf(WINDOW_MS)
    var welcome by mutableStateOf<WelcomeInfo?>(null)
    var loginPrefill by mutableStateOf("")                 // e-mail handed back to the login card ("Go to Login" after a password reset)
    var fpOpen by mutableStateOf(false)
    var fpStep by mutableStateOf("email")              // email | sent | verifying | reset | done | invalid
    var fpEmail by mutableStateOf("")
    var fpInvalidMsg by mutableStateOf("This reset link has expired or was already used. Please request a new one.")
    var fpTick by mutableLongStateOf(0L)               // bumps every second while the "sent" page counts down
    private var fpCode = ""
    private var fpFromLink = false
    private var fpTimer: Job? = null
    private var welcomeId = 0L
    private var watchJob: Job? = null

    /** Set by the Refer module: claims a friend's referral code. Returns true when it is settled (claimed or definitively rejected). */
    var referClaim: (suspend (String) -> Boolean)? = null

    fun install() {
        AppStore.authGate = { u ->
            if (needsVerify(u)) {
                // within the 60 s register window: resume / clean up the pending account (skipped while register() runs)
                if (!registering) AppStore.scope.launch { try { resumePending(u) } catch (_: Exception) { } }
                false                                   // treated as a guest until the e-mail is verified
            } else true
        }
        AppStore.onLogin = { u ->
            if (isGoogle(u) || (u.metadata?.creationTimestamp ?: 0L) >= VERIFY_FROM) ensureProfile(u)
        }
        AppStore.onLogout = { }
    }

    private fun isGoogle(u: FirebaseUser) = u.providerData.any { it.providerId == "google.com" }

    /** Email/password user who has not opened the verification link yet. */
    fun needsVerify(u: FirebaseUser?): Boolean = u != null && !u.isEmailVerified &&
        u.providerData.any { it.providerId == "password" } && (u.metadata?.creationTimestamp ?: 0L) >= VERIFY_FROM

    // ------------------------------------------------------------------ messages
    fun friendly(e: Throwable?): String {
        val code = (e as? FirebaseAuthException)?.errorCode ?: ""
        return when {
            e is FirebaseNetworkException -> "Network error. Please check your internet connection."
            e is FirebaseTooManyRequestsException || code == "ERROR_TOO_MANY_REQUESTS" -> "Too many attempts. Please wait a few minutes and try again."
            e is FirebaseAuthUserCollisionException && code == "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL" -> "This email is registered with a password. Please log in using your password."
            e is FirebaseAuthUserCollisionException || code == "ERROR_EMAIL_ALREADY_IN_USE" -> "This email is already registered. Try logging in instead."
            e is FirebaseAuthWeakPasswordException || code == "ERROR_WEAK_PASSWORD" -> "Password must be at least 6 characters long."
            code == "ERROR_INVALID_EMAIL" -> "Please enter a valid email address."
            e is FirebaseAuthInvalidUserException || e is FirebaseAuthInvalidCredentialsException ||
                code in setOf("ERROR_INVALID_CREDENTIAL", "ERROR_WRONG_PASSWORD", "ERROR_USER_NOT_FOUND") -> "Incorrect email or password. Please check and try again."
            else -> e?.message?.takeIf { it.isNotBlank() } ?: "Something went wrong"
        }
    }

    private fun userGone(e: Throwable?): Boolean {
        val code = (e as? FirebaseAuthException)?.errorCode ?: ""
        return e is FirebaseAuthInvalidUserException || code == "ERROR_USER_NOT_FOUND" || code == "ERROR_USER_TOKEN_EXPIRED" || code == "ERROR_USER_DISABLED"
    }

    // ------------------------------------------------------------------ verification mail
    /** Sends the verification mail (60 s cooldown). Returns "sent" | "wait" | "error". */
    suspend fun sendVerify(user: FirebaseUser): String {
        val key = "ev_last_" + user.uid
        if (60_000L - (System.currentTimeMillis() - Prefs.long(key)) > 0) return "wait"
        return try {
            try {
                user.sendEmailVerification(ActionCodeSettings.newBuilder().setUrl(BuildConfig.SITE_URL + "/").build()).await()
            } catch (e: Exception) {
                if (e is FirebaseAuthException || (e.message ?: "").contains("continue", true)) user.sendEmailVerification().await() else throw e
            }
            Prefs.put(key, System.currentTimeMillis()); "sent"
        } catch (e: Exception) {
            if (e is FirebaseTooManyRequestsException) "wait" else "error"
        }
    }

    // ------------------------------------------------------------------ login
    suspend fun login(email: String, pass: String): LoginRes {
        return try {
            val user = Repo.auth.signInWithEmailAndPassword(email, pass).await().user ?: return LoginRes.Fail("Something went wrong")
            if (needsVerify(user)) {
                val r = sendVerify(user)
                Repo.auth.signOut()
                return LoginRes.NeedsVerify(r == "sent")
            }
            LoginRes.Ok(Repo.auth.currentUser?.displayName?.ifBlank { null } ?: "Player")
        } catch (e: Exception) { LoginRes.Fail(friendly(e)) }
    }

    /** Google account chooser (Credential Manager) -> Firebase credential. Needs the Web client ID in BuildConfig. */
    suspend fun google(ctx: Context): GoogleRes {
        val id = BuildConfig.GOOGLE_WEB_CLIENT_ID
        if (id.isBlank()) return GoogleRes.Fail("Google sign-in is not set up in this build yet. Please log in with your email.")
        return try {
            val req = GetCredentialRequest.Builder().addCredentialOption(GetSignInWithGoogleOption.Builder(id).build()).build()
            val res = CredentialManager.create(ctx).getCredential(ctx, req)
            val cred = res.credential
            if (cred !is CustomCredential || cred.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) return GoogleRes.Fail("Google sign-in failed. Please try again.")
            val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
            val user = Repo.auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await().user
            GoogleRes.Ok(user?.displayName?.ifBlank { null } ?: "Player")
        } catch (e: GetCredentialCancellationException) { GoogleRes.Cancelled
        } catch (e: NoCredentialException) { GoogleRes.Fail("No Google account found on this phone. Add one in Settings and try again.")
        } catch (e: GetCredentialException) { GoogleRes.Fail(e.message?.takeIf { it.isNotBlank() } ?: "Google sign-in failed. Please try again.")
        } catch (e: Exception) { GoogleRes.Fail(friendly(e)) }
    }

    // ------------------------------------------------------------------ register + verify window
    private class Pending(val uid: String, val name: String, val phone: String, val email: String, val ref: String, val ts: Long) {
        fun json(): String = JSONObject().put("uid", uid).put("name", name).put("phone", phone).put("email", email).put("ref", ref).put("ts", ts).toString()
    }
    private fun readPending(): Pending? = try {
        val o = JSONObject(Prefs.str(PKEY, "null"))
        Pending(o.optString("uid"), o.optString("name"), o.optString("phone"), o.optString("email"), o.optString("ref"), o.optLong("ts"))
    } catch (e: Exception) { null }
    private fun clearPending() = Prefs.remove(PKEY)

    /** Creates the account + sends the verification mail. Returns an error text, or null when the verify screen is now showing. */
    suspend fun register(name: String, phone: String, email: String, pass: String, ref: String): String? {
        registering = true
        var created: FirebaseUser? = null
        try {
            created = Repo.auth.createUserWithEmailAndPassword(email, pass).await().user ?: return "Something went wrong"
            created.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name).build()).await()
            var info = Pending(created.uid, name, phone, email, ref.trim(), System.currentTimeMillis())
            Prefs.put(PKEY, info.json())
            val vr = sendVerify(created)
            if (vr != "sent" && vr != "wait") throw IllegalStateException("We could not send the verification email. Please check the email address and try again.")
            info = Pending(info.uid, info.name, info.phone, info.email, info.ref, System.currentTimeMillis())
            Prefs.put(PKEY, info.json())
            startWatch(created, info)
            return null
        } catch (e: Exception) {
            created?.let { try { it.delete().await() } catch (_: Exception) { }; clearPending() }
            return friendly(e)
        } finally { registering = false }
    }

    private fun setView(state: String, email: String, deadline: Long = 0L) { verify = VerifyView(state, email, deadline) }

    private fun stopWatch() { watchJob?.cancel(); watchJob = null }

    private fun startWatch(user: FirebaseUser, info: Pending) {
        stopWatch()
        val deadline = info.ts + WINDOW_MS
        setView("wait", info.email, deadline)
        watchJob = AppStore.scope.launch {
            var n = 0
            while (isActive) {
                val left = deadline - System.currentTimeMillis()
                verifyLeft = maxOf(0L, left)
                if (n++ % 2 == 0 || left <= 0) {
                    try { user.reload().await() } catch (e: Exception) {
                        if (userGone(e)) { clearPending(); watchJob = null; setView("expired", info.email); return@launch }
                    }
                    if (user.isEmailVerified) { watchJob = null; finishVerified(user, info); return@launch }
                }
                if (left <= 0) { watchJob = null; expire(user, info); return@launch }
                delay(1000)
            }
        }
    }

    private suspend fun finishVerified(user: FirebaseUser, info: Pending) {
        try { user.getIdToken(true).await() } catch (_: Exception) { }
        try { ensureProfile(user) } catch (_: Exception) { }
        try { Repo.auth.signOut() } catch (_: Exception) { }
        setView("ok", info.email)
        if (!AppStore.authOpen) AppStore.toast("Email verified! Please login.")
    }

    private suspend fun expire(user: FirebaseUser, info: Pending) {
        var gone = false
        try { user.delete().await(); gone = true } catch (e: Exception) { if (userGone(e)) gone = true }
        if (gone) clearPending() else { try { Repo.auth.signOut() } catch (_: Exception) { } }   // a failed delete is retried on the next app open
        setView("expired", info.email)
    }

    /** When the app reopens (it was closed during the window), resume or clean up the pending account. */
    private suspend fun resumePending(user: FirebaseUser) {
        val info = readPending() ?: return
        if (info.uid != user.uid || watchJob != null) return
        try { user.reload().await() } catch (_: Exception) { }
        if (user.isEmailVerified) {
            ensureProfile(user); try { Repo.auth.signOut() } catch (_: Exception) { }
            AppStore.authTab = "login"; AppStore.authOpen = true; setView("ok", info.email); return
        }
        if (System.currentTimeMillis() >= info.ts + WINDOW_MS) {
            try { user.delete().await(); clearPending() } catch (e: Exception) { if (userGone(e)) clearPending() }
            return
        }
        AppStore.authTab = "register"; AppStore.authOpen = true; startWatch(user, info)
    }

    /** What the verify screen's button does. Returns the state it was in. */
    suspend fun verifyAction(): String {
        val st = verify?.state ?: "wait"
        if (st == "wait") {                              // cancel: the account is deleted right away
            stopWatch()
            val u = Repo.auth.currentUser
            if (u != null) { try { u.delete().await(); clearPending() } catch (_: Exception) { try { Repo.auth.signOut() } catch (_: Exception) { } } }
        }
        verify = null
        return st
    }

    /** The "login screen closed" counterpart of `_verifyReset`: forget a finished verify screen (a running countdown stays). */
    fun verifyReset() { if (watchJob == null) verify = null }

    /** The profile is created in Firestore only once the email is verified (or for Google users). */
    suspend fun ensureProfile(user: FirebaseUser): Boolean {
        try {
            val p = readPending()
            if (Repo.getDoc("users", user.uid) != null) { if (p != null && p.uid == user.uid) clearPending(); return true }
            val mine = if (p != null && p.uid == user.uid) p else null
            var playerId = ""
            var tries = 0
            while (tries < 20) {
                playerId = (1_000_000 + (Math.random() * 9_000_000).toInt()).toString()
                val dup = Repo.getCol("users") { it.whereEqualTo("playerId", playerId).limit(1) }
                if (dup.isEmpty()) break
                tries++
            }
            Repo.set(listOf("users", user.uid), mapOf(
                "appName" to (mine?.name?.ifEmpty { null } ?: user.displayName?.ifEmpty { null } ?: (user.email ?: "Player").substringBefore('@')),
                "email" to (user.email ?: ""), "phone" to (mine?.phone?.ifEmpty { null } ?: user.phoneNumber ?: ""),
                "balance" to 0, "depositBalance" to 0, "withdrawBalance" to 0, "uid" to user.uid, "playerId" to playerId,
                "joined_matches" to emptyList<String>(), "score" to 0, "kills" to 0, "matchesPlayed" to 0, "matchesWon" to 0, "totalEarned" to 0,
                "gameName" to "", "gameUid" to "", "isUidVerified" to false, "photoUrl" to (user.photoUrl?.toString() ?: ""), "nameChangesLeft" to 2,
            ))
            // referral: add the friend's code now that the profile exists (link ?ref=… or the box on the sign-up form)
            try {
                val rc = (mine?.ref?.ifEmpty { null } ?: Prefs.str("ffcb_ref")).filter { it.isDigit() }
                val claim = referClaim
                if (rc.isNotEmpty() && claim != null) { if (claim(rc)) Prefs.remove("ffcb_ref") else Prefs.put("ffcb_ref", rc) }
                else if (rc.isNotEmpty()) Prefs.put("ffcb_ref", rc)
            } catch (_: Exception) { }
            if (mine != null) clearPending()
            return true
        } catch (_: Exception) { return false }
    }

    // ------------------------------------------------------------------ welcome card
    private val LINES = listOf(
        "Ready to win some matches? 🎯", "New matches are live. Grab your slot! 🎮", "Your wallet is safe and ready 💰",
        "Good luck, champion! 🏆", "Let's get that Booyah! 🔥",
    )

    fun showWelcome(name: String, tag: String) {
        val first = name.trim().split(Regex("\\s+")).firstOrNull().orEmpty().take(16).ifEmpty { "Player" }
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val greet = if (h in 5..11) "Good morning" else if (h in 12..16) "Good afternoon" else if (h in 17..20) "Good evening" else "Good night"
        welcome = WelcomeInfo(++welcomeId, first, "$greet, $first!", LINES.random(), tag)
    }

    // ------------------------------------------------------------------ forgot / reset password
    private fun fpKey(email: String) = "fp_last_" + email.lowercase()
    fun fpLeftMs(email: String): Long = COOLDOWN - (System.currentTimeMillis() - Prefs.long(fpKey(email)))
    private fun stopFpTimer() { fpTimer?.cancel(); fpTimer = null }

    /** Starts the 1-second tick that drives the resend countdown on the "Check your email" page. */
    fun fpStartTicker() {
        stopFpTimer()
        fpTimer = AppStore.scope.launch { while (isActive) { fpTick = System.currentTimeMillis(); if (fpLeftMs(fpEmail) <= 0) break; delay(1000) } }
    }

    /** From the "Forgot Password?" link on the login screen. */
    fun fpForgot(prefill: String) {
        fpFromLink = false
        val pref = prefill.trim()
        fpEmail = pref
        if (pref.isNotEmpty() && fpLeftMs(pref) > 0) { fpStep = "sent"; fpOpen = true; fpStartTicker(); return }   // already sent: go to the waiting page
        fpStep = "email"; fpOpen = true
    }

    fun fpClose() {
        stopFpTimer(); fpOpen = false
        if (fpFromLink) { fpFromLink = false; AppStore.authTab = "login"; AppStore.authOpen = true }
    }

    fun fpChangeEmail() { stopFpTimer(); fpCode = ""; fpStep = "email" }

    /** Back to the login screen with the e-mail filled in. Returns that e-mail. */
    fun fpToLogin(): String {
        stopFpTimer(); fpOpen = false; fpFromLink = false
        val em = fpEmail; fpCode = ""
        AppStore.authTab = "login"; AppStore.authOpen = true
        return em
    }

    private fun fpErr(e: Throwable?): String {
        val code = (e as? FirebaseAuthException)?.errorCode ?: ""
        return when {
            e is FirebaseNetworkException -> "Network error. Please check your internet connection."
            e is FirebaseTooManyRequestsException || code == "ERROR_TOO_MANY_REQUESTS" -> "Too many requests. Please wait a few minutes and try again."
            code == "ERROR_INVALID_EMAIL" -> "Please enter a valid email address."
            e is FirebaseAuthInvalidUserException || code == "ERROR_USER_NOT_FOUND" -> "No account was found with this email."
            e is FirebaseAuthWeakPasswordException || code == "ERROR_WEAK_PASSWORD" -> "Password must be at least 6 characters long."
            else -> e?.message?.takeIf { it.isNotBlank() } ?: "Something went wrong. Please try again."
        }
    }

    /** Sends the reset link. Returns an error text, or null on success / when a link was already sent (-> waiting page). */
    suspend fun sendForgot(email: String): String? {
        fpEmail = email
        if (fpLeftMs(email) > 0) { fpStep = "sent"; fpStartTicker(); return null }
        return try {
            Repo.auth.sendPasswordResetEmail(email).await()
            Prefs.put(fpKey(email), System.currentTimeMillis())
            fpStep = "sent"; fpStartTicker()
            AppStore.notify("success", "Reset link sent", "Please check your inbox and your Spam folder.", 7000)
            null
        } catch (e: Exception) { fpErr(e) }
    }

    suspend fun fpResend(): String? {
        val email = fpEmail
        if (email.isEmpty()) return null
        return try {
            Repo.auth.sendPasswordResetEmail(email).await()
            Prefs.put(fpKey(email), System.currentTimeMillis())
            AppStore.notify("success", "Link sent again", "Check your inbox and Spam folder.", 7000)
            fpStartTicker(); null
        } catch (e: Exception) { fpStartTicker(); fpErr(e) }
    }

    /** A reset link (…?mode=resetPassword&oobCode=…) was opened in the app. */
    fun openResetLink(code: String) {
        if (code.isBlank()) return
        fpCode = code; fpFromLink = true; fpStep = "verifying"; fpOpen = true
        AppStore.authOpen = false
        AppStore.scope.launch {
            try {
                val email = Repo.auth.verifyPasswordResetCode(code).await()
                fpEmail = email
                delay(700)
                fpStep = "reset"
            } catch (e: Exception) {
                fpInvalidMsg = if (e is FirebaseNetworkException) "Network error. Please check your internet connection and open the link again."
                else "This reset link has expired or was already used. Please request a new one."
                fpStep = "invalid"
            }
        }
    }

    /** Saves the new password. Returns an error text, or null (step moves to "done" / "invalid"). */
    suspend fun fpSavePw(pw: String): String? {
        return try {
            Repo.auth.confirmPasswordReset(fpCode, pw).await()
            fpCode = ""; fpFromLink = false; fpStep = "done"; null
        } catch (e: Exception) {
            val c = (e as? FirebaseAuthException)?.errorCode ?: ""
            if (c == "ERROR_EXPIRED_ACTION_CODE" || c == "ERROR_INVALID_ACTION_CODE") {
                fpInvalidMsg = "This reset link has expired or was already used. Please request a new one."; fpStep = "invalid"; null
            } else fpErr(e)
        }
    }
}
