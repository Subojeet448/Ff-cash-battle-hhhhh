package com.ffcashbattle.app.ui.modals

import android.graphics.Bitmap
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.RefCard
import com.ffcashbattle.app.data.Refer
import com.ffcashbattle.app.data.Sfx
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private val SC_UP = CubicBezierEasing(0.2f, 0.9f, 0.3f, 1f)
private val SC_POP = CubicBezierEasing(0.2f, 1.4f, 0.3f, 1f)

private class Part(var x: Float, var y: Float, var vx: Float, var vy: Float, val g: Float, var rot: Float, val vr: Float, val s: Float, val col: Color, var life: Int)

/** Website `#sc-wrap`: the full-screen golden scratch card. The server decides the amount when scratching starts. */
@Composable
internal fun ScratchOverlay(cardId: String, onClose: () -> Unit) {
    val density = LocalDensity.current.density
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val info = Refer.info
    val card: RefCard? = info?.cards?.firstOrNull { it.id == cardId }

    // ---- state
    var claimed by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }
    var revealing by remember { mutableStateOf(false) }
    var amt by remember { mutableStateOf<Double?>(null) }
    var drawing by remember { mutableStateOf(false) }
    var foil by remember { mutableStateOf<Bitmap?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    var clock by remember { mutableFloatStateOf(0f) }
    var rayAngle by remember { mutableFloatStateOf(0f) }
    val job: Array<Deferred<Double?>?> = remember { arrayOfNulls<Deferred<Double?>>(1) }
    val last: Array<Offset?> = remember { arrayOfNulls<Offset>(1) }
    val parts: ArrayList<Part> = remember { ArrayList<Part>() }
    var cardCenter by remember { mutableStateOf(Offset.Zero) }
    var rootOrigin by remember { mutableStateOf(Offset.Zero) }
    val countAnim = remember { Animatable(0f) }

    val enter = remember { Animatable(0f) }
    val boxIn = remember { Animatable(0f) }
    val cardIn = remember { Animatable(0f) }
    val popT = remember { Animatable(1f) }
    val ringT = remember { Animatable(1f) }
    val amtT = remember { Animatable(1f) }
    val titleT = remember { Animatable(1f) }
    val flashT = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        launch { enter.animateTo(1f, tween(250)) }
        launch { boxIn.animateTo(1f, tween(400, easing = CubicBezierEasing(0.2f, 1.2f, 0.3f, 1f))) }
        launch { delay(150); cardIn.animateTo(1f, tween(700, easing = CubicBezierEasing(0.2f, 1.2f, 0.3f, 1f))) }
        Sfx.play("touch")
    }

    // ---- amounts / texts (website helpers jackMax / cardWallet)
    val cfg = info?.cfg
    fun jackMax(): Double {
        val x = card
        if (x != null && x.src != "ref") return if ((x.src == "admin" || x.src == "match") && x.max > x.min) x.max * (if (x.mult != 0.0) x.mult else 1.0) else 0.0
        return if (cfg != null && cfg.amountMode == "random") cfg.maxAmount else 0.0
    }
    fun wallet(): String {
        val x = card
        return if (x != null && x.src != "ref") (if (x.to == "withdraw") "Withdrawable balance" else "Deposit balance") else if (cfg != null) Refer.walletTxt(cfg) else "wallet"
    }
    val big = amt?.let { val m = jackMax(); m > 0 && it >= m * 0.8 } == true

    // ---- foil
    val strokePaint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND } }
    val fillPaint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR); style = Paint.Style.FILL } }
    fun repaint() { foil?.let { paintFoil(it, density); tick++ } }

    fun coverage(): Float {
        val b = foil ?: return 0f
        return try {
            val t = Bitmap.createScaledBitmap(b, 40, 25, true)
            val px = IntArray(40 * 25); t.getPixels(px, 0, 40, 0, 0, 40, 25)
            var clear = 0
            for (v in px) if ((v ushr 24) < 110) clear++
            t.recycle()
            clear / 1000f
        } catch (_: Throwable) { 0f }
    }

    fun emit(n: Int, x: Float, y: Float, shave: Boolean) {
        val cols = if (shave) listOf(0xFFFFE9A0, 0xFFF4C24A, 0xFFFFF6CF, 0xFFD9961B) else listOf(0xFFFFD66B, 0xFFEC4899, 0xFFA855F7, 0xFF22D3EE, 0xFF34D399, 0xFFFFFFFF, 0xFFF97316)
        repeat(n) {
            val a = if (shave) (-PI / 2 + (Random.nextDouble() - 0.5) * 2.2) else Random.nextDouble() * PI * 2
            val sp = if (shave) 1.2 + Random.nextDouble() * 2.6 else 3 + Random.nextDouble() * 8
            parts.add(
                Part(
                    x, y, (cos(a) * sp).toFloat() * density, (sin(a) * sp - (if (shave) 0 else 3)).toFloat() * density, (if (shave) 0.16f else 0.22f) * density,
                    Random.nextFloat() * 6f, ((Random.nextFloat() - 0.5f) * 0.4f), (if (shave) 2.5f + Random.nextFloat() * 3f else 6f + Random.nextFloat() * 7f) * density,
                    Color(cols[Random.nextInt(cols.size)]), if (shave) 34 else 90 + Random.nextInt(40),
                ),
            )
        }
    }

    fun resetCard() {
        claimed = false; busy = false; done = false; revealing = false; amt = null; last[0] = null; job[0] = null
        repaint()
    }

    fun claimNow(): Deferred<Double?> {
        val existing = job[0]
        if (existing != null) return existing
        claimed = true; busy = true
        Sfx.play("touch"); haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        // runs in the app scope on purpose: closing the card mid-request must not lose the reward notice
        val d = AppStore.scope.async {
            try {
                val a = Refer.scratch(cardId)
                amt = a
                a
            } catch (e: Exception) {
                AppStore.toast(e.message ?: "Could not open this card")
                if (!done) resetCard()
                job[0] = null
                null
            }
        }
        job[0] = d
        return d
    }

    suspend fun finish() {
        if (revealing || done) return
        revealing = true
        val r = claimNow().await()
        if (r == null) { revealing = false; return }
        done = true; drawing = false
        scope.launch { countAnim.snapTo(0f); countAnim.animateTo(1f, tween(900, easing = CubicBezierEasing(0.215f, 0.61f, 0.355f, 1f))) }
        scope.launch { popT.snapTo(0f); popT.animateTo(1f, tween(600, easing = CubicBezierEasing(0.2f, 1.4f, 0.3f, 1f))) }
        scope.launch { ringT.snapTo(0f); ringT.animateTo(1f, tween(900, easing = CubicBezierEasing(0f, 0f, 0.2f, 1f))) }
        scope.launch { amtT.snapTo(0f); amtT.animateTo(1f, tween(800, easing = CubicBezierEasing(0.2f, 1.5f, 0.3f, 1f))) }
        scope.launch { titleT.snapTo(0f); titleT.animateTo(1f, tween(700, easing = SC_POP)) }
        scope.launch { flashT.snapTo(0f); flashT.animateTo(1f, tween(800)) }
        emit(110, cardCenter.x - rootOrigin.x, cardCenter.y - rootOrigin.y, false)
        Sfx.play("notification"); haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        delay(500)
        Refer.load(false)
    }

    fun closeCard() {
        val was = claimed && !done
        val d = job[0]
        val wasDone = done
        onClose()
        if (was && d != null) AppStore.scope.launch {
            val a = d.await()
            if (a != null) { AppStore.toast("You won ${Refer.money(a)}! Added to your wallet"); Refer.load(false) }
        } else if (wasDone) AppStore.scope.launch { Refer.load(false) }
    }

    BackHandler { closeCard() }

    // one frame loop: particles, spinning rays, twinkles, hint bounce
    LaunchedEffect(Unit) {
        var prev = 0L
        while (true) {
            withFrameNanos { n ->
                val dt = if (prev == 0L) 0.016f else ((n - prev) / 1_000_000_000f).coerceAtMost(0.05f)
                prev = n
                clock += dt
                rayAngle = (rayAngle + dt * (if (done) 360f / 7f else 360f / 14f)) % 360f
                if (parts.isNotEmpty()) {
                    val iter = parts.iterator()
                    while (iter.hasNext()) {
                        val p = iter.next()
                        p.vy += p.g; p.x += p.vx; p.y += p.vy; p.vx *= 0.99f; p.rot += p.vr; p.life--
                        if (p.life <= 0 || p.y > 4000f) iter.remove()
                    }
                }
            }
        }
    }

    // coverage check while the finger is down
    LaunchedEffect(drawing) {
        while (drawing && !done) { delay(150); if (!done && coverage() > 0.42f) finish() }
    }

    // ---------------------------------------------------------------------------- UI
    Box(
        Modifier.fillMaxSize().onGloballyPositioned { rootOrigin = it.positionInRoot() }
            .graphicsLayer { alpha = enter.value }
            .background(Brush.radialGradient(listOf(Color(0x8C7C3AED), Color(0xEB0C0A24)), Offset.Unspecified, 2000f))
    ) {
        // dim backdrop tap = close (outside the card)
        Box(Modifier.fillMaxSize().press(1f, true) { closeCard() })

        Column(
            Modifier.align(Alignment.Center).fillMaxWidth(0.92f).widthIn(max = 340.dp)
                .graphicsLayer { val v = boxIn.value; translationY = (1f - v) * 30.dp.toPx(); val k = 0.94f + 0.06f * v; scaleX = k; scaleY = k }
                .drawBehind { drawSparks(clock, density) }
                .pointerInput(Unit) { detectTapGestures { } },                       // taps on the box itself do not close the card
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // close
            Box(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.align(Alignment.Center).clip(RoundedCornerShape(99.dp)).background(Color(0x24FFFFFF)).border(1.dp, Color(0x40FFFFFF), RoundedCornerShape(99.dp)).padding(horizontal = 12.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    FaIcon("fa-solid fa-gift", rem(0.7).value.dp, Color.White)
                    FText("REFERRAL REWARD", size = rem(0.7), weight = FontWeight.ExtraBold, color = Color.White, letterSpacing = 0.5.sp)
                }
                Box(
                    Modifier.align(Alignment.TopEnd).padding(end = 0.dp).size(34.dp).clip(CircleShape).background(Color(0x29FFFFFF)).press(0.9f) { closeCard() },
                    contentAlignment = Alignment.Center,
                ) { FaIcon("fa-solid fa-xmark", rem(1.0).value.dp, Color.White) }
            }
            FText(
                if (done) (if (big) "JACKPOT! 🎉" else "Congratulations! 🎉") else "Scratch & Win!", size = rem(1.6), weight = FontWeight.Black, color = Color.White, letterSpacing = (-0.3).sp,
                align = TextAlign.Center, modifier = Modifier.padding(top = 12.dp, bottom = 2.dp).graphicsLayer { val v = if (done) titleT.value else 1f; scaleX = 0.6f + 0.4f * v; scaleY = 0.6f + 0.4f * v; alpha = v.coerceIn(0f, 1f) },
            )
            FText(
                if (done) "${Refer.money(amt ?: 0.0)} added to your ${wallet()}" else "Rub the golden card with your finger", size = rem(0.84), color = Color.White.copy(alpha = 0.85f),
                align = TextAlign.Center, modifier = Modifier.padding(bottom = 16.dp),
            )

            // ---- the card
            val cardShape = RoundedCornerShape(22.dp)
            Box(
                Modifier.fillMaxWidth().aspectRatio(300f / 190f)
                    .graphicsLayer {
                        val v = cardIn.value
                        val pop = if (done) { val t = popT.value; if (t < 0.4f) 1f + 0.06f * (t / 0.4f) else 1.06f - 0.06f * ((t - 0.4f) / 0.6f) } else 1f
                        translationY = (1f - v) * 40.dp.toPx(); rotationZ = -4f * (1f - v)
                        val k = (0.85f + 0.15f * v) * pop; scaleX = k; scaleY = k; alpha = v.coerceIn(0f, 1f)
                    }
                    .boxShadow(40.dp, Color(0x59FFD66B), cardShape).clip(cardShape)
                    .onGloballyPositioned { cardCenter = it.positionInRoot() + Offset(it.size.width / 2f, it.size.height / 2f) }
                    .onSizeChanged { sz: IntSize ->
                        if (sz.width > 10 && (foil == null || foil!!.width != sz.width || foil!!.height != sz.height)) {
                            foil = Bitmap.createBitmap(sz.width, sz.height, Bitmap.Config.ARGB_8888).also { paintFoil(it, density) }
                            tick++
                        }
                    },
            ) {
                // prize layer
                Box(
                    Modifier.fillMaxSize()
                        .background(Brush.radialGradient(0f to Color(0xFF6D5DFC), 0.48f to Color(0xFF4338CA), 1f to Color(0xFF241A7A), center = Offset.Unspecified, radius = 900f)),
                    contentAlignment = Alignment.Center,
                ) {
                    // rotating rays
                    Canvas(Modifier.fillMaxSize()) {
                        val r = 260.dp.toPx()
                        val ctr = Offset(size.width / 2f, size.height / 2f)
                        rotate(rayAngle, ctr) {
                            val br = Brush.radialGradient(listOf(Color(0x1AFFFFFF), Color.Transparent), ctr, r * 0.62f)
                            var a = 0f
                            while (a < 360f) { drawArc(br, a, 10f, true, Offset(ctr.x - r, ctr.y - r), Size(r * 2, r * 2)); a += 20f }
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        FText(
                            if (big) "JACKPOT!" else "YOU WON", size = rem(0.78), weight = FontWeight.Black, color = Color(0xFFFFD66B), letterSpacing = 3.sp,
                            modifier = Modifier.graphicsLayer { alpha = if (done) amtT.value.coerceIn(0f, 1f) else 1f },
                        )
                        Row(
                            Modifier.graphicsLayer {
                                val v = if (done) amtT.value else 1f
                                val k = if (done) (if (v < 0.6f) 0.2f + (1.22f - 0.2f) * (v / 0.6f) else 1.22f - 0.22f * ((v - 0.6f) / 0.4f)) else 1f
                                scaleX = k; scaleY = k; rotationZ = if (done) (if (v < 0.6f) -8f + 11f * (v / 0.6f) else 3f * (1f - (v - 0.6f) / 0.4f)) else 0f
                                alpha = if (done) v.coerceIn(0f, 1f) else 1f
                            },
                            verticalAlignment = Alignment.Top,
                        ) {
                            FText("₹", size = rem(2.0), weight = FontWeight.Black, color = Color(0xFFFFD66B), modifier = Modifier.padding(top = 4.dp, end = 3.dp))
                            val a = amt
                            val shown = if (a == null) "?" else if (done) fmtNum(a * countAnim.value) else fmtNum(a)
                            FText(shown, size = rem(3.4), weight = FontWeight.Black, color = Color.White, maxLines = 1)
                        }
                        Row(
                            Modifier.padding(top = 4.dp).graphicsLayer { alpha = if (done) ((amtT.value - 0.2f) / 0.6f).coerceIn(0f, 1f) else 1f },
                            horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically,
                        ) {
                            FaIcon("fa-solid fa-circle-check", rem(0.76).value.dp, Color(0xFFA7F3D0))
                            FText("Added to your wallet", size = rem(0.76), weight = FontWeight.Bold, color = Color(0xFFA7F3D0))
                        }
                    }
                }

                // the golden foil you scratch
                val fadeOut = remember { Animatable(1f) }
                LaunchedEffect(done) { if (done) fadeOut.animateTo(0f, tween(600)) else fadeOut.snapTo(1f) }
                val bmp = foil
                if (bmp != null && fadeOut.value > 0f) {
                    Canvas(
                        Modifier.fillMaxSize().graphicsLayer { alpha = fadeOut.value }
                            .then(
                                if (done) Modifier else Modifier.pointerInput(bmp) {
                                    val cv = android.graphics.Canvas(bmp)
                                    awaitEachGesture {
                                        val down = awaitFirstDown(requireUnconsumed = false)
                                        down.consume()
                                        if (done) return@awaitEachGesture
                                        drawing = true; last[0] = null
                                        claimNow()
                                        fun stroke(p: Offset) {
                                            strokePaint.strokeWidth = 30f * density
                                            val l = last[0]
                                            if (l != null) cv.drawLine(l.x, l.y, p.x, p.y, strokePaint) else cv.drawCircle(p.x, p.y, 15f * density, fillPaint)
                                            last[0] = p; tick++
                                            if (Random.nextFloat() < 0.55f) emit(2, cardCenter.x - rootOrigin.x - bmp.width / 2f + p.x, cardCenter.y - rootOrigin.y - bmp.height / 2f + p.y, true)
                                        }
                                        stroke(down.position)
                                        var go = true
                                        while (go) {
                                            val ev = awaitPointerEvent()
                                            for (ch in ev.changes) if (ch.positionChanged()) { stroke(ch.position); ch.consume() }
                                            go = ev.changes.any { it.pressed }
                                        }
                                        drawing = false; last[0] = null
                                        if (!done && claimed && coverage() > 0.42f) scope.launch { finish() }
                                    }
                                },
                            ),
                    ) {
                        @Suppress("UNUSED_VARIABLE") val t = tick
                        drawImage(bmp.asImageBitmap())
                    }
                }
                // shine sweep + hint (hidden once scratching started)
                if (!busy && !done) {
                    Canvas(Modifier.fillMaxSize()) {
                        val q = ((clock % 2.4f) / 2.4f) / 0.55f
                        val bw = size.width * 0.34f
                        val x0 = -size.width * 0.5f + size.width * 1.8f * q
                        if (q < 1f) drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color(0x8CFFFFFF), Color.Transparent), x0, x0 + bw), Offset(x0, 0f), Size(bw, size.height))
                    }
                    Row(
                        Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp)
                            .graphicsLayer { translationY = -5.dp.toPx() * (0.5f - 0.5f * cos(clock / 1.4f * PI.toFloat() * 2f)) }
                            .clip(RoundedCornerShape(99.dp)).background(Color(0xC75A3A00)).padding(horizontal = 14.dp, vertical = 7.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
                    ) {
                        FaIcon("fa-solid fa-hand-pointer", rem(0.8).value.dp, Color(0xFFFFE9A8))
                        FText("Scratch here", size = rem(0.8), weight = FontWeight.ExtraBold, color = Color(0xFFFFE9A8))
                    }
                }
                // expanding ring when the card opens
                if (done && ringT.value < 1f) Canvas(Modifier.fillMaxSize()) {
                    val t = ringT.value
                    drawCircle(Color.White.copy(alpha = 0.9f * (1f - t)), 15.dp.toPx() * (1f + 17f * t), Offset(size.width / 2f, size.height / 2f), style = Stroke(3.dp.toPx()))
                }
            }

            if (!done) {
                FText(
                    "Reveal now", size = rem(0.82), weight = FontWeight.Bold, color = Color.White.copy(alpha = 0.7f), underline = true,
                    modifier = Modifier.padding(top = 16.dp).press(0.95f) { scope.launch { claimNow(); finish() } }.padding(8.dp),
                )
            } else {
                val a = remember { Animatable(0f) }
                LaunchedEffect(Unit) { a.animateTo(1f, tween(500, easing = SC_UP)) }
                BtnMain(
                    onClick = { closeCard() },
                    modifier = Modifier.padding(top = 18.dp).fillMaxWidth().graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 12.dp.toPx() },
                ) {
                    FText("Awesome!", weight = FontWeight.Bold, color = Color.White)
                    Box(Modifier.size(8.dp))
                    FaIcon("fa-solid fa-check", rem(1.0).value.dp, Color.White)
                }
            }
        }

        // white flash when the card opens
        if (done && flashT.value < 1f) Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.35f * (1f - flashT.value))))

        // gold shavings + confetti
        Canvas(Modifier.fillMaxSize()) {
            @Suppress("UNUSED_VARIABLE") val c = clock
            for (p in parts) {
                val al = (p.life / 24f).coerceIn(0f, 1f)
                translate(p.x, p.y) {
                    rotate(p.rot * 57.2958f, Offset.Zero) {
                        drawRect(p.col.copy(alpha = al), Offset(-p.s / 2f, -p.s / 3f), Size(p.s, p.s * 0.66f))
                    }
                }
            }
        }
    }
}

private fun fmtNum(v: Double): String = if (v == Math.floor(v)) Math.round(v).toString() else (Math.round(v * 100) / 100.0).toString()

// ------------------------------------------------------------------------------------------ twinkling sparks around the card

private val SPARKS = listOf(
    floatArrayOf(2f, 18f, 0f, 10f), floatArrayOf(92f, 10f, 0.3f, 14f), floatArrayOf(12f, 86f, 0.7f, 8f), floatArrayOf(96f, 70f, 1.0f, 10f),
    floatArrayOf(48f, -2f, 1.3f, 12f), floatArrayOf(70f, 96f, 0.5f, 12f), floatArrayOf(-2f, 52f, 1.6f, 9f), floatArrayOf(30f, 6f, 1.9f, 8f),
)

private fun DrawScope.drawSparks(clock: Float, density: Float) {
    val pad = 14.dp.toPx()
    val w = size.width + pad * 2; val h = size.height + pad * 2
    for (s in SPARKS) {
        val t = (((clock - s[2]) % 2.2f) + 2.2f) % 2.2f / 2.2f
        val tri = if (t < 0.5f) t * 2f else (1f - t) * 2f               // 0 -> 1 -> 0
        val sc = 0.3f + 0.85f * tri
        val al = tri
        if (al <= 0.01f) continue
        val sz = s[3].dp.toPx()
        val cx = -pad + w * s[0] / 100f + sz / 2f
        val cy = -pad + h * s[1] / 100f + sz / 2f
        val path = Path().apply {
            val pts = listOf(0.5f to 0f, 0.62f to 0.38f, 1f to 0.5f, 0.62f to 0.62f, 0.5f to 1f, 0.38f to 0.62f, 0f to 0.5f, 0.38f to 0.38f)
            pts.forEachIndexed { i, (px, py) -> val x = (px - 0.5f) * sz; val y = (py - 0.5f) * sz; if (i == 0) moveTo(x, y) else lineTo(x, y) }
            close()
        }
        translate(cx, cy) { rotate(90f * tri, Offset.Zero) { scale(sc, Offset.Zero) { drawPath(path, Color(0xFFFFE9A0).copy(alpha = al)) } } }
    }
}

// ------------------------------------------------------------------------------------------ the foil (port of paintFoil)

private fun drawCentered(c: android.graphics.Canvas, text: String, x: Float, y: Float, p: Paint) {
    val fm = p.fontMetrics
    c.drawText(text, x, y - (fm.ascent + fm.descent) / 2f, p)
}

private fun paintFoil(bmp: Bitmap, d: Float) {
    val w = bmp.width.toFloat(); val h = bmp.height.toFloat()
    val c = android.graphics.Canvas(bmp)
    c.drawColor(0, PorterDuff.Mode.CLEAR)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.shader = LinearGradient(
        0f, 0f, w, h,
        intArrayOf(0xFFFFF2AE.toInt(), 0xFFF9C94D.toInt(), 0xFFD99A1B.toInt(), 0xFFFFE48C.toInt(), 0xFFE3A724.toInt(), 0xFFB87A0E.toInt()),
        floatArrayOf(0f, 0.2f, 0.42f, 0.6f, 0.8f, 1f), Shader.TileMode.CLAMP,
    )
    c.drawRect(0f, 0f, w, h, p)
    p.shader = null
    // glitter specks
    val n = Math.round(w * h / 240f)
    val spk = 1.6f * d
    for (i in 0 until n) {
        p.color = if (Random.nextFloat() < 0.5f) android.graphics.Color.argb((Random.nextFloat() * 0.38f * 255).toInt(), 255, 255, 255) else android.graphics.Color.argb((Random.nextFloat() * 0.24f * 255).toInt(), 110, 60, 0)
        val x = Random.nextFloat() * w; val y = Random.nextFloat() * h
        c.drawRect(x, y, x + spk, y + spk, p)
    }
    // diagonal hatching
    p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = android.graphics.Color.argb(31, 255, 255, 255)
    var x = -h
    while (x < w) { c.drawLine(x, h, x + h, 0f, p); x += 8f * d }
    // faint ₹ / ★ pattern
    p.style = Paint.Style.FILL; p.color = android.graphics.Color.argb(36, 122, 70, 0); p.textSize = 19f * d; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    for (r in 0 until 5) for (k in 0 until 7) drawCentered(c, if (r % 2 == 1) "★" else "₹", (k + (if (r % 2 == 1) 0.5f else 0f)) * (w / 6.2f) + w / 14f, r * (h / 4.2f) + h / 9f, p)
    // double border
    p.style = Paint.Style.STROKE; p.color = android.graphics.Color.argb(242, 255, 248, 205); p.strokeWidth = 3f * d
    c.drawRoundRect(7f * d, 7f * d, w - 7f * d, h - 7f * d, 18f * d, 18f * d, p)
    p.color = android.graphics.Color.argb(102, 140, 85, 0); p.strokeWidth = 1.2f * d
    c.drawRoundRect(12f * d, 12f * d, w - 12f * d, h - 12f * d, 14f * d, 14f * d, p)
    // emblem
    val cx = w / 2f; val cy = h * 0.4f; val rr = 32f * d
    p.style = Paint.Style.FILL
    p.shader = RadialGradient(cx - rr * 0.2f, cy - rr * 0.25f, rr * 1.15f, intArrayOf(0xFFFFFBE0.toInt(), 0xFFF6C23E.toInt(), 0xFFB97B10.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
    p.setShadowLayer(12f * d, 0f, 4f * d, android.graphics.Color.argb(140, 110, 60, 0))
    c.drawCircle(cx, cy, rr, p)
    p.clearShadowLayer(); p.shader = null
    p.style = Paint.Style.STROKE; p.color = android.graphics.Color.argb(242, 255, 250, 215); p.strokeWidth = 2.4f * d
    c.drawCircle(cx, cy, rr - 4f * d, p)
    p.style = Paint.Style.FILL; p.color = android.graphics.Color.WHITE; p.textSize = 34f * d; p.typeface = Typeface.DEFAULT
    drawCentered(c, "🎁", cx, cy + 2f * d, p)
    // embossed title
    p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD); p.textSize = 22f * d
    p.color = android.graphics.Color.argb(166, 110, 60, 0)
    drawCentered(c, "SCRATCH & WIN", cx + 1.5f * d, h * 0.73f + 1.8f * d, p)
    p.color = android.graphics.Color.rgb(255, 247, 207)
    drawCentered(c, "SCRATCH & WIN", cx, h * 0.73f, p)
    p.style = Paint.Style.STROKE; p.strokeWidth = 0.8f * d; p.color = android.graphics.Color.argb(128, 150, 90, 0)
    drawCentered(c, "SCRATCH & WIN", cx, h * 0.73f, p)
}
