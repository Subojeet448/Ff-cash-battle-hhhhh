package com.ffcashbattle.app.data

import android.content.Context
import android.content.SharedPreferences

/** localStorage replacement. Same key names as the website, so behaviour stays identical. */
object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(ctx: Context) { sp = ctx.getSharedPreferences("ffcb", Context.MODE_PRIVATE) }

    fun str(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    fun int(k: String, d: Int = 0): Int = try { sp.getInt(k, d) } catch (e: ClassCastException) { str(k, d.toString()).toIntOrNull() ?: d }
    fun long(k: String, d: Long = 0L): Long = try { sp.getLong(k, d) } catch (e: ClassCastException) { str(k, d.toString()).toLongOrNull() ?: d }
    fun bool(k: String, d: Boolean = false): Boolean = try { sp.getBoolean(k, d) } catch (e: ClassCastException) { str(k, d.toString()).toBooleanStrictOrNull() ?: d }

    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }
    fun put(k: String, v: Int) { sp.edit().putInt(k, v).apply() }
    fun put(k: String, v: Long) { sp.edit().putLong(k, v).apply() }
    fun put(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    fun remove(k: String) { sp.edit().remove(k).apply() }
    fun has(k: String): Boolean = sp.contains(k)

    var darkMode: Boolean
        get() = bool("darkMode", false)
        set(v) = put("darkMode", v)

    /** Sound sliders (Sound modal): vol_app / vol_touch default 50, the others 80. */
    fun vol(which: String): Int = int("vol_$which", if (which == "app" || which == "touch") 50 else 80)
    fun setVol(which: String, v: Int) = put("vol_$which", v)
}
