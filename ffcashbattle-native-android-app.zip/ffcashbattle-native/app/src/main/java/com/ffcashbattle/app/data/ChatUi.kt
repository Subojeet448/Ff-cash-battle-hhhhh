package com.ffcashbattle.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CompletableDeferred

/** The question sheet of the chat (`ask()` in chat.js): a title, optional text input / reason chips / text area and two buttons. */
class AskOpts(
    val title: String,
    val icon: String = "fa-circle-question",
    val text: String = "",
    val yes: String = "Confirm",
    val no: String = "Cancel",
    val danger: Boolean = false,
    val input: String? = null,
    val placeholder: String = "",
    val max: Int = 30,
    val chips: List<String> = emptyList(),
    val area: String? = null,
)

/** value = typed text / chosen chip (or "" for a plain confirm), extra = text area. */
class AskResult(val value: String = "", val extra: String = "")

/** Bottom sheets that live inside the chat app (the website's `#cs` sheet). */
sealed class ChatSheet {
    class Ask(val o: AskOpts, val done: CompletableDeferred<AskResult?>) : ChatSheet()
    class Onboard : ChatSheet()
    class MsgMenu(val id: String) : ChatSheet()
    class UserCard(val uid: String, val name: String, val photo: String) : ChatSheet()
    class NewGroup : ChatSheet()
    class GroupInfo(val gid: String) : ChatSheet()
    class History(val tab: String) : ChatSheet()
    class Saved : ChatSheet()
}

object ChatUi {
    var sheet by mutableStateOf<ChatSheet?>(null)
    var menuOpen by mutableStateOf(false)          // the ⋮ menu of a conversation
    var emojiOpen by mutableStateOf(false)         // emoji panel above the composer
    var historyTab by mutableStateOf("matches")

    fun show(s: ChatSheet) {
        (sheet as? ChatSheet.Ask)?.done?.complete(null)
        sheet = s
    }

    /** Close whatever sheet is open. */
    fun closeSheet() {
        (sheet as? ChatSheet.Ask)?.done?.complete(null)
        sheet = null
    }

    /** Called after a sheet finished its closing animation: only clears it when it is still the one that was closed. */
    fun dismissed(s: ChatSheet) {
        if (sheet === s) sheet = null
        (s as? ChatSheet.Ask)?.done?.complete(null)
    }

    suspend fun ask(o: AskOpts): AskResult? {
        val d = CompletableDeferred<AskResult?>()
        show(ChatSheet.Ask(o, d))
        return d.await()
    }
}
