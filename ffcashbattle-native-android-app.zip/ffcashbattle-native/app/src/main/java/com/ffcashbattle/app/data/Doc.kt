package com.ffcashbattle.app.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import java.util.Date

/**
 * Firestore documents are schema-less (the website reads any field), so every document is kept as a Doc:
 * the id + the raw map, with forgiving typed getters (numbers may be stored as strings, timestamps as numbers, etc.).
 */
class Doc(val id: String, val m: Map<String, Any?>) {
    operator fun get(k: String): Any? = m[k]
    fun has(k: String): Boolean = m[k] != null

    fun s(k: String, d: String = ""): String = when (val v = m[k]) {
        null -> d
        is String -> v
        is Number -> if (v.toDouble() % 1.0 == 0.0) v.toLong().toString() else v.toString()
        else -> v.toString()
    }

    fun n(k: String, d: Double = 0.0): Double = when (val v = m[k]) {
        is Number -> v.toDouble()
        is String -> v.replace(Regex("[^0-9.\\-]"), "").toDoubleOrNull() ?: d
        else -> d
    }

    fun i(k: String, d: Int = 0): Int = n(k, d.toDouble()).toInt()
    fun l(k: String, d: Long = 0L): Long = n(k, d.toDouble()).toLong()
    fun b(k: String, d: Boolean = false): Boolean = when (val v = m[k]) {
        is Boolean -> v
        is String -> v.equals("true", true)
        is Number -> v.toInt() != 0
        else -> d
    }

    @Suppress("UNCHECKED_CAST")
    fun list(k: String): List<Any?> = (m[k] as? List<Any?>) ?: emptyList()

    fun strList(k: String): List<String> = list(k).mapNotNull { it?.toString() }

    @Suppress("UNCHECKED_CAST")
    fun map(k: String): Map<String, Any?> = (m[k] as? Map<String, Any?>) ?: emptyMap()

    @Suppress("UNCHECKED_CAST")
    fun maps(k: String): List<Map<String, Any?>> = list(k).mapNotNull { it as? Map<String, Any?> }

    /** Firestore Timestamp / epoch-millis / {seconds} -> epoch millis (0 when missing). */
    fun ms(k: String): Long = toMs(m[k])

    fun with(vararg kv: Pair<String, Any?>): Doc = Doc(id, m + kv.toMap())

    companion object {
        val EMPTY = Doc("", emptyMap())
        fun of(s: DocumentSnapshot): Doc = Doc(s.id, s.data ?: emptyMap())

        fun toMs(v: Any?): Long = when (v) {
            is Timestamp -> v.seconds * 1000 + v.nanoseconds / 1_000_000
            is Date -> v.time
            is Number -> { val x = v.toLong(); if (x in 1 until 100_000_000_000L) x * 1000 else x }
            is Map<*, *> -> ((v["seconds"] as? Number)?.toLong() ?: 0L) * 1000
            is String -> parseDate(v)
            else -> 0L
        }

        /** Port of trxtime.js parseDate: ISO strings and the locale strings the old app stored ("31/10/2026, 9:58:30 pm"). */
        fun parseDate(raw: String): Long {
            val s = raw.trim(); if (s.isEmpty()) return 0L
            val iso = Regex("^(\\d{4})-(\\d{2})-(\\d{2})(?:[T ](\\d{2}):(\\d{2})(?::(\\d{2}))?)?").find(s)
            if (iso != null) {
                val g = iso.groupValues
                return java.util.Calendar.getInstance().apply {
                    clear(); set(g[1].toInt(), g[2].toInt() - 1, g[3].toInt(), g[4].toIntOrNull() ?: 0, g[5].toIntOrNull() ?: 0, g[6].toIntOrNull() ?: 0)
                }.timeInMillis
            }
            val m = Regex("^(\\d{1,2})[/\\-.](\\d{1,2})[/\\-.](\\d{2,4})(?:[,\\s]+(\\d{1,2}):(\\d{2})(?::(\\d{2}))?\\s*([ap]m)?)?", RegexOption.IGNORE_CASE).find(s) ?: return 0L
            val g = m.groupValues
            val a = g[1].toInt(); val b = g[2].toInt(); var y = g[3].toInt(); if (y < 100) y += 2000
            var d = a; var mo = b; if (b > 12 && a <= 12) { d = b; mo = a }
            var h = g[4].toIntOrNull() ?: 0; val mi = g[5].toIntOrNull() ?: 0; val se = g[6].toIntOrNull() ?: 0; val ap = g[7].lowercase()
            if (ap == "pm" && h < 12) h += 12; if (ap == "am" && h == 12) h = 0
            return java.util.Calendar.getInstance().apply { clear(); set(y, mo - 1, d, h, mi, se) }.timeInMillis
        }
    }
}

/** trxtime.js trxMs(): one reliable way to read a transaction's time. */
fun Doc.trxMs(): Long {
    val ts = m["timestamp"]
    if (ts != null) { val v = toMs(ts); if (v > 0) return v }
    for (k in listOf("createdAt", "at", "ts", "time")) {
        val v = m[k]
        if (v is Number && v.toLong() > 100_000_000_000L) return v.toLong()
        if (v is Timestamp || v is Map<*, *>) { val x = toMs(v); if (x > 0) return x }
    }
    val a = Doc.parseDate(s("date")); if (a > 0) return a
    return Doc.parseDate(s("createdAt"))
}

/** trxSort(): newest first, ties broken by original order (later wins). */
fun sortTrx(list: List<Doc>): List<Doc> =
    list.withIndex().sortedWith(compareByDescending<IndexedValue<Doc>> { it.value.trxMs() }.thenByDescending { it.index }).map { it.value }

/** Firestore number like the JS SDK writes it: whole values as integers, everything else as double. */
fun fsNum(d: Double): Any = if (d % 1.0 == 0.0 && Math.abs(d) < 9.0e15) d.toLong() else d
