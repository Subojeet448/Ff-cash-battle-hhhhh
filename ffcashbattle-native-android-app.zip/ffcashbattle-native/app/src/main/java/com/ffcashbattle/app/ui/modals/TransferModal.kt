package com.ffcashbattle.app.ui.modals

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.Repo
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FRich
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.InputBox
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.screens.FaqChip
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay
import java.util.Locale

/** Recipient lookup states of `#recipient-status`. */
private sealed class Rcp {
    object None : Rcp()
    object Self : Rcp()
    object Searching : Rcp()
    class Found(val name: String) : Rcp()
    object Missing : Rcp()
    object Error : Rcp()
}

/** Website `#modal-transfer`. Sending is switched off in the website (balance can only be added by the admin), so Confirm only explains that. */
@Composable
fun TransferModal() {
    val c = FF.c
    var pid by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var rcp by remember { mutableStateOf<Rcp>(Rcp.None) }

    // app.verifyRecipient — look the Player ID up (after a short pause while typing)
    LaunchedEffect(pid) {
        if (pid.length < 5) { rcp = Rcp.None; return@LaunchedEffect }
        if (pid == AppStore.user.s("playerId")) { rcp = Rcp.Self; return@LaunchedEffect }
        rcp = Rcp.Searching
        delay(250)
        rcp = try {
            val hit = Repo.getCol("users") { it.whereEqualTo("playerId", pid).limit(1) }.firstOrNull()
            if (hit != null) Rcp.Found(hit.s("appName").ifEmpty { "User" }) else Rcp.Missing
        } catch (e: Exception) { Rcp.Error }
    }

    ModalSheet {
        val close = LocalSheetClose.current
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            FText("Transfer Balance", size = rem(1.5), weight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                FaqChip("transfer")
                Box(Modifier.press(0.9f) { close() }) { FaIcon("fa-solid fa-xmark", rem(1.5).value.dp, c.textMuted) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 15.dp), horizontalArrangement = Arrangement.End) {
            FText("Available: ", size = rem(0.8), color = c.textMuted)
            FText("₹ " + String.format(Locale.US, "%.2f", AppStore.depositBalance), size = rem(0.8), weight = FontWeight.Bold, color = c.success)
        }

        TLabel("Recipient Player ID")
        InputBox(pid, { pid = it }, Modifier.fillMaxWidth(), placeholder = "Enter 7-digit Player ID")
        // #recipient-status — margin:-10px 0 10px under the 15px input margin
        Box(Modifier.fillMaxWidth().padding(top = 5.dp, bottom = 10.dp).heightIn(min = 18.dp)) {
            when (val r = rcp) {
                Rcp.None -> {}
                Rcp.Self -> FText("Cannot send to self", size = rem(0.8), weight = FontWeight.SemiBold, color = c.danger)
                Rcp.Searching -> FText("Searching...", size = rem(0.8), weight = FontWeight.SemiBold, color = c.textMuted)
                is Rcp.Found -> Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    FaIcon("fa-solid fa-circle-check", rem(0.8).value.dp, c.success)
                    FRich("Found: [${r.name}]", size = rem(0.8), weight = FontWeight.SemiBold, color = c.success)
                }
                Rcp.Missing -> FText("Not found!", size = rem(0.8), weight = FontWeight.SemiBold, color = c.danger)
                Rcp.Error -> FText("Error", size = rem(0.8), weight = FontWeight.SemiBold, color = c.danger)
            }
        }

        TLabel("Amount (₹)")
        InputBox(amount, { amount = cleanAmount(it) }, Modifier.fillMaxWidth(), placeholder = "Min: ₹10", keyboardType = KeyboardType.Decimal)
        Spacer(Modifier.height(15.dp))
        TLabel("Note (Optional)")
        InputBox(note, { note = it }, Modifier.fillMaxWidth(), placeholder = "e.g. Gift")
        Spacer(Modifier.height(15.dp))

        // dashed divider + security password
        Box(
            Modifier.fillMaxWidth().padding(top = 5.dp).drawBehind {
                drawLine(c.border, Offset(0f, 0.5.dp.toPx()), Offset(size.width, 0.5.dp.toPx()), 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 3.dp.toPx())))
            }.padding(top = 15.dp),
        ) {
            Column(Modifier.fillMaxWidth()) {
                TLabel("Security Password *")
                InputBox(pass, { pass = it }, Modifier.fillMaxWidth(), placeholder = "Enter App Password", password = true)
            }
        }
        Spacer(Modifier.height(15.dp))
        BtnMain("Confirm & Send", { AppStore.toast("Transfers are currently unavailable. Please contact support for help.") }, Modifier.fillMaxWidth().padding(top = 15.dp))
    }
}

@Composable
private fun TLabel(t: String) {
    FText(t, size = rem(0.8), color = FF.c.textMuted, modifier = Modifier.fillMaxWidth().padding(bottom = 5.dp))
}
