package com.ffcashbattle.app.ui.shell

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.ffcashbattle.app.data.Cfg
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.state.WebTarget
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem

/**
 * Full-screen website page over the app: Proofs -> https://ffcashbattle.in/proof (also `?share=<trxId>`).
 *
 * The proof page lives on the website, so this is the one place the app shows web content. Going "back" to the website root
 * (the page's own back arrow / "Open app" button) closes the overlay and returns to the native app.
 * Android back: web history first, then close.
 */
@Composable
fun WebOverlay() {
    val target = AppStore.web
    // keep the last target while the slide-out animation runs
    val last = remember { arrayOfNulls<WebTarget>(1) }
    if (target != null) last[0] = target
    AnimatedVisibility(
        visible = target != null,
        enter = slideInHorizontally(tween(300)) { it } + fadeIn(tween(200)),
        exit = slideOutHorizontally(tween(250)) { it } + fadeOut(tween(200)),
    ) {
        last[0]?.let { WebScreen(it) }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun WebScreen(t: WebTarget) {
    val c = FF.c
    var progress by remember { mutableFloatStateOf(0f) }
    var error by remember { mutableStateOf(false) }
    var web by remember { mutableStateOf<WebView?>(null) }

    BackHandler(enabled = AppStore.web != null) {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else AppStore.web = null
    }

    Box(Modifier.fillMaxSize().background(c.bgBody)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            // slim progress line (primary -> pink)
            Box(Modifier.fillMaxWidth().height(3.dp)) {
                if (progress in 0.01f..0.99f) Box(Modifier.fillMaxWidth(progress).height(3.dp).background(Brush.horizontalGradient(listOf(c.primary, Color(0xFFF43F5E)))))
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                            setBackgroundColor(if (c.isDark) 0xFF0B1020.toInt() else 0xFFF4F6FB.toInt())
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.databaseEnabled = true
                            settings.loadWithOverviewMode = true
                            settings.useWideViewPort = true
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            settings.mediaPlaybackRequiresUserGesture = true
                            settings.cacheMode = WebSettings.LOAD_DEFAULT
                            settings.userAgentString = settings.userAgentString + " FFCashBattleApp/1.0"
                            try { CookieManager.getInstance().setAcceptCookie(true) } catch (_: Exception) { }
                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) { progress = newProgress / 100f }
                            }
                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) { error = false }
                                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                    val u = request?.url ?: return false
                                    val host = u.host ?: ""
                                    val site = host == "ffcashbattle.in" || host == "www.ffcashbattle.in"
                                    if (site) {
                                        val path = (u.path ?: "").trimEnd('/')
                                        // website root / app page = "back to the app"
                                        if (path.isEmpty() || path == "/index.html") { AppStore.web = null; return true }
                                        return false
                                    }
                                    // links to other sites (Telegram, WhatsApp, YouTube...) open outside the app
                                    if (request.isForMainFrame) { AppStore.openUrl(u.toString()); return true }
                                    return false
                                }
                                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, err: WebResourceError?) {
                                    if (request?.isForMainFrame == true) error = true
                                }
                            }
                            web = this
                            loadUrl(t.url)
                        }
                    },
                    onRelease = { v -> try { v.stopLoading(); v.destroy() } catch (_: Exception) { }; web = null },
                )
                if (error) {
                    Column(
                        Modifier.fillMaxSize().background(c.bgBody).padding(30.dp),
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                    ) {
                        FaIcon("fa-solid fa-circle-xmark", rem(2.6).value.dp, c.danger)
                        FText("Could not load the page", size = rem(1.1), weight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 14.dp))
                        FText("Check your internet connection and try again.", size = rem(0.85), color = c.textMuted, align = TextAlign.Center, modifier = Modifier.padding(top = 6.dp, bottom = 18.dp))
                        BtnMain("Retry", onClick = { error = false; web?.reload() }, small = true, modifier = Modifier.width(160.dp))
                        BtnMain("Close", onClick = { AppStore.web = null }, small = true, modifier = Modifier.padding(top = 10.dp).width(160.dp), colors = listOf(c.textMuted, c.textMuted))
                    }
                }
            }
        }
    }
}
