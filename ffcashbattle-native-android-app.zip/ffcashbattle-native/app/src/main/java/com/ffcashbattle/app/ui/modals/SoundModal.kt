package com.ffcashbattle.app.ui.modals

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.Prefs
import com.ffcashbattle.app.data.Sfx
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem

private class SoundDef(val key: String, val icon: String, val label: String, val hint: String)

private val SOUNDS = listOf(
    SoundDef("app", "fa-solid fa-music", "Background Sound", "Slide fully left = OFF"),
    SoundDef("touch", "fa-solid fa-hand-pointer", "Touch Sound", "Only plays on bottom nav taps. Slide fully left = OFF"),
    SoundDef("withdrawal", "fa-solid fa-money-bill-wave", "Withdrawal Sound", "Slide fully left = OFF"),
    SoundDef("notification", "fa-regular fa-bell", "Notification Sound", "Slide fully left = OFF"),
    SoundDef("settings", "fa-solid fa-gear", "Settings Sound", "Plays when opening settings. Slide fully left = OFF"),
    SoundDef("clear", "fa-solid fa-trash-can", "Clear Sound", "Plays when clearing notifications. Slide fully left = OFF"),
)

/** `#modal-sound` — "Sound Settings": six volume sliders saved like the website's vol_* keys. */
@Composable
fun SoundModal() {
    val c = FF.c
    val close = LocalSheetClose.current
    ModalSheet {
        Row(Modifier.fillMaxWidth().padding(bottom = 20.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.tap { close() }) { FaIcon("fa-solid fa-arrow-left", rem(1.2).value.dp, c.textMain) }
            FText("Sound Settings", size = rem(1.5), weight = FontWeight.Bold)
        }
        for (s in SOUNDS) SoundCard(s)
    }
}

@Composable
private fun SoundCard(s: SoundDef) {
    val c = FF.c
    var v by remember { mutableIntStateOf(Prefs.vol(s.key)) }
    Column(Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(14.dp)).background(c.bgInput).padding(15.dp)) {
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                FaIcon(s.icon, rem(1.0).value.dp, c.primary)
                FText(s.label, weight = FontWeight.Bold)
            }
            FText("$v%", weight = FontWeight.Bold, color = c.primary)
        }
        VolumeSlider(v) { nv ->
            if (nv != v) {
                v = nv
                Prefs.setVol(s.key, nv)
                // like setSound(): touch / settings / clear play a sample while dragging
                if (nv > 0 && (s.key == "touch" || s.key == "settings" || s.key == "clear")) Sfx.play(s.key)
            }
        }
        FText(s.hint, size = rem(0.7), color = c.textMuted, modifier = Modifier.padding(top = 5.dp))
    }
}

/** `<input type=range>` look (Chrome Android): thin track, blue fill, round thumb. */
@Composable
private fun VolumeSlider(value: Int, onChange: (Int) -> Unit) {
    val c = FF.c
    var w by remember { mutableFloatStateOf(1f) }
    val cb by rememberUpdatedState(onChange)
    val accent = Color(0xFF0075FF)
    val trackBg = if (c.isDark) Color(0xFF475569) else Color(0xFFB3B3B3)
    Box(
        Modifier.fillMaxWidth().height(22.dp)
            .onSizeChanged { w = it.width.toFloat() }
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    val r = 8.dp.toPx()
                    cb((((o.x - r) / (w - 2 * r)).coerceIn(0f, 1f) * 100f).toInt().coerceIn(0, 100))
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures { ch, _ ->
                    val r = 8.dp.toPx()
                    cb((((ch.position.x - r) / (w - 2 * r)).coerceIn(0f, 1f) * 100f).toInt().coerceIn(0, 100))
                    ch.consume()
                }
            }
            .drawBehind {
                val r = 8.dp.toPx()
                val th = 4.dp.toPx()
                val x = r + (size.width - 2 * r) * (value / 100f)
                val cy = size.height / 2f
                drawRoundRect(trackBg, Offset(0f, cy - th / 2), Size(size.width, th), CornerRadius(th / 2))
                drawRoundRect(accent, Offset(0f, cy - th / 2), Size(x, th), CornerRadius(th / 2))
                drawCircle(accent, r, Offset(x, cy))
            },
    )
}
