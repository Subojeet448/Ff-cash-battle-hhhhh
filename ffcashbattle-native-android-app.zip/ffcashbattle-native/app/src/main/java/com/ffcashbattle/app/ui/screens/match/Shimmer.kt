package com.ffcashbattle.app.ui.screens.match

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.ui.theme.FF

/** `.skeleton-anim`: sliding #f1f5f9 / #e2e8f0 shimmer (dark: bg-input / border). */
@Composable
fun shimmerBrush(): Brush {
    val c = FF.c
    val inf = rememberInfiniteTransition(label = "shimmer")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Restart), label = "t")
    val a = if (c.isDark) c.bgInput else Color(0xFFF1F5F9)
    val b = if (c.isDark) c.border else Color(0xFFE2E8F0)
    val w = 700f
    val x = -w + 2f * w * t
    return Brush.horizontalGradient(listOf(a, b, a), startX = x, endX = x + w)
}

@Composable
fun Skel(modifier: Modifier, radius: Dp = 8.dp) {
    Box(modifier.clip(RoundedCornerShape(radius)).background(shimmerBrush()))
}

/** `.sk-card` placeholder shown while matches are loading. */
@Composable
fun MatchSkeleton() {
    val c = FF.c
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 25.dp).height(260.dp)
            .clip(shape).background(if (c.isDark) c.bgCard else Color.White).border(1.dp, c.border, shape),
    ) {
        Skel(Modifier.fillMaxWidth().height(140.dp), 0.dp)
        Column(Modifier.padding(15.dp)) {
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                repeat(3) { Skel(Modifier.weight(1f).height(50.dp), 12.dp) }
            }
            Box(Modifier.fillMaxWidth().padding(bottom = 8.dp)) { Skel(Modifier.fillMaxWidth(0.6f).height(10.dp), 5.dp) }
            Box(Modifier.fillMaxWidth().padding(top = 10.dp)) { Skel(Modifier.fillMaxWidth().height(45.dp), 12.dp) }
        }
    }
}
