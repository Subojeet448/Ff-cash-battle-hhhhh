package com.ffcashbattle.app.ui.modals

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.data.Msg
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Payload for `modal-wd-success` (website `app.showWithdrawSuccess(amount, {method, net, ref})`). */
class WdSuccessInfo(val amount: Double, val method: String, val net: Double, val ref: String)

private fun fmt2(v: Double) = String.format(Locale.US, "%.2f", v)

/** Website `#modal-wd-success`: tick, amounts, 3-step progress, auto-closes after 8 seconds. */
@Composable
fun WdSuccessModal() {
    val c = FF.c
    val info = AppStore.modalArg as? WdSuccessInfo
    if (info == null) { LaunchedEffect(Unit) { AppStore.closeModal() }; return }
    val gp = info.method == "GIFTCARD"
    val now = remember { Date() }
    val df = remember { SimpleDateFormat("dd MMM yyyy", Locale("en", "IN")) }
    val today = remember { df.format(now) }
    val eta = if (gp) "Within 15 – 20 min" else today + " - " + df.format(Date(now.time + 3L * 24 * 60 * 60 * 1000))
    // English-only display name (non-ASCII stripped), exactly like the website
    val name = remember {
        val raw = AppStore.user.s("appName").ifEmpty { AppStore.user.s("name") }.ifEmpty { "Player" }
        raw.filter { it.code in 0x20..0x7E }.trim().ifEmpty { "Player" }
    }
    val body = if (gp) Msg.withdraw.gpPopupBody(info.amount) else Msg.withdraw.popupBody(info.amount, info.net, Doc("", mapOf("method" to info.method)))
    val foot = if (gp) Msg.withdraw.gpPopupFoot() else Msg.withdraw.popupFoot()

    ModalSheet(handle = false, center = true, centerWidth = 340.dp, padding = PaddingValues(horizontal = 25.dp, vertical = 30.dp)) {
        val close = LocalSheetClose.current
        LaunchedEffect(Unit) { delay(8000); close() }

        // .wd-tick  (tick-pop .45s)
        val pop = remember { Animatable(0f) }
        LaunchedEffect(Unit) { pop.animateTo(1f, tween(450, easing = CubicBezierEasing(0.2f, 1.4f, 0.4f, 1f))) }
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(
                Modifier.graphicsLayer { scaleX = pop.value; scaleY = pop.value }
                    .boxShadow(24.dp, Color(0x5910B981), CircleShape)
                    .size(84.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF059669)))),
                contentAlignment = Alignment.Center,
            ) { FaIcon("fa-solid fa-check", rem(2.4).value.dp, Color.White) }
        }
        FText(
            Msg.withdraw.popupTitle(), size = rem(1.3), weight = FontWeight.Black, color = c.success, align = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 6.dp),
        )
        FText("Hi $name, you're all set!", size = rem(1.0), weight = FontWeight.Bold, align = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp))
        FText(
            body, size = rem(0.92), color = c.textMuted, lineHeight = rem(0.92) * 1.55f, align = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 18.dp),
        )

        // detail box
        Column(Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(14.dp)).background(c.bgInput).padding(14.dp)) {
            SRow("Amount", "₹" + fmt2(info.amount), FontWeight.ExtraBold)
            SRow("You will receive", "₹" + fmt2(info.net), FontWeight.ExtraBold, c.success, note = "(after ₹2 fee)")
            SRow("Method", if (gp) "Google Play Gift Card" else "UPI", FontWeight.Bold)
            SRow("Reference ID", info.ref.ifEmpty { "--" }, FontWeight.ExtraBold, mono = true)
            SRow("Request Date", today, FontWeight.Bold)
            SRow("Expected By", eta, FontWeight.Bold, c.success, last = true)
        }

        // .wd-steps
        Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Step("fa-solid fa-check", "Request received", 2, Modifier.weight(1f), last = false)
            Step("fa-solid fa-hourglass-half", "Under review", 1, Modifier.weight(1f), last = false)
            Step("fa-solid fa-paper-plane", "Money sent", 0, Modifier.weight(1f), last = true)
        }

        FText(
            foot, size = rem(0.78), color = c.textMuted, lineHeight = rem(0.78) * 1.5f, align = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 16.dp),
        )
        BtnMain("Done", { close() }, Modifier.fillMaxWidth())
    }
}

@Composable
private fun SRow(label: String, value: String, weight: FontWeight, color: Color = FF.c.textMain, mono: Boolean = false, note: String? = null, last: Boolean = false) {
    val c = FF.c
    Row(Modifier.fillMaxWidth().padding(bottom = if (last) 0.dp else 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            FText(label, size = rem(0.85), color = c.textMuted)
            if (note != null) FText(" $note", size = rem(0.85) * 0.833f, color = c.textMuted)
        }
        FText(value, size = rem(0.85), weight = weight, color = color, mono = mono, letterSpacing = if (mono) 0.5.sp else 0.sp, align = TextAlign.End, modifier = Modifier.padding(start = 8.dp))
    }
}

/** `.wd-step`: state 2 = done (green), 1 = now (amber, pulsing), 0 = todo. A connector runs to the next step. */
@Composable
private fun Step(icon: String, label: String, state: Int, modifier: Modifier, last: Boolean) {
    val c = FF.c
    val tone = if (state == 2) c.success else if (state == 1) c.warning else c.textMuted
    // fx-pulse-dot: 0%,100% scale 1 / opacity 1  ->  50% scale 1.35 / opacity .6
    val t = rememberInfiniteTransition(label = "wdPulse").animateFloat(
        0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart), label = "p",
    ).value
    val tri = 1f - kotlin.math.abs(2f * t - 1f)
    val ps = if (state == 1) 1f + 0.35f * tri else 1f
    val pa = if (state == 1) 1f - 0.4f * tri else 1f
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.fillMaxWidth().height(30.dp), contentAlignment = Alignment.Center) {
            if (!last) {
                // connector: from the circle's right edge (+3) to the next one: width = 100% - 34, left = 50% + 17
                Box(Modifier.fillMaxWidth().height(2.dp), contentAlignment = Alignment.CenterEnd) {
                    Box(Modifier.fillMaxWidth(0.5f).height(2.dp).background(if (state == 2) c.success else c.border))
                }
            }
            Box(
                Modifier.graphicsLayer { scaleX = ps; scaleY = ps; alpha = pa }
                    .size(30.dp).clip(CircleShape)
                    .background(if (state == 2) c.success else c.bgInput)
                    .border(2.dp, if (state == 2) c.success else if (state == 1) c.warning else c.border, CircleShape),
                contentAlignment = Alignment.Center,
            ) { FaIcon(icon, rem(0.75).value.dp, if (state == 2) Color.White else tone) }
        }
        FText(label, size = rem(0.68), weight = FontWeight.Bold, color = tone, align = TextAlign.Center)
    }
}
