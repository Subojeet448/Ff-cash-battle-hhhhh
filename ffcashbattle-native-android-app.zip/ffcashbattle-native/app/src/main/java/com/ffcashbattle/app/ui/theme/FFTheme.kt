package com.ffcashbattle.app.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.R

/**
 * Design tokens copied 1:1 from the website (css/base/variables.css + css/themes/dark.css).
 * The website's root font-size is 14px, so 1rem = 14 dp/sp here: use rem() / remDp() when a CSS value is in rem.
 */
@Immutable
class FFColors(
    val bgBody: Color, val bgCard: Color, val bgInput: Color,
    val primary: Color, val primaryDark: Color, val primaryLight: Color,
    val accent: Color, val textMain: Color, val textMuted: Color,
    val success: Color, val warning: Color, val danger: Color,
    val border: Color, val isDark: Boolean,
)

val LightFF = FFColors(
    bgBody = Color(0xFFF4F6FB), bgCard = Color(0xFFFFFFFF), bgInput = Color(0xFFEEF1F8),
    primary = Color(0xFF4F46E5), primaryDark = Color(0xFF3730A3), primaryLight = Color(0xFFE0E7FF),
    accent = Color(0xFFF43F5E), textMain = Color(0xFF0F172A), textMuted = Color(0xFF64748B),
    success = Color(0xFF10B981), warning = Color(0xFFF59E0B), danger = Color(0xFFEF4444),
    border = Color(0xFFE3E8F2), isDark = false,
)

val DarkFF = FFColors(
    bgBody = Color(0xFF0B1020), bgCard = Color(0xFF151C32), bgInput = Color(0xFF1F2847),
    primary = Color(0xFF6366F1), primaryDark = Color(0xFF4338CA), primaryLight = Color(0x386366F1),
    accent = Color(0xFFF43F5E), textMain = Color(0xFFE8ECF7), textMuted = Color(0xFF8B97B8),
    success = Color(0xFF10B981), warning = Color(0xFFF59E0B), danger = Color(0xFFEF4444),
    border = Color(0xFF27304F), isDark = true,
)

val LocalFF = staticCompositionLocalOf { LightFF }

/** Usage: FF.c.primary */
object FF {
    val c: FFColors
        @Composable @ReadOnlyComposable get() = LocalFF.current
}

/** Inter, the website's font (weights 400-900). */
val Inter = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
    Font(R.font.inter_extrabold, FontWeight.ExtraBold),
    Font(R.font.inter_black, FontWeight.Black),
)

/** CSS rem -> sp (html font-size is 14px on the website). */
fun rem(v: Float): TextUnit = (v * 14f).sp
fun rem(v: Double): TextUnit = (v * 14.0).sp

/** CSS rem -> dp. */
fun remDp(v: Float): Dp = (v * 14f).dp
fun remDp(v: Double): Dp = (v * 14.0).dp

/** Some brand colours the website hard-codes. */
object Brand {
    val gold = Color(0xFFFFC426)
    val verifiedBlue = Color(0xFF1D9BF0)
    val whatsappBg = Color(0xFFDCFCE7)
    val whatsappFg = Color(0xFF16A34A)
    val pink = Color(0xFFEC4899)
}

@Composable
fun FFTheme(dark: Boolean, content: @Composable () -> Unit) {
    // The website ignores the phone's font-size setting (CSS px), so the app does the same to stay pixel-identical.
    val base = LocalDensity.current
    CompositionLocalProvider(
        LocalFF provides (if (dark) DarkFF else LightFF),
        LocalDensity provides Density(base.density, fontScale = 1f),
    ) { content() }
}
