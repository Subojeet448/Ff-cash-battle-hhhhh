package com.ffcashbattle.app.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Base64
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.ByteArrayOutputStream

/** Small image helpers: the website keeps profile photos as `data:image/jpeg;base64,…` strings in Firestore. */
object Img {
    private val cache = object : LruCache<String, ImageBitmap>(24) {}

    /** Decodes a `data:` URL (cached). Null when it is not a valid base64 image. */
    fun fromDataUrl(url: String): ImageBitmap? {
        cache.get(url)?.let { return it }
        return try {
            val b64 = url.substringAfter("base64,", "")
            if (b64.isEmpty()) return null
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap() ?: return null
            cache.put(url, bmp); bmp
        } catch (_: Exception) { null }
    }

    /** Result of [squarePhoto]: either the data URL or an error text for the user. */
    class Photo(val dataUrl: String?, val error: String?)

    /**
     * Website `handleImageUpload`: any image is centre-cropped to 320x320, JPEG-compressed (< ~60 KB of base64) and returned as a data URL.
     * Call from a background dispatcher.
     */
    fun squarePhoto(ctx: android.content.Context, uri: Uri): Photo {
        val cr = ctx.contentResolver
        val type = cr.getType(uri) ?: ""
        if (type.isNotEmpty() && !type.startsWith("image/")) return Photo(null, "Please select an image file (JPG or PNG).")
        try {
            val size = cr.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
            if (size > 10L * 1024 * 1024) return Photo(null, "This image is too large. Please choose one under 10 MB.")
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return Photo(null, "This image could not be loaded. Please try another one.")
            var sample = 1
            while (minOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 320) sample *= 2
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
                ?: return Photo(null, "This image could not be loaded. Please try another one.")
            // honour the EXIF rotation like a browser does
            val rot = try {
                cr.openInputStream(uri)?.use {
                    when (android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                        android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } ?: 0f
            } catch (_: Exception) { 0f }
            if (rot != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot) }, true)
            val m = minOf(bmp.width, bmp.height)
            val sq = Bitmap.createBitmap(bmp, (bmp.width - m) / 2, (bmp.height - m) / 2, m, m)
            val out320 = Bitmap.createScaledBitmap(sq, 320, 320, true)
            var q = 85
            var url = encode(out320, q)
            while (url.length > 60000 && q > 40) { q -= 10; url = encode(out320, q) }
            if (url.length > 90000) return Photo(null, "We could not process this image. Please try a different one.")
            return Photo(url, null)
        } catch (_: Throwable) {
            return Photo(null, "This image could not be loaded. Please try another one.")
        }
    }

    private fun encode(b: Bitmap, q: Int): String {
        val bos = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, q, bos)
        return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }
}
