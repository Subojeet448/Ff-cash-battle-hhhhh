package com.ffcashbattle.app.ui.modals.notif

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.Msg
import com.ffcashbattle.app.data.NotifItem
import com.ffcashbattle.app.ui.comp.CoinAmount
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.GiftCodeBox
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay
import java.util.Locale

/** The icon + colour tone the website picks from the notification text (`look()` in notifications.js). */
class NfLook(val icon: String, val color: Color, val soft: Color)

private val PRIMARY_SOFT = Color(0x1F4F46E5)
private fun tone(color: Long, softAlpha: Float) = Pair(Color(color), Color(color).copy(alpha = softAlpha))

fun nfLook(n: NotifItem): NfLook {
    val t = (n.title + " " + n.message).lowercase()
    fun mk(icon: String, color: Long, a: Float) = NfLook(icon, Color(color), Color(color).copy(alpha = a))
    return when {
        n.claimAmount > 0 || n.scratchCard.isNotEmpty() -> mk("fa-gift", 0xFF7C3AED, 0.14f)
        n.giftCode.isNotEmpty() -> mk("fa-gift", 0xFF10B981, 0.14f)
        Regex("refund|returned|reversed").containsMatchIn(t) -> mk("fa-rotate-left", 0xFF3B82F6, 0.14f)
        Regex("withdraw").containsMatchIn(t) -> mk("fa-arrow-up-from-bracket", 0xFFF59E0B, 0.15f)
        Regex("deposit|credited|added to your").containsMatchIn(t) -> mk("fa-wallet", 0xFF10B981, 0.14f)
        Regex("not verified|could not|failed|rejected|banned").containsMatchIn(t) -> mk("fa-triangle-exclamation", 0xFFEF4444, 0.13f)
        Regex("match|room|prize|won|winner|kills|tournament").containsMatchIn(t) -> mk("fa-trophy", 0xFFF59E0B, 0.15f)
        else -> NfLook("fa-bell", Color(0xFF4F46E5), PRIMARY_SOFT)
    }
}

fun nfAgo(ms: Long): String {
    if (ms <= 0) return ""
    val s = maxOf(0L, (System.currentTimeMillis() - ms) / 1000)
    return when {
        s < 60 -> "Just now"
        s < 3600 -> "${s / 60}m ago"
        s < 86400 -> "${s / 3600}h ago"
        s < 604800 -> "${s / 86400}d ago"
        else -> ""
    }
}

fun nfWhen(n: NotifItem): String {
    val rel = nfAgo(n.ms)
    return if (rel.isNotEmpty()) (if (n.date.isNotEmpty()) "$rel · ${n.date}" else rel) else n.date
}

// ------------------------------------------------------------------------------------------ card wrappers (animation)

/** Entrance (nf-in: slide 26 from the right + scale .97) and exit (nf-out: fly left, rotate -3, shrink) wrapper. */
@Composable
private fun CardMotion(cardId: String, outIndex: Int?, content: @Composable () -> Unit) {
    val enter = remember(cardId) { Animatable(0f) }
    LaunchedEffect(cardId) { enter.animateTo(1f, tween(500, easing = CubicBezierEasing(0.2f, 1f, 0.2f, 1f))) }
    val exit = remember(cardId) { Animatable(0f) }
    LaunchedEffect(outIndex) {
        if (outIndex != null) { delay(outIndex * 55L); exit.animateTo(1f, tween(450, easing = CubicBezierEasing(0.55f, 0f, 0.8f, 0.3f))) }
    }
    Box(
        Modifier.graphicsLayer {
            val e = enter.value; val x = exit.value
            alpha = e * (1f - x)
            translationX = (1f - e) * 26.dp.toPx() - 70.dp.toPx() * x
            rotationZ = -3f * x
            val sc = (0.97f + 0.03f * e) * (1f - 0.1f * x)
            scaleX = sc; scaleY = sc
        },
    ) { content() }
}

/** `.nf-x` — small red delete button in the top-right corner of a card. */
@Composable
private fun DeleteX(modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.size(26.dp).clip(CircleShape).background(Color(0x1FEF4444)).tap { onClick() }, contentAlignment = Alignment.Center) {
        FaIcon("fa-solid fa-xmark", rem(0.78).value.dp, Color(0xFFEF4444))
    }
}

@Composable
private fun DateLine(text: String) {
    val c = FF.c
    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
        FaIcon("fa-regular fa-clock", rem(0.7).value.dp, c.textMuted.copy(alpha = 0.8f))
        FText(text, size = rem(0.7), weight = FontWeight.SemiBold, color = c.textMuted.copy(alpha = 0.8f))
    }
}

@Composable
private fun NewBadge() {
    val inf = rememberInfiniteTransition(label = "badge")
    val s by inf.animateFloat(1f, 1.08f, infiniteRepeatable(tween(1000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bs")
    Box(
        Modifier.graphicsLayer { scaleX = s; scaleY = s }.clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(FF.c.primary, Color(0xFFF43F5E)))).padding(horizontal = 8.dp, vertical = 3.dp),
    ) { FText("NEW", size = rem(0.6), weight = FontWeight.Black, color = Color.White, letterSpacing = 0.5.sp) }
}

@Composable
private fun ClaimButton(text: String, icon: String, enabled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(
        modifier.fillMaxWidth().graphicsLayer { alpha = if (enabled) 1f else 0.6f }
            .then(if (enabled) Modifier.boxShadow(18.dp, Color(0x80F43F5E), RoundedCornerShape(12.dp)) else Modifier)
            .press(0.97f, enabled) { onClick() }
            .clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Color(0xFF4F46E5), Color(0xFFF43F5E)))).padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically,
    ) {
        FaIcon(icon, rem(1.0).value.dp, Color.White)
        FText(text, weight = FontWeight.ExtraBold, color = Color.White)
    }
}

// ------------------------------------------------------------------------------------------ notification card

@Composable
fun NotifCard(
    n: NotifItem, outIndex: Int?, target: Boolean,
    onOpen: () -> Unit, onDelete: () -> Unit, onScratch: () -> Unit,
) {
    val c = FF.c
    val lk = nfLook(n)
    val shape = RoundedCornerShape(16.dp)
    CardMotion(n.key, outIndex) {
        Box(
            Modifier.fillMaxWidth().padding(bottom = 10.dp)
                .boxShadow(if (c.isDark) 14.dp else 10.dp, if (c.isDark) Color(0x59000000) else Color(0x0D0F172A), shape)
                .press(0.985f) { onOpen() }
                .clip(shape).background(c.bgCard)
                .drawBehind { drawRect(lk.color, size = Size(4.dp.toPx(), size.height)) }
                .border(if (target) 2.dp else 1.dp, if (target) Color(0xFFEF4444) else if (n.fresh) lk.color else c.border, shape),
        ) {
            Row(Modifier.padding(start = 14.dp, top = 14.dp, bottom = 14.dp, end = 44.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.padding(start = 4.dp).size(38.dp).clip(RoundedCornerShape(12.dp)).background(lk.soft), contentAlignment = Alignment.Center) {
                    FaIcon("fa-solid ${lk.icon}", rem(1.0).value.dp, lk.color)
                }
                Column(Modifier.weight(1f)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                        FText(n.title, size = rem(0.92), weight = FontWeight.ExtraBold, lineHeight = rem(0.92) * 1.3f, modifier = Modifier.weight(1f).padding(bottom = 3.dp))
                        if (n.fresh) NewBadge()
                    }
                    FText(n.message.ifEmpty { Msg.notif.emptyBody() }, size = rem(0.82), color = c.textMuted, lineHeight = rem(0.82) * 1.5f)
                    if (n.giftCode.isNotEmpty()) GiftCodeBox(n.giftCode)
                    if (n.scratchCard.isNotEmpty()) ClaimButton("Scratch now", "fa-solid fa-hand-pointer", modifier = Modifier.padding(top = 8.dp)) { onScratch() }
                    DateLine(nfWhen(n))
                }
            }
            DeleteX(Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 8.dp)) { onDelete() }
        }
    }
}

/** `.claim-card` — reward notification with amount + Claim button (shine sweep + floating gift icon). */
@Composable
fun ClaimCard(
    n: NotifItem, outIndex: Int?, target: Boolean, busy: Boolean,
    onDelete: () -> Unit, onClaim: () -> Unit,
) {
    val c = FF.c
    val shape = RoundedCornerShape(18.dp)
    val inf = rememberInfiniteTransition(label = "claim")
    val shine by inf.animateFloat(-1.3f, 2.4f, infiniteRepeatable(tween(4000, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "shine")
    val float by inf.animateFloat(0f, -4f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "float")
    CardMotion(n.key, outIndex) {
        Box(
            Modifier.fillMaxWidth().padding(bottom = 12.dp)
                .boxShadow(24.dp, Color(0x594F46E5), shape)
                .clip(shape)
                .background(Brush.linearGradient(if (c.isDark) listOf(Color(0xFF1E1B4B), Color(0xFF3B0764)) else listOf(Color(0xFFEEF2FF), Color(0xFFFDF2F8))))
                .border(if (target) 2.dp else 1.dp, if (target) Color(0xFFEF4444) else c.primary, shape)
                .drawBehind {
                    val w = size.width * 0.35f
                    val x = size.width * shine
                    drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = if (c.isDark) 0.12f else 0.55f), Color.Transparent), startX = x, endX = x + w), Offset(x, 0f), Size(w, size.height))
                },
        ) {
            Column(Modifier.padding(start = 16.dp, top = 16.dp, bottom = 16.dp, end = 44.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.offset(y = float.dp).size(36.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(c.primary, Color(0xFFF43F5E)))),
                        contentAlignment = Alignment.Center,
                    ) { FaIcon("fa-solid fa-gift", rem(1.0).value.dp, Color.White) }
                    FText(n.title, size = rem(0.92), weight = FontWeight.ExtraBold, lineHeight = rem(0.92) * 1.3f, modifier = Modifier.weight(1f))
                }
                CoinAmount(String.format(Locale.US, "%.2f", n.claimAmount), size = rem(1.7), weight = FontWeight.Black, color = c.primary, coinSize = 22.dp, modifier = Modifier.padding(top = 6.dp, bottom = 10.dp))
                FText(n.message.ifEmpty { Msg.notif.claimBody() }, size = rem(0.82), color = c.textMuted, lineHeight = rem(0.82) * 1.5f, modifier = Modifier.padding(bottom = 12.dp))
                if (n.claimed) ClaimButton("Claimed", "fa-solid fa-check", enabled = false) { }
                else ClaimButton(if (busy) "..." else "Claim ₹" + String.format(Locale.US, "%.2f", n.claimAmount), if (busy) "fa-solid fa-spinner" else "fa-solid fa-hand-holding-dollar", enabled = !busy) { onClaim() }
                DateLine(nfWhen(n))
            }
            DeleteX(Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 8.dp)) { onDelete() }
        }
    }
}

// ------------------------------------------------------------------------------------------ skeleton / empty / failed

@Composable
fun NotifSkeletons() {
    val c = FF.c
    val inf = rememberInfiniteTransition(label = "skel")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart), label = "t")
    val brush = Brush.horizontalGradient(
        listOf(c.bgInput, c.border, c.bgInput),
        startX = -400f + 1200f * t, endX = 400f + 1200f * t,
    )
    repeat(3) {
        Row(
            Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(16.dp)).background(c.bgCard)
                .border(1.dp, c.border, RoundedCornerShape(16.dp)).padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(brush))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.fillMaxWidth(0.55f).height(12.dp).clip(RoundedCornerShape(8.dp)).background(brush))
                Box(Modifier.fillMaxWidth(0.9f).height(10.dp).clip(RoundedCornerShape(8.dp)).background(brush))
            }
        }
    }
}

@Composable
fun NotifEmpty(failed: Boolean) {
    val c = FF.c
    val inf = rememberInfiniteTransition(label = "empty")
    val ring1 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart), label = "r1")
    val ring2 by inf.animateFloat(-0.5f, 0.5f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart), label = "r2")
    val shake by inf.animateFloat(-8f, 8f, infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "shake")
    Column(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 34.dp, bottom = 22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(
            Modifier.padding(bottom = 12.dp).size(84.dp).clip(CircleShape).background(if (c.isDark) Color(0x334F46E5) else c.primaryLight)
                .drawBehind {
                    for (p in listOf(ring1, if (ring2 < 0f) ring2 + 1f else ring2)) {
                        val s = 1f + 0.7f * p
                        drawCircle(c.primary.copy(alpha = 0.5f * (1f - p)), radius = size.minDimension / 2f * s, style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            FaIcon(if (failed) "fa-solid fa-wifi" else "fa-regular fa-bell", rem(2.0).value.dp, c.primary, Modifier.graphicsLayer { rotationZ = if (failed) 0f else shake })
        }
        FText(if (failed) Msg.notif.loadFailed() else Msg.notif.emptyTitle(), size = rem(1.05), weight = FontWeight.ExtraBold, align = TextAlign.Center)
        if (!failed) FText(Msg.notif.emptySub(), size = rem(0.82), color = c.textMuted, align = TextAlign.Center, lineHeight = rem(0.82) * 1.5f, modifier = Modifier.widthIn(max = 240.dp))
    }
}

// ------------------------------------------------------------------------------------------ detail card

/** `.nf-detail` — big card shown when a notification is tapped. */
@Composable
fun NotifDetail(n: NotifItem, onClose: () -> Unit, onDelete: () -> Unit, onScratch: () -> Unit) {
    val c = FF.c
    val lk = nfLook(n)
    val pop = remember { Animatable(0f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, tween(450, easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f))) }
    val cardShape = RoundedCornerShape(24.dp)
    Box(Modifier.fillMaxSize().background(Color(0x8C0F172A)).tap { onClose() }.padding(18.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier.fillMaxWidth().padding(top = 34.dp)
                .graphicsLayer {
                    alpha = minOf(1f, pop.value * 2f)
                    translationY = (1f - pop.value) * 30.dp.toPx()
                    val s = 0.9f + 0.1f * pop.value
                    scaleX = s; scaleY = s
                },
        ) {
            Box(Modifier.fillMaxWidth().boxShadow(60.dp, Color(0x59000000), cardShape).clip(cardShape).background(c.bgCard).tap { }) {
                Column(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 48.dp, bottom = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    FText(n.title, size = rem(1.1), weight = FontWeight.Black, align = TextAlign.Center, modifier = Modifier.padding(bottom = 8.dp))
                    Column(Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState())) {
                        FText(n.message, size = rem(0.9), color = c.textMuted, lineHeight = rem(0.9) * 1.6f, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                    if (n.giftCode.isNotEmpty()) GiftCodeBox(n.giftCode)
                    if (n.scratchCard.isNotEmpty()) ClaimButton("Scratch now", "fa-solid fa-hand-pointer", modifier = Modifier.padding(top = 8.dp)) { onScratch() }
                    Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                        FaIcon("fa-regular fa-clock", rem(0.72).value.dp, c.textMuted)
                        FText(nfWhen(n), size = rem(0.72), color = c.textMuted)
                    }
                    Row(
                        Modifier.padding(top = 16.dp).press(0.93f) { onDelete() }.clip(RoundedCornerShape(30.dp)).background(Color(0x1FEF4444)).padding(horizontal = 22.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
                    ) {
                        FaIcon("fa-solid fa-trash-can", rem(1.0).value.dp, Color(0xFFEF4444))
                        FText("Delete", weight = FontWeight.ExtraBold, color = Color(0xFFEF4444))
                    }
                }
                Box(Modifier.align(Alignment.TopEnd).padding(10.dp).size(32.dp).clip(CircleShape).background(c.bgInput).tap { onClose() }, contentAlignment = Alignment.Center) {
                    FaIcon("fa-solid fa-xmark", rem(1.0).value.dp, c.textMuted)
                }
            }
            // icon circle overlapping the card top (not clipped by the card)
            Box(
                Modifier.align(Alignment.TopCenter).offset(y = (-34).dp)
                    .graphicsLayer { val s = pop.value; scaleX = s; scaleY = s }
                    .boxShadow(26.dp, lk.color.copy(alpha = 0.6f), CircleShape).clip(CircleShape).size(68.dp)
                    .background(Brush.linearGradient(listOf(lk.color, c.primary))),
                contentAlignment = Alignment.Center,
            ) { FaIcon("fa-solid ${lk.icon}", rem(1.7).value.dp, Color.White) }
        }
    }
}
