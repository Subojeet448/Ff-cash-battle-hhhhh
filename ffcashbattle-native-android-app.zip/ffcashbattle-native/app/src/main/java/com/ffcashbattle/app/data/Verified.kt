package com.ffcashbattle.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.ffcashbattle.app.state.AppStore
import com.google.firebase.firestore.ListenerRegistration

/** Port of js/core/verified.js — blue-tick users live in config/verified { uids: [...] }; last list is cached for instant display. */
object Verified {
    var uids by mutableStateOf<Set<String>>(emptySet())
        private set
    private var reg: ListenerRegistration? = null

    fun load() {
        try {
            val raw = Prefs.str("ffcb_ver", "")
            if (raw.isNotEmpty()) uids = raw.split(",").filter { it.isNotEmpty() }.toSet()
        } catch (_: Exception) { }
    }

    fun has(uid: String?): Boolean =
        !uid.isNullOrEmpty() && (uid in uids || (uid == AppStore.uid && AppStore.user.b("isVerified")))

    fun start() {
        if (reg != null) return
        try {
            reg = Repo.listenDoc("config", "verified") { d, _ ->
                val set = (d?.strList("uids") ?: emptyList()).toSet()
                uids = set
                try { Prefs.put("ffcb_ver", set.take(500).joinToString(",")) } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
    }

    fun stop() { try { reg?.remove() } catch (_: Exception) { }; reg = null }
}
