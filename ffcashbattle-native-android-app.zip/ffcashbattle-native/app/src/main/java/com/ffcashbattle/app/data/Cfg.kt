package com.ffcashbattle.app.data

/** One place for fixed settings (copied from the website: js/core/firebase.js, js/core/app-config.js). */
object Cfg {
    const val SITE = "https://ffcashbattle.in"
    const val PROOF_URL = "https://ffcashbattle.in/proof"
    const val TERMS_URL = "https://ffcashbattle.in/terms"

    // Main Firebase project (same one the website uses)
    const val API_KEY = "AIzaSyA1DJ5TQaK8HxasfTwKHNTxgNPHRCy4KRY"
    const val APP_ID = "1:461449506021:web:93cab101e9d382f8a2f80c"
    const val PROJECT_ID = "tournament-e8da7"
    const val STORAGE_BUCKET = "tournament-e8da7.firebasestorage.app"
    const val SENDER_ID = "461449506021"

    /** Coin Battle game server (Main Admin Panel on Render). */
    const val GAME_SERVER = "https://admin-panel-v1.onrender.com"
    const val GAME_API = "https://admin-panel-v1.onrender.com/api/ball"

    /**
     * Chat. The website currently runs chat inside the MAIN project (CHAT_TOKEN_URL = ""), so the app does the same.
     * To move chat to the separate chat project (tournament2-75029) put the token URL here (e.g. "https://<admin>.onrender.com/api/chat/token").
     */
    const val CHAT_TOKEN_URL = ""
    const val CHAT_API_KEY = "AIzaSyBW8cLulCXc4zwBgs3xHJFF3GvafFRqA0A"
    const val CHAT_APP_ID = "1:505785259739:web:143cf42fca376e5cd21efe"
    const val CHAT_PROJECT_ID = "tournament2-75029"
    const val CHAT_TTL_HOURS = 24
    val chatSeparate: Boolean get() = CHAT_TOKEN_URL.isNotBlank()

    const val WA_FALLBACK = "https://wa.me/542336410897?text=Hello%20Help%20Needed"
    const val TG_FALLBACK = "https://t.me/Tec_guru_ji"
    const val MATCH_LIMIT = 40
}
