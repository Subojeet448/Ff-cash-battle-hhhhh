package com.ffcashbattle.app.ui.screens

import android.annotation.SuppressLint
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import com.ffcashbattle.app.data.Cfg
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.data.Repo
import com.ffcashbattle.app.data.Sfx
import com.ffcashbattle.app.data.Verified
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.screens.chat.Cx6366
import com.ffcashbattle.app.ui.screens.chat.CxViolet
import com.ffcashbattle.app.ui.screens.chat.CsBtn
import com.ffcashbattle.app.ui.screens.chat.cxRedBrush
import com.ffcashbattle.app.ui.screens.chat.easeOutExpo
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import com.google.firebase.Timestamp
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.util.Date

/**
 * Coin Battle / Bomb & Gems, full screen (website `ballGame.open()` / `bombGame.open()`).
 * The two game screens are the website's own pages (bundled in assets/site/pages/game). They run in a native
 * WebView host and talk to the app through [GameNative] (login token, wallet balance, live game updates, confirm,
 * deposit, close). The server (admin panel) runs every rule and all money, exactly like on the website.
 */
@Composable
fun GameOverlay() {
    val which = AppStore.gameOpen
    var last by remember { mutableStateOf("coin") }
    if (which != null) last = which
    AnimatedVisibility(
        which != null,
        enter = fadeIn(tween(350)) + scaleIn(tween(350, easing = easeOutExpo), initialScale = 1.03f),
        exit = fadeOut(tween(200)),
    ) { GameHost(last) }
}

private class GameConfirm(val id: Int, val title: String, val text: String, val yes: String, val no: String, val danger: Boolean)

private const val HOST = "appassets.androidplatform.net"

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun GameHost(which: String) {
    val c = FF.c
    val bg = if (which == "bomb") Color(0xFF1B1030) else if (c.isDark) Color(0xFF2A1D33) else Color(0xFFF1E4EC)
    var confirm by remember { mutableStateOf<GameConfirm?>(null) }
    val native = remember(which) { GameNative(which, c.isDark) { confirm = it } }

    DisposableEffect(native) { onDispose { native.release() } }

    BackHandler(true) {
        val cf = confirm
        if (cf != null) { confirm = null; native.answer(cf.id, false) }
        else native.back()
    }

    Box(Modifier.fillMaxSize().background(bg).tap { }) {
        AndroidView(
            factory = { ctx ->
                val loader = WebViewAssetLoader.Builder().setDomain(HOST).addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(ctx)).build()
                WebView(ctx).apply {
                    setBackgroundColor(bg.toArgb())
                    overScrollMode = View.OVER_SCROLL_NEVER
                    isVerticalScrollBarEnabled = false
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        mediaPlaybackRequiresUserGesture = false
                        allowFileAccess = false
                        allowContentAccess = false
                        setSupportZoom(false)
                        builtInZoomControls = false
                        textZoom = 100
                        mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        cacheMode = WebSettings.LOAD_DEFAULT
                    }
                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
                        // the game never navigates away; anything else is blocked
                        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = request.url.host != HOST
                        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                            AppStore.gameOpen = null
                            AppStore.toast("The game stopped unexpectedly. Please open it again.")
                            return true
                        }
                    }
                    native.web = this
                    addJavascriptInterface(native, "__ffNative")
                    loadUrl("https://$HOST/assets/site/pages/game/" + (if (which == "bomb") "bomb" else "coin") + ".html")
                }
            },
            modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        )
        val cf = confirm
        if (cf != null) ConfirmCard(cf) { ok -> confirm = null; native.answer(cf.id, ok) }
    }
}

// ---------------------------------------------------------------- confirm (website ui.confirm)
@Composable
private fun ConfirmCard(cf: GameConfirm, done: (Boolean) -> Unit) {
    val c = FF.c
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).tap { done(false) }, contentAlignment = Alignment.Center) {
        val shape = RoundedCornerShape(26.dp)
        Column(
            Modifier.padding(horizontal = 28.dp).widthIn(max = 340.dp).fillMaxWidth().boxShadow(50.dp, Color(0x66000000), shape).clip(shape).background(c.bgCard).tap { }.padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            val sh = RoundedCornerShape(20.dp)
            Box(
                Modifier.padding(bottom = 12.dp).size(58.dp).clip(sh).background(if (cf.danger) cxRedBrush() else Brush.linearGradient(listOf(Cx6366, CxViolet))),
                contentAlignment = Alignment.Center,
            ) { FaIcon(if (cf.danger) "fa-solid fa-triangle-exclamation" else "fa-solid fa-circle-question", rem(1.5).value.dp, Color.White) }
            FText(cf.title, Modifier.fillMaxWidth().padding(bottom = 6.dp), size = rem(1.08), weight = FontWeight.Black, align = TextAlign.Center)
            if (cf.text.isNotEmpty()) FText(cf.text, Modifier.fillMaxWidth().padding(bottom = 16.dp), size = rem(0.84), color = c.textMuted, lineHeight = rem(0.84) * 1.5f, align = TextAlign.Center)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CsBtn(cf.no, { done(false) }, Modifier.weight(1f), yes = false)
                CsBtn(cf.yes, { done(true) }, Modifier.weight(1f), yes = true, red = cf.danger)
            }
        }
    }
}

// ---------------------------------------------------------------- the Kotlin side of bridge.js
private class GameNative(private val which: String, private val dark: Boolean, private val onConfirm: (GameConfirm) -> Unit) {
    var web: WebView? = null
    private val scope: CoroutineScope get() = AppStore.scope
    private val watchers = HashMap<Int, ListenerRegistration>()

    private fun js(code: String) {
        val w = web ?: return
        w.post { try { w.evaluateJavascript(code, null) } catch (_: Exception) { } }
    }

    fun release() {
        synchronized(watchers) { watchers.values.forEach { try { it.remove() } catch (_: Exception) { } }; watchers.clear() }
        val w = web ?: return
        web = null
        w.post {
            try { w.removeJavascriptInterface("__ffNative"); w.stopLoading(); w.loadUrl("about:blank"); w.destroy() } catch (_: Exception) { }
        }
    }

    /** Hardware Back: the page decides (lobby -> close, running match -> asks "Leave the match?"). */
    fun back() {
        val w = web ?: run { AppStore.gameOpen = null; return }
        w.evaluateJavascript("(function(){try{return window.__ffBack?window.__ffBack():'none'}catch(e){return 'none'}})()") { r ->
            if (r != null && r.contains("none")) AppStore.toast("Use the buttons on the screen to leave")
        }
    }

    fun answer(id: Int, ok: Boolean) = js("window.__ffConfirm($id,$ok)")

    // ---- called from JavaScript (JavaBridge thread)
    @JavascriptInterface fun dark(): Boolean = dark
    @JavascriptInterface fun balance(): String = AppStore.user.n("balance").toString()
    @JavascriptInterface fun uid(): String = AppStore.uid ?: ""
    @JavascriptInterface fun verified(uid: String): Boolean = Verified.has(uid)
    @JavascriptInterface fun sfx(n: String) { Sfx.play(if (n == "clear" || n == "touch") n else "touch") }

    @JavascriptInterface fun me(): String {
        val d: Doc = AppStore.user
        val name = d.s("appName").ifEmpty { d.s("userName") }.ifEmpty { Repo.auth.currentUser?.displayName ?: "" }.ifEmpty { "Player" }
        val photo = d.s("photoUrl").ifEmpty { Repo.auth.currentUser?.photoUrl?.toString() ?: "" }
        return JSONObject().put("name", name).put("photo", photo).toString()
    }

    @JavascriptInterface fun api(id: Int, kind: String, path: String, body: String, ms: Int) {
        scope.launch(Dispatchers.IO) {
            var code = 0; var text = ""; var err = ""
            try {
                if (!Regex("^[A-Za-z0-9_/-]{1,60}$").matches(path)) throw IllegalArgumentException("Bad request")
                val u = Repo.auth.currentUser ?: throw IllegalStateException("Please log in first")
                val tok = u.getIdToken(false).await().token ?: ""
                val base = if (kind == "bomb") Cfg.GAME_API.replace(Regex("/api/ball$"), "/api/bomb") else Cfg.GAME_API
                val t = ms.coerceIn(3000, 120000)
                val conn = URL("$base/$path").openConnection() as HttpURLConnection
                try {
                    conn.requestMethod = "POST"; conn.connectTimeout = minOf(t, 30000); conn.readTimeout = t; conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json"); conn.setRequestProperty("Authorization", "Bearer $tok")
                    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    code = conn.responseCode
                    val st = if (code >= 400) conn.errorStream else conn.inputStream
                    text = st?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                } finally { conn.disconnect() }
            } catch (_: SocketTimeoutException) {
                err = "Game server is waking up — try again in a minute"
            } catch (_: IOException) {
                err = "Cannot reach the game server"
            } catch (e: Exception) {
                err = e.message ?: "Cannot reach the game server"
            }
            js("window.__ffCb($id,$code,${JSONObject.quote(text)},${JSONObject.quote(err)})")
        }
    }

    @JavascriptInterface fun watch(id: Int, coll: String, gid: String) {
        if ((coll != "ball_games" && coll != "bomb_games") || !Regex("^[A-Za-z0-9_-]{1,80}$").matches(gid)) return
        val reg = Repo.doc(coll, gid).addSnapshotListener { s, e ->
            if (e != null) js("window.__ffWatch($id,\"\",${JSONObject.quote(e.message ?: "error")})")
            else if (s != null && s.exists()) {
                val o = toJ(s.data ?: emptyMap<String, Any?>()) as JSONObject
                o.put("id", gid)
                js("window.__ffWatch($id,${JSONObject.quote(o.toString())},\"\")")
            }
        }
        synchronized(watchers) { watchers.put(id, reg)?.remove() }
    }

    @JavascriptInterface fun unwatch(id: Int) { synchronized(watchers) { watchers.remove(id)?.remove() } }

    @JavascriptInterface fun confirm(id: Int, json: String) {
        val o = try { JSONObject(json) } catch (_: Exception) { JSONObject() }
        val yes = o.optString("yes", "").ifEmpty { "Confirm" }
        val c = GameConfirm(id, o.optString("title", "").ifEmpty { "Are you sure?" }, o.optString("text", ""), yes, o.optString("no", "").ifEmpty { "Cancel" }, o.optBoolean("danger", yes.equals("Leave", true)))
        scope.launch(Dispatchers.Main) { onConfirm(c) }
    }

    @JavascriptInterface fun deposit() { scope.launch(Dispatchers.Main) { AppStore.gameOpen = null; AppStore.openModal("modal-deposit") } }
    @JavascriptInterface fun close() { scope.launch(Dispatchers.Main) { AppStore.gameOpen = null } }

    private fun toJ(v: Any?): Any? = when (v) {
        null -> JSONObject.NULL
        is Timestamp -> v.toDate().time
        is Date -> v.time
        is Map<*, *> -> JSONObject().also { o -> v.forEach { (k, x) -> o.put(k.toString(), toJ(x)) } }
        is Iterable<*> -> JSONArray().also { a -> v.forEach { a.put(toJ(it)) } }
        is Double -> if (v.isNaN() || v.isInfinite()) 0 else v
        is Float -> if (v.isNaN() || v.isInfinite()) 0 else v
        is Number, is Boolean, is String -> v
        else -> v.toString()
    }
}
