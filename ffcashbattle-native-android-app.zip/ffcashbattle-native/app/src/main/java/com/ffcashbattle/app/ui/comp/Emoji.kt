package com.ffcashbattle.app.ui.comp

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.unit.em

/**
 * Emoji as pictures (js/core/emoji-png.js): every emoji that has a PNG in res (e_<hex>.png, same files as the website's
 * assets/emoji) is drawn as that picture so emoji look the same on every phone. Others stay normal text.
 */
object Emoji {
    private val cache = HashMap<String, Int>()

    fun res(ctx: Context, name: String): Int =
        cache.getOrPut(name) { ctx.resources.getIdentifier("e_" + name.replace('-', '_'), "drawable", ctx.packageName) }

    private val DEFAULT_PRESENTATION = setOf(
        0x231A, 0x231B, 0x23E9, 0x23EA, 0x23EB, 0x23EC, 0x23F0, 0x23F3, 0x25FD, 0x25FE, 0x2614, 0x2615, 0x267F, 0x2693, 0x26A1, 0x26AA, 0x26AB,
        0x26BD, 0x26BE, 0x26C4, 0x26C5, 0x26CE, 0x26D4, 0x26EA, 0x26F2, 0x26F3, 0x26F5, 0x26FA, 0x26FD, 0x2705, 0x270A, 0x270B, 0x2728, 0x274C,
        0x274E, 0x2753, 0x2754, 0x2755, 0x2757, 0x2795, 0x2796, 0x2797, 0x27B0, 0x27BF, 0x2B1B, 0x2B1C, 0x2B50, 0x2B55,
    ) + (0x2648..0x2653).toSet()

    private fun isPict(cp: Int): Boolean =
        cp in 0x1F000..0x1FAFF || cp in 0x2600..0x27BF || cp in 0x2300..0x23FF || cp in 0x2B00..0x2BFF || cp in 0x2190..0x21FF ||
            cp in 0x2900..0x297F || cp == 0x3030 || cp == 0x303D || cp == 0x3297 || cp == 0x3299 || cp == 0xA9 || cp == 0xAE || cp == 0x203C ||
            cp == 0x2049 || cp == 0x2122 || cp == 0x2139 || cp in 0x25A0..0x25FF

    private fun isRegional(cp: Int) = cp in 0x1F1E6..0x1F1FF
    private fun isModifier(cp: Int) = cp in 0x1F3FB..0x1F3FF

    /** Quick test: does the text contain anything that could be an emoji? */
    fun mayHave(s: String): Boolean {
        for (ch in s) { val c = ch.code; if (c >= 0x203C && (c <= 0x3299 || c in 0xD83C..0xD83E) || c == 0x20E3) return true }
        return false
    }

    class Built(val text: AnnotatedString, val inline: Map<String, InlineTextContent>)

    fun build(ctx: Context, s: String): Built? {
        if (!mayHave(s)) return null
        val cps = s.codePoints().toArray()
        val inline = HashMap<String, InlineTextContent>()
        var found = false
        val out = buildAnnotatedString {
            var i = 0
            while (i < cps.size) {
                val cp = cps[i]
                var end = i + 1
                var name: String? = null
                if (isRegional(cp) && i + 1 < cps.size && isRegional(cps[i + 1])) {
                    end = i + 2
                    name = cps.slice(i until end).joinToString("-") { Integer.toHexString(it) }
                } else if ((cp in 0x30..0x39 || cp == 0x23 || cp == 0x2A) && i + 1 < cps.size &&
                    (cps[i + 1] == 0x20E3 || (cps[i + 1] == 0xFE0F && i + 2 < cps.size && cps[i + 2] == 0x20E3))
                ) {
                    end = if (cps[i + 1] == 0x20E3) i + 2 else i + 3
                    name = cps.slice(i until end).filter { it != 0xFE0F }.joinToString("-") { Integer.toHexString(it) }
                } else if (isPict(cp)) {
                    var j = i + 1
                    var fe = false
                    if (j < cps.size && cps[j] == 0xFE0F) { fe = true; j++ }
                    if (j < cps.size && isModifier(cps[j])) j++
                    while (j + 1 < cps.size && cps[j] == 0x200D && isPict(cps[j + 1])) {
                        j += 2
                        if (j < cps.size && cps[j] == 0xFE0F) j++
                        if (j < cps.size && isModifier(cps[j])) j++
                    }
                    if (cp >= 0x1F000 || cp in DEFAULT_PRESENTATION || fe) {
                        end = j
                        name = cps.slice(i until end).filter { it != 0xFE0F }.joinToString("-") { Integer.toHexString(it) }
                    }
                }
                val str = String(cps, i, end - i)
                val rid = if (name != null) res(ctx, name) else 0
                if (name != null && rid != 0) {
                    found = true
                    val key = "e$rid"
                    if (!inline.containsKey(key)) {
                        inline[key] = InlineTextContent(Placeholder(1.18.em, 1.18.em, PlaceholderVerticalAlign.TextCenter)) {
                            Image(painterResource(rid), null, Modifier.fillMaxSize())
                        }
                    }
                    appendInlineContent(key, str)
                } else append(str)
                i = end
            }
        }
        return if (found) Built(out, inline) else null
    }
}
