package com.ffcashbattle.app.ui.shell

import android.app.Activity
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.statusBars
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.state.Page
import com.ffcashbattle.app.ui.comp.NotifyStack
import com.ffcashbattle.app.ui.comp.ToastHost
import com.ffcashbattle.app.ui.modals.*
import com.ffcashbattle.app.ui.screens.*
import com.ffcashbattle.app.ui.theme.FF
import kotlin.math.abs
import kotlin.math.max

/**
 * The whole app: page host + fixed header + bottom nav + drawer + modals + login screen + overlays,
 * stacked in the website's order (page < header < nav < chat app < drawer < login < modals < game < web < ban < loading < toast < notify cards).
 */
@Composable
fun AppRoot() {
    val c = FF.c
    val context = LocalContext.current
    val view = LocalView.current
    // status / navigation bar icon colours follow the app theme (not the phone's)
    SideEffect {
        val w = (context as? Activity)?.window ?: return@SideEffect
        val ic = WindowCompat.getInsetsController(w, view)
        ic.isAppearanceLightStatusBars = !c.isDark
        ic.isAppearanceLightNavigationBars = !c.isDark
        if (Build.VERSION.SDK_INT >= 29) { w.isNavigationBarContrastEnforced = false; w.isStatusBarContrastEnforced = false }
    }

    // Android back: web page -> modal -> drawer -> login -> any other page goes Home -> leave the app.
    // Registered FIRST on purpose: handlers composed later (web overlay, chat app, page sub-screens) take priority over it.
    BackHandler(enabled = !AppStore.overlayFree || AppStore.page != Page.HOME) {
        when {
            AppStore.web != null -> AppStore.web = null
            AppStore.modal != null -> AppStore.closeModal()
            AppStore.drawerOpen -> AppStore.drawerOpen = false
            AppStore.authOpen -> AppStore.authOpen = false
            AppStore.page != Page.HOME -> AppStore.goto(Page.HOME)
        }
    }

    Box(Modifier.fillMaxSize().background(c.bgBody)) {
        PageHost()
        HeaderHost()
        BottomNav(Modifier.align(Alignment.BottomCenter))
        FaqLayer()
        ChatAppOverlay()
        AppDrawer()
        AuthHost()
        ForgotLayer()
        ModalHost()
        GameOverlay()
        FaqSheet()
        SessionOverlay()
        WebOverlay()
        BanOverlay()
        LoadingOverlay()
        WelcomeHost()
        ToastHost()
        NotifyStack()
    }
}

// ------------------------------------------------------------------------------------------ pages

@OptIn(ExperimentalAnimationApi::class)
@Composable
private fun PageHost() {
    val c = FF.c
    val holder = rememberSaveableStateHolder()
    val density = LocalDensity.current
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val pagePad = PaddingValues(top = 80.dp + top, bottom = 86.dp + bottom)
    val chatPad = PaddingValues(top = top, bottom = 65.dp + bottom)
    val page = AppStore.page

    // header.js: hide the header while scrolling down (after 60px), show it again on scroll up
    val connection = remember(page) {
        val threshold = with(density) { 60.dp.toPx() }
        val jitter = with(density) { 5.dp.toPx() }
        object : NestedScrollConnection {
            var scrollTop = 0f
            var last = 0f
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                scrollTop = max(0f, scrollTop - consumed.y)
                if (abs(last - scrollTop) <= jitter) return Offset.Zero
                AppStore.headerHidden = scrollTop > last && scrollTop > threshold
                last = scrollTop
                return Offset.Zero
            }
        }
    }

    Box(Modifier.fillMaxSize().background(c.bgBody).nestedScroll(connection)) {
        CompositionLocalProvider(LocalPagePadding provides pagePad, LocalChatPadding provides chatPad) {
            AnimatedContent(
                targetState = page,
                transitionSpec = {
                    (fadeIn(tween(300, delayMillis = 60)) + slideInHorizontally(tween(350, easing = CubicBezierEasing(0.2f, 0.8f, 0.2f, 1f))) { with(density) { 30.dp.roundToPx() } } +
                        scaleIn(tween(350), initialScale = 0.95f)) togetherWith fadeOut(tween(120))
                },
                label = "page",
            ) { p ->
                holder.SaveableStateProvider(p.name) {
                    when (p) {
                        Page.HOME -> HomePage()
                        Page.MATCHES -> MatchesPage()
                        Page.CHAT -> ChatPage()
                        Page.RANK -> RankPage()
                        Page.WALLET -> WalletPage()
                    }
                }
            }
        }
    }
}

@Composable
private fun HeaderHost() {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val h = 65.dp + top
    val hidden = AppStore.headerHidden || AppStore.chatMode
    val y by animateDpAsState(if (hidden) -(h + 14.dp) else 0.dp, tween(300, easing = FastOutSlowInEasing), label = "headerY")
    if (hidden && y <= -(h + 13.dp)) return
    AppHeader(Modifier.offset(y = y))
}

// ------------------------------------------------------------------------------------------ overlays

@Composable
private fun AuthHost() {
    AnimatedVisibility(
        visible = AppStore.authOpen,
        enter = fadeIn(tween(250)) + slideInVertically(tween(350, easing = CubicBezierEasing(0.2f, 0.8f, 0.2f, 1f))) { it / 6 },
        exit = fadeOut(tween(200)),
    ) { AuthScreen() }
}

/** Maps the website's modal ids to their composables (each wraps its content in ModalSheet). */
@Composable
private fun ModalHost() {
    val id = AppStore.modal ?: return
    key(id) {
        when (id) {
            "modal-deposit" -> DepositModal()
            "modal-withdraw" -> WithdrawModal()
            "modal-wd-success" -> WdSuccessModal()
            "modal-transfer" -> TransferModal()
            "modal-gift" -> GiftModal()
            "modal-trx-detail" -> TrxDetailModal()
            "modal-wallet-history" -> WalletHistoryModal()
            "modal-join" -> JoinModal()
            "modal-roster" -> RosterModal()
            "modal-notifications" -> NotificationsModal()
            "modal-settings" -> SettingsModal()
            "modal-sound" -> SoundModal()
            "modal-edit-profile" -> EditProfileModal()
            "modal-rules" -> RulesModal()
            "modal-notice" -> NoticeModal()
            "modal-logout" -> LogoutModal()
            "modal-refer" -> ReferModal()
            else -> LaunchedEffect(id) { AppStore.closeModal() }
        }
    }
}
