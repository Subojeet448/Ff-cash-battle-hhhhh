package com.ffcashbattle.app.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

/**
 * Thin helpers over Firebase (same project as the website). Paths are given as segments:
 *   Repo.getDoc("users", uid)  ·  Repo.getCol("users", uid, "transactions") { it.orderBy("timestamp") }
 */
object Repo {
    val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()

    fun col(vararg p: String): CollectionReference = db.collection(p.joinToString("/"))
    fun doc(vararg p: String): DocumentReference = db.document(p.joinToString("/"))

    suspend fun getDoc(vararg p: String): Doc? {
        val s = doc(*p).get().await()
        return if (s.exists()) Doc.of(s) else null
    }

    suspend fun getCol(vararg p: String, q: (Query) -> Query = { it }): List<Doc> =
        q(col(*p)).get().await().documents.map { Doc.of(it) }

    /** Realtime document. cb(doc or null if missing, fromCache). */
    fun listenDoc(vararg p: String, cb: (Doc?, Boolean) -> Unit): ListenerRegistration =
        doc(*p).addSnapshotListener { s, e ->
            if (e != null || s == null) return@addSnapshotListener
            cb(if (s.exists()) Doc.of(s) else null, s.metadata.isFromCache)
        }

    /** Realtime collection (optionally a query). cb(list, fromCache). */
    fun listenCol(vararg p: String, q: (Query) -> Query = { it }, cb: (List<Doc>, Boolean) -> Unit): ListenerRegistration =
        q(col(*p)).addSnapshotListener { s, e ->
            if (e != null || s == null) return@addSnapshotListener
            cb(s.documents.map { Doc.of(it) }, s.metadata.isFromCache)
        }

    suspend fun set(path: List<String>, data: Map<String, Any?>, merge: Boolean = false) {
        if (merge) doc(*path.toTypedArray()).set(data, SetOptions.merge()).await() else doc(*path.toTypedArray()).set(data).await()
    }

    suspend fun update(path: List<String>, data: Map<String, Any?>) { doc(*path.toTypedArray()).update(data).await() }
    suspend fun add(path: List<String>, data: Map<String, Any?>): String = col(*path.toTypedArray()).add(data).await().id
    suspend fun delete(path: List<String>) { doc(*path.toTypedArray()).delete().await() }

    fun serverTs(): Any = FieldValue.serverTimestamp()
    fun inc(n: Number): Any = if (n is Double || n is Float) FieldValue.increment(n.toDouble()) else FieldValue.increment(n.toLong())
    fun arrayUnion(vararg v: Any): Any = FieldValue.arrayUnion(*v)
    fun arrayRemove(vararg v: Any): Any = FieldValue.arrayRemove(*v)
    fun delField(): Any = FieldValue.delete()
}
