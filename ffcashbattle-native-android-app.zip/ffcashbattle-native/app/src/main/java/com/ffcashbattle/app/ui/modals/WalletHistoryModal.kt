package com.ffcashbattle.app.ui.modals

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.trxMs
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.screens.wallet.TrxRow
import com.ffcashbattle.app.ui.screens.wallet.WEEK_MS
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem

/** Website `#modal-wallet-history`: withdrawal / deposit history of the last 7 days. */
@Composable
fun WalletHistoryModal() {
    val c = FF.c
    var tab by remember { mutableStateOf("withdraw") }
    val cutoff = System.currentTimeMillis() - WEEK_MS
    val data = AppStore.trx.filter { it.s("type") == tab && it.trxMs().let { ms -> ms <= 0L || ms >= cutoff } }

    ModalSheet {
        val close = LocalSheetClose.current
        Row(Modifier.fillMaxWidth().padding(bottom = 15.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.press(0.9f) { close() }) { FaIcon("fa-solid fa-arrow-left", rem(1.2).value.dp, c.textMain) }
                FText("History", size = rem(1.5), weight = FontWeight.Bold)
            }
            Box(Modifier.press(0.9f) { close() }) { FaIcon("fa-solid fa-xmark", rem(1.4).value.dp, c.textMuted) }
        }
        val shape = RoundedCornerShape(14.dp)
        Row(Modifier.padding(bottom = 15.dp).fillMaxWidth().clip(shape).background(c.bgCard).border(1.dp, c.border, shape).padding(5.dp)) {
            for ((k, label) in listOf("withdraw" to "Withdrawal History", "deposit" to "Deposit History")) {
                val on = tab == k
                Box(
                    Modifier.weight(1f).press(0.97f) { tab = k }.clip(RoundedCornerShape(10.dp)).background(if (on) c.primaryLight else Color.Transparent).padding(12.dp),
                    contentAlignment = Alignment.Center,
                ) { FText(label, size = rem(0.9), weight = if (on) FontWeight.Bold else FontWeight.SemiBold, color = if (on) c.primary else c.textMuted, align = TextAlign.Center) }
            }
        }
        FText("Showing last 7 days only • Older records auto-removed", size = rem(0.72), color = c.textMuted, align = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp))
        Column(Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
            if (data.isEmpty()) {
                FText("No $tab records in the last 7 days.", color = Color(0xFFAAAAAA), align = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(30.dp))
            } else for (t in data) TrxRow(t)
        }
    }
}
