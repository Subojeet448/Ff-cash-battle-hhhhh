package com.ffcashbattle.app.ui.modals

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.keyframes
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.data.Msg
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.GiftCodeBox
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.SpinIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.screens.match.jsNum
import com.ffcashbattle.app.ui.screens.wallet.StatusChip
import com.ffcashbattle.app.ui.screens.wallet.orderNo
import com.ffcashbattle.app.ui.screens.wallet.proofEligible
import com.ffcashbattle.app.ui.screens.wallet.rawAmount
import com.ffcashbattle.app.ui.screens.wallet.toneIconColors
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem

private fun jsStr(v: Any?): String = when (v) { null -> ""; is Number -> jsNum(v.toDouble()); else -> v.toString() }

/** `mask(v)`: "ab•••••yz" — first/last two characters stay visible. */
private fun mask(v: String): String = if (v.length > 4) v.take(2) + "•".repeat(maxOf(v.length - 4, 2)) + v.takeLast(2) else v

/** Website `#modal-trx-detail`: status message + reason + next steps + details of one transaction (opens on top of everything). */
@Composable
fun TrxDetailModal() {
    val c = FF.c
    val t = AppStore.modalArg as? Doc ?: Doc.EMPTY
    val d = remember(t) { Msg.describe(t) }
    val type = t.s("type").lowercase()
    val method = t.s("method")
    val raw = rawAmount(t)
    val amount = if (raw.contains("₹")) raw else "₹$raw"
    val (icBg, icFg) = toneIconColors(d.tone, c.isDark)

    val rows = ArrayList<Pair<String, String>>()
    rows.add("Type" to when (type) { "withdraw" -> "Withdrawal"; "deposit" -> "Deposit"; "refund" -> "Refund"; else -> "Match entry" })
    if (method.isNotEmpty()) rows.add("Method" to when {
        method == "BANK" -> "Bank transfer"; method == "GIFTCARD" -> "Google Play Gift Card"; method == "CRYPTO" -> "Crypto"
        method == "UPI" && type == "withdraw" -> "UPI"; else -> method
    })
    if (type == "withdraw" && t.has("net") && jsStr(t["net"]).isNotEmpty()) rows.add((if (method == "GIFTCARD") "Gift card value" else "You receive") to jsStr(t["net"]))
    if (t.s("upiId").isNotEmpty()) rows.add("UPI ID" to mask(t.s("upiId")))
    if (t.s("accountNumber").isNotEmpty()) rows.add("Account" to mask(t.s("accountNumber")))
    if (t.s("walletAddress").isNotEmpty()) rows.add("Wallet" to mask(t.s("walletAddress")))
    if (t.s("coin").isNotEmpty()) rows.add("Coin / Network" to t.s("coin") + (if (t.s("network").isNotEmpty()) " · " + t.s("network") else ""))
    if (t.s("trxId").isNotEmpty()) rows.add((if (method == "CRYPTO") "Transaction hash" else "UTR / Txn ID") to t.s("trxId"))
    rows.add("Order No" to orderNo(t))
    if (t.s("note").isNotEmpty()) rows.add("Note" to t.s("note"))
    rows.add("Date" to t.s("date").ifEmpty { "--" })
    val ref = Msg.refOf(t)
    if (ref.isNotEmpty()) rows.add("Reference ID" to ref)

    val showHelp = d.status in listOf("failed", "rejected", "cancelled", "pending", "processing")
    val showShare = proofEligible(t)

    ModalSheet(padding = PaddingValues(start = 22.dp, top = 22.dp, end = 22.dp, bottom = 26.dp)) {
        val close = LocalSheetClose.current
        // .td-hero
        Column(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            val pop = remember { Animatable(0f) }
            LaunchedEffect(Unit) { pop.animateTo(1f, keyframes { durationMillis = 500; 0f at 0; 0.6f at 300; 1f at 500 }) }
            Box(
                Modifier.graphicsLayer {
                    val k = pop.value
                    val sc = if (k < 0.6f) 0.88f + 0.16f * (k / 0.6f) else 1.04f - 0.04f * ((k - 0.6f) / 0.4f)
                    scaleX = sc; scaleY = sc; alpha = minOf(1f, k * 2f)
                }.padding(bottom = 10.dp).size(68.dp).clip(CircleShape).background(icBg),
                contentAlignment = Alignment.Center,
            ) {
                if (d.status == "processing") SpinIcon(rem(1.9).value.dp, icFg, icon = "fa-solid " + d.icon)
                else FaIcon("fa-solid " + d.icon, rem(1.9).value.dp, icFg)
            }
            FText(amount, size = rem(1.9), weight = FontWeight.Black, maxLines = 1)
            StatusChip(d.status, d.label)
            FText(d.headline, size = rem(1.05), weight = FontWeight.ExtraBold, align = TextAlign.Center, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
            FText(d.message, size = rem(0.88), color = c.textMuted, lineHeight = rem(0.88) * 1.55f, align = TextAlign.Center)
        }

        d.reason?.let { rs ->
            val shape = RoundedCornerShape(14.dp)
            Column(
                Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(shape)
                    .background(if (c.isDark) Color(0x1AF59E0B) else Color(0xFFFFF7ED))
                    .border(1.dp, if (c.isDark) Color(0x4DF59E0B) else Color(0xFFFED7AA), shape)
                    .padding(horizontal = 14.dp, vertical = 12.dp),
            ) {
                Row(Modifier.padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    FaIcon("fa-solid fa-circle-info", rem(0.82).value.dp, if (c.isDark) Color(0xFFFBBF24) else Color(0xFFC2410C))
                    FText(rs.label, size = rem(0.82), weight = FontWeight.ExtraBold, color = if (c.isDark) Color(0xFFFBBF24) else Color(0xFFC2410C))
                }
                FText(rs.text, size = rem(0.84), lineHeight = rem(0.84) * 1.5f, color = if (c.isDark) Color(0xFFFCD34D) else Color(0xFF9A3412))
            }
        }

        if (d.next.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                FText("WHAT HAPPENS NEXT", size = rem(0.72), weight = FontWeight.ExtraBold, color = c.textMuted, letterSpacing = 0.5.sp, modifier = Modifier.padding(bottom = 6.dp))
                for (n in d.next) {
                    Row(Modifier.padding(start = 2.dp)) {
                        FText("•", size = rem(0.84), lineHeight = rem(0.84) * 1.6f, modifier = Modifier.width(16.dp))
                        FText(n, size = rem(0.84), lineHeight = rem(0.84) * 1.6f, modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // Google Play gift code — only after the admin marked it successful
        if (type == "withdraw" && method.uppercase() == "GIFTCARD" && t.s("status") == "success" && t.s("giftCode").isNotEmpty()) GiftCodeBox(t.s("giftCode"))

        // .td-rows
        Column(Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(14.dp)).background(c.bgInput).padding(horizontal = 14.dp, vertical = 6.dp)) {
            rows.forEachIndexed { i, (k, v) ->
                val last = i == rows.lastIndex
                Row(
                    Modifier.fillMaxWidth()
                        .then(if (last) Modifier else Modifier.drawBehind {
                            drawLine(c.border, Offset(0f, size.height - 0.5.dp.toPx()), Offset(size.width, size.height - 0.5.dp.toPx()), 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(3.dp.toPx(), 3.dp.toPx())))
                        })
                        .padding(vertical = 9.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    FText(k, size = rem(0.82), color = c.textMuted)
                    FText(v, size = rem(0.82), weight = FontWeight.Bold, align = TextAlign.End, modifier = Modifier.weight(1f))
                }
            }
        }

        // .td-actions
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (showShare) {
                PillBtn(Modifier.weight(1f), listOf(Color(0xFFFFC426), Color(0xFFFFC426)), true, { close(); AppStore.openProof(t.id) }) {
                    FaIcon(if (t.b("isShared")) "fa-solid fa-pen" else "fa-solid fa-share-nodes", rem(0.9).value.dp, Color(0xFF3B2A1A))
                    FText(if (t.b("isShared")) "Edit Proof" else "Share as Proof", weight = FontWeight.Bold, color = Color(0xFF3B2A1A), align = TextAlign.Center)
                }
            }
            if (showHelp) {
                PillBtn(Modifier.weight(1f), listOf(c.primary, c.primaryDark), true, { close(); AppStore.openWhatsApp() }) {
                    FaIcon("fa-brands fa-whatsapp", rem(1.0).value.dp, Color.White)
                    FText("Contact Support", weight = FontWeight.Bold, color = Color.White, align = TextAlign.Center)
                }
            }
            PillBtn(Modifier.weight(1f), listOf(c.bgInput, c.bgInput), false, { close() }) {
                FText("Close", weight = FontWeight.Bold, color = c.textMain, align = TextAlign.Center)
            }
        }
    }
}

/** `.td-actions .btn-main`: flex 1, padding 12, fully rounded. */
@Composable
private fun PillBtn(modifier: Modifier, colors: List<Color>, shadow: Boolean, onClick: () -> Unit, content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(50.dp)
    Row(
        modifier.press(0.96f) { onClick() }
            .then(if (shadow) Modifier.boxShadow(15.dp, Color(0x664F46E5), shape) else Modifier)
            .clip(shape).background(Brush.linearGradient(colors)).padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}
