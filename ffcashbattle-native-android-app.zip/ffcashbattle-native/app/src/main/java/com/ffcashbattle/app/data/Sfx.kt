package com.ffcashbattle.app.data

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import com.ffcashbattle.app.R

/** Sounds from the website (assets/sounds): clear, notification, setting(s), touch, withdrawal. Volume = the Sound modal sliders. */
object Sfx {
    private var pool: SoundPool? = null
    private val ids = HashMap<String, Int>()
    private val loaded = HashSet<Int>()

    fun init(ctx: Context) {
        if (pool != null) return
        val p = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .build()
        p.setOnLoadCompleteListener { _, id, status -> if (status == 0) loaded.add(id) }
        ids["clear"] = p.load(ctx, R.raw.clear, 1)
        ids["notification"] = p.load(ctx, R.raw.notification, 1)
        ids["settings"] = p.load(ctx, R.raw.setting, 1)
        ids["touch"] = p.load(ctx, R.raw.touch, 1)
        ids["withdrawal"] = p.load(ctx, R.raw.withdrawal, 1)
        pool = p
    }

    /** which: clear | notification | settings | touch | withdrawal */
    fun play(which: String) {
        val v = Prefs.vol(which)
        if (v <= 0) return
        val id = ids[which] ?: return
        if (!loaded.contains(id)) return
        val f = v / 100f
        pool?.play(id, f, f, 1, 0, 1f)
    }
}
