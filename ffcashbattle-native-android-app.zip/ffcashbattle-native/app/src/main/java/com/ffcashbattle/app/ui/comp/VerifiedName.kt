package com.ffcashbattle.app.ui.comp

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.Verified

private val VT_BLUE = Color(0xFF0A84FF)

/** `window.vfy.name(name, uid)`: verified users get the pink→purple gradient name + a glowing blue tick; others plain text. */
@Composable
fun VerifiedName(
    name: String, uid: String?, size: TextUnit, modifier: Modifier = Modifier,
    weight: FontWeight = FontWeight.Normal, color: Color = FF_textMain(), maxLines: Int = 1, force: Boolean = false,
) {
    if (!force && !Verified.has(uid)) {
        FText(name, modifier, size = size, weight = weight, color = color, maxLines = maxLines, overflow = TextOverflow.Ellipsis)
        return
    }
    val inf = rememberInfiniteTransition(label = "vt")
    val glow by inf.animateFloat(0.55f, 1f, infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "g")
    val tick = size.value * 0.85f
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        FText(
            name, Modifier.weight(1f, fill = false), size = size, weight = FontWeight.ExtraBold, maxLines = maxLines, overflow = TextOverflow.Ellipsis,
            brush = Brush.horizontalGradient(listOf(Color(0xFFEC4899), Color(0xFFC026D3), Color(0xFFA855F7))),
        )
        Box(
            Modifier.padding(start = 4.dp).size(tick.dp).drawBehind {
                val r = size.minDimension * 0.95f
                drawCircle(Brush.radialGradient(listOf(VT_BLUE.copy(alpha = 0.55f * glow), Color.Transparent), center = Offset(size.width / 2f, size.height / 2f), radius = r), radius = r, center = Offset(size.width / 2f, size.height / 2f))
            },
            contentAlignment = Alignment.Center,
        ) { FaIcon("fa-solid fa-circle-check", tick.dp, VT_BLUE) }
    }
}

@Composable
private fun FF_textMain(): Color = com.ffcashbattle.app.ui.theme.FF.c.textMain
