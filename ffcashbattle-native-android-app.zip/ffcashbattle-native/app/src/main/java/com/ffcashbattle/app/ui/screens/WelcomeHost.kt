package com.ffcashbattle.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.AuthFlow
import com.ffcashbattle.app.data.WelcomeInfo
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.NamedImage
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Website `#welcome-card`: the gradient "Good morning, Name!" card that drops in from the top after a login. */
@Composable
fun WelcomeHost() {
    val w = AuthFlow.welcome ?: return
    key(w.id) { WelcomeCard(w) }
}

private class Confetti(val dx: Float, val dy: Float, val rot: Float, val color: Color, val s: Float, val delay: Float)

@Composable
private fun WelcomeCard(info: WelcomeInfo) {
    val scope = rememberCoroutineScope()
    val prog = remember { Animatable(0f) }          // 0 = parked above the screen, 1 = shown
    val bar = remember { Animatable(1f) }           // countdown strip
    val conf = remember { Animatable(0f) }          // seconds since the card showed (for the confetti)
    var closing by remember { mutableStateOf(false) }
    var drag by remember { mutableFloatStateOf(0f) }

    val pieces = remember {
        val cols = listOf(0xFFFDE047, 0xFFF472B6, 0xFF34D399, 0xFF60A5FA, 0xFFFB923C, 0xFFFFFFFF).map { Color(it) }
        List(18) { i ->
            val a = (Math.PI * 2 * i) / 18 + Random.nextDouble() * 0.4
            val d = 70 + Random.nextDouble() * 90
            Confetti(
                dx = (cos(a) * d).toFloat(), dy = (sin(a) * d * 0.7 - 20).toFloat(), rot = (Random.nextDouble() * 540 - 270).toFloat(),
                color = cols[i % cols.size], s = 5f + Random.nextInt(6), delay = 0.45f + Random.nextFloat() * 0.12f,
            )
        }
    }

    suspend fun hide() {
        if (closing) return
        closing = true
        drag = 0f
        prog.animateTo(0f, tween(550, easing = CubicBezierEasing(0.55f, 0f, 0.8f, 0.3f)))
        if (AuthFlow.welcome?.id == info.id) AuthFlow.welcome = null
    }

    LaunchedEffect(Unit) {
        delay(300)
        launch { prog.animateTo(1f, tween(750, easing = CubicBezierEasing(0.22f, 1.25f, 0.36f, 1f))) }
        launch { conf.animateTo(2f, tween(2000, easing = LinearEasing)) }
        launch { delay(350); bar.animateTo(0f, tween(4900, easing = LinearEasing)) }
        delay(4900)                                     // 300 ms + 4.9 s = the website's 5200 ms
        hide()
    }

    val shape = RoundedCornerShape(24.dp)
    Box(Modifier.fillMaxSize().statusBarsPadding().padding(top = 12.dp), contentAlignment = Alignment.TopCenter) {
        Box(
            Modifier.fillMaxWidth(0.94f).widthIn(max = 400.dp)
                .graphicsLayer {
                    val p = prog.value
                    translationY = (p - 1f) * 1.65f * size.height + drag
                    val k = 0.92f + 0.08f * p
                    scaleX = k; scaleY = k
                    alpha = (p / 0.4f).coerceIn(0f, 1f)
                }
                .boxShadow(48.dp, Color(0x724F46E5), shape)
                .clip(shape)
                .background(Brush.linearGradient(listOf(Color(0xFF4F46E5), Color(0xFF7C3AED), Color(0xFFD33E85))))
                .drawBehind {
                    // inset highlight in the top-left corner
                    drawRect(Brush.radialGradient(listOf(Color(0x38FFFFFF), Color.Transparent), Offset.Zero, size.width * 0.7f))
                    drawRect(Color(0x47FFFFFF), Offset.Zero, Size(size.width, 1.dp.toPx()))
                }
                .pointerInput(Unit) { detectTapGestures(onTap = { scope.launch { hide() } }) }
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragEnd = { if (drag < -28.dp.toPx()) scope.launch { hide() } else drag = 0f },
                        onDragCancel = { drag = 0f },
                    ) { change, amount -> change.consume(); drag = (drag + amount).coerceAtMost(0f) }
                }
                .padding(start = 14.dp, top = 14.dp, end = 14.dp, bottom = 17.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                // avatar + waving hand
                Box(
                    Modifier.size(54.dp).drawBehind {
                        // ring pulse (twice, starting 0.5 s after the card shows)
                        val rt = (conf.value - 0.5f) / 1.8f
                        if (rt in 0f..2f) {
                            val q = if (rt < 1f) rt else rt - 1f
                            drawCircle(Color.White.copy(alpha = 0.7f * 0.8f * (1f - q)), 32.dp.toPx() * (0.85f + 0.65f * q), style = Stroke(2.dp.toPx()))
                        }
                    },
                ) {
                    Box(Modifier.size(54.dp).boxShadow(20.dp, Color(0x40000000), CircleShape).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                        FText(info.name.take(1).uppercase().ifEmpty { "P" }, size = rem(1.4), weight = FontWeight.ExtraBold, color = Color(0xFF4F46E5))
                    }
                    Box(
                        Modifier.align(Alignment.BottomEnd).graphicsLayer { translationX = 8.dp.toPx(); translationY = 8.dp.toPx() }
                            .graphicsLayer {
                                val t = (conf.value - 0.7f) / 1.3f
                                rotationZ = if (t in 0f..2f) waveDeg(if (t < 1f) t else t - 1f) else 0f
                                transformOrigin = TransformOrigin(0.7f, 0.8f)
                            }
                            .boxShadow(10.dp, Color(0x40000000), CircleShape).size(28.dp).clip(CircleShape).background(Color(0xFFFDE68A)),
                        contentAlignment = Alignment.Center,
                    ) { FText("👋", size = rem(1.0)) }
                }
                Column(Modifier.weight(1f)) {
                    Row(
                        Modifier.padding(bottom = 5.dp).clip(RoundedCornerShape(20.dp)).background(Color(0x33FFFFFF)).padding(horizontal = 8.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically,
                    ) {
                        FaIcon("fa-solid fa-circle-check", rem(0.66).value.dp, Color(0xFFD1FAE5))
                        FText(info.tag.uppercase(), size = rem(0.66), weight = FontWeight.ExtraBold, color = Color(0xFFD1FAE5), letterSpacing = 0.3.sp)
                    }
                    FText(info.title, size = rem(1.08), weight = FontWeight.ExtraBold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, lineHeight = rem(1.08) * 1.2f, letterSpacing = (-0.2).sp)
                    FText(info.sub, size = rem(0.78), color = Color.White.copy(alpha = 0.88f), lineHeight = rem(0.78) * 1.35f, modifier = Modifier.padding(top = 3.dp))
                }
                NamedImage(
                    "logo",
                    Modifier.boxShadow(14.dp, Color(0x4D000000), RoundedCornerShape(14.dp)).size(52.dp).clip(RoundedCornerShape(14.dp)).border(2.dp, Color(0x8CFFFFFF), RoundedCornerShape(14.dp)),
                )
            }
            // countdown strip (.wl-bar)
            Box(Modifier.align(Alignment.BottomStart).graphicsLayer { translationY = 10.dp.toPx() }.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x33FFFFFF))) {
                Box(Modifier.fillMaxSize().graphicsLayer { scaleX = bar.value; transformOrigin = TransformOrigin(0f, 0.5f) }.background(Color(0xD9FFFFFF)))
            }
            // confetti burst from the avatar centre
            Canvas(Modifier.matchParentSize()) {
                val e = CubicBezierEasing(0.15f, 0.7f, 0.3f, 1f)
                for (p in pieces) {
                    val k = ((conf.value - p.delay) / 1.15f).coerceIn(0f, 1f)
                    if (k <= 0f || k >= 1f) continue
                    val q = e.transform(k)
                    val a = if (k < 0.7f) 1f else 1f - (k - 0.7f) / 0.3f
                    val w = p.s.dp.toPx(); val h = w * 0.6f
                    translate(27.dp.toPx() + p.dx.dp.toPx() * q, 27.dp.toPx() + (p.dy + 40f).dp.toPx() * q) {
                        rotate(p.rot * q, Offset.Zero) {
                            scale(0.4f + 0.6f * q, Offset.Zero) {
                                drawRoundRect(p.color.copy(alpha = a), Offset(-w / 2f, -h / 2f), Size(w, h), CornerRadius(2.dp.toPx()))
                            }
                        }
                    }
                }
            }
        }
    }
}

/** `wl-wave` keyframes: 0 -> 22° -> -14° -> 18° -> -6° -> 0 over one cycle (t in 0..1). */
private fun waveDeg(t: Float): Float {
    val pts = listOf(0f to 0f, 0.2f to 22f, 0.4f to -14f, 0.6f to 18f, 0.8f to -6f, 1f to 0f)
    for (i in 1 until pts.size) {
        val (t1, d1) = pts[i]; val (t0, d0) = pts[i - 1]
        if (t <= t1) return d0 + (d1 - d0) * ((t - t0) / (t1 - t0))
    }
    return 0f
}
