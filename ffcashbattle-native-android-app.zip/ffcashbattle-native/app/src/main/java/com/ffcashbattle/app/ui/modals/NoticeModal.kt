package com.ffcashbattle.app.ui.modals

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem

/** `#modal-notice` — centred "Announcement" popup (85% wide, max 320, radius 24, padding 30 25). */
@Composable
fun NoticeModal() {
    val c = FF.c
    val close = LocalSheetClose.current
    val w = minOf(LocalConfiguration.current.screenWidthDp * 0.85f, 320f).dp
    ModalSheet(center = true, centerWidth = w, padding = PaddingValues(horizontal = 25.dp, vertical = 30.dp), handle = false) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.padding(bottom = 15.dp).size(70.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(c.primaryLight, if (c.isDark) c.primaryLight else Color(0xFFF3E8FF)))),
                contentAlignment = Alignment.Center,
            ) { FaIcon("fa-solid fa-bullhorn", rem(2.0).value.dp, c.primary) }
            FText("Announcement", size = rem(1.4), weight = FontWeight.ExtraBold, modifier = Modifier.padding(bottom = 10.dp), align = TextAlign.Center)
            FText(
                AppStore.noticeText.ifEmpty { "Welcome to FF Cash Battle!" }, color = c.textMuted, lineHeight = rem(1.6),
                align = TextAlign.Center, modifier = Modifier.padding(bottom = 25.dp),
            )
            Box(
                Modifier.fillMaxWidth().press(0.96f) { close() }.clip(RoundedCornerShape(50.dp))
                    .background(Brush.linearGradient(listOf(c.primary, c.primaryDark))).padding(12.dp),
                contentAlignment = Alignment.Center,
            ) { FText("Okay, Got it", weight = FontWeight.Bold, color = Color.White, align = TextAlign.Center) }
        }
    }
}
