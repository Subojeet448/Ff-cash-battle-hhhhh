package com.ffcashbattle.app.ui.modals

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.Cfg
import com.ffcashbattle.app.data.Repo
import com.ffcashbattle.app.data.fsNum
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FRich
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.NamedImage
import com.ffcashbattle.app.ui.comp.SpinIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.screens.match.jsNum
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Transaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

private const val MAXTRY = 5
private const val LOCK_MS = 24L * 3600 * 1000
private const val CODE_LEN = 24

// ====================================================================== data layer

private class GiftErr(val kind: String) : RuntimeException(kind)
private sealed class GiftRes {
    class Scratch(val hash: String) : GiftRes()
    class Coins(val amount: Double) : GiftRes()
}
private class Tries(val fails: Int, val resetAt: Long)

private fun sha256(txt: String): String =
    MessageDigest.getInstance("SHA-256").digest(txt.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

private fun orderNo(id: String): String {
    val d = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
    return "GF-$d-" + id.takeLast(6).uppercase()
}

private fun leftStr(ms: Long): String {
    val h = ms / 3_600_000; val m = (ms % 3_600_000) / 60_000
    return (if (h > 0) "${h}h " else "") + "${m}m"
}

private fun findErr(e: Throwable?): GiftErr? {
    var t = e; var n = 0
    while (t != null && n++ < 8) { if (t is GiftErr) return t; t = t.cause }
    return null
}

private suspend fun loadTries(uid: String): Tries = try {
    val d = Repo.getDoc("gift_tries", uid)
    val fails = d?.i("fails") ?: 0
    val resetAt = d?.l("resetAt") ?: 0L
    if (resetAt != 0L && resetAt < System.currentTimeMillis()) Tries(0, 0L) else Tries(fails, resetAt)   // old fails expired
} catch (e: Exception) { Tries(0, 0L) }

/** Scratch-type code: ask the game server to turn the redeem record into a scratch card. Returns the card id or null. */
private suspend fun issueCard(hash: String): String? {
    val user = Repo.auth.currentUser ?: return null
    for (i in 0 until 2) {
        try {
            val tok = user.getIdToken(false).await().token ?: ""
            val r = withContext(Dispatchers.IO) {
                val con = URL(Cfg.GAME_SERVER.trimEnd('/') + "/api/ref/giftcard").openConnection() as HttpURLConnection
                try {
                    con.requestMethod = "POST"; con.connectTimeout = 15000; con.readTimeout = 20000; con.doOutput = true
                    con.setRequestProperty("Content-Type", "application/json"); con.setRequestProperty("Authorization", "Bearer $tok")
                    con.outputStream.use { it.write(JSONObject().put("hash", hash).toString().toByteArray()) }
                    val body = (if (con.responseCode in 200..299) con.inputStream else con.errorStream)?.bufferedReader()?.readText().orEmpty()
                    JSONObject(body)
                } finally { con.disconnect() }
            }
            if (r.optBoolean("ok") && r.has("card")) {
                val card = r.opt("card")
                val id = if (card is JSONObject) card.optString("id") else card?.toString().orEmpty()
                if (id.isNotEmpty() && id != "null") return id
            }
        } catch (_: Exception) { }
        delay(1500)
    }
    return null
}

/** The redeem transaction (website `runTransaction` block). The amount comes from the code's pre-shuffled pool. */
private fun redeemTx(tx: Transaction, uid: String, hash: String, codeRef: DocumentReference, redRef: DocumentReference, userRef: DocumentReference, trxRef: DocumentReference, nRef: DocumentReference): GiftRes {
    val cs = tx.get(codeRef)
    if (!cs.exists()) throw GiftErr("invalid")
    val c = cs.data ?: emptyMap()
    if (c["status"] != "active") throw GiftErr("invalid")
    val now = System.currentTimeMillis()
    val exp = (c["expiresAt"] as? Number)?.toLong() ?: 0L
    if (exp != 0L && exp < now) throw GiftErr("expired")
    val used = (c["used"] as? Number)?.toLong() ?: 0L
    val max = ((c["max"] as? Number)?.toLong() ?: 0L).let { if (it == 0L) 1L else it }
    if (used >= max) throw GiftErr("full")
    if (tx.get(redRef).exists()) throw GiftErr("already")
    val pool = c["pool"] as? List<*>
    val raw = pool?.getOrNull(used.toInt())
    val amount = (raw as? Number)?.toDouble() ?: raw?.toString()?.toDoubleOrNull() ?: 0.0
    if (!(amount > 0.0)) throw GiftErr("invalid")
    val u = tx.get(userRef).data ?: emptyMap()
    val toWithdraw = c["balance"] == "withdraw"
    val field = if (toWithdraw) "withdrawBalance" else "depositBalance"
    fun num(k: String) = (u[k] as? Number)?.toDouble() ?: 0.0
    val cur = if (toWithdraw) num("withdrawBalance") else if (u["depositBalance"] != null) num("depositBalance") else num("balance")
    val ord = orderNo(trxRef.id)
    val date = java.text.DateFormat.getDateInstance(java.text.DateFormat.SHORT).format(java.util.Date())
    tx.set(redRef, mapOf("uid" to uid, "amount" to fsNum(amount), "at" to now, "name" to ((u["appName"] as? String)?.ifEmpty { null } ?: "User"), "orderNo" to ord))
    tx.update(codeRef, mapOf("used" to FieldValue.increment(1)))
    if (c["reward"] == "scratch") {          // no instant credit: the server issues a scratch card, the prize is revealed by scratching
        tx.update(userRef, mapOf("lastGiftHash" to hash))
        return GiftRes.Scratch(hash)
    }
    val newBal = Math.round((cur + amount) * 100) / 100.0
    tx.update(userRef, mapOf(field to fsNum(newBal), "lastGiftHash" to hash))
    tx.set(trxRef, mapOf(
        "title" to "Gift code redeemed: ₹${jsNum(amount)}", "amount" to "+₹${jsNum(amount)}", "type" to "deposit", "status" to "success", "kind" to "gift",
        "giftHash" to hash, "orderNo" to ord, "balanceType" to (if (toWithdraw) "withdraw" else "deposit"), "date" to date, "createdAt" to now,
    ))
    tx.set(nRef, mapOf(
        "title" to "🎁 Gift code: ₹${jsNum(amount)} added", "message" to "Order $ord — added to your ${if (toWithdraw) "withdrawal" else "deposit"} balance.",
        "type" to "gift", "read" to false, "date" to date, "createdAt" to now,
    ))
    return GiftRes.Coins(amount)
}

// ====================================================================== UI

private val GpDeep = Color(0xFF5B21B6)

/** Website `#modal-gift` — "Redeem Gift Code" (24-character code, 5 wrong tries lock it for 24 hours). */
@Composable
fun GiftModal() {
    val c = FF.c
    val dark = c.isDark
    val uid = AppStore.uid
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var msgOk by remember { mutableStateOf(false) }
    var fails by remember { mutableIntStateOf(0) }
    var locked by remember { mutableStateOf(false) }
    var triesLoaded by remember { mutableStateOf(false) }
    var bad by remember { mutableStateOf(false) }
    var badTick by remember { mutableIntStateOf(0) }
    var win by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    val n = code.length
    val ok = n == CODE_LEN && !bad

    // app.openGift: load the wrong-try counter, focus the box
    LaunchedEffect(Unit) {
        if (uid != null) {
            val t = loadTries(uid)
            fails = t.fails; locked = t.fails >= MAXTRY && t.resetAt > System.currentTimeMillis(); triesLoaded = true
            if (locked) { msg = "Too many wrong tries. Try again in " + leftStr(t.resetAt - System.currentTimeMillis()); msgOk = false }
        }
        delay(350)
        try { focus.requestFocus() } catch (_: Exception) { }
    }
    LaunchedEffect(badTick) { if (badTick > 0) { bad = true; delay(600); bad = false } }

    val decor: DrawScope.() -> Unit = remember(dark) { { giftBackdrop(dark) } }

    ModalSheet(
        handle = false, topRadius = 34.dp, decor = decor,
        padding = PaddingValues(start = 22.dp, top = 22.dp, end = 22.dp, bottom = 26.dp),
    ) {
        val close = LocalSheetClose.current
        Box(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth()) {
                // .gp-handle: 78x8, margin -6px auto 12px
                Box(Modifier.fillMaxWidth().height(14.dp)) {
                    Box(Modifier.align(Alignment.TopCenter).offset(y = (-6).dp).width(78.dp).height(8.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x598B5CF6)))
                }
                Hero(win)

                // ------------------------------------------------------------ the 24-character box
                GiftField(
                    code = code, ok = ok, bad = bad, badTick = badTick, focus = focus,
                    onChange = { v ->
                        if (v.length <= CODE_LEN) { code = v; bad = false; if (v.length != CODE_LEN) msg = "" }
                    },
                    onPaste = {
                        val cm = AppStore.app.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        val t = try { cm.primaryClip?.getItemAt(0)?.text?.toString()?.trim()?.take(CODE_LEN) } catch (_: Exception) { null }
                        if (t.isNullOrEmpty()) AppStore.toast("Long-press the box to paste") else { code = t; bad = false; if (t.length != CODE_LEN) msg = "" }
                    },
                    onDone = { if (!busy && n == CODE_LEN) doRedeem(uid, code, { busy = it }, { m, o -> msg = m; msgOk = o }, { f, l -> fails = f; locked = l; triesLoaded = true }, { badTick++ }, { win = true }, { close() }) },
                )
                // .gp-meter
                val frac by animateFloatAsState(n / CODE_LEN.toFloat(), tween(250, easing = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)), label = "meter")
                Box(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 12.dp, bottom = 4.dp).height(4.dp).clip(RoundedCornerShape(5.dp)).background(Color(0x247C3AED))) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(frac).clip(RoundedCornerShape(5.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF7C3AED), Color(0xFFDB2777)))))
                }
                // .gift-sub
                Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, bottom = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    FText("$n / $CODE_LEN", size = rem(0.72), weight = FontWeight.Bold, color = if (dark) Color(0xFFB9A6E8) else Color(0xFF7C6AA6))
                    if (triesLoaded) Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                        for (i in 0 until MAXTRY) {
                            val x = i < fails
                            Box(Modifier.size(9.dp).graphicsLayer { val s = if (x) 1.15f else 1f; scaleX = s; scaleY = s }.clip(CircleShape).background(if (x) Color(0xFFEF4444) else Color(0xFF10B981)))
                        }
                        FText(if (locked) "locked" else "${MAXTRY - fails} tries left", size = rem(0.72), weight = FontWeight.Bold, color = if (dark) Color(0xFFB9A6E8) else Color(0xFF7C6AA6), modifier = Modifier.padding(start = 4.dp))
                    }
                }
                // .gift-msg
                Box(Modifier.fillMaxWidth().padding(start = 6.dp, end = 6.dp, top = 2.dp).heightIn(min = 20.dp)) {
                    if (msg.isNotEmpty()) FText(msg, size = rem(0.82), weight = FontWeight.Bold, color = if (msgOk) Color(0xFF10B981) else Color(0xFFEF4444))
                }

                // ------------------------------------------------------------ note
                Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 8.dp, bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Shield()
                    val ns = (LocalConfiguration.current.screenWidthDp * 0.03f).coerceIn(10.64f, 12.32f).sp
                    FRich(
                        "One code can be used once per account.\n5 wrong tries lock redeeming for [24 hours].",
                        Modifier.weight(1f), size = ns, color = if (dark) Color(0xFFCDBCF5) else Color(0xFF4C3B73), boldColor = if (dark) Color(0xFFE9D5FF) else Color(0xFF7E22CE),
                        weight = FontWeight.SemiBold, lineHeight = ns * 1.5f,
                    )
                }

                RedeemButton(enabled = n == CODE_LEN && !busy, busy = busy) {
                    doRedeem(uid, code, { busy = it }, { m, o -> msg = m; msgOk = o }, { f, l -> fails = f; locked = l; triesLoaded = true }, { badTick++ }, { win = true }, { close() })
                }
            }
            // .gp-x
            Box(
                Modifier.align(Alignment.TopEnd).offset(x = 6.dp, y = (-6).dp).size(44.dp)
                    .press(0.88f) { close() }
                    .clip(RoundedCornerShape(16.dp)).background(if (dark) Color(0x38A78BFA) else Color(0x47A878F0)),
                contentAlignment = Alignment.Center,
            ) { FaIcon("fa-solid fa-xmark", rem(1.15).value.dp, if (dark) Color(0xFFE9D5FF) else GpDeep) }
        }
    }
}

/** `app.redeemGift` */
private fun doRedeem(
    uid: String?, code: String,
    setBusy: (Boolean) -> Unit, say: (String, Boolean) -> Unit, setTries: (Int, Boolean) -> Unit,
    markBad: () -> Unit, markWin: () -> Unit, close: () -> Unit,
) {
    if (code.length != CODE_LEN) return
    if (uid == null) { AppStore.toast("Please login first"); return }
    setBusy(true); say("", false)
    // runs in the app scope: the wallet animation continues after the sheet has closed
    AppStore.scope.launch {
        try {
            val t = loadTries(uid)
            if (t.fails >= MAXTRY && t.resetAt > System.currentTimeMillis()) {
                setTries(t.fails, true); say("Too many wrong tries. Try again in " + leftStr(t.resetAt - System.currentTimeMillis()), false); return@launch
            }
            val h = sha256(code)
            val codeRef = Repo.doc("gift_codes", h); val redRef = Repo.doc("gift_codes", h, "redeems", uid); val userRef = Repo.doc("users", uid)
            val trxRef = Repo.col("users", uid, "transactions").document(); val nRef = Repo.col("users", uid, "notifications").document()
            val res: GiftRes = try {
                Repo.db.runTransaction { tx -> redeemTx(tx, uid, h, codeRef, redRef, userRef, trxRef, nRef) }.await()
            } catch (e: Exception) {
                val ge = findErr(e)
                if (ge != null) {
                    // count the wrong try
                    val fails = t.fails + 1
                    try { Repo.set(listOf("gift_tries", uid), mapOf("fails" to fails, "resetAt" to System.currentTimeMillis() + LOCK_MS)) } catch (_: Exception) { }
                    markBad(); setTries(fails, fails >= MAXTRY)
                    val txt = when (ge.kind) { "expired" -> "This gift code has expired."; "full" -> "This gift code is fully used."; "already" -> "You have already used this code."; else -> "Invalid gift code." }
                    say(if (fails >= MAXTRY) "Too many wrong tries. Locked for 24 hours." else "$txt ${MAXTRY - fails} tries left.", false)
                    return@launch
                }
                throw e
            }
            when (res) {
                is GiftRes.Scratch -> {
                    markWin(); say("🎉 You won a Scratch Card!", true)
                    val cid = issueCard(res.hash)
                    delay(700); close()
                    if (cid != null) { delay(350); AppStore.openModal("modal-refer", "scratch:$cid") } else AppStore.toast("Your scratch card will appear in Refer & Earn")
                }
                is GiftRes.Coins -> {
                    markWin(); say("🎉 ₹" + jsNum(res.amount) + " added!", true)
                    delay(700); close()
                    // the live user listener has the new balance by now
                    AppStore.playWalletFx("deposit", res.amount, maxOf(AppStore.balance, res.amount), "Gift Code Redeemed 🎁", "Adding your gift to the wallet…")
                }
            }
        } catch (e: Exception) {
            say("Could not redeem: " + (e.message?.takeIf { it.isNotEmpty() } ?: "try again"), false)
        } finally { setBusy(false) }
    }
}

// ---------------------------------------------------------------------- pieces

/** `.gp-hero` — floating gift art + "Redeem Gift Code" title. */
@Composable
private fun Hero(win: Boolean) {
    val dark = FF.c.isDark
    val sw = LocalConfiguration.current.screenWidthDp
    val artW = minOf((sw - 44) * 0.47f, 230f).dp          // width:47%, max 230px
    val inf = rememberInfiniteTransition(label = "gpFloat")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart), label = "t")
    val tri = 1f - kotlin.math.abs(2f * t - 1f)                 // 0 -> 1 -> 0
    val ease = tri * tri * (3f - 2f * tri)
    val pop = remember { Animatable(1f) }
    LaunchedEffect(win) { if (win) { pop.snapTo(0f); pop.animateTo(1f, tween(900, easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f))) } }
    Row(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        NamedImage(
            "wallet_gift_card",
            Modifier.width(artW).offset(x = (-10).dp)
                .graphicsLayer {
                    translationY = -7.dp.toPx() * ease
                    rotationZ = -1f + 2.5f * ease + (if (win) { val k = pop.value; (if (k < 0.4f) -6f * (k / 0.4f) else -6f * (1f - (k - 0.4f) / 0.6f)) } else 0f)
                    val s = if (win) { val k = pop.value; if (k < 0.4f) 1f + 0.18f * (k / 0.4f) else 1.18f - 0.18f * ((k - 0.4f) / 0.6f) } else 1f
                    scaleX = s; scaleY = s
                },
            ContentScale.FillWidth,
        )
        Column(Modifier.weight(1f).offset(x = (-10).dp).padding(end = 6.dp, top = 18.dp)) {
            val ts = (sw * 0.056f).coerceIn(18.9f, 26.6f).sp
            FText("Redeem", size = ts, weight = FontWeight.Black, color = if (dark) Color.White else Color(0xFF0F0A2E), lineHeight = ts * 1.12f, letterSpacing = (-0.5).sp)
            FText("Gift Code", size = ts, weight = FontWeight.Black, lineHeight = ts * 1.12f, letterSpacing = (-0.5).sp, brush = Brush.horizontalGradient(listOf(Color(0xFF6D28D9), Color(0xFFDB2777))))
            val ps = (sw * 0.031f).coerceIn(10.92f, 12.6f).sp
            FText(
                "Enter your 24-character code exactly as given.", size = ps, weight = FontWeight.SemiBold, color = if (dark) Color(0xFFCDBCF5) else Color(0xFF6B5A93),
                lineHeight = ps * 1.4f, modifier = Modifier.padding(top = 8.dp, bottom = 10.dp),
            )
            Box(Modifier.width(70.dp).height(5.dp).clip(RoundedCornerShape(5.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF7C3AED), Color(0xFFC026D3)))))
        }
    }
}

/** `.gp-field` + `.gift-input` + paste button. */
@Composable
private fun GiftField(
    code: String, ok: Boolean, bad: Boolean, badTick: Int, focus: FocusRequester,
    onChange: (String) -> Unit, onPaste: () -> Unit, onDone: () -> Unit,
) {
    val dark = FF.c.isDark
    val src = remember { MutableInteractionSource() }
    val focused by src.collectIsFocusedAsState()
    val shape = RoundedCornerShape(26.dp)
    val ring = if (bad) listOf(Color(0xFFEF4444), Color(0xFFFB7185)) else if (ok) listOf(Color(0xFF10B981), Color(0xFF6EE7B7), Color(0xFF10B981)) else listOf(Color(0xFF7C3AED), Color(0xFFC084FC), Color(0xFF7C3AED))
    val shake = remember { Animatable(0f) }
    LaunchedEffect(badTick) { if (badTick > 0) { shake.snapTo(0f); shake.animateTo(1f, tween(450, easing = LinearEasing)) } }
    val lift by animateFloatAsState(if (focused) -1f else 0f, tween(300), label = "lift")
    val ts = (LocalConfiguration.current.screenWidthDp * 0.035f).coerceIn(10.36f, 13.72f).sp
    val txt = if (dark) Color(0xFFF3E8FF) else Color(0xFF2A1458)
    Box(
        Modifier.fillMaxWidth().padding(top = 14.dp)
            .graphicsLayer {
                val k = shake.value
                translationX = if (k in 0.0001f..0.9999f) { val pts = floatArrayOf(0f, -7f, 7f, -7f, 7f, 0f); val i = (k * 5f).toInt().coerceIn(0, 4); (pts[i] + (pts[i + 1] - pts[i]) * (k * 5f - i)).dp.toPx() } else 0f
                translationY = lift.dp.toPx()
            }
            .boxShadow(30.dp, Color(0xB37C3AED), shape)
            .clip(shape).background(Brush.linearGradient(ring)).padding(3.dp),
    ) {
        Box(
            Modifier.fillMaxWidth().height(62.dp).clip(RoundedCornerShape(23.dp))
                .background(Brush.verticalGradient(if (dark) listOf(Color(0xFF241545), Color(0xFF1B0F36)) else listOf(Color(0xFFF4F4FB), Color(0xFFECECF6)))),
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.fillMaxWidth().padding(start = 12.dp, end = 62.dp), contentAlignment = Alignment.Center) {
                if (code.isEmpty()) FText("••••••••••••••••••••••••", size = ts, weight = FontWeight.Bold, mono = true, letterSpacing = 4.sp, color = (if (dark) Color(0xFF8E7BC0) else Color(0xFF6B6B85)).copy(alpha = 0.85f), maxLines = 1, softWrap = false, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                BasicTextField(
                    value = code, onValueChange = onChange, singleLine = true, interactionSource = src,
                    textStyle = TextStyle(color = txt, fontSize = ts, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, textAlign = TextAlign.Center),
                    cursorBrush = SolidColor(txt),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, autoCorrectEnabled = false, keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { onDone() }),
                    modifier = Modifier.fillMaxWidth().focusRequester(focus),
                )
            }
            Box(
                Modifier.align(Alignment.CenterEnd).padding(end = 7.dp).size(46.dp).press(0.88f) { onPaste() }
                    .clip(RoundedCornerShape(15.dp)).background(if (dark) Color(0x38A78BFA) else Color(0x47A878F0)),
                contentAlignment = Alignment.Center,
            ) { FaIcon("fa-regular fa-clipboard", rem(1.25).value.dp, if (dark) Color(0xFFE9D5FF) else GpDeep) }
        }
    }
}

/** The purple shield with a white tick (`.gp-note svg`). */
@Composable
private fun Shield() {
    Canvas(Modifier.size(30.dp)) {
        val s = size.width / 24f
        val p = Path().apply {
            moveTo(12f * s, 2f * s); lineTo(4f * s, 5.5f * s); lineTo(4f * s, 11.5f * s)
            cubicTo(4f * s, 16.5f * s, 7.4f * s, 20.1f * s, 12f * s, 22f * s)
            cubicTo(16.6f * s, 20.1f * s, 20f * s, 16.5f * s, 20f * s, 11.5f * s)
            lineTo(20f * s, 5.5f * s); close()
        }
        drawPath(p, Color(0xFF6D28D9))
        val t = Path().apply { moveTo(8.2f * s, 12.2f * s); lineTo(10.8f * s, 14.8f * s); lineTo(15.8f * s, 9.6f * s) }
        drawPath(t, Color.White, style = Stroke(2.2f * s, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** `.gp-btn` — big glossy purple "Redeem" pill. */
@Composable
private fun RedeemButton(enabled: Boolean, busy: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(34.dp)
    val inf = rememberInfiniteTransition(label = "gpBtn")
    val sh by inf.animateFloat(
        -0.7f, 1.3f,
        infiniteRepeatable(keyframes { durationMillis = 3400; -0.7f at 0 using LinearEasing; 1.3f at 1700 using LinearEasing; 1.3f at 3400 }, RepeatMode.Restart), label = "shine",
    )
    val ch by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart), label = "chev")
    val tri = 1f - kotlin.math.abs(2f * ch - 1f)
    val wide = LocalConfiguration.current.screenWidthDp > 360
    val label = if (LocalConfiguration.current.screenWidthDp <= 360) rem(1.25) else rem(1.5)
    Box(
        Modifier.fillMaxWidth().height(64.dp)
            .graphicsLayer { alpha = if (enabled) 1f else 0.45f }
            .then(if (enabled) Modifier.boxShadow(34.dp, Color(0xD97C3AED), shape) else Modifier)
            .drawBehind {
                // 0 0 0 5px rgba(168,85,247,.55) then 0 0 0 3px rgba(255,255,255,.85|.7)
                val r = 34.dp.toPx()
                if (enabled) drawRoundRect(Color(0x8CA855F7), Offset(-5.dp.toPx(), -5.dp.toPx()), Size(size.width + 10.dp.toPx(), size.height + 10.dp.toPx()), CornerRadius(r + 5.dp.toPx()))
                drawRoundRect(Color.White.copy(alpha = if (enabled) 0.85f else 0.7f), Offset(-3.dp.toPx(), -3.dp.toPx()), Size(size.width + 6.dp.toPx(), size.height + 6.dp.toPx()), CornerRadius(r + 3.dp.toPx()))
            }
            .press(0.97f, enabled) { onClick() }
            .clip(shape)
            .background(Brush.verticalGradient(0f to Color(0xFF9A4DFF), 0.55f to Color(0xFF7A22F0), 1f to Color(0xFF6414D6)))
            .drawWithContent {
                // gloss on the top half
                drawRect(Brush.verticalGradient(listOf(Color(0x47FFFFFF), Color.Transparent), endY = size.height / 2f), size = Size(size.width, size.height / 2f))
                // light sweep
                val w = size.width * 0.45f; val x = size.width * sh
                drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color(0x66FFFFFF), Color.Transparent), startX = x, endX = x + w), Offset(x, 0f), Size(w, size.height))
                drawContent()
            },
        contentAlignment = Alignment.Center,
    ) {
        if (wide) {
            FaIcon("fa-solid fa-angles-right", rem(1.7).value.dp, Color(0x47FFFFFF), Modifier.align(Alignment.CenterStart).padding(start = 22.dp).graphicsLayer { translationX = 6.dp.toPx() * tri; alpha = 0.5f + 0.5f * tri })
            FaIcon("fa-solid fa-angles-left", rem(1.7).value.dp, Color(0x47FFFFFF), Modifier.align(Alignment.CenterEnd).padding(end = 22.dp).graphicsLayer { translationX = -6.dp.toPx() * tri; alpha = 0.5f + 0.5f * tri })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (busy) SpinIcon(rem(1.55).value.dp, Color.White) else FaIcon("fa-solid fa-gift", rem(1.55).value.dp, Color.White)
            FText(if (busy) "Checking…" else "Redeem", size = label, weight = FontWeight.Black, color = Color.White, letterSpacing = 0.2.sp)
        }
    }
}

/** Layered gradients of `.gift-sheet.gp` (light lilac / dark violet) + the soft glow top-right + the thin border. */
private fun DrawScope.giftBackdrop(dark: Boolean) {
    val w = size.width; val h = size.height
    if (dark) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF2B1650), Color(0xFF190D33))))
        ellipseGlow(w * 0.85f, 0f, w * 1.2f, h * 0.7f, Color(0x597C3AED), 0.55f)
    } else {
        drawRect(Brush.verticalGradient(0f to Color(0xFFF8EFFE), 0.45f to Color(0xFFF1DEFB), 1f to Color(0xFFF7EEFD)))
        ellipseGlow(0f, h * 0.4f, w * 0.9f, h * 0.6f, Color(0xA6ECBEFC), 0.6f)
        ellipseGlow(w * 0.85f, 0f, w * 1.2f, h * 0.7f, Color(0xE6FFFFFF), 0.55f)
    }
    // ::before — 150px glow at right:-30 top:60
    val gr = 75.dp.toPx() * 1.414f
    val gc = Offset(w + 30.dp.toPx() - 75.dp.toPx(), 60.dp.toPx() + 75.dp.toPx())
    drawCircle(Brush.radialGradient(0f to Color(0x59C494FF), 0.7f to Color(0x00C494FF), center = gc, radius = gr), gr, gc)
    drawRoundRect(
        if (dark) Color(0x40A78BFA) else Color(0xCCFFFFFF), Offset(0.5.dp.toPx(), 0.5.dp.toPx()), Size(w - 1.dp.toPx(), h + 80.dp.toPx()),
        CornerRadius(34.dp.toPx()), style = Stroke(1.dp.toPx()),
    )
}

/** CSS `radial-gradient(rx ry at cx cy, c0, transparent stop)` — an elliptical glow. */
private fun DrawScope.ellipseGlow(cx: Float, cy: Float, rx: Float, ry: Float, c0: Color, stop: Float) {
    val k = ry / rx
    withTransform({ translate(cx, cy); scale(1f, k, Offset.Zero) }) {
        drawRect(
            Brush.radialGradient(0f to c0, stop to c0.copy(alpha = 0f), center = Offset.Zero, radius = rx),
            topLeft = Offset(-cx, -cy / k), size = Size(size.width, size.height / k),
        )
    }
}
