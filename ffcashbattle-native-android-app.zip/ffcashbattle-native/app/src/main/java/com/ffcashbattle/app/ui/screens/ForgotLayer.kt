package com.ffcashbattle.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.border
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.AuthFlow
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FRich
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.SpinIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Website `#fp-wrapper`: full-screen "Forgot password" flow (email -> check email -> new password -> done). */
@Composable
fun ForgotLayer() {
    AnimatedVisibility(visible = AuthFlow.fpOpen, enter = fadeIn(tween(300)), exit = fadeOut(tween(250))) { ForgotScreen() }
}

private val EASE = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)
private val POP = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f)

@Composable
private fun ForgotScreen() {
    val haptic = LocalHapticFeedback.current
    BackHandler(enabled = AuthFlow.fpOpen) { AuthFlow.fpClose() }

    var email by remember { mutableStateOf(AuthFlow.fpEmail) }
    var pw1 by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var bad by remember { mutableStateOf(emptySet<String>()) }
    var shakeTick by remember { mutableIntStateOf(0) }

    fun fail(vararg ids: String) { bad = ids.toSet(); shakeTick++; haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
    fun say(type: String, title: String, msg: String) = AppStore.notify(type, title, msg)

    val send: () -> Unit = {
        val e = email.trim()
        if (e.isEmpty()) { fail("email"); say("error", "Email required", "Please enter your registered email address.") }
        else if (!Regex("^\\S+@\\S+\\.\\S+$").matches(e)) { fail("email"); say("error", "Invalid email", "Please enter a valid email address.") }
        else if (!busy) {
            busy = true
            AppStore.scope.launch {
                val err = AuthFlow.sendForgot(e)
                busy = false
                if (err != null) { fail("email"); say("error", "Could not send link", err) }
            }
        }
    }
    val resend: () -> Unit = {
        if (!busy) {
            busy = true
            AppStore.scope.launch {
                val err = AuthFlow.fpResend()
                busy = false
                if (err != null) say("error", "Could not send link", err)
            }
        }
    }
    val save: () -> Unit = {
        if (pw1.length < 6) { fail("pw1"); say("error", "Password too short", "Password must be at least 6 characters long.") }
        else if (pw1 != pw2) { fail("pw2"); say("error", "Passwords don't match", "Please type the same password in both fields.") }
        else if (!busy) {
            busy = true
            AppStore.scope.launch {
                val err = AuthFlow.fpSavePw(pw1)
                busy = false
                if (err != null) { fail("pw1"); say("error", "Could not update password", err) }
            }
        }
    }

    AuthBackdrop(Modifier.fillMaxSize()) {
        BoxWithConstraints(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            val minH = maxHeight
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).heightIn(min = minH).padding(20.dp),
                verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                ForgotCard(shakeTick) {
                    AnimatedContent(
                        targetState = AuthFlow.fpStep,
                        transitionSpec = {
                            (fadeIn(tween(500, 60, EASE)) + slideInHorizontally(tween(500, 60, EASE)) { w -> w / 12 }) togetherWith fadeOut(tween(120))
                        },
                        label = "fpstep",
                    ) { step ->
                        Column(Modifier.fillMaxWidth().padding(start = 24.dp, top = 34.dp, end = 24.dp, bottom = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            when (step) {
                                "sent" -> SentStep(busy, resend)
                                "verifying" -> VerifyingStep()
                                "reset" -> ResetStep(pw1, pw2, { pw1 = it; bad = bad - "pw1" }, { pw2 = it; bad = bad - "pw2" }, bad, busy, save)
                                "done" -> DoneStep { AuthFlow.loginPrefill = AuthFlow.fpToLogin() }
                                "invalid" -> InvalidStep()
                                else -> EmailStep(email, { email = it; bad = bad - "email" }, "email" in bad, busy, send)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ForgotCard(shakeTick: Int, content: @Composable () -> Unit) {
    val c = FF.c
    val shape = RoundedCornerShape(28.dp)
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) { enter.animateTo(1f, tween(650, easing = POP)) }
    val shake = remember { Animatable(0f) }
    LaunchedEffect(shakeTick) { if (shakeTick > 0) { shake.snapTo(0f); shake.animateTo(1f, tween(450, easing = LinearEasing)) } }
    Box(
        Modifier.widthIn(max = 400.dp).fillMaxWidth()
            .graphicsLayer {
                val e = enter.value
                translationY = (1f - e) * 60.dp.toPx(); scaleX = 0.94f + 0.06f * e; scaleY = 0.94f + 0.06f * e
                alpha = (e * 2.5f).coerceIn(0f, 1f)
                translationX = shakeOffset(shake.value, 8.dp.toPx())
            }
            .boxShadow(70.dp, Color(0x73000000), shape)
            .clip(shape).background(if (c.isDark) Color(0xF71E293B) else Color(0xF7FFFFFF)),
    ) {
        AuthTopBar(Modifier.align(Alignment.TopStart))
        content()
        Box(
            Modifier.align(Alignment.TopEnd).padding(top = 14.dp, end = 14.dp).size(34.dp).clip(CircleShape).background(c.bgInput).press(0.88f) { AuthFlow.fpClose() },
            contentAlignment = Alignment.Center,
        ) { FaIcon("fa-solid fa-xmark", rem(1.2).value.dp, c.textMuted) }
    }
}

// ---------------------------------------------------------------------------- shared bits

/** `.fp-ico` 84dp gradient tile with pulsing ring(s) and a floating icon. */
@Composable
private fun FpIcon(icon: String, grad: List<Color>, ring: Color, twoRings: Boolean = false, badge: Boolean = false) {
    val inf = rememberInfiniteTransition(label = "fpico")
    val r1 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = CubicBezierEasing(0f, 0f, 0.2f, 1f)), RepeatMode.Restart), label = "r1")
    val r2 by inf.animateFloat(-0.5f, 0.5f, infiniteRepeatable(tween(2200, easing = CubicBezierEasing(0f, 0f, 0.2f, 1f)), RepeatMode.Restart), label = "r2")
    val flt by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Reverse), label = "flt")
    val fly by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2800, easing = LinearEasing), RepeatMode.Reverse), label = "fly")
    Box(Modifier.padding(bottom = 16.dp), contentAlignment = Alignment.Center) {
        @Composable
        fun ringBox(p: Float) {
            val q = if (p < 0f) p + 1f else p
            Box(
                Modifier.size(84.dp).graphicsLayer { val k = 0.92f + 0.33f * q; scaleX = k; scaleY = k; alpha = 0.55f * (1f - q) }
                    .drawBehind { drawRoundRect(ring, size = size, cornerRadius = CornerRadius(32.dp.toPx()), style = Stroke(2.dp.toPx())) },
            )
        }
        ringBox(r1); if (twoRings) ringBox(r2)
        Box(
            Modifier.boxShadow(30.dp, grad[0].copy(alpha = 0.38f), RoundedCornerShape(26.dp)).size(84.dp).clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(grad)),
            contentAlignment = Alignment.Center,
        ) { FaIcon(icon, rem(2.1).value.dp, Color.White, Modifier.graphicsLayer { translationY = -6.dp.toPx() * flt }) }
        if (badge) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(end = 0.dp).graphicsLayer { translationX = 8.dp.toPx() + 6.dp.toPx() * fly; translationY = -6.dp.toPx() - 4.dp.toPx() * fly }
                    .boxShadow(14.dp, Color(0x38000000), CircleShape).size(30.dp).clip(CircleShape).background(Color.White),
                contentAlignment = Alignment.Center,
            ) { FaIcon("fa-solid fa-paper-plane", rem(0.8).value.dp, FF.c.primary) }
        }
    }
}

@Composable
private fun FpTitle(t: String) {
    FText(t, size = rem(1.45), weight = FontWeight.Black, align = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp))
}

@Composable
private fun FpSub(markup: String) {
    FRich(markup, Modifier.fillMaxWidth().padding(bottom = 18.dp), size = rem(0.9), color = FF.c.textMuted, boldColor = FF.c.primary, weight = FontWeight.Normal, align = TextAlign.Center, lineHeight = rem(0.9) * 1.55f)
}

/** `.fp-btn` */
@Composable
private fun FpButton(label: String, icon: String, busy: Boolean = false, busyLabel: String = "", onClick: () -> Unit) {
    BtnMain(onClick = { if (!busy) onClick() }, modifier = Modifier.fillMaxWidth().graphicsLayer { alpha = if (busy) 0.92f else 1f }) {
        if (busy) SpinIcon(rem(1.0).value.dp, Color.White) else FaIcon(icon, rem(1.0).value.dp, Color.White)
        Spacer9()
        FText(if (busy && busyLabel.isNotEmpty()) busyLabel else label, weight = FontWeight.Bold, color = Color.White)
    }
}

@Composable
private fun Spacer9() { Box(Modifier.width(9.dp)) }

/** `.fp-link` */
@Composable
private fun FpLink(label: String, icon: String? = null, strong: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val c = FF.c
    Row(
        Modifier.padding(top = if (strong) 8.dp else 12.dp).clip(RoundedCornerShape(10.dp)).press(0.96f, enabled = enabled) { onClick() }.padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        val col = if (strong && enabled) c.primary else c.textMuted
        if (icon != null) FaIcon(icon, rem(0.84).value.dp, col)
        FText(label, size = rem(0.84), weight = FontWeight.Bold, color = col, modifier = Modifier.graphicsLayer { alpha = if (enabled) 1f else 0.85f })
    }
}

private val GMAIL = Regex("@(gmail|googlemail)\\.com$", RegexOption.IGNORE_CASE)

@Composable
private fun GmailChip() {
    val c = FF.c
    Row(
        Modifier.padding(bottom = 12.dp).press(0.95f) { AppStore.openUrl("https://mail.google.com/") }.clip(RoundedCornerShape(30.dp)).background(c.bgInput).padding(horizontal = 20.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        FaIcon("fa-brands fa-google", rem(0.86).value.dp, c.textMain)
        FText("Open Gmail", size = rem(0.86), weight = FontWeight.Bold)
    }
}

// ---------------------------------------------------------------------------- 1. email

@Composable
private fun EmailStep(email: String, onEmail: (String) -> Unit, invalid: Boolean, busy: Boolean, send: () -> Unit) {
    val c = FF.c
    FpIcon("fa-solid fa-key", listOf(c.primary, c.accent), c.primary)
    FpTitle("Forgot password?")
    FpSub("No worries! Enter your registered email and we'll send you a secure link to set a new password.")
    Column(Modifier.fillMaxWidth()) {
        AuthInput(email, onEmail, "Your email address", "fa-solid fa-envelope", keyboardType = KeyboardType.Email, invalid = invalid, imeAction = ImeAction.Done, onDone = send)
    }
    FpButton("Send Reset Link", "fa-solid fa-paper-plane", busy, "Sending...", send)
    Row(
        Modifier.fillMaxWidth().padding(top = 14.dp).clip(RoundedCornerShape(12.dp)).background(c.bgInput).padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.Top,
    ) {
        FaIcon("fa-solid fa-inbox", rem(0.78).value.dp, c.primary, Modifier.padding(top = 2.dp))
        FRich("The email may land in your [Spam / Junk] folder — please check there too.", size = rem(0.78), color = c.textMuted, boldColor = c.textMain, lineHeight = rem(0.78) * 1.45f)
    }
    FpLink("Back to Login", "fa-solid fa-arrow-left") { AuthFlow.fpClose() }
}

// ---------------------------------------------------------------------------- 2. sent / waiting page

@Composable
private fun SentStep(busy: Boolean, resend: () -> Unit) {
    val c = FF.c
    val email = AuthFlow.fpEmail
    @Suppress("UNUSED_VARIABLE") val tick = AuthFlow.fpTick                      // re-read every second while counting down
    val left = AuthFlow.fpLeftMs(email).coerceAtLeast(0L)
    val s = ((left + 999) / 1000).toInt()
    val ready = left <= 0L

    FpIcon("fa-solid fa-envelope-open-text", listOf(Color(0xFF10B981), Color(0xFF4F46E5)), Color(0xFF10B981), twoRings = true, badge = true)
    FpTitle("Check your email")
    FRich(
        "We've sent a password reset link to\n[$email]", Modifier.fillMaxWidth().padding(bottom = 18.dp), size = rem(0.9), color = c.textMuted, boldColor = c.primary,
        align = TextAlign.Center, lineHeight = rem(0.9) * 1.55f,
    )
    Column(Modifier.fillMaxWidth().padding(bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for ((i, t) in listOf("Open your email app", "Open our email & tap [Reset password]", "Set your new password there").withIndex()) {
            val a = remember { Animatable(0f) }
            LaunchedEffect(Unit) { delay(250L + 100L * i); a.animateTo(1f, tween(500, easing = EASE)) }
            Row(
                Modifier.fillMaxWidth().graphicsLayer { alpha = a.value; translationX = (1f - a.value) * 22.dp.toPx() }.clip(RoundedCornerShape(12.dp)).background(c.bgInput).padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(11.dp), verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(24.dp).clip(CircleShape).background(c.primary), contentAlignment = Alignment.Center) {
                    FText("${i + 1}", size = rem(0.75), weight = FontWeight.ExtraBold, color = Color.White)
                }
                FRich(t, size = rem(0.86), weight = FontWeight.SemiBold, color = c.textMain)
            }
        }
    }
    // .fp-spam
    val spamFg = if (c.isDark) Color(0xFFFDE68A) else Color(0xFF92400E)
    val spamShape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(spamShape).background(if (c.isDark) Color(0x21F59E0B) else Color(0xFFFFFBEB))
            .border(1.5.dp, if (c.isDark) Color(0x66FBBF24) else Color(0xFFFCD34D), spamShape).padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top,
    ) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(Color(0xFFF59E0B)), contentAlignment = Alignment.Center) {
            FaIcon("fa-solid fa-triangle-exclamation", rem(1.0).value.dp, Color.White)
        }
        Column {
            FText("Can't find the email?", size = rem(0.86), weight = FontWeight.Bold, color = spamFg, modifier = Modifier.padding(bottom = 2.dp))
            FRich(
                "Please check your [Spam / Junk] (and Promotions) folder. If it's there, tap [\"Not spam\"] so you receive our emails in your inbox.",
                size = rem(0.78), color = spamFg, boldColor = spamFg, lineHeight = rem(0.78) * 1.45f,
            )
        }
    }
    if (GMAIL.containsMatchIn(email)) GmailChip()
    // .fp-resend
    Column(Modifier.widthIn(max = 300.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(10.dp)).background(c.bgInput)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth((left / 180000f).coerceIn(0f, 1f)).clip(RoundedCornerShape(10.dp)).background(Brush.horizontalGradient(listOf(c.primary, c.accent))))
        }
        FpLink(
            if (ready) "Resend link" else "Resend link in ${s / 60}:${(s % 60).toString().padStart(2, '0')}",
            if (ready) "fa-solid fa-rotate-right" else null, strong = true, enabled = ready && !busy,
        ) { resend() }
    }
    FpLink("Use a different email", "fa-solid fa-pen") { AuthFlow.fpChangeEmail() }
}

// ---------------------------------------------------------------------------- 3. verifying link

@Composable
private fun VerifyingStep() {
    val c = FF.c
    FpIcon("fa-solid fa-circle-notch", listOf(c.primary, c.accent), c.primary)
    FpTitle("Verifying your link…")
    FpSub("Please wait a moment.")
}

// ---------------------------------------------------------------------------- 4. set new password

@Composable
private fun ResetStep(pw1: String, pw2: String, on1: (String) -> Unit, on2: (String) -> Unit, bad: Set<String>, busy: Boolean, save: () -> Unit) {
    val c = FF.c
    val okLen = pw1.length >= 6
    val okMix = pw1.any { it in 'a'..'z' } && pw1.any { it in 'A'..'Z' }
    val okNum = pw1.any { it.isDigit() }
    val okMatch = pw1.isNotEmpty() && pw1 == pw2

    FpIcon("fa-solid fa-shield-halved", listOf(Color(0xFF4F46E5), Color(0xFF06B6D4)), c.primary)
    FpTitle("Set new password")
    FRich(
        "Create a new password for\n[${AuthFlow.fpEmail}]", Modifier.fillMaxWidth().padding(bottom = 18.dp), size = rem(0.9), color = c.textMuted, boldColor = c.primary,
        align = TextAlign.Center, lineHeight = rem(0.9) * 1.55f,
    )
    Column(Modifier.fillMaxWidth()) {
        AuthInput(pw1, on1, "New password", "fa-solid fa-lock", eye = true, invalid = "pw1" in bad, bottom = 10.dp)
        PwMeter(pwLevel(pw1))
        AuthInput(pw2, on2, "Confirm new password", "fa-solid fa-lock", eye = true, invalid = "pw2" in bad, imeAction = ImeAction.Done, onDone = save, bottom = 10.dp)
    }
    Column(
        Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 16.dp).clip(RoundedCornerShape(12.dp)).background(c.bgInput).padding(horizontal = 13.dp, vertical = 11.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Rule(okLen, "At least 6 characters", null)
        Rule(okMix, "Upper & lower case letters ", "(recommended)")
        Rule(okNum, "A number ", "(recommended)")
        Rule(okMatch, "Both passwords match", null)
    }
    FpButton("Update Password", "fa-solid fa-check", busy, "Saving...", save)
}

@Composable
private fun Rule(on: Boolean, text: String, note: String?) {
    val c = FF.c
    val col = if (on) (if (c.isDark) Color(0xFF6EE7B7) else Color(0xFF059669)) else c.textMuted
    val pop = remember { Animatable(1f) }
    LaunchedEffect(on) { if (on) { pop.snapTo(0f); pop.animateTo(1f, tween(400, easing = POP)) } }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(14.dp), contentAlignment = Alignment.Center) {
            FaIcon(
                if (on) "fa-solid fa-circle-check" else "fa-solid fa-circle", rem(if (on) 0.85 else 0.7).value.dp, if (on) Color(0xFF10B981) else c.textMuted,
                Modifier.graphicsLayer { val k = if (on) 0.4f + 0.6f * pop.value else 1f; scaleX = k; scaleY = k },
            )
        }
        FText(text, size = rem(0.78), weight = FontWeight.SemiBold, color = col)
        if (note != null) FText(note, size = rem(0.78), weight = FontWeight.Medium, color = col.copy(alpha = 0.7f), modifier = Modifier.padding(start = 0.dp))
    }
}

// ---------------------------------------------------------------------------- 5. done

@Composable
private fun DoneStep(toLogin: () -> Unit) {
    val pop = remember { Animatable(0f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, tween(600, easing = POP)) }
    val inf = rememberInfiniteTransition(label = "dring")
    val ring by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2000, easing = CubicBezierEasing(0f, 0f, 0.2f, 1f)), RepeatMode.Restart), label = "r")
    Box(Modifier.padding(bottom = 16.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size(96.dp).graphicsLayer { val k = 0.92f + 0.3f * ring; scaleX = k; scaleY = k; alpha = 0.55f * (1f - ring) }.border(2.dp, Color(0xFF10B981), CircleShape))
        Box(
            Modifier.graphicsLayer { scaleX = pop.value; scaleY = pop.value }.boxShadow(30.dp, Color(0x6610B981), CircleShape).size(96.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF059669)))),
            contentAlignment = Alignment.Center,
        ) { DrawnCheck(60.dp, 200) }
    }
    FpTitle("Password updated!")
    FpSub("Your password has been changed successfully.\nYou can now log in with your new password.")
    FpButton("Go to Login", "fa-solid fa-right-to-bracket", onClick = toLogin)
}

// ---------------------------------------------------------------------------- 6. invalid / expired link

@Composable
private fun InvalidStep() {
    FpIcon("fa-solid fa-link-slash", listOf(Color(0xFFEF4444), Color(0xFFB91C1C)), Color(0xFFEF4444))
    FpTitle("Link expired")
    FpSub(AuthFlow.fpInvalidMsg)
    FpButton("Get a New Link", "fa-solid fa-rotate-right") { AuthFlow.fpChangeEmail() }
    FpLink("Back to Login", "fa-solid fa-arrow-left") { AuthFlow.fpClose() }
}
