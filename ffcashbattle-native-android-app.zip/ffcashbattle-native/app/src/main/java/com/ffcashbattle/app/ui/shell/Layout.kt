package com.ffcashbattle.app.ui.shell

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.dp

/**
 * The website's `.page-section` padding: top = 80px + status bar (room for the fixed header), bottom = 86px + navigation bar
 * (room for the bottom nav). Every page puts this on its scroll container's contentPadding.
 * Chat page (global header hidden): use LocalChatPadding instead.
 */
val LocalPagePadding = compositionLocalOf { PaddingValues(top = 80.dp, bottom = 86.dp) }

/** Same but with the header hidden (Chat page): top = status bar only. */
val LocalChatPadding = compositionLocalOf { PaddingValues(top = 0.dp, bottom = 86.dp) }

object ShellDims {
    val headerBase = 65.dp
    val navBase = 65.dp
}
