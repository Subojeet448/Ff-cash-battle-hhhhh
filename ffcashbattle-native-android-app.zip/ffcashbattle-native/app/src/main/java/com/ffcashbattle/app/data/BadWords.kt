package com.ffcashbattle.app.data

import com.ffcashbattle.app.state.AppStore
import com.google.firebase.firestore.ListenerRegistration
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer

/**
 * Port of js/core/badwords.js. The admin edits the list in Admin -> Chat Manager -> Banned Words (config/chat_words):
 * { words: [...], enabled: true|false, msg: "custom text" }. Catches CAPITALS, f.u.c.k, f u c k, fuuuck and leet (a=@, o=0 ...).
 */
object BadWords {
    private var words: List<String> = emptyList()
    private var enabled = true
    private var msg = ""
    private var reg: ListenerRegistration? = null

    private val LEET = mapOf('0' to 'o', '1' to 'i', '3' to 'e', '4' to 'a', '5' to 's', '7' to 't', '@' to 'a', '$' to 's', '!' to 'i')
    private val MARKS = Regex("[\\u0300-\\u036f]")
    private val DUP = Regex("(.)\\1+")
    private val NOT_LETTER = Regex("[^a-z\\u0900-\\u097f]+")

    init {
        try {
            val raw = Prefs.str("ffcb_bw")
            if (raw.isNotEmpty()) {
                val o = JSONObject(raw); val a = o.optJSONArray("words")
                if (a != null) { words = (0 until a.length()).map { a.optString(it) }; enabled = o.optBoolean("enabled", true); msg = o.optString("msg") }
            }
        } catch (_: Exception) { }
    }

    private fun norm(s: String): String {
        val low = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFKD).replace(MARKS, "")
        val sb = StringBuilder(low.length)
        for (ch in low) sb.append(if (ch == ' ') ' ' else (LEET[ch] ?: ch))
        return sb.toString()
    }

    private fun squash(s: String) = s.replace(DUP, "$1")
    private fun letters(s: String) = s.replace(NOT_LETTER, "")
    private fun tokens(s: String) = s.split(NOT_LETTER).filter { it.isNotEmpty() }

    /** The blocked word found in [text], or "" when it is clean. */
    fun find(text: String): String {
        if (!enabled || words.isEmpty()) return ""
        val n = norm(text); if (n.isBlank()) return ""
        val toks = tokens(n)
        val tokSq = toks.map { squash(it) }
        val singles = ArrayList<String>()
        var run = ""
        for (t in toks) { if (t.length == 1) run += t else { if (run.length > 2) singles.add(run); run = "" } }
        if (run.length > 2) singles.add(run)
        val joined = singles.map { squash(it) }
        val flat = squash(letters(n))
        for (raw in words) {
            val w = norm(raw).trim(); if (w.isEmpty()) continue
            val wl = letters(w); val wsq = squash(wl); if (wl.isEmpty()) continue
            if (w.any { it.isWhitespace() }) { if (flat.contains(wsq)) return raw; continue }
            if (toks.contains(wl) || tokSq.contains(wsq) || joined.contains(wsq)) return raw
        }
        return ""
    }

    /** true (and a toast) when the text must not be sent. */
    fun blocked(text: String): Boolean {
        val w = find(text); if (w.isEmpty()) return false
        val m = msg.trim()
        AppStore.toast(if (m.isNotEmpty()) m.replace(Regex("\\{word\\}", RegexOption.IGNORE_CASE), w) else "\"$w\" word block hai — isko hata kar likho")
        return true
    }

    fun start() {
        if (reg != null) return
        try {
            reg = Repo.listenDoc("config", "chat_words") { d, _ ->
                words = (d?.list("words") ?: emptyList()).map { it.toString() }
                enabled = d?.get("enabled") != false
                msg = d?.s("msg") ?: ""
                try {
                    Prefs.put("ffcb_bw", JSONObject().put("words", JSONArray(words)).put("enabled", enabled).put("msg", msg).toString())
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
    }

    fun stop() { try { reg?.remove() } catch (_: Exception) { }; reg = null }
}
