package com.ffcashbattle.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.state.Page
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/**
 * Port of pages/chat/chat-keep.js: message alerts (in-app card + status-bar notification), red dots, message life (24h / 7 days),
 * friend chats kept on this phone, "save on this device", auto-keep, mute, backup / restore.
 */
object ChatKeep {
    private const val DAY = 86_400_000L

    var prefVer by mutableIntStateOf(0)
        private set
    var worldFlag by mutableStateOf(false)
    var replyFlag by mutableStateOf(false)
    var openError by mutableStateOf<String?>(null)
    private var pendingRoom: Pair<String, String>? = null

    private val baseline = HashMap<String, Boolean>()
    private val bg = HashMap<String, ListenerRegistration>()
    private var rpUnsub: ListenerRegistration? = null
    private var rpBase = false
    private var expJob: Job? = null
    private var dmBusy = false

    // ------------------------------------------------------------------ prefs (per user, on this phone)
    private fun pk(k: String) = "ffk_" + (Chat.uid ?: Repo.auth.currentUser?.uid ?: "guest") + "_" + k

    @Suppress("UNUSED_EXPRESSION")
    fun pref(k: String, d: Boolean): Boolean { prefVer; return Prefs.bool(pk(k), d) }

    fun setPref(k: String, v: Boolean) { Prefs.put(pk(k), v); prefVer++ }

    @Suppress("UNUSED_EXPRESSION")
    fun list(k: String): List<String> { prefVer; return Prefs.str(pk(k)).split("|").filter { it.isNotEmpty() } }

    fun inList(k: String, key: String): Boolean = key in list(k)

    fun toggleList(k: String, key: String): Boolean {
        val l = list(k).toMutableList()
        val on = if (key in l) { l.remove(key); false } else { l.add(key); true }
        Prefs.put(pk(k), l.joinToString("|")); prefVer++
        return on
    }

    fun roomKey(th: ChatThread) = th.kind + ":" + th.id

    // ------------------------------------------------------------------ alerts
    fun alertsPermitted(): Boolean = SysNotif.canPost(AppStore.app)
    fun alertsOn(): Boolean = alertsPermitted() && pref("notif", true)

    private fun announce(title: String, body: String, room: String) {
        if (pref("sound", true)) Sfx.play("notification")
        if (!Chat.appVisible) { if (alertsOn()) SysNotif.post(AppStore.app, SysNotif.CH_CHAT, title, body, "chat" to room) }
        else AppStore.notify("info", title, body, durationMs = 5200)
    }

    /** Called when the user switched the "Message alerts" switch on and the permission answer is known. */
    fun alertsAnswered(granted: Boolean) {
        setPref("notif", granted)
        if (granted) {
            AppStore.toast("Message alerts are ON 🔔")
            SysNotif.post(AppStore.app, SysNotif.CH_CHAT, "FF Cash Battle", "Alerts are working — you will see new messages here.")
        } else AppStore.toast("Alerts are blocked. Allow notifications for this app in your phone settings.")
    }

    /** Incoming-message detection (cchats / cgroups last-message fields). */
    fun onChats(prev: Map<String, Doc>, next: Map<String, Doc>, kind: String) {
        val uid = Chat.uid ?: return
        val first = baseline[kind] != true
        baseline[kind] = true
        if (!first) {
            for ((id, c) in next) {
                val p = prev[id]
                val lastAt = c.l("lastAt"); val lastFrom = c.s("lastFrom")
                if (lastAt == 0L || lastFrom.isEmpty() || lastFrom == uid) continue
                if (p != null && lastAt <= p.l("lastAt")) continue
                if (!Chat.alive(Doc("", mapOf("at" to lastAt)), kind)) continue
                if (Chat.thread?.id == id && AppStore.chatOpen && Chat.appVisible) continue
                if (kind == "dm" && lastFrom in Chat.blocked) continue
                if (inList("muted", "$kind:$id")) continue
                val other = if (kind == "dm") c.strList("members").firstOrNull { it != uid } else null
                if (other != null) Chat.loadProf(other)
                val title = if (kind == "dm") Chat.friendName(other ?: lastFrom) else c.s("name").ifEmpty { "Group" }
                announce(title, c.s("lastMsg").ifEmpty { "New message" }, "$kind:$id")
            }
        }
        recount()
    }

    // ------------------------------------------------------------------ red dots
    private fun unreadOf(map: Map<String, Doc>): Int {
        val uid = Chat.uid ?: return 0
        var n = 0
        for (c in map.values) {
            val u = (c.map("unread")[uid] as? Number)?.toInt() ?: 0
            if (u > 0 && !inList("muted", (if (c.strList("members").size == 2) "dm:" else "group:") + c.id)) n += u
        }
        return n
    }

    fun unreadMsgs(): Int = unreadOf(Chat.chats) + unreadOf(Chat.groups)

    fun recount(): Int {
        val msgs = unreadMsgs(); val req = Chat.incoming.size
        val total = msgs + req + (if (worldFlag || replyFlag) 1 else 0)
        AppStore.navChatDot = total > 0
        return total
    }

    private suspend fun checkWorld() {
        if (Chat.me == null) return
        try {
            val s = Chat.fs().collection("cworld").orderBy("at", Query.Direction.DESCENDING).limit(1).get().await()
            val m = s.documents.firstOrNull()?.let { Doc.of(it) }
            worldFlag = m != null && m.l("at") > Prefs.long(pk("lastWorld")) && m.s("from") != Chat.uid && Chat.alive(m)
            recount()
        } catch (_: Exception) { }
    }

    // ------------------------------------------------------------------ lifecycle hooks (called by Chat)
    fun afterBoot() {
        val uid = Chat.uid ?: return
        ChatStore.load(uid)
        startBg()
        AppStore.scope.launch { checkWorld() }
        watchReplies()
        recount()
    }

    fun onForeground() { AppStore.scope.launch { checkWorld(); recount() } }

    fun onReset() {
        baseline.clear(); worldFlag = false; replyFlag = false; rpBase = false
        try { rpUnsub?.remove() } catch (_: Exception) { }; rpUnsub = null
        bg.values.forEach { try { it.remove() } catch (_: Exception) { } }; bg.clear()
        expJob?.cancel(); ChatStore.unload()
        pendingRoom = null; openError = null
        AppStore.navChatDot = false
        AppStore.chatOpen = false
    }

    fun onOpen(th: ChatThread) {
        if (th.kind == "world") { Prefs.put(pk("lastWorld"), System.currentTimeMillis()); worldFlag = false; markRepliesSeen() }
        recount()
        AppStore.scope.launch { delay(1500); purge(th) }
        expJob?.cancel()
        expJob = AppStore.scope.launch {
            while (Chat.thread === th) {
                delay(60_000)
                if (Chat.thread !== th) break
                val l = Chat.msgs
                if (l.any { !it.b("local") && !Chat.alive(it, th.kind) }) Chat.setMsgs(l.filter { it.b("local") || Chat.alive(it, th.kind) })
            }
        }
    }

    fun onClose(@Suppress("UNUSED_PARAMETER") th: ChatThread?) { expJob?.cancel(); recount() }

    fun onMsgs(th: ChatThread, msgs: List<Doc>) {
        if (th.kind == "dm") keepDm(th, msgs)
        if (th.kind == "world") {
            Prefs.put(pk("lastWorld"), System.currentTimeMillis())
            val m = msgs.lastOrNull()
            if (m != null && m.s("from") != Chat.uid && !Chat.appVisible && pref("world", false) && !inList("muted", "world:world") && System.currentTimeMillis() - m.l("at") < 15_000) {
                announce(Chat.world.name.ifEmpty { "World chat" }, (m.s("name").ifEmpty { "Player" }) + ": " + m.s("text"), "world:world")
            }
        }
    }

    // ------------------------------------------------------------------ expiry
    fun ttlLabel(kind: String? = null): String {
        val h = Chat.ttlMs(kind) / 3_600_000L
        return if (h % 24L == 0L) (if (h / 24L == 1L) "24 hours" else "${h / 24L} days") else "$h hours"
    }

    fun leftText(m: Doc, kind: String?): String {
        val l = Chat.ttlMs(kind) - (System.currentTimeMillis() - m.l("at"))
        if (l <= 0) return "expired"
        val h = l / 3_600_000L; val mi = (l % 3_600_000L) / 60_000L
        return if (h > 0) "${h}h ${mi}m" else "${mi}m"
    }

    /** Delete expired messages of this chat from the database (rules allow it only after the life time; the admin server also cleans up). */
    private suspend fun purge(th: ChatThread) {
        try {
            val key = "ffp_" + roomKey(th); val last = Prefs.long(key)
            val now = System.currentTimeMillis()
            if (now - last < 3_600_000L) return
            Prefs.put(key, now)
            val cutoff = now - Math.max(Chat.ttlMs(th.kind), DAY)
            val s = Chat.fs().collection(Chat.pathOf(th)).whereLessThan("at", cutoff).limit(40).get().await()
            for (d in s.documents) { try { d.reference.delete().await() } catch (_: Exception) { break } }
        } catch (_: Exception) { }
    }

    // ------------------------------------------------------------------ friend chats (DM): stay on this phone
    private fun mkRec(m: Doc, th: ChatThread, dm: Boolean = false, auto: Boolean = false): SavedMsg {
        val uid = Chat.uid ?: ""
        val from = m.s("from")
        return SavedMsg(
            "$uid|${roomKey(th)}|${m.id}", uid, roomKey(th), Chat.threadName(th), th.kind, m.id, from,
            m.s("name").ifEmpty { if (from == uid) "You" else Chat.friendName(from) }, Chat.parseMsg(m).text, m.l("at"), System.currentTimeMillis(), dm, auto,
        )
    }

    private fun keepDm(th: ChatThread, msgs: List<Doc>) {
        if (dmBusy) return
        dmBusy = true
        try {
            val rk = roomKey(th); val ids = msgs.map { it.id }.toHashSet()
            val saved = ChatStore.savedKeys(); val dmk = ChatStore.dmKeys().toMutableSet()
            val put = ArrayList<SavedMsg>(); val del = ArrayList<String>()
            for (m in msgs) {
                if (m.b("local")) continue
                val r = mkRec(m, th, dm = true)
                if (m.b("deleted")) { if (r.k in dmk) { del.add(r.k); dmk.remove(r.k) }; continue }
                if (r.text.isEmpty() || r.k in saved) continue
                if (r.k !in dmk || m.b("edited")) { put.add(r); dmk.add(r.k) }
            }
            ChatStore.put(put); ChatStore.del(del)
            // older copies the server already removed (after 7 days) come back from this phone
            val old = ChatStore.all().filter { it.room == rk && it.id !in ids }
            if (old.isNotEmpty() && Chat.thread?.id == th.id) {
                val back = old.map { r -> Doc(r.id, mapOf("from" to r.from, "name" to r.name, "text" to r.text, "at" to r.at, "local" to true)) }
                Chat.setMsgs((back + msgs.filter { !it.b("local") }).sortedBy { it.l("at") })
            }
        } catch (_: Exception) { }
        dmBusy = false
    }

    // ------------------------------------------------------------------ saved messages
    @Suppress("UNUSED_EXPRESSION")
    fun isSaved(m: Doc): Boolean {
        ChatStore.version
        val th = Chat.thread ?: return false
        val r = ChatStore.get("${Chat.uid}|${roomKey(th)}|${m.id}")
        return r != null && !r.dm
    }

    fun saveMsg(id: String) {
        val m = Chat.msgs.firstOrNull { it.id == id } ?: return
        val th = Chat.thread ?: return
        ChatStore.put(listOf(mkRec(m, th)))
        AppStore.toast("Saved on this device ✓")
    }

    fun unsaveMsg(id: String) {
        val m = Chat.msgs.firstOrNull { it.id == id } ?: return
        val th = Chat.thread ?: return
        ChatStore.del(listOf(mkRec(m, th).k))
        AppStore.toast("Removed from saved")
    }

    // auto-keep: one listener per chosen chat
    private fun startBg() {
        val uid = Chat.uid ?: return
        val want = list("auto").toSet()
        bg.keys.toList().forEach { k -> if (k !in want) { try { bg.remove(k)?.remove() } catch (_: Exception) { } } }
        for (rk in want) {
            if (bg.containsKey(rk)) continue
            val kind = rk.substringBefore(':'); val id = rk.substringAfter(':', "")
            if (kind.isEmpty() || id.isEmpty()) continue
            val th = ChatThread(kind, id)
            val reg = Chat.fs().collection(Chat.pathOf(th)).whereGreaterThan("at", System.currentTimeMillis() - Chat.ttlMs(kind)).orderBy("at", Query.Direction.DESCENDING).limit(100)
                .addSnapshotListener { s, e ->
                    if (e != null || s == null) return@addSnapshotListener
                    val have = ChatStore.savedKeys()
                    val recs = s.documents.map { Doc.of(it) }.filter { !it.b("deleted") && Chat.parseMsg(it).text.isNotEmpty() }
                        .map { mkRec(it, th, auto = true) }.filter { it.k !in have }
                    ChatStore.put(recs)
                }
            bg[rk] = reg
        }
        if (uid.isEmpty()) return
    }

    suspend fun toggleAuto() {
        val th = Chat.thread ?: return
        val rk = roomKey(th); val on = !inList("auto", rk)
        if (on) ChatUi.ask(AskOpts(icon = "fa-floppy-disk", title = "Keep a copy of this chat?", text = "New messages in this chat are also saved on THIS phone, so they stay after the server deletes them (after ${ttlLabel(th.kind)}). Uses a little phone storage.", yes = "Keep copy")) ?: return
        toggleList("auto", rk); startBg(); ChatUi.menuOpen = false
        AppStore.toast(if (on) "Auto-keep ON for this chat" else "Auto-keep OFF")
    }

    fun toggleMute() {
        val th = Chat.thread ?: return
        val on = toggleList("muted", roomKey(th)); ChatUi.menuOpen = false
        AppStore.toast(if (on) "Alerts muted for this chat" else "Alerts back on"); recount()
    }

    // ------------------------------------------------------------------ replies to ME in World -> red dot + notification
    private fun watchReplies() {
        val id = Chat.uid ?: return
        if (rpUnsub != null || Chat.me == null) return
        rpUnsub = Chat.fs().collection("cworld").whereEqualTo("ru", id).addSnapshotListener { s, e ->
            if (e != null || s == null) return@addSnapshotListener
            val l = s.documents.map { Doc.of(it) }.filter { Chat.alive(it) && it.s("from") != id }.sortedByDescending { it.l("at") }
            val lastSeen = Prefs.long("ffrp_$id")
            val fresh = l.filter { it.l("at") > lastSeen }
            if (rpBase && fresh.isNotEmpty()) {
                val m = fresh[0]
                announce((m.s("name").ifEmpty { "Someone" }) + " replied to you", Chat.parseMsg(m).text.ifEmpty { "Tap to see" }, "world:world")
            }
            replyFlag = fresh.isNotEmpty() && Chat.thread?.kind != "world"
            rpBase = true
            recount()
        }
    }

    fun markRepliesSeen() {
        val id = Chat.uid ?: return
        Prefs.put("ffrp_$id", System.currentTimeMillis()); replyFlag = false; recount()
    }

    // ------------------------------------------------------------------ opening the chat app
    /** Opens the full-screen chat (the landing card's "Enter"): starts chat, asks for a username on first use. */
    fun openApp() {
        if (!AppStore.loggedIn) { AppStore.checkLogin { openApp() }; return }
        openError = null
        AppStore.chatOpen = true
        AppStore.scope.launch {
            try { Chat.boot() } catch (e: Exception) { openError = e.message ?: "Chat could not start"; return@launch }
            if (Chat.me == null) ChatUi.show(ChatSheet.Onboard()) else consumePending()
        }
    }

    fun closeApp() {
        if (Chat.thread != null) Chat.closeThread()
        ChatUi.closeSheet()
        AppStore.chatOpen = false
    }

    private fun consumePending() {
        val p = pendingRoom ?: return
        pendingRoom = null
        val uid = Chat.uid ?: return
        val u = if (p.first == "dm") p.second.split("_").firstOrNull { it != uid } ?: "" else ""
        Chat.openThread(p.first, p.second, u)
    }

    /** A tapped message notification ("dm:<id>" / "group:<id>" / "world:world"). */
    fun openFromNotification(room: String) {
        val kind = room.substringBefore(':'); val id = room.substringAfter(':', "")
        if (kind.isEmpty() || id.isEmpty()) return
        AppStore.scope.launch {
            var t = 0
            while (!AppStore.loggedIn && t < 150) { delay(100); t++ }
            if (!AppStore.loggedIn) return@launch
            pendingRoom = kind to id
            AppStore.goto(Page.CHAT)
            openApp()
        }
    }
}
