package com.ffcashbattle.app.ui.screens.chat

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.Chat
import com.ffcashbattle.app.ui.comp.Avatar
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// chat.css colours
internal val CxIndigo = Color(0xFF4F46E5)
internal val CxViolet = Color(0xFF7C3AED)
internal val CxPink = Color(0xFFEC4899)
internal val Cx6366 = Color(0xFF6366F1)
internal val CxAmber = Color(0xFFF59E0B)
internal val CxRed = Color(0xFFEF4444)
internal val CxGreen = Color(0xFF22C55E)
internal val CxSoft = Color(0xFFC7D2FE)

/** linear-gradient(135deg,#4f46e5,#7c3aed 55%,#ec4899) — the chat header / hero. */
internal fun cxBarBrush(): Brush = Brush.linearGradient(0f to CxIndigo, 0.55f to CxViolet, 1f to CxPink)
internal fun cxBtnBrush(): Brush = Brush.linearGradient(listOf(Cx6366, CxViolet))
internal fun cxRedBrush(): Brush = Brush.linearGradient(listOf(CxRed, Color(0xFFDC2626)))
internal fun cxFabBrush(): Brush = Brush.linearGradient(listOf(Cx6366, CxPink))
internal val easeOutBack = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f)
internal val easeOutExpo = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)

/** Fade + slide up (the `.cv-row` / `.sec-h` entrance, staggered by index). */
@Composable
internal fun RowIn(index: Int, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay((minOf(index, 10) * 45).toLong()); a.animateTo(1f, tween(450, easing = easeOutExpo)) }
    Box(modifier.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 14.dp.toPx() }) { content() }
}

/** `clBounce`: translateY 0 -> -8px and rotate -4deg -> 4deg, back and forth. Returns (translateY dp, rotation deg). */
@Composable
internal fun rememberBounce(ms: Int = 2600, rise: Float = 8f): Pair<Float, Float> {
    val inf = rememberInfiniteTransition(label = "bounce")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(ms / 2, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    return Pair(-rise * t, -4f + 8f * t)
}

/** 0 -> 1 -> 0 pulse (used for live dots and ring pulses). */
@Composable
internal fun rememberPulse(ms: Int = 1600): Float {
    val inf = rememberInfiniteTransition(label = "pulse")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(ms / 2, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    return t
}

@Composable
internal fun ChatEmpty(icon: String, title: String?, text: String?, small: Boolean = false, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    val c = FF.c
    val (ty, rot) = rememberBounce(3000)
    Column(
        modifier.fillMaxWidth().padding(horizontal = if (small) 16.dp else 24.dp, vertical = if (small) 22.dp else 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        FaIcon(icon, rem(if (small) 1.8 else 2.6).value.dp, CxSoft, Modifier.padding(bottom = 6.dp).graphicsLayer { translationY = ty.dp.toPx(); rotationZ = rot })
        if (title != null) FText(title, size = rem(1.0), weight = FontWeight.Bold, align = TextAlign.Center)
        if (text != null) FText(text, size = rem(0.8), color = c.textMuted, align = TextAlign.Center, lineHeight = rem(0.8) * 1.5f)
        if (action != null) Box(Modifier.padding(top = 8.dp)) { action() }
    }
}

/** `.ct-load` — three bouncing dots. */
@Composable
internal fun LoadingDots(modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "dots")
    Row(modifier.fillMaxWidth().padding(24.dp), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally)) {
        for (i in 0 until 3) {
            val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(420, delayMillis = i * 140, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "d$i")
            Box(Modifier.size(9.dp).graphicsLayer { translationY = -6.dp.toPx() * t; alpha = 0.4f + 0.6f * t }.clip(CircleShape).background(Cx6366))
        }
    }
}

/** `.sec-h` */
@Composable
internal fun SecHeader(title: String, modifier: Modifier = Modifier, trailing: (@Composable () -> Unit)? = null) {
    Row(modifier.fillMaxWidth().padding(start = 2.dp, end = 2.dp, top = 20.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        FText(title.uppercase(), Modifier.weight(1f), size = rem(0.8), weight = FontWeight.Black, color = FF.c.textMuted, letterSpacing = 0.8.sp)
        if (trailing != null) trailing()
    }
}

/** `.mini-b` */
@Composable
internal fun MiniBtn(text: String, icon: String?, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.press(0.95f, onClick = onClick).clip(RoundedCornerShape(20.dp)).background(Cx6366.copy(alpha = 0.12f)).padding(horizontal = 12.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) FaIcon(icon, rem(0.72).value.dp, FF.c.primary)
        FText(text, size = rem(0.72), weight = FontWeight.ExtraBold, color = FF.c.primary)
    }
}

/** `.cv-row` card. */
@Composable
internal fun CvRow(index: Int, onClick: (() -> Unit)?, modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    val c = FF.c
    val shape = RoundedCornerShape(18.dp)
    RowIn(index, Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
        var m = modifier.fillMaxWidth()
        if (onClick != null) m = m.press(0.98f, onClick = onClick)
        Row(m.clip(shape).background(c.bgCard).border(1.dp, c.border, shape).padding(horizontal = 12.dp, vertical = 11.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically, content = content)
    }
}

/** Count badge (`.bdg`): primary, or red + pulsing when [unread]. */
@Composable
internal fun CountBadge(n: Int, unread: Boolean = true) {
    val p = if (unread) rememberPulse(1800) else 0f
    Box(
        Modifier.widthIn(min = 20.dp).height(20.dp).graphicsLayer { scaleX = 1f + 0.08f * p; scaleY = 1f + 0.08f * p }.clip(RoundedCornerShape(20.dp)).background(if (unread) CxRed else Cx6366).padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center,
    ) { FText(if (n > 99) "99+" else n.toString(), size = rem(0.68), weight = FontWeight.Black, color = Color.White) }
}

/** Avatar with the green "online" dot. */
@Composable
internal fun ChatAv(name: String, photo: String?, size: Dp = 46.dp, online: Boolean = false, ring: Boolean = false, modifier: Modifier = Modifier) {
    Box(modifier) {
        Avatar(Chat.photoOf(photo), name.ifEmpty { "?" }, size, borderColor = if (ring) Color.White.copy(alpha = 0.7f) else null)
        if (online) Box(Modifier.align(Alignment.BottomEnd).size(13.dp).clip(CircleShape).background(CxGreen).border(2.dp, FF.c.bgCard, CircleShape))
    }
}

/** `.av-e` — emoji avatar of rooms / groups. */
@Composable
internal fun EmojiAv(emoji: String, size: Dp = 46.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFFE0E7FF), Color(0xFFFCE7F3)))), contentAlignment = Alignment.Center) {
        FText(emoji.ifEmpty { "👥" }, size = rem(1.4))
    }
}

/** `.cs-b` — sheet button. */
@Composable
internal fun CsBtn(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, yes: Boolean = true, red: Boolean = false, enabled: Boolean = true, icon: String? = null) {
    val c = FF.c
    val shape = RoundedCornerShape(16.dp)
    var m = modifier.press(0.97f, enabled, onClick)
    if (yes && enabled) m = m.boxShadow(18.dp, (if (red) CxRed else Cx6366).copy(alpha = 0.5f), shape)
    m = m.clip(shape)
    m = if (yes) m.background(if (red) cxRedBrush() else cxBtnBrush()) else m.background(c.bgInput)
    Row(m.padding(14.dp).graphicsLayer { alpha = if (enabled) 1f else 0.5f }, horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) FaIcon(icon, rem(0.92).value.dp, if (yes) Color.White else c.textMain)
        FText(text, size = rem(0.92), weight = FontWeight.Black, color = if (yes) Color.White else c.textMain, maxLines = 1)
    }
}

// ------------------------------------------------------------------ time formatting
private val timeFmt by lazy { SimpleDateFormat("hh:mm a", Locale("en", "IN")) }
private val dayFmt by lazy { SimpleDateFormat("d MMM", Locale("en", "IN")) }

internal fun fmtTime(ms: Long): String = try { synchronized(timeFmt) { timeFmt.format(Date(ms)).lowercase() } } catch (_: Exception) { "" }

internal fun sameDay(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a }; val y = Calendar.getInstance().apply { timeInMillis = b }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

internal fun dayLabel(ms: Long): String = if (sameDay(ms, System.currentTimeMillis())) "Today" else try { synchronized(dayFmt) { dayFmt.format(Date(ms)) } } catch (_: Exception) { "" }

/** `fmtAgo` of the chat list: now / 5m / 3h / yesterday-ish / date. */
internal fun fmtAgo(ms: Long): String {
    if (ms <= 0L) return ""
    val d = System.currentTimeMillis() - ms
    return when {
        d < 60_000L -> "now"
        d < 3_600_000L -> (d / 60_000L).toString() + "m"
        d < 86_400_000L -> (d / 3_600_000L).toString() + "h"
        else -> dayLabel(ms)
    }
}

/** `chat.isBigEmoji`: 1–3 emoji only, nothing else. */
internal fun isBigEmoji(t: String?): Boolean {
    if (t == null) return false
    val s = t.trim()
    if (s.isEmpty() || s.length > 24) return false
    var count = 0; var prevZwj = false
    var i = 0
    while (i < s.length) {
        val cp = s.codePointAt(i); i += Character.charCount(cp)
        when {
            cp == 0xFE0F -> { }
            cp == 0x200D -> { prevZwj = true; continue }
            cp in 0x1F3FB..0x1F3FF -> { }
            Character.isWhitespace(cp) -> { }
            isPictographic(cp) -> { if (!prevZwj) count++ }
            else -> return false
        }
        prevZwj = false
    }
    return count in 1..3
}

private fun isPictographic(cp: Int): Boolean =
    cp in 0x1F300..0x1FAFF || cp in 0x2600..0x27BF || cp in 0x2B00..0x2BFF || cp in 0x2300..0x23FF || cp in 0x1F000..0x1F2FF ||
        cp == 0xA9 || cp == 0xAE || cp == 0x203C || cp == 0x2049 || cp == 0x2122 || cp == 0x2139 || cp in 0x2190..0x21FF || cp in 0x25A0..0x25FF || cp == 0x3030 || cp == 0x303D || cp == 0x3297 || cp == 0x3299
