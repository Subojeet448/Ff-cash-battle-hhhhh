package com.ffcashbattle.app

import android.app.Application
import com.ffcashbattle.app.data.AuthFlow
import com.ffcashbattle.app.data.Cfg
import com.ffcashbattle.app.data.Prefs
import com.ffcashbattle.app.data.Sfx
import com.ffcashbattle.app.data.SysNotif
import com.ffcashbattle.app.state.AppStore
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

class FFApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        com.ffcashbattle.app.data.Verified.load()
        Sfx.init(this)
        SysNotif.createChannels(this)
        // same Firebase project as the website (works even without google-services.json)
        if (FirebaseApp.getApps(this).isEmpty()) {
            FirebaseApp.initializeApp(
                this,
                FirebaseOptions.Builder()
                    .setApiKey(Cfg.API_KEY)
                    .setApplicationId(Cfg.APP_ID)
                    .setProjectId(Cfg.PROJECT_ID)
                    .setStorageBucket(Cfg.STORAGE_BUCKET)
                    .setGcmSenderId(Cfg.SENDER_ID)
                    .build(),
            )
        }
        AuthFlow.install()
        com.ffcashbattle.app.data.Refer.install()
        AppStore.start(this)
    }
}
