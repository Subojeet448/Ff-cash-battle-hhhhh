package com.ffcashbattle.app

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import com.ffcashbattle.app.data.AuthFlow
import com.ffcashbattle.app.data.Cfg
import com.ffcashbattle.app.data.Chat
import com.ffcashbattle.app.data.ChatKeep
import com.ffcashbattle.app.data.Prefs
import com.ffcashbattle.app.data.SysNotif
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.shell.AppRoot
import com.ffcashbattle.app.ui.theme.FFTheme

class MainActivity : ComponentActivity() {
    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_FFCashBattle)          // leave the splash window background behind
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
        )
        setContent { FFTheme(AppStore.dark) { AppRoot() } }
        handleIntent(intent)
        requestNotificationPermissionOnce()
    }

    override fun onStart() { super.onStart(); Chat.setVisible(true) }

    override fun onStop() { super.onStop(); Chat.setVisible(false) }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Tapping a status-bar notification opens the bell sheet; ffcashbattle.in/proof links open the Proof page. */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val data = i.data
        if (data != null && (data.host == "ffcashbattle.in" || data.host == "www.ffcashbattle.in")) {
            val path = (data.path ?: "").trimEnd('/')
            // referral link (?ref=<playerId>): remembered until the Sign Up form uses it
            data.getQueryParameter("ref")?.filter { it.isDigit() }?.take(12)?.takeIf { it.isNotEmpty() }?.let { Prefs.put("ffcb_ref", it) }
            // Firebase password-reset link (?mode=resetPassword&oobCode=…) -> the in-app reset screen
            val code = data.getQueryParameter("oobCode")
            if (data.getQueryParameter("mode") == "resetPassword" && !code.isNullOrBlank()) { AuthFlow.openResetLink(code); return }
            if (path == "/proof") AppStore.openProof(data.getQueryParameter("share"))
            else if (path == "/terms") AppStore.openWeb(Cfg.TERMS_URL, "Terms")
        }
        if (i.getStringExtra("open") == "notifications") AppStore.openModal("modal-notifications")
        i.getStringExtra("chat")?.takeIf { it.isNotEmpty() }?.let { ChatKeep.openFromNotification(it) }
    }

    private fun requestNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT >= 33 && !SysNotif.canPost(this) && !Prefs.bool("asked_notif_perm")) {
            Prefs.put("asked_notif_perm", true)
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
