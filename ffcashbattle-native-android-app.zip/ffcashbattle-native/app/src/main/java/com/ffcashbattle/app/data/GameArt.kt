package com.ffcashbattle.app.data

import androidx.annotation.DrawableRes
import com.ffcashbattle.app.R

/** Port of js/core/gameart.js: every avatar / banner / empty-state picture is local art. */
object GameArt {
    private val AVATARS = intArrayOf(
        R.drawable.avatar_1, R.drawable.avatar_2, R.drawable.avatar_3, R.drawable.avatar_4, R.drawable.avatar_5, R.drawable.avatar_6,
        R.drawable.avatar_7, R.drawable.avatar_8, R.drawable.avatar_9, R.drawable.avatar_10, R.drawable.avatar_11, R.drawable.avatar_12,
    )

    private fun hash(s: String): Long {
        var h = 7L
        for (ch in s) h = (h * 33 + ch.code.toLong()) and 0xFFFFFFFFL
        return h
    }

    @DrawableRes fun avatar(seed: String?): Int = AVATARS[(hash(seed ?: "").toInt().let { Math.floorMod(it, 12) })]

    fun modeOf(m: Doc?): String {
        if (m == null) return "default"
        val t = listOf("mode", "modeShort", "type", "modeLabel", "category").map { m.s(it) }.firstOrNull { it.isNotEmpty() }.orEmpty().lowercase()
        return when {
            Regex("(^|\\b)cs\\b|clash|squad").containsMatchIn(t) -> "cs"
            Regex("(^|\\b)lw\\b|lone|wolf|1v1").containsMatchIn(t) -> "lw"
            Regex("(^|\\b)br\\b|battle|royale|solo|duo").containsMatchIn(t) -> "br"
            else -> "default"
        }
    }

    @DrawableRes fun banner(m: Doc?): Int = when (modeOf(m)) {
        "cs" -> R.drawable.art_banner_cs
        "lw" -> R.drawable.art_banner_lw
        "br" -> R.drawable.art_banner_br
        else -> R.drawable.art_banner_default
    }

    @DrawableRes fun hero(): Int = R.drawable.art_hero
    @DrawableRes fun empty(kind: String): Int = if (kind == "search") R.drawable.art_empty_search else R.drawable.art_empty_matches

    /** window.app.avatarUrl(d): the user's photo (url / data: URI) or the generated art. Returns either a String url or null. */
    fun photoOf(d: Doc?): String? = d?.s("photoUrl")?.takeIf { it.isNotBlank() }
    fun seedOf(d: Doc?): String = d?.s("playerId")?.ifEmpty { d.s("appName") }?.ifEmpty { "User" } ?: "User"
}
