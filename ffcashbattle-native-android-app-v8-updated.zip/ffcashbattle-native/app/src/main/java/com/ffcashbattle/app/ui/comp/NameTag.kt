package com.ffcashbattle.app.ui.comp

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.unit.em
import com.ffcashbattle.app.R

/**
 * Name tags: a `(cs)` written anywhere in a name (player name, match title, room name) is shown as the CS badge picture
 * in the same place, and the brackets never show. Empty `()` are dropped too.
 *
 *   "Rahul (cs)"        ->  Rahul [CS badge]
 *   "(CS) Daily Match"  ->  [CS badge] Daily Match
 *   "Pro ( )"           ->  Pro
 *
 * Use it through `FText(..., tags = true)`; [plain] gives the same name as plain text (toasts, notifications).
 */
object NameTag {
    private val CS = Regex("""\(\s*cs\s*\)""", RegexOption.IGNORE_CASE)
    private val EMPTY = Regex("""\(\s*\)""")
    private const val KEY = "tag_cs"

    /** Quick test: is there anything to replace? */
    fun has(s: String): Boolean = s.indexOf('(') >= 0 && (CS.containsMatchIn(s) || EMPTY.containsMatchIn(s))

    /** The name as plain text: `(cs)` -> `CS`, empty `()` removed, double spaces collapsed. */
    fun plain(s: String): String {
        if (!has(s)) return s
        return EMPTY.replace(CS.replace(s, " CS "), "").replace(Regex("\\s{2,}"), " ").trim()
    }

    /** Name with the badge as inline picture; emoji inside the name still become their PNGs. Null when the text has no tag. */
    fun build(ctx: Context, s: String): Emoji.Built? {
        if (!has(s)) return null
        val inline = HashMap<String, InlineTextContent>()
        var badge = false
        val out = buildAnnotatedString {
            var last = 0
            fun text(raw: String) {
                val seg = EMPTY.replace(raw, "")
                if (seg.isEmpty()) return
                val e = Emoji.build(ctx, seg)
                if (e != null) { append(e.text); inline.putAll(e.inline) } else append(seg)
            }
            for (m in CS.findAll(s)) {
                val before = s.substring(last, m.range.first)
                text(before)
                // a little air between the name and the badge when they touch: "Rahul(cs)"
                if (before.isNotEmpty() && !before.last().isWhitespace() && !before.endsWith("(")) append(' ')
                appendInlineContent(KEY, "CS")
                badge = true
                last = m.range.last + 1
            }
            text(s.substring(last))
        }
        if (badge) {
            inline[KEY] = InlineTextContent(Placeholder(1.3.em, 1.3.em, PlaceholderVerticalAlign.TextCenter)) {
                Image(painterResource(R.drawable.tag_cs), "CS", Modifier.fillMaxSize())
            }
        }
        return Emoji.Built(out, inline)
    }
}
