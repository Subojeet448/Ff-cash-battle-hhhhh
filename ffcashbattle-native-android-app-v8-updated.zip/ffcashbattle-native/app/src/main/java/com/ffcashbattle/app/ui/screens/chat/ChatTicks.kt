package com.ffcashbattle.app.ui.screens.chat

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.Chat
import com.ffcashbattle.app.data.ChatThread
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.SpinIcon
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem

/**
 * Message ticks (same rules as the website, pages/chat/chat-ui.js):
 *
 *   spinner       message is not on the server yet (no internet / slow net) - it keeps turning until the message is delivered to the server
 *   1 tick        sent: the server has it
 *   2 ticks       delivered (friend chat): the friend was online after the message
 *   2 green ticks seen: friend chat -> the friend opened the chat;  World chat -> somebody else opened / posted in World after it
 *
 * Only my own messages get ticks. Group chats show a single tick.
 */
internal enum class Tick { NONE, PENDING, SENT, DELIVERED, SEEN }

/** Everything the ticks of one open thread depend on, collected once per recomposition (see [tickCtx]). */
internal class TickCtx(
    val kind: String,
    val unseen: Set<String>,   // DM: my messages the friend has not opened yet
    val peer: Doc?,            // DM: live profile of the friend (online / lastSeen)
    val lastAt: Long,          // DM: time of the newest message in the chat
    val foreignAt: Long,       // World: time of the newest message by somebody else
    val worldSeenMax: Long,    // World: newest worldSeenAt of somebody else
)

/** Call from composition: it reads Chat state, so the ticks update by themselves when a friend comes online / opens the chat. */
internal fun tickCtx(th: ChatThread, list: List<Doc>): TickCtx {
    val uid = Chat.uid ?: ""
    return when (th.kind) {
        "dm" -> {
            val c = Chat.chats[th.id]
            val n = (c?.map("unread")?.get(th.uid) as? Number)?.toInt() ?: 0
            val mine = list.filter { it.s("from") == uid && !it.b("deleted") && !it.b("local") && !it.b("_p") }
            // the last n messages of mine are still unread by the friend
            TickCtx("dm", mine.takeLast(n).map { it.id }.toHashSet(), Chat.prof[th.uid], c?.l("lastAt") ?: 0L, 0L, 0L)
        }
        "world" -> {
            var foreign = 0L
            for (x in list) if (x.s("from") != uid && !x.b("deleted") && x.l("at") > foreign) foreign = x.l("at")
            TickCtx("world", emptySet(), null, 0L, foreign, Chat.worldSeenMax)
        }
        else -> TickCtx(th.kind, emptySet(), null, 0L, 0L, 0L)
    }
}

internal fun tickOf(m: Doc, x: TickCtx): Tick {
    val uid = Chat.uid ?: ""
    if (m.b("local") || m.b("deleted") || m.s("from") != uid) return Tick.NONE
    if (m.b("_p")) return Tick.PENDING
    val at = m.l("at")
    return when (x.kind) {
        "dm" -> {
            if (at <= x.lastAt && m.id !in x.unseen) Tick.SEEN
            else {
                val seenAt = x.peer?.l("lastSeen") ?: 0L
                if (seenAt >= at || (x.peer?.b("online") == true && System.currentTimeMillis() - seenAt < 150_000L)) Tick.DELIVERED else Tick.SENT
            }
        }
        "world" -> if (x.worldSeenMax >= at || x.foreignAt > at) Tick.SEEN else Tick.SENT
        else -> Tick.SENT
    }
}

/** [onBubble] = the message sits in my coloured bubble (white ticks); false for big-emoji messages without a bubble. */
@Composable
internal fun TickIcon(t: Tick, onBubble: Boolean) {
    if (t == Tick.NONE) return
    val base = if (onBubble) Color.White.copy(alpha = 0.85f) else FF.c.textMuted
    val green = if (onBubble) Color(0xFF4ADE80) else Color(0xFF16A34A)
    when (t) {
        Tick.PENDING -> SpinIcon(rem(0.7).value.dp, base)
        Tick.SENT -> FaIcon("fa-solid fa-check", rem(0.72).value.dp, base)
        Tick.DELIVERED -> FaIcon("fa-solid fa-check-double", rem(0.72).value.dp, base)
        Tick.SEEN -> FaIcon("fa-solid fa-check-double", rem(0.72).value.dp, green)
        Tick.NONE -> Unit
    }
}
