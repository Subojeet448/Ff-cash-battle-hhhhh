package com.ffcashbattle.app.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.Chat
import com.ffcashbattle.app.data.ChatKeep
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.screens.chat.Cx6366
import com.ffcashbattle.app.ui.screens.chat.CxIndigo
import com.ffcashbattle.app.ui.screens.chat.CxPink
import com.ffcashbattle.app.ui.screens.chat.CxRed
import com.ffcashbattle.app.ui.screens.chat.CxViolet
import com.ffcashbattle.app.ui.screens.chat.WorldIcon
import com.ffcashbattle.app.ui.screens.chat.easeOutExpo
import com.ffcashbattle.app.ui.screens.chat.rememberBounce
import com.ffcashbattle.app.ui.shell.LocalChatPadding
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem

/** The Chat tab of the bottom navigation: the "Enter" hero card (chat-ui.js landing). The real chat opens full-screen (ChatAppOverlay). */
@Composable
fun ChatPage() {
    val c = FF.c
    val pad = LocalChatPadding.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> ChatKeep.alertsAnswered(granted) }
    // start the chat engine in the background so the numbers below are ready
    LaunchedEffect(com.ffcashbattle.app.state.AppStore.loggedIn) {
        if (com.ffcashbattle.app.state.AppStore.loggedIn) { try { Chat.boot() } catch (_: Exception) { } }
    }
    val intro = remember { Animatable(0f) }
    LaunchedEffect(Unit) { intro.animateTo(1f, tween(600, easing = easeOutExpo)) }
    val w = Chat.world
    val unread = ChatKeep.unreadMsgs(); val req = Chat.incoming.size
    val (ty, rot) = rememberBounce(2600, 8f)
    val inf = rememberInfiniteTransition(label = "cl")
    val float1 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(3500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "f1")
    val float2 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(3500, delayMillis = 0, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "f2")
    val arrow by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "arrow")
    val ring by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1500)), label = "ring")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = pad.calculateTopPadding() + 22.dp, bottom = pad.calculateBottomPadding() + 14.dp, start = 18.dp, end = 18.dp)) {
        val shape = RoundedCornerShape(30.dp)
        Box(
            Modifier.fillMaxWidth().graphicsLayer { alpha = intro.value; translationY = (1f - intro.value) * 28.dp.toPx(); val s = 0.95f + 0.05f * intro.value; scaleX = s; scaleY = s }
                .press(0.97f) { ChatKeep.openApp() }.boxShadow(40.dp, Color(0xCC7C3AED), shape).clip(shape)
                .background(Brush.linearGradient(0f to CxIndigo, 0.45f to CxViolet, 1f to CxPink)),
        ) {
            // floating bubbles
            Box(Modifier.align(Alignment.TopStart).offset(x = (-30).dp, y = (-30 - 16 * float1).dp).size(120.dp).graphicsLayer { val s = 1f + 0.08f * float1; scaleX = s; scaleY = s }.clip(CircleShape).background(Color.White.copy(alpha = 0.14f)))
            Box(Modifier.align(Alignment.BottomEnd).offset(x = 14.dp, y = (-20 - 16 * float2).dp).size(70.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.14f)))
            Box(Modifier.align(Alignment.TopEnd).offset(x = (-60).dp, y = (40 - 10 * float1).dp).size(36.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.14f)))
            Column(Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 34.dp, bottom = 26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                WorldIcon(w.emoji, 104.dp, rem(3.4), Modifier.padding(bottom = 8.dp).graphicsLayer { translationY = ty.dp.toPx(); rotationZ = rot })
                FText(w.name, size = rem(1.65), weight = FontWeight.Black, color = Color.White, letterSpacing = 0.3.sp, align = TextAlign.Center)
                FText(w.tagline, Modifier.padding(top = 6.dp, bottom = 18.dp), size = rem(0.85), color = Color.White.copy(alpha = 0.9f), align = TextAlign.Center)
                Row(
                    Modifier.boxShadow(22.dp, Color(0x66000000), RoundedCornerShape(40.dp)).clip(RoundedCornerShape(40.dp)).background(Color.White).padding(horizontal = 24.dp, vertical = 11.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    FText("Enter", weight = FontWeight.Black, color = CxIndigo)
                    FaIcon("fa-solid fa-arrow-right", rem(1.0).value.dp, CxIndigo, Modifier.graphicsLayer { translationX = 5.dp.toPx() * arrow })
                }
            }
            if (unread > 0 || req > 0) Box(Modifier.align(Alignment.TopEnd).offset(x = (-18).dp, y = 16.dp).size(14.dp)) {
                Box(Modifier.size(14.dp).graphicsLayer { val s = 1f + 1.7f * ring; scaleX = s; scaleY = s; alpha = 0.7f * (1f - ring) }.clip(CircleShape).background(CxRed))
                Box(Modifier.size(14.dp).clip(CircleShape).background(CxRed).border(2.dp, Color.White, CircleShape))
            }
        }
        if (Chat.me != null) {
            Row(Modifier.padding(top = 16.dp).fillMaxWidth().graphicsLayer { alpha = intro.value }, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Chip("fa-solid fa-user-group", "${Chat.friends.list.size}/${Chat.MAX_FRIENDS}", "Friends", false, Modifier.weight(1f))
                Chip("fa-solid fa-user-plus", req.toString(), "Requests", req > 0, Modifier.weight(1f))
                Chip("fa-solid fa-message", unread.toString(), "Unread", unread > 0, Modifier.weight(1f))
            }
            ChatKeep.prefVer
            if (!ChatKeep.alertsPermitted() && !ChatKeep.pref("askedHide", false)) {
                val s = RoundedCornerShape(18.dp)
                val shake by inf.animateFloat(-1f, 1f, infiniteRepeatable(tween(600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "shake")
                Row(
                    Modifier.padding(top = 12.dp).fillMaxWidth().clip(s)
                        .background(if (c.isDark) Brush.linearGradient(listOf(Cx6366.copy(alpha = 0.2f), CxPink.copy(alpha = 0.12f))) else Brush.linearGradient(listOf(Color(0xFFEEF2FF), Color(0xFFFDF2F8))))
                        .border(1.dp, if (c.isDark) Color(0x478184F8) else Color(0xFFE0E7FF), s).padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(40.dp).graphicsLayer { rotationZ = 8f * shake }.clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Cx6366, CxPink))), contentAlignment = Alignment.Center) { FaIcon("fa-solid fa-bell", rem(1.0).value.dp, Color.White) }
                    Column(Modifier.weight(1f)) {
                        FText("Never miss a message", size = rem(0.86), weight = FontWeight.Bold)
                        FText("Turn on alerts — we'll notify you when a friend messages.", size = rem(0.7), color = c.textMuted, lineHeight = rem(0.7) * 1.3f)
                    }
                    Box(Modifier.press(0.93f) { if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS) else ChatKeep.alertsAnswered(true) }.clip(RoundedCornerShape(12.dp)).background(c.primary).padding(horizontal = 14.dp, vertical = 9.dp)) {
                        FText("Turn on", size = rem(0.76), weight = FontWeight.ExtraBold, color = Color.White)
                    }
                    Box(Modifier.press(0.85f) { ChatKeep.setPref("askedHide", true) }.padding(6.dp)) { FaIcon("fa-solid fa-xmark", rem(0.9).value.dp, c.textMuted) }
                }
            }
        }
    }
}

@Composable
private fun Chip(icon: String, value: String, label: String, hot: Boolean, modifier: Modifier) {
    val c = FF.c
    val shape = RoundedCornerShape(18.dp)
    val bg = if (hot) (if (c.isDark) Color(0x1FEF4444) else Color(0xFFFEF2F2)) else c.bgCard
    val bd = if (hot) Color(0xFFFCA5A5) else c.border
    Column(modifier.clip(shape).background(bg).border(1.dp, bd, shape).padding(horizontal = 6.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        FaIcon(icon, rem(1.05).value.dp, if (hot) CxRed else c.primary)
        FText(value, size = rem(1.05), weight = FontWeight.Bold, color = if (hot) CxRed else c.textMain)
        FText(label, size = rem(0.68), weight = FontWeight.Bold, color = c.textMuted)
    }
}
