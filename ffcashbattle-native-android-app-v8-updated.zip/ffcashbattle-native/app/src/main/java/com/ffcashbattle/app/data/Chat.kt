package com.ffcashbattle.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.TextFieldValue
import com.ffcashbattle.app.state.AppStore
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.Query
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ChatWorld(val name: String = "Booyah Lounge", val emoji: String = "🔥", val tagline: String = "Meet players, flex wins, find your squad", val slow: Int = 0, val locked: Boolean = false, val ttlHours: Int = 0)
class ChatFriends(val list: List<String> = emptyList(), val starred: List<String> = emptyList(), val nicks: Map<String, String> = emptyMap())
class ChatThread(val kind: String, val id: String, val uid: String = "")
class ChatReply(val id: String, val n: String, val t: String, val u: String)
class ParsedMsg(val text: String, val rp: ChatReply?)

/**
 * Chat system (port of pages/chat/chat.js): World room, friend chats, groups, profile, search.
 * Data lives in the chat database (the main Firebase project unless Cfg.CHAT_TOKEN_URL is set).
 * Collections: cprofiles, cusernames, cfriends, cblocks, crequests, cchats(/msgs), cgroups(/msgs), cworld, creports, cconfig.
 */
object Chat {
    const val MAX_FRIENDS = 20
    const val EDIT_MS = 10 * 60 * 1000L
    const val DM_TTL_MS = 7 * 86_400_000L

    // ------------------------------------------------------------------ state (Compose snapshot state)
    var uid by mutableStateOf<String?>(null)
    var me by mutableStateOf<Doc?>(null)                 // cprofiles/{uid}; null = no chat profile yet
    var ready by mutableStateOf(false)
    var starting by mutableStateOf(false)
    var world by mutableStateOf(ChatWorld())
    var friends by mutableStateOf(ChatFriends())
    var blocked by mutableStateOf<List<String>>(emptyList())
    var incoming by mutableStateOf<List<Doc>>(emptyList())    // pending requests sent to me
    var outgoing by mutableStateOf<List<Doc>>(emptyList())    // requests I sent
    var chats by mutableStateOf<Map<String, Doc>>(emptyMap())
    var groups by mutableStateOf<Map<String, Doc>>(emptyMap())
    val prof = mutableStateMapOf<String, Doc>()
    var ver by mutableStateOf<Set<String>>(emptySet())
    var tab by mutableStateOf("chat")                    // chat | profile | game | search

    var thread by mutableStateOf<ChatThread?>(null)
    var msgs by mutableStateOf<List<Doc>>(emptyList())   // oldest first; local copies carry "local" = true
    var msgsState by mutableStateOf("loading")           // loading | ok | error
    var msgsError by mutableStateOf("")
    var editing by mutableStateOf<String?>(null)
    var reply by mutableStateOf<ChatReply?>(null)
    var draft by mutableStateOf(TextFieldValue(""))
    var jumpTo by mutableStateOf<String?>(null)          // message id to scroll to + flash (quote tap)
    var jumpTick by mutableStateOf(0)
    /** World ticks: newest "worldSeenAt" of any OTHER player (a World message of mine older than this has been seen). */
    var worldSeenMax by mutableStateOf(0L)

    private var db: FirebaseFirestore? = null
    private var cauth: FirebaseAuth? = null
    private val unsubs = ArrayList<ListenerRegistration>()
    private var thUnsub: ListenerRegistration? = null
    private var bootJob: Deferred<Boolean>? = null
    private var bootUid: String? = null
    private val pending = HashMap<String, Deferred<Doc>>()
    private var lastWorldSend = 0L
    private var noReplyFields = false
    private var peerUnsub: ListenerRegistration? = null     // live profile of the DM partner (online / lastSeen -> delivered tick)
    private var wsUnsub: ListenerRegistration? = null       // who saw my World messages
    private var wsJob: kotlinx.coroutines.Job? = null
    private var wsWriteAt = 0L
    private var noWorldSeen = false

    // ------------------------------------------------------------------ database
    fun fs(): FirebaseFirestore {
        val cur = db
        if (cur != null) return cur
        val d: FirebaseFirestore
        if (!Cfg.chatSeparate) d = Repo.db
        else {
            val app = try { FirebaseApp.getInstance("chat") } catch (_: IllegalStateException) {
                FirebaseApp.initializeApp(AppStore.app, FirebaseOptions.Builder().setApiKey(Cfg.CHAT_API_KEY).setApplicationId(Cfg.CHAT_APP_ID).setProjectId(Cfg.CHAT_PROJECT_ID).build(), "chat")
            }
            cauth = FirebaseAuth.getInstance(app)
            d = FirebaseFirestore.getInstance(app)
        }
        db = d
        return d
    }

    fun docRef(path: String): DocumentReference = fs().document(path)

    /** Signs in to the chat project when it is a separate one (custom token from the admin server). */
    private suspend fun chatReady() {
        fs()
        if (!Cfg.chatSeparate) return
        val me = Repo.auth.currentUser ?: throw Exception("Please login first")
        val ca = cauth ?: return
        if (ca.currentUser?.uid == me.uid) return
        val idt = me.getIdToken(false).await().token ?: throw Exception("Please login first")
        val res = withContext(Dispatchers.IO) {
            val c = URL(Cfg.CHAT_TOKEN_URL).openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"; c.connectTimeout = 30000; c.readTimeout = 30000
                c.setRequestProperty("Authorization", "Bearer $idt")
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
                try { JSONObject(txt) } catch (_: Exception) { JSONObject() }
            } finally { c.disconnect() }
        }
        if (!res.optBoolean("ok")) throw Exception(res.optString("error").ifEmpty { "Chat server not reachable" })
        ca.signInWithCustomToken(res.getString("token")).await()
    }

    // ------------------------------------------------------------------ helpers
    fun errMsg(e: Throwable?): String =
        if (isDenied(e)) "Not allowed (limit reached, blocked, or time over)" else (e?.message ?: "Something went wrong")

    private fun isDenied(e: Throwable?): Boolean = e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED

    fun toast(m: String) = AppStore.toast(m)

    fun chatId(a: String, b: String): String = listOf(a, b).sorted().joinToString("_")

    fun ttlMs(kind: String?): Long =
        if (kind == "dm") DM_TTL_MS else Math.max(1, Math.min(168, world.ttlHours.takeIf { it > 0 } ?: Cfg.CHAT_TTL_HOURS)).toLong() * 3_600_000L

    fun alive(m: Doc?, kind: String? = null): Boolean = m != null && (System.currentTimeMillis() - m.l("at")) < ttlMs(kind)

    fun friendName(u: String): String =
        friends.nicks[u]?.takeIf { it.isNotEmpty() } ?: prof[u]?.s("name")?.takeIf { it.isNotEmpty() } ?: "Player"

    fun isFriend(u: String): Boolean = u in friends.list
    fun isBlocked(u: String): Boolean = u in blocked

    /** A photo the app can really show (http url / data: url); anything else = the generated art. */
    fun photoOf(raw: String?): String? = raw?.takeIf { it.startsWith("http") || it.startsWith("data:") }

    /** My avatar exactly as Settings shows it. */
    fun myPhoto(): String = photoOf(AppStore.user.s("photoUrl")) ?: ""

    fun isVer(u: String?): Boolean {
        if (u.isNullOrEmpty()) return false
        if (u in ver || Verified.has(u)) return true
        return if (u == uid) me?.b("verified") == true else prof[u]?.b("verified") == true
    }

    /** a verified user may edit / delete ANY message in every room he can see; own messages after the 10 min window too */
    fun canMod(m: Doc?): Boolean = m != null && !m.b("deleted") && isVer(uid) && thread != null && (m.s("from") != uid || System.currentTimeMillis() - m.l("at") >= EDIT_MS)

    // ------------------------------------------------------------------ replies (stored natively: rid/rn/rt/ru; hidden prefix fallback)
    private val RPX = Regex("^⁠R(\\{.*?\\})⁠", RegexOption.DOT_MATCHES_ALL)
    private fun encReply(r: ChatReply): String = "⁠R" + JSONObject().put("i", r.id).put("n", r.n).put("t", r.t).put("u", r.u).toString() + "⁠"

    fun parseMsg(m: Doc?): ParsedMsg {
        if (m == null) return ParsedMsg("", null)
        if (m.s("rid").isNotEmpty()) return ParsedMsg(m.s("text"), ChatReply(m.s("rid"), m.s("rn").ifEmpty { "Player" }, m.s("rt"), m.s("ru")))
        val t = m.s("text"); val x = RPX.find(t)
        if (x != null) {
            try { val j = JSONObject(x.groupValues[1]); return ParsedMsg(t.substring(x.value.length), ChatReply(j.optString("i"), j.optString("n"), j.optString("t"), j.optString("u"))) } catch (_: Exception) { }
        }
        return ParsedMsg(t, null)
    }

    fun snippet(m: Doc): String = (if (m.b("deleted")) "Message deleted" else parseMsg(m).text).replace(Regex("\\s+"), " ").trim().take(100)

    // ------------------------------------------------------------------ profiles
    suspend fun getProf(u: String): Doc {
        val cached = prof[u]
        if (cached != null) return cached
        val pn = pending[u]
        if (pn != null) return pn.await()
        val d = AppStore.scope.async {
            var p: Doc = try {
                val s = docRef("cprofiles/$u").get().await()
                if (s.exists()) Doc.of(s) else Doc(u, mapOf("uid" to u, "name" to "Player", "username" to ""))
            } catch (_: Exception) { Doc(u, mapOf("uid" to u, "name" to "Player", "username" to "")) }
            // blue tick = users/{uid}.isVerified (set only by admin)
            try {
                val x = Repo.getDoc("users", u)
                if (x != null) p = p.with("verified" to (x.get("isVerified") == true || p.get("verified") == true))
            } catch (_: Exception) { }
            prof[u] = p; pending.remove(u)
            p
        }
        pending[u] = d
        return d.await()
    }

    fun loadProf(u: String) {
        if (u.isEmpty() || prof[u] != null) return
        AppStore.scope.launch { try { getProf(u) } catch (_: Exception) { } }
    }

    // ------------------------------------------------------------------ boot / listeners
    private fun listenDoc(path: String, fn: (Doc?) -> Unit) {
        unsubs.add(docRef(path).addSnapshotListener { s, e -> if (e == null && s != null) fn(if (s.exists()) Doc.of(s) else null) })
    }

    private fun listenQ(q: Query, fn: (List<Doc>) -> Unit) {
        unsubs.add(q.addSnapshotListener { s, e -> if (e == null && s != null) fn(s.documents.map { Doc.of(it) }) })
    }

    /** Opens the chat for the logged-in user. Throws with a readable message when chat cannot start. */
    suspend fun boot(): Boolean {
        val u = Repo.auth.currentUser
        if (u == null) { if (uid != null) reset(); throw Exception("Please login first") }
        if (ready && uid == u.uid) return true
        val running = bootJob
        if (running != null && bootUid == u.uid) return running.await()
        if (uid != null && uid != u.uid) reset()
        bootUid = u.uid
        starting = true
        val job = AppStore.scope.async { doBoot(u.uid) }
        bootJob = job
        try { return job.await() } finally { if (bootJob === job) { bootJob = null; starting = false } }
    }

    private suspend fun doBoot(id: String): Boolean {
        uid = id
        fun same(): Boolean = Repo.auth.currentUser?.uid == id && uid == id
        chatReady(); if (!same()) return false
        ChatStore.load(id)
        BadWords.start()
        listenDoc("cconfig/verified") { d ->
            ver = (d?.strList("uids") ?: emptyList()).toSet()
            ver.forEach { v -> prof[v]?.let { p -> prof[v] = p.with("verified" to true) } }
        }
        listenDoc("cconfig/world") { d -> if (d != null) mergeWorld(d) }
        val snap = docRef("cprofiles/$id").get().await(); if (!same()) return false
        me = if (snap.exists()) Doc.of(snap) else null
        val m = me
        if (m != null) {
            val photo = myPhoto(); val name = AppStore.user.s("appName").ifEmpty { m.s("name") }
            if ((photo.isNotEmpty() && photo != m.s("photo")) || (name.isNotEmpty() && name != m.s("name"))) {
                me = m.with("photo" to (photo.ifEmpty { m.s("photo") }), "name" to name)
                try { docRef("cprofiles/$id").update(mapOf("photo" to (photo.ifEmpty { m.s("photo") }), "name" to name)).await() } catch (_: Exception) { }
            }
            startListeners(); if (!same()) return false
        }
        ready = true
        ChatKeep.afterBoot()
        return true
    }

    private fun mergeWorld(d: Doc) {
        val w = world
        world = ChatWorld(
            name = if (d.has("name")) d.s("name") else w.name,
            emoji = if (d.has("emoji")) d.s("emoji") else w.emoji,
            tagline = if (d.has("tagline")) d.s("tagline") else w.tagline,
            slow = if (d.has("slow")) d.i("slow") else w.slow,
            locked = if (d.has("locked")) d.b("locked") else w.locked,
            ttlHours = if (d.has("ttlHours")) d.i("ttlHours") else w.ttlHours,
        )
    }

    private fun startListeners() {
        val id = uid ?: return
        listenDoc("cfriends/$id") { d ->
            friends = if (d == null) ChatFriends() else ChatFriends(d.strList("list"), d.strList("starred"), d.map("nicks").mapValues { it.value?.toString() ?: "" })
            friends.list.forEach { loadProf(it) }
        }
        listenDoc("cblocks/$id") { d -> blocked = d?.strList("list") ?: emptyList() }
        listenQ(fs().collection("crequests").whereEqualTo("to", id)) { l -> incoming = l.filter { it.s("status") == "pending" } }
        listenQ(fs().collection("crequests").whereEqualTo("from", id)) { l -> outgoing = l; l.forEach { loadProf(it.s("to")) } }
        listenQ(fs().collection("cchats").whereArrayContains("members", id)) { l ->
            val prev = chats; chats = l.associateBy { it.id }; ChatKeep.onChats(prev, chats, "dm")
        }
        listenQ(fs().collection("cgroups").whereArrayContains("members", id)) { l ->
            val prev = groups; groups = l.associateBy { it.id }; ChatKeep.onChats(prev, groups, "group")
        }
        startPresence(id)
    }

    private var presenceJob: kotlinx.coroutines.Job? = null
    var appVisible = true

    private fun startPresence(id: String) {
        presenceJob?.cancel()
        presenceJob = AppStore.scope.launch {
            while (true) {
                delay(60_000)
                if (me != null && uid == id && appVisible) try { docRef("cprofiles/$id").update(mapOf("online" to true, "lastSeen" to System.currentTimeMillis())).await() } catch (_: Exception) { }
            }
        }
    }

    /** The app went to the background / came back (the website's visibilitychange). */
    fun setVisible(v: Boolean) {
        appVisible = v
        val id = uid ?: return
        if (me == null) return
        AppStore.scope.launch { try { docRef("cprofiles/$id").update(mapOf("online" to v, "lastSeen" to System.currentTimeMillis())).await() } catch (_: Exception) { } }
        if (v) ChatKeep.onForeground()
    }

    /** Wipe everything that belongs to the previous account (listeners, timers, cached profiles, open thread). */
    fun reset() {
        unsubs.forEach { try { it.remove() } catch (_: Exception) { } }; unsubs.clear()
        try { thUnsub?.remove() } catch (_: Exception) { }; thUnsub = null
        stopTickWatch(); worldSeenMax = 0L
        presenceJob?.cancel(); presenceJob = null
        uid = null; me = null; ready = false; starting = false
        friends = ChatFriends(); blocked = emptyList(); incoming = emptyList(); outgoing = emptyList(); chats = emptyMap(); groups = emptyMap()
        prof.clear(); pending.clear(); ver = emptySet()
        thread = null; msgs = emptyList(); editing = null; reply = null; draft = TextFieldValue("")
        tab = "chat"; lastWorldSend = 0L
        bootJob = null; bootUid = null
        ChatUi.closeSheet(); ChatUi.menuOpen = false; ChatUi.emojiOpen = false
        BadWords.stop()
        ChatKeep.onReset()
    }

    // ------------------------------------------------------------------ profile
    private val UNAME = Regex("^[a-z0-9_]{3,20}$")

    suspend fun createProfile(unameRaw: String): Boolean {
        val uname = unameRaw.lowercase().removePrefix("@")
        if (!UNAME.matches(uname)) { toast("Username: 3–20 letters, numbers or _"); return false }
        val id = uid ?: return false
        val u = Repo.auth.currentUser
        val name = AppStore.user.s("appName").ifEmpty { u?.displayName ?: "Player" }
        val photo = myPhoto()
        val prof = mapOf<String, Any?>("uid" to id, "username" to uname, "name" to name, "photo" to photo, "isPrivate" to false, "bio" to "", "createdAt" to System.currentTimeMillis(), "lastSeen" to System.currentTimeMillis(), "online" to true)
        return try {
            val d = fs()
            val b = d.batch()
            b.set(d.document("cusernames/$uname"), mapOf("uid" to id))
            b.set(d.document("cprofiles/$id"), prof)
            b.set(d.document("cfriends/$id"), mapOf("list" to emptyList<String>(), "starred" to emptyList<String>(), "nicks" to emptyMap<String, String>(), "lastAdded" to ""))
            b.set(d.document("cblocks/$id"), mapOf("list" to emptyList<String>()))
            b.commit().await()
            me = Doc(id, prof)
            startListeners()
            ChatKeep.afterBoot()
            true
        } catch (e: Exception) { toast(if (isDenied(e)) "That username is taken — try another" else errMsg(e)); false }
    }

    suspend fun setPrivacy(p: Boolean) {
        val id = uid ?: return
        try { docRef("cprofiles/$id").update(mapOf("isPrivate" to p)).await(); me = me?.with("isPrivate" to p) } catch (e: Exception) { toast(errMsg(e)) }
    }

    suspend fun editBio() {
        val id = uid ?: return
        val r = ChatUi.ask(AskOpts(icon = "fa-pen", title = "Your bio", input = me?.s("bio") ?: "", max = 80, placeholder = "Say something about you", yes = "Save")) ?: return
        try { docRef("cprofiles/$id").update(mapOf("bio" to r.value)).await(); me = me?.with("bio" to r.value) } catch (e: Exception) { toast(errMsg(e)) }
    }

    suspend fun unblock(u: String) {
        val id = uid ?: return
        ChatUi.ask(AskOpts(icon = "fa-lock-open", title = "Unblock this user?", yes = "Unblock")) ?: return
        try { docRef("cblocks/$id").update("list", FieldValue.arrayRemove(u)).await(); toast("Unblocked") } catch (e: Exception) { toast(errMsg(e)) }
    }

    suspend fun searchUsers(q0: String): List<Doc> {
        val q = q0.lowercase().trim().removePrefix("@")
        if (q.length < 2) return emptyList()
        val s = fs().collection("cprofiles").whereGreaterThanOrEqualTo("username", q).whereLessThanOrEqualTo("username", q + "").limit(15).get().await()
        return s.documents.map { Doc.of(it) }.filter { it.s("uid") != uid && (!it.b("isPrivate") || it.s("username") == q) }
    }

    // ------------------------------------------------------------------ friend requests
    suspend fun sendRequest(u: String): Boolean {
        val id = uid ?: return false; val m = me ?: return false
        if (friends.list.size >= MAX_FRIENDS) { toast("Your friend list is full ($MAX_FRIENDS/$MAX_FRIENDS)"); return false }
        val rid = id + "_" + u
        return try {
            val ref = docRef("crequests/$rid")
            if (ref.get().await().exists()) ref.delete().await()
            ref.set(mapOf("from" to id, "to" to u, "status" to "pending", "createdAt" to System.currentTimeMillis(), "fromName" to m.s("name"), "fromPhoto" to m.s("photo"), "fromUsername" to m.s("username"))).await()
            toast("Friend request sent ✓"); true
        } catch (e: Exception) { toast(if (isDenied(e)) "Couldn't send — their list may be full or you are blocked" else errMsg(e)); false }
    }

    suspend fun acceptRequest(r: Doc): Boolean {
        val id = uid ?: return false
        if (friends.list.size >= MAX_FRIENDS) { toast("Your friend list is full ($MAX_FRIENDS/$MAX_FRIENDS)"); return false }
        val from = r.s("from")
        return try {
            val b = fs().batch()
            b.update(docRef("crequests/${r.id}"), mapOf("status" to "accepted", "respondedAt" to System.currentTimeMillis()))
            b.update(docRef("cfriends/$id"), mapOf("list" to FieldValue.arrayUnion(from), "lastAdded" to from))
            b.update(docRef("cfriends/$from"), mapOf("list" to FieldValue.arrayUnion(id)))
            b.commit().await()
            toast("You are now friends 🎉"); true
        } catch (e: Exception) { toast(if (isDenied(e)) "Couldn't accept — their friend list may be full" else errMsg(e)); false }
    }

    suspend fun rejectRequest(r: Doc) {
        try { docRef("crequests/${r.id}").update(mapOf("status" to "rejected", "respondedAt" to System.currentTimeMillis())).await(); toast("Request rejected") } catch (e: Exception) { toast(errMsg(e)) }
    }

    suspend fun cancelRequest(id: String) {
        try { docRef("crequests/$id").delete().await(); toast("Request cancelled") } catch (e: Exception) { toast(errMsg(e)) }
    }

    suspend fun removeFriend(u: String) {
        val id = uid ?: return
        ChatUi.ask(AskOpts(icon = "fa-user-minus", title = "Remove ${friendName(u)}?", text = "You will both lose this friend. You can send a new request later.", yes = "Remove", danger = true)) ?: return
        try {
            val b = fs().batch()
            b.update(docRef("cfriends/$id"), mapOf("list" to FieldValue.arrayRemove(u), "starred" to FieldValue.arrayRemove(u)))
            b.update(docRef("cfriends/$u"), mapOf("list" to FieldValue.arrayRemove(id)))
            b.commit().await()
            try { docRef("crequests/${id}_$u").delete().await() } catch (_: Exception) { }
            try { docRef("crequests/${u}_$id").delete().await() } catch (_: Exception) { }
            toast("Friend removed")
        } catch (e: Exception) { toast(errMsg(e)) }
    }

    // ------------------------------------------------------------------ conversation
    fun pathOf(th: ChatThread): String = when (th.kind) { "world" -> "cworld"; "dm" -> "cchats/${th.id}/msgs"; else -> "cgroups/${th.id}/msgs" }
    fun pathOf(kind: String, id: String): String = pathOf(ChatThread(kind, id))

    fun threadName(th: ChatThread): String = when (th.kind) {
        "dm" -> friendName(th.uid)
        "group" -> groups[th.id]?.s("name")?.ifEmpty { "Group" } ?: "Group"
        else -> world.name
    }

    fun openThread(kind: String, id: String, u: String = "") {
        ChatUi.menuOpen = false; ChatUi.emojiOpen = false
        val th = ChatThread(kind, id, u)
        thread = th; editing = null; draft = TextFieldValue("")
        msgs = emptyList(); msgsState = "loading"; msgsError = ""
        if (kind == "dm") loadProf(u)
        try { thUnsub?.remove() } catch (_: Exception) { }
        ChatKeep.onOpen(th)
        stopTickWatch()
        // includeMetadataChanges: a message that is still waiting for the server (no net / slow) is flagged "_p" and shows a spinner;
        // when the server has it, the same listener fires again and the spinner turns into a tick.
        thUnsub = fs().collection(pathOf(th)).whereGreaterThan("at", System.currentTimeMillis() - ttlMs(kind)).orderBy("at", Query.Direction.DESCENDING).limit(80)
            .addSnapshotListener(MetadataChanges.INCLUDE) { s, e ->
                if (thread !== th) return@addSnapshotListener
                if (e != null || s == null) { msgsState = "error"; msgsError = errMsg(e); return@addSnapshotListener }
                val list = s.documents.map { d -> Doc.of(d).let { if (d.metadata.hasPendingWrites()) it.with("_p" to true) else it } }.filter { alive(it, kind) }.reversed()
                msgs = list; msgsState = "ok"
                if (s.documentChanges.isNotEmpty()) {
                    ChatKeep.onMsgs(th, list)
                    markRead()
                    if (kind == "world") pingWorldSeen()
                }
                if (kind == "world") ensureWorldWatch()
            }
        if (kind == "dm") {
            peerUnsub = docRef("cprofiles/$u").addSnapshotListener { ps, pe ->
                if (pe != null || ps == null || !ps.exists() || thread !== th) return@addSnapshotListener
                val old = prof[u]
                val merged = (old?.m ?: emptyMap()) + (ps.data ?: emptyMap())
                prof[u] = Doc(u, merged + ("verified" to (old?.b("verified") == true || ps.getBoolean("verified") == true)))
            }
        }
        if (kind == "world") {
            pingWorldSeen(true)
            wsJob = AppStore.scope.launch { while (true) { delay(25_000); pingWorldSeen() } }
        }
    }

    // ------------------------------------------------------------------ ticks: sent / delivered / seen
    // DM:    spinner = not on the server yet · 1 tick = sent · 2 grey = friend was online after it · 2 green = friend opened the chat
    //        (cchats.unread[friend] went back to 0)
    // World: spinner · 1 tick = sent · 2 green = somebody else has seen it (their profile.worldSeenAt, or they posted after you)
    // Same data model as the website (pages/chat/chat.js), so both show the same ticks.

    /** "I am looking at the World room right now" — written to my profile at most every 20 s. */
    fun pingWorldSeen(force: Boolean = false) {
        val id = uid ?: return
        if (noWorldSeen || me == null || thread?.kind != "world" || !appVisible) return
        val n = System.currentTimeMillis()
        if (!force && n - wsWriteAt < 20_000) return
        wsWriteAt = n
        docRef("cprofiles/$id").update("worldSeenAt", n).addOnFailureListener { e -> if (isDenied(e)) noWorldSeen = true }
    }

    /** Watches other players' worldSeenAt while I have World messages that nobody has seen yet. */
    private fun ensureWorldWatch() {
        val id = uid ?: return
        if (thread?.kind != "world") return
        val mine = msgs.filter { it.s("from") == id && !it.b("deleted") && !it.b("_p") }
        if (mine.isEmpty()) { stopWorldWatch(); return }
        if (worldSeenMax >= mine.last().l("at")) { stopWorldWatch(); return }   // everything of mine is already seen
        if (wsUnsub != null) return
        wsUnsub = fs().collection("cprofiles").whereGreaterThan("worldSeenAt", mine.first().l("at") - 1).orderBy("worldSeenAt", Query.Direction.DESCENDING).limit(6)
            .addSnapshotListener { qs, e ->
                if (e != null || qs == null) { stopWorldWatch(); return@addSnapshotListener }
                var mx = 0L
                for (d in qs.documents) if (d.id != id) mx = Math.max(mx, (d.get("worldSeenAt") as? Number)?.toLong() ?: 0L)
                if (mx > worldSeenMax) worldSeenMax = mx
                ensureWorldWatch()
            }
    }

    private fun stopWorldWatch() { try { wsUnsub?.remove() } catch (_: Exception) { }; wsUnsub = null }

    private fun stopTickWatch() {
        stopWorldWatch()
        wsJob?.cancel(); wsJob = null
        try { peerUnsub?.remove() } catch (_: Exception) { }; peerUnsub = null
    }

    fun closeThread() {
        val th = thread
        try { thUnsub?.remove() } catch (_: Exception) { }; thUnsub = null
        stopTickWatch()
        thread = null; editing = null; reply = null; draft = TextFieldValue("")   // msgs stay so the slide-out animation still shows them
        ChatUi.menuOpen = false; ChatUi.emojiOpen = false
        ChatKeep.onClose(th)
    }

    private fun markRead() {
        val th = thread ?: return; val id = uid ?: return
        if (th.kind == "world") return
        val c = if (th.kind == "dm") chats[th.id] else groups[th.id]
        val n = (c?.map("unread")?.get(id) as? Number)?.toInt() ?: 0
        if (c != null && n > 0) docRef((if (th.kind == "dm") "cchats/" else "cgroups/") + th.id).update("unread.$id", 0)
    }

    /** Replace the shown messages (local copies of friend chats come back from this phone). */
    fun setMsgs(l: List<Doc>) { msgs = l }

    fun replyTo(id: String) {
        val m = msgs.firstOrNull { it.id == id } ?: return
        if (m.b("deleted") || thread == null) return
        reply = ChatReply(m.id, if (m.s("from") == uid) "You" else m.s("name").ifEmpty { friendName(m.s("from")) }, snippet(m), m.s("from"))
        ChatUi.closeSheet()
    }

    fun cancelReply() { reply = null }

    /** Open (or start) a direct message with anyone — friends, or World users whose profile is public. */
    suspend fun openDm(u: String) {
        val id = uid ?: return
        if (u.isEmpty() || u == id) return
        val p = getProf(u)
        if (isBlocked(u)) { toast("You blocked this user — unblock to message"); return }
        if (!isFriend(u) && p.b("isPrivate")) { toast("This profile is private — send a friend request first"); return }
        ChatUi.closeSheet()
        openThread("dm", chatId(id, u), u)
    }

    /** Sends the typed text. Returns true when the composer should be cleared (the message is on its way). */
    fun send(onFail: (String) -> Unit): Boolean {
        val th = thread ?: return false; val id = uid ?: return false; val m = me ?: return false
        val text = draft.text.trim()
        if (text.isEmpty()) return false
        if (BadWords.blocked(text)) return false
        if (editing != null) { doEdit(text); return true }
        val now = System.currentTimeMillis()
        if (th.kind == "world") {
            if (world.locked) { toast("World chat is locked by admin right now"); return false }
            val slow = world.slow * 1000L
            if (slow > 0 && now - lastWorldSend < slow) { toast("Slow mode: wait ${Math.ceil((slow - (now - lastWorldSend)) / 1000.0).toInt()}s"); return false }
        }
        if (th.kind == "dm" && isBlocked(th.uid)) { toast("You blocked this user"); return false }
        val rp = reply; reply = null
        AppStore.scope.launch {
            try {
                val msg = HashMap<String, Any?>()
                msg["from"] = id; msg["text"] = text; msg["at"] = now
                if (th.kind == "world") { msg["name"] = m.s("name"); msg["photo"] = m.s("photo"); lastWorldSend = now }
                if (th.kind == "dm" && chats[th.id] == null) {
                    val members = listOf(id, th.uid).sorted()
                    docRef("cchats/${th.id}").set(mapOf("members" to members, "createdAt" to now, "lastMsg" to "", "lastAt" to 0L, "lastFrom" to "", "unread" to emptyMap<String, Any>())).await()
                    chats = chats + (th.id to Doc(th.id, mapOf("members" to members)))
                }
                val col = fs().collection(pathOf(th))
                fun packed(r: ChatReply) = encReply(ChatReply(r.id, r.n.take(30), r.t.take(80), r.u)) + text
                if (rp != null && !noReplyFields) {
                    try { col.add(msg + mapOf("rid" to rp.id, "rn" to rp.n.take(40), "rt" to rp.t.take(140), "ru" to rp.u)).await() }
                    catch (e: Exception) { if (isDenied(e)) { noReplyFields = true; col.add(msg + ("text" to packed(rp))).await() } else throw e }
                } else if (rp != null) col.add(msg + ("text" to packed(rp))).await()
                else col.add(msg).await()
                val last = ((if (rp != null) "↪ " else "") + text).take(60)
                if (th.kind == "dm") docRef("cchats/${th.id}").update(mapOf("lastMsg" to last, "lastAt" to now, "lastFrom" to id, "unread.${th.uid}" to FieldValue.increment(1))).await()
                if (th.kind == "group") {
                    val g = groups[th.id]
                    val up = HashMap<String, Any?>(); up["lastMsg"] = last; up["lastAt"] = now; up["lastFrom"] = id
                    (g?.strList("members") ?: emptyList()).forEach { mm -> if (mm != id) up["unread.$mm"] = FieldValue.increment(1) }
                    docRef("cgroups/${th.id}").update(up).await()
                }
            } catch (e: Exception) {
                onFail(text)
                toast(if (isDenied(e)) "Message not sent — you can't message this user" else errMsg(e))
            }
        }
        return true
    }

    private fun doEdit(text: String) {
        val th = thread ?: return; val id = editing ?: return
        val m = msgs.firstOrNull { it.id == id }
        val mod = canMod(m)
        if (m == null || (!mod && System.currentTimeMillis() - m.l("at") >= EDIT_MS)) { cancelEdit(); toast("Edit time (10 min) is over"); return }
        val pre = if (m.s("rid").isNotEmpty()) "" else RPX.find(m.s("text"))?.value ?: ""
        val data: Map<String, Any?> = if (mod) mapOf("text" to pre + text, "edited" to true, "editBy" to uid) else mapOf("text" to pre + text, "edited" to true)
        AppStore.scope.launch {
            try { docRef(pathOf(th) + "/" + id).update(data).await(); cancelEdit() } catch (e: Exception) { toast(errMsg(e)) }
        }
    }

    fun cancelEdit() { editing = null; draft = TextFieldValue("") }

    fun editStart(id: String) {
        val m = msgs.firstOrNull { it.id == id } ?: return
        ChatUi.closeSheet(); editing = id
        val t = parseMsg(m).text
        draft = TextFieldValue(t, androidx.compose.ui.text.TextRange(t.length))
    }

    suspend fun delMsg(id: String) {
        val th = thread ?: return
        ChatUi.ask(AskOpts(icon = "fa-trash", title = "Delete this message?", text = "It will be removed for everyone.", yes = "Delete", danger = true)) ?: return
        val m = msgs.firstOrNull { it.id == id }; val mod = canMod(m)
        if (m == null || (!mod && System.currentTimeMillis() - m.l("at") >= EDIT_MS)) { toast("Delete time (10 min) is over"); return }
        val data: Map<String, Any?> = if (mod) mapOf("deleted" to true, "text" to "", "delBy" to uid) else mapOf("deleted" to true, "text" to "")
        try { docRef(pathOf(th) + "/" + id).update(data).await(); toast("Message deleted") } catch (e: Exception) { toast(errMsg(e)) }
    }

    // ------------------------------------------------------------------ ⋮ menu: block / star / rename / report / group
    suspend fun mBlock() {
        val th = thread ?: return; val id = uid ?: return; val u = th.uid
        ChatUi.menuOpen = false
        val bl = isBlocked(u); val n = friendName(u)
        ChatUi.ask(AskOpts(icon = if (bl) "fa-lock-open" else "fa-ban", title = if (bl) "Unblock $n?" else "Block $n?", text = if (bl) "They will be able to message you again." else "They will not be able to send you messages.", yes = if (bl) "Unblock" else "Block", danger = !bl)) ?: return
        try { docRef("cblocks/$id").update("list", if (bl) FieldValue.arrayRemove(u) else FieldValue.arrayUnion(u)).await(); toast(if (bl) "User unblocked" else "User blocked") } catch (e: Exception) { toast(errMsg(e)) }
    }

    suspend fun mStar() {
        val th = thread ?: return; val id = uid ?: return; val u = th.uid
        ChatUi.menuOpen = false
        val st = u in friends.starred; val n = friendName(u)
        ChatUi.ask(AskOpts(icon = "fa-star", title = if (st) "Remove star from $n?" else "Star $n?", text = if (st) "They will no longer be pinned on top." else "Starred friends are pinned on top of your chat list.", yes = if (st) "Remove star" else "Star friend")) ?: return
        try { docRef("cfriends/$id").update("starred", if (st) FieldValue.arrayRemove(u) else FieldValue.arrayUnion(u)).await(); toast(if (st) "Star removed" else "Friend starred ⭐") } catch (e: Exception) { toast(errMsg(e)) }
    }

    suspend fun mRename() {
        val th = thread ?: return; val id = uid ?: return; val u = th.uid
        ChatUi.menuOpen = false
        val real = prof[u]?.s("name")?.ifEmpty { "Player" } ?: "Player"
        val r = ChatUi.ask(AskOpts(icon = "fa-pen", title = "Rename (only for you)", text = "Their real name stays \"$real\". Leave empty to reset.", input = friends.nicks[u] ?: "", placeholder = real, yes = "Save name")) ?: return
        try { docRef("cfriends/$id").update("nicks.$u", r.value).await(); toast("Name saved") } catch (e: Exception) { toast(errMsg(e)) }
    }

    suspend fun mReport() {
        val th = thread ?: return; val id = uid ?: return; val m = me ?: return
        ChatUi.menuOpen = false
        val u = th.uid; val n = if (th.kind == "dm") friendName(u) else threadName(th)
        val r = ChatUi.ask(AskOpts(icon = "fa-flag", title = "Report $n?", text = "This sends a message to our support team. They will review the chat.", chips = listOf("Spam", "Abuse / harassment", "Cheating / hacks", "Scam / fraud", "Other"), area = "Tell support what happened (optional)", yes = "Send to support", danger = true)) ?: return
        try {
            fs().collection("creports").add(mapOf("from" to id, "against" to u, "chatId" to th.id.ifEmpty { "world" }, "kind" to th.kind, "reason" to r.value + (if (r.extra.isNotEmpty()) " — " + r.extra else ""), "createdAt" to System.currentTimeMillis(), "status" to "open", "fromName" to m.s("name"), "againstName" to n)).await()
            toast("Report sent to support ✓")
        } catch (e: Exception) { toast(errMsg(e)) }
    }

    /** User card in World → Report. */
    suspend fun reportWorldUser(u: String, nm: String) {
        val id = uid ?: return
        ChatUi.closeSheet()
        val r = ChatUi.ask(AskOpts(icon = "fa-flag", title = "Report $nm?", text = "Our support team will review the World chat.", chips = listOf("Spam", "Abuse / harassment", "Scam / fraud", "Other"), yes = "Send report", danger = true)) ?: return
        try {
            fs().collection("creports").add(mapOf("from" to id, "against" to u, "chatId" to "world", "kind" to "world", "reason" to r.value + (if (r.extra.isNotEmpty()) " — " + r.extra else ""), "createdAt" to System.currentTimeMillis(), "status" to "open", "fromName" to (me?.s("name") ?: ""), "againstName" to nm)).await()
            toast("Report sent to support ✓")
        } catch (e: Exception) { toast(errMsg(e)) }
    }

    fun mGroupInfo() {
        val th = thread ?: return
        ChatUi.menuOpen = false
        val g = groups[th.id] ?: return
        g.strList("members").forEach { loadProf(it) }
        ChatUi.show(ChatSheet.GroupInfo(g.id))
    }

    suspend fun mLeave() {
        val th = thread ?: return; val id = uid ?: return
        ChatUi.menuOpen = false
        val g = groups[th.id] ?: return
        ChatUi.ask(AskOpts(icon = "fa-right-from-bracket", title = "Leave \"${g.s("name")}\"?", text = "You will stop receiving messages from this group.", yes = "Leave", danger = true)) ?: return
        try { docRef("cgroups/${g.id}").update("members", FieldValue.arrayRemove(id)).await(); closeThread(); toast("You left the group") } catch (e: Exception) { toast(errMsg(e)) }
    }

    fun createGroupSheet() {
        if (friends.list.isEmpty()) { toast("Add some friends first"); return }
        friends.list.forEach { loadProf(it) }
        ChatUi.show(ChatSheet.NewGroup())
    }

    suspend fun makeGroup(nameRaw: String, picked: Set<String>) {
        val id = uid ?: return
        val name = nameRaw.trim()
        if (name.length < 2) { toast("Enter a group name"); return }
        if (picked.isEmpty()) { toast("Pick at least one friend"); return }
        try {
            val emoji = listOf("🎮", "⚔️", "🏆", "🔥", "🦅", "💥").random()
            val ref = fs().collection("cgroups").add(mapOf("name" to name, "emoji" to emoji, "owner" to id, "members" to (listOf(id) + picked), "createdAt" to System.currentTimeMillis(), "lastMsg" to "", "lastAt" to System.currentTimeMillis(), "lastFrom" to "", "unread" to emptyMap<String, Any>())).await()
            ChatUi.closeSheet(); toast("Group created 🎉")
            delay(350); openThread("group", ref.id)
        } catch (e: Exception) { toast(errMsg(e)) }
    }
}
