package com.ffcashbattle.app.data

import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject

/**
 * Hands the app's login over to the website pages that open inside the app (Proofs -> ffcashbattle.in/proof).
 *
 * Why: the proof page is the website, running in a WebView that has its own storage. The website decides "logged in?" with
 * the Firebase JS SDK, which looks for its saved user in the page's storage - and a WebView never has the user the native app
 * signed in. So Like / Comment / Share on the proof page always said "login first", even for a logged-in app user.
 *
 * What this does: [script] builds a tiny JavaScript that is run BEFORE the page's own scripts. It writes the current Firebase user
 * (uid, e-mail, name, photo and a fresh ID token) into the page storage in exactly the format the Firebase JS SDK saves it
 * ("firebase:authUser:<apiKey>:[DEFAULT]", in IndexedDB and localStorage), so the SDK starts up already signed in as the same
 * user. When the app is logged out it removes that saved user instead, so a WebView never keeps an old account.
 *
 * Limits: the fresh ID token is valid for about 1 hour, so one proof-page session works for ~1 hour; open the page again after that.
 * The same script also copies the app's light / dark mode into the page (localStorage "darkMode", which the website reads).
 * Nothing is sent anywhere and the token never leaves the phone - it is only written into the WebView's own storage.
 */
object WebAuth {
    /** The only hosts that get the login (document-start scripts are limited to these origins). */
    val ORIGINS: Set<String> = setOf("https://ffcashbattle.in", "https://www.ffcashbattle.in")

    /** Never throws: on any problem the script just signs the page out (empty user), exactly like before this feature. */
    suspend fun script(dark: Boolean = false): String {
        val user = try { Repo.auth.currentUser } catch (_: Exception) { null }
        var u: JSONObject? = null
        if (user != null) {
            try {
                // a fresh token (valid ~1 h); when offline fall back to the one we have
                val res = withTimeoutOrNull(6_000) { try { user.getIdToken(true).await() } catch (_: Exception) { user.getIdToken(false).await() } }
                val token = res?.token
                if (res != null && token != null) {
                    val o = JSONObject()
                    o.put("uid", user.uid)
                    user.email?.let { o.put("email", it) }
                    o.put("emailVerified", user.isEmailVerified)
                    user.displayName?.let { o.put("displayName", it) }
                    user.photoUrl?.let { o.put("photoURL", it.toString()) }
                    user.phoneNumber?.let { o.put("phoneNumber", it) }
                    o.put("isAnonymous", false)
                    val prov = JSONArray()
                    for (p in user.providerData) {
                        if (p.providerId == "firebase") continue   // the JS SDK lists only the real sign-in providers
                        val po = JSONObject()
                        po.put("providerId", p.providerId)
                        po.put("uid", p.uid ?: user.uid)
                        p.displayName?.let { po.put("displayName", it) }
                        p.email?.let { po.put("email", it) }
                        p.phoneNumber?.let { po.put("phoneNumber", it) }
                        p.photoUrl?.let { po.put("photoURL", it.toString()) }
                        prov.put(po)
                    }
                    o.put("providerData", prov)
                    val sts = JSONObject()
                    sts.put("refreshToken", "")
                    sts.put("accessToken", token)
                    sts.put("expirationTime", res.expirationTimestamp * 1000L)
                    o.put("stsTokenManager", sts)
                    user.metadata?.let { md ->
                        o.put("createdAt", md.creationTimestamp.toString())
                        o.put("lastLoginAt", md.lastSignInTimestamp.toString())
                    }
                    o.put("apiKey", Cfg.API_KEY)
                    o.put("appName", "[DEFAULT]")
                    u = o
                }
            } catch (_: Exception) { u = null }
        }
        val key = JSONObject.quote("firebase:authUser:${Cfg.API_KEY}:[DEFAULT]")
        val value = u?.toString() ?: "null"
        return """
            (function(){try{
              var K=$key, U=$value;
              try{ localStorage.setItem('darkMode', '$dark'); }catch(e){}   // the page follows the app's light / dark mode
              try{ if(U){ localStorage.setItem(K, JSON.stringify(U)); } else { localStorage.removeItem(K); } }catch(e){}
              try{
                var rq=indexedDB.open('firebaseLocalStorageDb',1);
                rq.onupgradeneeded=function(){ var d=rq.result; if(!d.objectStoreNames.contains('firebaseLocalStorage')) d.createObjectStore('firebaseLocalStorage',{keyPath:'fbase_key'}); };
                rq.onsuccess=function(){ try{
                  var d=rq.result, tx=d.transaction('firebaseLocalStorage','readwrite'), st=tx.objectStore('firebaseLocalStorage');
                  if(U){ st.put({fbase_key:K, value:U}); } else { st.delete(K); }
                  tx.oncomplete=function(){ try{d.close();}catch(e){} };
                }catch(e){} };
              }catch(e){}
            }catch(e){}})();
        """.trimIndent()
    }
}
