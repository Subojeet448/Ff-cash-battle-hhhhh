package com.ffcashbattle.app.ui.screens.chat

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.R
import com.ffcashbattle.app.data.Chat
import com.ffcashbattle.app.data.ChatKeep
import com.ffcashbattle.app.data.ChatSheet
import com.ffcashbattle.app.data.ChatStore
import com.ffcashbattle.app.data.ChatUi
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.data.Games
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FRich
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.SpinIcon
import com.ffcashbattle.app.ui.comp.VerifiedName
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.screens.FaqChip
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.Inter
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private fun unreadOf(c: Doc?, uid: String): Int = (c?.map("unread")?.get(uid) as? Number)?.toInt() ?: 0

// ==================================================================================== Chat tab

private class ListRow(
    val kind: String, val id: String, val uid: String, val name: String, val photo: String?, val emoji: String?,
    val lastMsg: String, val lastAt: Long, val unread: Int, val star: Boolean, val online: Boolean, val members: Int,
)

@Composable
internal fun ChatListPane() {
    val c = FF.c
    val uid = Chat.uid ?: ""
    val items = ArrayList<ListRow>()
    for (f in Chat.friends.list) {
        val ch = Chat.chats[Chat.chatId(uid, f)]; val p = Chat.prof[f]
        items.add(ListRow("dm", Chat.chatId(uid, f), f, Chat.friendName(f), p?.s("photo"), null, ch?.s("lastMsg") ?: "", ch?.l("lastAt") ?: 0L, unreadOf(ch, uid), f in Chat.friends.starred, p?.b("online") == true, 0))
    }
    for (ch in Chat.chats.values) {
        val o = ch.strList("members").firstOrNull { it != uid } ?: continue
        if (o in Chat.friends.list || Chat.isBlocked(o)) continue
        Chat.loadProf(o)
        val p = Chat.prof[o]
        items.add(ListRow("dm", ch.id, o, Chat.friendName(o), p?.s("photo"), null, ch.s("lastMsg"), ch.l("lastAt"), unreadOf(ch, uid), false, p?.b("online") == true, 0))
    }
    for (g in Chat.groups.values) {
        items.add(ListRow("group", g.id, "", g.s("name"), null, g.s("emoji"), g.s("lastMsg"), g.l("lastAt"), unreadOf(g, uid), false, false, g.strList("members").size))
    }
    items.sortWith(compareByDescending<ListRow> { it.star }.thenByDescending { it.lastAt })

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 40.dp)) {
        WorldCard()
        SecHeader("Chats") { MiniBtn("New group", "fa-solid fa-users-line", { Chat.createGroupSheet() }) }
        if (items.isEmpty()) {
            ChatEmpty("fa-solid fa-comments", "No chats yet", "Find players in Search and send a friend request. Once accepted you can chat here.") {
                CsBtn("Find friends", { Chat.tab = "search" }, Modifier.width(190.dp))
            }
        } else {
            items.forEachIndexed { i, it ->
                CvRow(i, { Chat.openThread(it.kind, it.id, it.uid) }) {
                    if (it.kind == "dm") ChatAv(it.name, it.photo, 46.dp, online = it.online) else EmojiAv(it.emoji ?: "👥", 46.dp, world = it.kind == "world")
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            if (it.kind == "dm") VerifiedName(it.name, it.uid, rem(0.92), Modifier.weight(1f, fill = false), FontWeight.Bold, force = Chat.isVer(it.uid))
                            else FText(it.name, Modifier.weight(1f, fill = false), size = rem(0.92), weight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, tags = true)
                            if (it.star) FaIcon("fa-solid fa-star", rem(0.72).value.dp, CxAmber)
                            if (it.kind == "group") Box(Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFFEEF2FF)).padding(horizontal = 7.dp, vertical = 1.dp)) { FText(it.members.toString(), size = rem(0.62), weight = FontWeight.ExtraBold, color = CxIndigo) }
                        }
                        FText(
                            if (it.lastMsg.isNotEmpty()) it.lastMsg else if (it.kind == "dm") "Say hi 👋" else "No messages yet",
                            size = rem(0.75), color = if (it.unread > 0) c.textMain else c.textMuted, weight = if (it.unread > 0) FontWeight.Bold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        FText(if (it.lastAt > 0) fmtAgo(it.lastAt) else "", size = rem(0.68), color = c.textMuted)
                        if (it.unread > 0) CountBadge(it.unread)
                    }
                }
            }
        }
    }
}

@Composable
private fun WorldCard() {
    val w = Chat.world
    val shape = RoundedCornerShape(22.dp)
    val (ty, rot) = rememberBounce(2600, 5f)
    val pulse = rememberPulse(1400)
    val flag = ChatKeep.worldFlag || ChatKeep.replyFlag
    Box(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().press(0.975f) { Chat.openThread("world", "world") }.boxShadow(30.dp, Color(0xCCEF4444), shape).clip(shape)
                .background(Brush.linearGradient(0f to CxAmber, 0.6f to CxRed, 1f to CxPink)).padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(if (isBooyahDefault(w.emoji)) Color.Transparent else Color.White.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                WorldIcon(w.emoji, 50.dp, rem(2.0), Modifier.graphicsLayer { translationY = ty.dp.toPx(); rotationZ = rot })
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                FText(w.name, size = rem(1.02), weight = FontWeight.Black, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                FText(w.tagline, size = rem(0.72), color = Color.White.copy(alpha = 0.92f), maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Row(Modifier.clip(RoundedCornerShape(20.dp)).background(Color.Black.copy(alpha = 0.22f)).padding(horizontal = 10.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).graphicsLayer { alpha = 0.55f + 0.45f * pulse; scaleX = 0.85f + 0.3f * pulse; scaleY = 0.85f + 0.3f * pulse }.clip(CircleShape).background(Color(0xFF4ADE80)))
                FText("LIVE", size = rem(0.62), weight = FontWeight.Black, color = Color.White, letterSpacing = 0.8.sp)
            }
        }
        if (flag) Box(Modifier.align(Alignment.TopEnd).offset(x = (-12).dp, y = 10.dp).size(14.dp).clip(CircleShape).background(if (ChatKeep.replyFlag) Color(0xFFF43F5E) else CxRed).border(2.dp, Color.White, CircleShape))
    }
}

// ==================================================================================== Profile tab

@Composable
internal fun ChatProfilePane() {
    val c = FF.c
    val m = Chat.me ?: return
    val scope = rememberCoroutineScope()
    val uid = Chat.uid ?: ""
    val friends = Chat.friends.list.sortedByDescending { it in Chat.friends.starred }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 40.dp)) {
        val shape = RoundedCornerShape(28.dp)
        Column(Modifier.fillMaxWidth().boxShadow(22.dp, Color(0x1F000000), shape).clip(shape).background(c.bgCard).border(1.dp, c.border, shape).padding(bottom = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().height(110.dp).background(Brush.linearGradient(0f to Cx6366, 0.55f to Color(0xFFA855F7), 1f to CxPink)).drawBehind {
                drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.28f), Color.Transparent), center = Offset(size.width * 0.8f, size.height * 0.2f), radius = size.width * 0.5f), radius = size.width * 0.5f, center = Offset(size.width * 0.8f, size.height * 0.2f))
            })
            Box(Modifier.offset(y = (-50).dp).padding(bottom = 0.dp)) {
                Box(Modifier.size(92.dp).border(4.dp, c.bgCard, CircleShape).clip(CircleShape)) { ChatAv(m.s("name"), m.s("photo"), 92.dp) }
                val p = rememberPulse(1800)
                Box(Modifier.align(Alignment.BottomEnd).offset(x = (-4).dp, y = (-6).dp).size(18.dp).graphicsLayer { scaleX = 1f + 0.12f * p; scaleY = 1f + 0.12f * p }.clip(CircleShape).background(CxGreen).border(3.dp, c.bgCard, CircleShape))
            }
            Column(Modifier.offset(y = (-42).dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                VerifiedName(m.s("name"), uid, rem(1.3), weight = FontWeight.Black, force = Chat.isVer(uid))
                FText("@" + m.s("username"), size = rem(0.86), weight = FontWeight.ExtraBold, color = c.primary, modifier = Modifier.padding(top = 2.dp))
                Row(Modifier.padding(start = 24.dp, end = 24.dp, top = 10.dp).tap { scope.launch { Chat.editBio() } }, horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
                    if (m.s("bio").isNotEmpty()) FText(m.s("bio"), Modifier.weight(1f, fill = false), size = rem(0.82), color = c.textMuted, lineHeight = rem(0.82) * 1.5f, align = TextAlign.Center)
                    else FText("Tap to add a bio", Modifier.weight(1f, fill = false), size = rem(0.82), color = c.textMuted, italic = true)
                    FaIcon("fa-solid fa-pen", rem(0.7).value.dp, c.textMuted.copy(alpha = 0.6f))
                }
                PrivacyToggle(m.b("isPrivate"))
                FText(
                    if (m.b("isPrivate")) "Private: people can find you only by your exact username." else "Public: anyone can find you by searching your username.",
                    Modifier.padding(start = 28.dp, end = 28.dp, bottom = 14.dp), size = rem(0.7), color = c.textMuted, align = TextAlign.Center, lineHeight = rem(0.7) * 1.4f,
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatTile(Chat.friends.list.size.toString(), "/" + Chat.MAX_FRIENDS, "Friends", Modifier.weight(1f))
                    StatTile(Chat.friends.starred.size.toString(), "", "Starred", Modifier.weight(1f))
                    StatTile(Chat.blocked.size.toString(), "", "Blocked", Modifier.weight(1f))
                }
                val hs = RoundedCornerShape(18.dp)
                Row(
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp).press(0.98f) { ChatUi.historyTab = "matches"; ChatUi.show(ChatSheet.History("matches")) }
                        .clip(hs).background(Brush.linearGradient(listOf(Cx6366.copy(alpha = 0.10f), CxPink.copy(alpha = 0.08f)))).border(1.dp, c.border, hs).padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Cx6366, Color(0xFFA855F7)))), contentAlignment = Alignment.Center) { FaIcon("fa-solid fa-clock-rotate-left", rem(1.0).value.dp, Color.White) }
                    Column(Modifier.weight(1f)) {
                        FText("History", size = rem(0.92), weight = FontWeight.ExtraBold)
                        FText("Match history & friend requests", size = rem(0.7), color = c.textMuted)
                    }
                    if (Chat.incoming.isNotEmpty()) CountBadge(Chat.incoming.size)
                    FaIcon("fa-solid fa-chevron-right", rem(0.8).value.dp, c.textMuted)
                }
            }
        }
        AlertsCard()
        SecHeader("My friends")
        if (friends.isEmpty()) ChatEmpty("fa-solid fa-user-group", null, "No friends yet", small = true)
        friends.forEachIndexed { i, f ->
            CvRow(i, null) {
                ChatAv(Chat.friendName(f), Chat.prof[f]?.s("photo"), 46.dp)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        VerifiedName(Chat.friendName(f), f, rem(0.92), Modifier.weight(1f, fill = false), FontWeight.Bold, force = Chat.isVer(f))
                        if (f in Chat.friends.starred) FaIcon("fa-solid fa-star", rem(0.72).value.dp, CxAmber)
                    }
                    FText("@" + (Chat.prof[f]?.s("username") ?: ""), size = rem(0.75), color = c.textMuted, maxLines = 1)
                }
                RoundAct("fa-solid fa-message", false) { Chat.openThread("dm", Chat.chatId(uid, f), f) }
                RoundAct("fa-solid fa-user-minus", true) { scope.launch { Chat.removeFriend(f) } }
            }
        }
        if (Chat.blocked.isNotEmpty()) {
            SecHeader("Blocked")
            Chat.blocked.forEachIndexed { i, b ->
                Chat.loadProf(b)
                CvRow(i, null) {
                    ChatAv(Chat.prof[b]?.s("name") ?: "?", Chat.prof[b]?.s("photo"), 46.dp)
                    FText(Chat.prof[b]?.s("name")?.ifEmpty { "User" } ?: "User", Modifier.weight(1f), size = rem(0.92), weight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    RoundAct("fa-solid fa-lock-open", false) { scope.launch { Chat.unblock(b) } }
                }
            }
        }
    }
}

@Composable
private fun RoundAct(icon: String, red: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(36.dp).press(0.9f, onClick = onClick).clip(RoundedCornerShape(12.dp)).background(if (red) CxRed.copy(alpha = 0.10f) else Cx6366.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
        FaIcon(icon, rem(0.9).value.dp, if (red) CxRed else CxIndigo)
    }
}

@Composable
private fun StatTile(value: String, sub: String, label: String, modifier: Modifier) {
    val c = FF.c
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(c.bgInput).padding(horizontal = 4.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            FText(value, size = rem(1.1), weight = FontWeight.Black)
            if (sub.isNotEmpty()) FText(sub, size = rem(0.7), color = c.textMuted, weight = FontWeight.Normal)
        }
        FText(label.uppercase(), size = rem(0.66), weight = FontWeight.ExtraBold, color = c.textMuted, letterSpacing = 0.4.sp)
    }
}

@Composable
private fun PrivacyToggle(priv: Boolean) {
    val c = FF.c
    val scope = rememberCoroutineScope()
    val x by animateDpAsState(if (priv) 111.dp else 0.dp, spring(dampingRatio = 0.62f, stiffness = 380f), label = "thumb")
    Box(Modifier.padding(top = 16.dp, bottom = 8.dp).width(230.dp).clip(RoundedCornerShape(30.dp)).background(c.bgInput).padding(4.dp)) {
        Box(Modifier.offset(x = x).width(111.dp).height(36.dp).clip(RoundedCornerShape(26.dp)).background(if (priv) Brush.linearGradient(listOf(Cx6366, CxViolet)) else Brush.linearGradient(listOf(Color(0xFF22C55E), Color(0xFF10B981)))))
        Row(Modifier.fillMaxWidth().height(36.dp)) {
            for ((isPriv, label, icon) in listOf(Triple(false, "Public", "fa-solid fa-earth-asia"), Triple(true, "Private", "fa-solid fa-lock"))) {
                val on = priv == isPriv
                Row(Modifier.weight(1f).fillMaxSize().tap { scope.launch { Chat.setPrivacy(isPriv) } }, horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
                    FaIcon(icon, rem(0.8).value.dp, if (on) Color.White else c.textMuted)
                    FText(label, size = rem(0.8), weight = FontWeight.ExtraBold, color = if (on) Color.White else c.textMuted)
                }
            }
        }
    }
}

// ---- "Alerts & storage" card (chat-keep.js settingsCard)
@Composable
private fun AlertsCard() {
    val c = FF.c
    ChatKeep.prefVer
    ChatStore.version
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> ChatKeep.alertsAnswered(granted) }
    val shape = RoundedCornerShape(22.dp)
    val permitted = ChatKeep.alertsPermitted(); val on = ChatKeep.alertsOn()
    val state = if (!permitted) "Tap to allow" else if (on) "On" else "Off"
    val saved = ChatStore.count()
    Column(Modifier.padding(top = 14.dp).fillMaxWidth().clip(shape).background(c.bgCard).border(1.dp, c.border, shape).padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 14.dp)) {
        Row(Modifier.padding(top = 8.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            FaIcon("fa-solid fa-bell", rem(0.8).value.dp, c.textMuted)
            FText("ALERTS & STORAGE", size = rem(0.8), weight = FontWeight.Black, color = c.textMuted, letterSpacing = 0.8.sp)
        }
        KpRow("Message alerts", "$state · notification + sound for new messages", on) { want ->
            if (!want) { ChatKeep.setPref("notif", false); AppStore.toast("Message alerts are OFF") }
            else if (permitted) ChatKeep.alertsAnswered(true)
            else if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
            else ChatKeep.alertsAnswered(true)
        }
        KpRow("World chat alerts", "Notify for World room messages (can be noisy)", ChatKeep.pref("world", false)) { ChatKeep.setPref("world", it) }
        KpRow("Sound", "Play a sound when a message arrives", ChatKeep.pref("sound", true)) { ChatKeep.setPref("sound", it) }
        val bs = RoundedCornerShape(16.dp)
        Row(
            Modifier.padding(top = 10.dp).fillMaxWidth().press(0.98f) { ChatUi.show(ChatSheet.Saved()) }.clip(bs).background(CxAmber.copy(alpha = 0.10f)).border(1.dp, CxAmber.copy(alpha = 0.25f), bs).padding(horizontal = 12.dp, vertical = 11.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            FaIcon("fa-solid fa-bookmark", rem(1.1).value.dp, CxAmber)
            Column(Modifier.weight(1f)) {
                FText("Saved on this device", size = rem(0.86), weight = FontWeight.ExtraBold)
                FText("$saved message${if (saved == 1) "" else "s"} · stays after the server deletes them", size = rem(0.7), color = c.textMuted)
            }
            FaIcon("fa-solid fa-chevron-right", rem(0.8).value.dp, c.textMuted)
        }
        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
            FaIcon("fa-regular fa-hourglass-half", rem(0.75).value.dp, c.textMuted, Modifier.padding(top = 2.dp))
            FRich(
                "World chat lives [${ChatKeep.ttlLabel("world")}] on the server. Friend chats (DM) stay on this device and the server copy is removed every [7 days].",
                size = rem(0.7), color = c.textMuted, boldColor = c.textMain, lineHeight = rem(0.7) * 1.45f,
            )
        }
    }
}

@Composable
private fun KpRow(label: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = FF.c
    Row(Modifier.fillMaxWidth().tap { onChange(!checked) }.padding(vertical = 9.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            FText(label, size = rem(0.88), weight = FontWeight.ExtraBold)
            FText(sub, size = rem(0.7), color = c.textMuted, lineHeight = rem(0.7) * 1.3f)
        }
        KpSwitch(checked)
    }
}

@Composable
private fun KpSwitch(on: Boolean) {
    val c = FF.c
    val x by animateDpAsState(if (on) 20.dp else 0.dp, tween(220), label = "kp")
    val off by animateColorAsState(if (c.isDark) Color(0xFF475569) else Color(0xFFCBD5E1), label = "kpOff")
    Box(Modifier.width(48.dp).height(28.dp).clip(RoundedCornerShape(28.dp)).then(if (on) Modifier.background(Brush.linearGradient(listOf(Cx6366, CxPink))) else Modifier.background(off)).padding(3.dp)) {
        Box(Modifier.offset(x = x).size(22.dp).boxShadow(4.dp, Color(0x59000000), CircleShape).clip(CircleShape).background(Color.White))
    }
}

// ==================================================================================== Game tab

@Composable
internal fun ChatGamePane() {
    val c = FF.c
    LaunchedEffect(Unit) { Games.load() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 110.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 2.dp, end = 2.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                FaIcon("fa-solid fa-gamepad", rem(0.8).value.dp, CxViolet)
                FText("GAMES", size = rem(0.8), weight = FontWeight.Black, color = c.textMuted, letterSpacing = 0.8.sp)
            }
            FaqChip("games")
        }
        if (!Games.ball && !Games.bomb && !Games.fruit) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 34.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                FaIcon("fa-solid fa-gamepad", rem(2.2).value.dp, c.textMuted.copy(alpha = 0.5f))
                FText("Games are taking a break", weight = FontWeight.Bold)
                FText("They will be back here soon.", size = rem(0.9), color = c.textMuted)
            }
        } else Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (Games.ball) GameCard(R.drawable.cf_coin_gold, "Coin Battle", "Connect 4 coins in a row and win cash", false) { Games.open("coin") }
            if (Games.bomb) GameCard(R.drawable.bomb_icon, "Bomb & Gems", "Find gems, dodge hidden bombs, win cash", true) { Games.open("bomb") }
            if (Games.fruit) GameCard(R.drawable.fruit_icon, "Fruit Slash", "Live 1v1 fruit duel · Free endless mode", fruit = true) { Games.open("fruit") }
        }
        FRich(
            "Games use your wallet balance. Real name and avatar are shown to the other player. Bots, when used, are always marked [BOT].",
            Modifier.padding(start = 4.dp, end = 4.dp, top = 14.dp), size = rem(0.72), color = c.textMuted, boldColor = CxViolet, lineHeight = rem(0.72) * 1.5f,
        )
    }
}

@Composable
private fun GameCard(img: Int, title: String, sub: String, bomb: Boolean = false, fruit: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    val brush = if (fruit) Brush.linearGradient(0f to Color(0xFF3B1B7A), 0.55f to Color(0xFF7A2FB8), 1f to Color(0xFFFF6A3D))
        else if (bomb) Brush.linearGradient(0f to Color(0xFF1C1240), 0.55f to Color(0xFF4B1D8F), 1f to Color(0xFFD1286F)) else Brush.linearGradient(0f to Color(0xFF4C1D95), 0.55f to CxViolet, 1f to Color(0xFFDB2777))
    val p = rememberPulse(2000)
    Row(
        Modifier.fillMaxWidth().press(0.97f, onClick = onClick).boxShadow(34.dp, if (fruit) Color(0xCCFF6A3D) else if (bomb) Color(0xD9D1286F) else Color(0xE67C3AED), shape).clip(shape).background(brush).padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        if (fruit) Image(painterResource(img), null, Modifier.size(84.dp), contentScale = ContentScale.Fit)   // the fruit icon is a cut-out: no frame, like the website's .gc-fruit img
        else Image(painterResource(img), null, Modifier.size(84.dp).border(2.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(20.dp)).clip(RoundedCornerShape(20.dp)))
        Column(Modifier.weight(1f)) {
            FText(title, size = rem(1.12), weight = FontWeight.Black, color = Color.White)
            FText(sub, Modifier.padding(top = 2.dp, bottom = 6.dp), size = rem(0.78), color = Color.White.copy(alpha = 0.9f), lineHeight = rem(0.78) * 1.3f)
            Box(Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0x40FACC15)).padding(horizontal = 10.dp, vertical = 3.dp)) {
                FText("Entry from ₹2 · Win up to 1.8×", size = rem(0.68), weight = FontWeight.ExtraBold, color = Color(0xFFFDE047))
            }
        }
        Box(Modifier.size(40.dp).graphicsLayer { scaleX = 1f + 0.06f * p; scaleY = 1f + 0.06f * p }.boxShadow(16.dp, Color(0xE610B981), CircleShape).clip(CircleShape).background(Color(0xFF10B981)), contentAlignment = Alignment.Center) {
            FaIcon("fa-solid fa-play", rem(1.0).value.dp, Color.White)
        }
    }
}

// ==================================================================================== Search tab

private object SearchState {
    var q by mutableStateOf("")
    var res by mutableStateOf<List<Doc>?>(null)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
}

@Composable
internal fun ChatSearchPane() {
    val c = FF.c
    val scope = rememberCoroutineScope()
    val q = SearchState.q
    LaunchedEffect(q) {
        if (q.trim().length < 2) { SearchState.res = null; SearchState.loading = false; SearchState.error = null; return@LaunchedEffect }
        SearchState.loading = true; SearchState.error = null
        delay(350)
        try { val r = Chat.searchUsers(q); SearchState.res = r; r.forEach { Chat.loadProf(it.s("uid")) } } catch (e: Exception) { SearchState.error = Chat.errMsg(e) }
        SearchState.loading = false
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 40.dp)) {
        var focused by remember { mutableStateOf(false) }
        val shape = RoundedCornerShape(18.dp)
        Row(
            Modifier.fillMaxWidth().clip(shape).background(c.bgCard).border(2.dp, if (focused) Cx6366 else c.border, shape).padding(horizontal = 14.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            FaIcon("fa-solid fa-at", rem(1.0).value.dp, c.textMuted)
            BasicTextField(
                SearchState.q, { SearchState.q = it.take(24) }, Modifier.weight(1f).padding(vertical = 13.dp).androidxFocus { focused = it },
                singleLine = true, textStyle = TextStyle(color = c.textMain, fontSize = rem(0.95), fontFamily = Inter),
                cursorBrush = SolidColor(Cx6366), keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, autoCorrectEnabled = false),
                decorationBox = { inner -> Box { if (SearchState.q.isEmpty()) FText("Search by username", size = rem(0.95), color = c.textMuted); inner() } },
            )
        }
        Row(Modifier.padding(start = 4.dp, top = 10.dp, bottom = 12.dp)) {
            FText("Friends: ", size = rem(0.72), color = c.textMuted)
            FText("${Chat.friends.list.size}/${Chat.MAX_FRIENDS}", size = rem(0.72), color = c.textMain, weight = FontWeight.Bold)
        }
        val res = SearchState.res
        when {
            q.trim().length < 2 -> ChatEmpty("fa-solid fa-magnifying-glass", null, "Type at least 2 letters of a username", small = true)
            SearchState.loading -> LoadingDots()
            SearchState.error != null -> ChatEmpty("fa-solid fa-circle-info", null, SearchState.error, small = true)
            res != null && res.isEmpty() -> ChatEmpty("fa-solid fa-user-slash", "No player found", "Check the username. Private profiles only appear on an exact match.", small = true)
            res != null -> res.forEachIndexed { i, p -> SearchResult(i, p, scope) }
        }
    }
}

@Composable
private fun SearchResult(i: Int, p: Doc, scope: kotlinx.coroutines.CoroutineScope) {
    val c = FF.c
    val u = p.s("uid").ifEmpty { p.id }
    val pend = Chat.outgoing.firstOrNull { it.s("to") == u && it.s("status") == "pending" }
    val inc = Chat.incoming.firstOrNull { it.s("from") == u }
    var busy by remember(u) { mutableStateOf(false) }
    CvRow(i, null) {
        ChatAv(p.s("name"), p.s("photo"), 46.dp, online = p.b("online"))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                VerifiedName(p.s("name"), u, rem(0.92), Modifier.weight(1f, fill = false), FontWeight.Bold, force = Chat.isVer(u) || p.b("verified"))
                if (p.b("isPrivate")) FaIcon("fa-solid fa-lock", rem(0.68).value.dp, c.textMuted)
            }
            FText("@" + p.s("username") + (if (p.s("bio").isNotEmpty()) " · " + p.s("bio") else ""), size = rem(0.75), color = c.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        when {
            Chat.isFriend(u) -> Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                FaIcon("fa-solid fa-check", rem(0.72).value.dp, Color(0xFF10B981)); FText("Friends", size = rem(0.72), weight = FontWeight.ExtraBold, color = Color(0xFF10B981))
            }
            pend != null -> FText("Requested", size = rem(0.72), weight = FontWeight.ExtraBold, color = c.textMuted)
            inc != null -> AddBtn("Accept", null, false) { scope.launch { Chat.acceptRequest(inc) } }
            Chat.friends.list.size >= Chat.MAX_FRIENDS -> FText("List full", size = rem(0.72), weight = FontWeight.ExtraBold, color = c.textMuted)
            else -> AddBtn("Add", "fa-solid fa-user-plus", busy) { busy = true; scope.launch { val ok = Chat.sendRequest(u); if (!ok) busy = false } }
        }
    }
}

@Composable
private fun AddBtn(text: String, icon: String?, busy: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.press(0.95f, !busy, onClick).clip(RoundedCornerShape(14.dp)).background(cxBtnBrush()).padding(horizontal = 14.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        if (busy) SpinIcon(rem(0.76).value.dp, Color.White, icon = "fa-solid fa-spinner")
        else { if (icon != null) FaIcon(icon, rem(0.76).value.dp, Color.White); FText(text, size = rem(0.76), weight = FontWeight.ExtraBold, color = Color.White) }
    }
}

private fun Modifier.androidxFocus(onChange: (Boolean) -> Unit): Modifier = this.onFocusChanged { onChange(it.isFocused) }
