package com.ffcashbattle.app.ui.modals

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.Avatar
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.VerifiedName
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.screens.match.dbl
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay

private fun slotsOf(p: Map<String, Any?>): List<Int> {
    val arr = p["slots"] as? List<*>
    if (arr != null && arr.isNotEmpty()) return arr.map { dbl(it).toInt() }
    val s = dbl(p["slot"]).toInt()
    return if (s > 0) listOf(s) else emptyList()
}

/** Website `#modal-roster`: every joined player and the slot they chose (live — follows AppStore.matches). */
@Composable
fun RosterModal() {
    val c = FF.c
    val arg = AppStore.modalArg
    val id = when (arg) { is String -> arg; is Doc -> arg.id; else -> "" }
    val m: Doc = AppStore.matches.firstOrNull { it.id == id } ?: (arg as? Doc) ?: Doc.EMPTY
    val total = m.i("total").takeIf { it > 0 } ?: 48
    val parts = m.maps("participants")
    val joined = m.i("joined").takeIf { it > 0 } ?: parts.size
    val me = AppStore.uid
    val screenH = LocalConfiguration.current.screenHeightDp
    val narrow = LocalConfiguration.current.screenWidthDp <= 340

    ModalSheet(maxHeightFraction = 0.86f, scroll = false, padding = PaddingValues(start = 30.dp, top = 30.dp, end = 30.dp, bottom = 24.dp)) {
        val close = LocalSheetClose.current
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    FText(m.s("title").ifEmpty { "Players" }, size = rem(1.15), weight = FontWeight.ExtraBold, tags = true)
                    FText("$joined/$total joined · ${maxOf(0, total - joined)} slots left", size = rem(0.78), weight = FontWeight.SemiBold, color = c.textMuted, modifier = Modifier.padding(top = 2.dp))
                }
                Box(Modifier.size(38.dp).press(0.9f) { close() }.clip(RoundedCornerShape(13.dp)).background(c.bgInput), contentAlignment = Alignment.Center) {
                    FaIcon("fa-solid fa-xmark", rem(1.0).value.dp, c.textMuted)
                }
            }
            val fill by animateFloatAsState(minOf(1f, joined.toFloat() / total), tween(700, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)), label = "fill")
            Box(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 10.dp).height(6.dp).clip(RoundedCornerShape(6.dp)).background(c.bgInput)) {
                Box(Modifier.fillMaxWidth(fill).fillMaxHeight().clip(RoundedCornerShape(6.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF6366F1), Color(0xFFEC4899)))))
            }

            Column(Modifier.heightIn(max = (screenH * 0.86f - 150f).dp).verticalScroll(rememberScrollState()).padding(horizontal = 2.dp).padding(bottom = 8.dp)) {
                val bySlot = HashMap<Int, Map<String, Any?>>()
                val loose = ArrayList<Map<String, Any?>>()
                for (p in parts) { val s = slotsOf(p); if (s.isEmpty()) loose.add(p); for (n in s) bySlot[n] = p }

                @Composable
                fun Cells(numbers: List<Int>) {
                    val per = if (narrow) 1 else 2
                    numbers.chunked(per).forEach { row ->
                        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (n in row) RosterSlot(n, bySlot[n], me, Modifier.weight(1f))
                            if (row.size < per) Box(Modifier.weight((per - row.size).toFloat()))
                        }
                    }
                }

                val size = m.i("teamSize", 1)
                if ((m.s("mode") == "CS" || m.s("mode") == "LW") && size > 0) {
                    TeamLabel("TEAM A", Color(0xFF4F46E5)); Cells((1..size).toList())
                    TeamLabel("TEAM B", Color(0xFFE11D48)); Cells(((size + 1)..minOf(total, size * 2)).toList())
                } else if (size > 1) {
                    val teams = Math.ceil(total.toDouble() / size).toInt()
                    for (t in 0 until teams) {
                        TeamLabel("TEAM ${t + 1}", null)
                        Cells((0 until minOf(size, total - t * size)).map { t * size + it + 1 })
                    }
                } else Cells((1..total).toList())

                if (loose.isNotEmpty()) {
                    TeamLabel("SLOT NOT CHOSEN YET", null)
                    loose.chunked(if (narrow) 1 else 2).forEach { row ->
                        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (p in row) RosterSlot(0, p, me, Modifier.weight(1f))
                            if (row.size < (if (narrow) 1 else 2)) Box(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TeamLabel(text: String, color: Color?) {
    val c = FF.c
    Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 12.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        FText(text, size = rem(0.72), weight = FontWeight.Black, color = color ?: c.textMuted, letterSpacing = 0.8.sp)
        Box(Modifier.weight(1f).height(1.dp).background(c.border))
    }
}

/** `.ro-slot` — an empty (dashed) slot or a player card (full / me). `n == 0` renders the "–" of unplaced players. */
@Composable
private fun RosterSlot(n: Int, p: Map<String, Any?>?, me: String?, modifier: Modifier) {
    val c = FF.c
    val shape = RoundedCornerShape(16.dp)
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(minOf(n * 18L, 400L)); a.animateTo(1f, tween(450, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f))) }
    val anim = Modifier.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 10.dp.toPx() }
    if (p == null) {
        Row(
            modifier.then(anim).graphicsLayer { alpha *= 0.72f }.clip(shape)
                .drawBehind {
                    val sw = 1.dp.toPx()
                    drawRoundRect(c.border, topLeft = Offset(sw / 2f, sw / 2f), size = Size(size.width - sw, size.height - sw), cornerRadius = CornerRadius(16.dp.toPx()),
                        style = Stroke(sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 3.dp.toPx()))))
                }
                .padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            NumBox(n.toString(), Brush.linearGradient(listOf(c.bgInput, c.bgInput)), c.textMuted)
            FText("Empty", size = rem(0.74), weight = FontWeight.SemiBold, color = c.textMuted)
        }
        return
    }
    val uid = p["uid"]?.toString()
    val mine = uid != null && uid == me
    val name = p["appName"]?.toString()?.ifEmpty { null } ?: p["gameName"]?.toString()?.ifEmpty { null } ?: "Player"
    Row(
        modifier.then(anim)
            .then(if (mine) Modifier.drawBehind { drawRoundRect(Color(0x3810B981), topLeft = Offset(-2.dp.toPx(), -2.dp.toPx()), size = Size(size.width + 4.dp.toPx(), size.height + 4.dp.toPx()), cornerRadius = CornerRadius(18.dp.toPx())) } else Modifier)
            .clip(shape).background(Brush.linearGradient(listOf(Color(0x146366F1), Color(0x0FEC4899))))
            .border(1.dp, if (mine) Color(0xFF10B981) else Color(0x406366F1), shape)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        NumBox(if (n == 0) "–" else n.toString(), if (mine) Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF059669))) else Brush.linearGradient(listOf(Color(0xFF6366F1), Color(0xFF8B5CF6))), Color.White)
        Avatar(null, name, 36.dp, borderColor = if (c.isDark) Color(0xFF1E293B) else Color.White)
        Column(Modifier.weight(1f)) {
            VerifiedName(name, uid, rem(0.82), weight = FontWeight.ExtraBold)
            if (mine) FText("You", size = rem(0.64), weight = FontWeight.SemiBold, color = c.textMuted)
        }
    }
}

@Composable
private fun NumBox(text: String, bg: Brush, fg: Color) {
    Box(Modifier.size(26.dp).clip(RoundedCornerShape(9.dp)).background(bg), contentAlignment = Alignment.Center) {
        FText(text, size = rem(0.72), weight = FontWeight.Black, color = fg)
    }
}
