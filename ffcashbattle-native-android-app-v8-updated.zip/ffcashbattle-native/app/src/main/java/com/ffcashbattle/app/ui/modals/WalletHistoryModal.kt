package com.ffcashbattle.app.ui.modals

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import java.util.Calendar
import java.util.Locale
import com.ffcashbattle.app.data.trxMs
import com.ffcashbattle.app.data.Msg
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.screens.wallet.TrxRow
import com.ffcashbattle.app.ui.screens.match.jsNum
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem

private const val DAY_MS = 24L * 60 * 60 * 1000

/** Filter chips of the History sheet: key -> (label, "showing ..." hint, "no records ..." text, start time). Same as the website (pages/history/history.js). */
private class HRange(val label: String, val hint: String, val none: String, val since: () -> Long)

private val H_RANGES = linkedMapOf(
    "today" to HRange("Today", "Showing today only", "today") {
        Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    },
    "week" to HRange("This Week", "Showing last 7 days", "in the last 7 days") { System.currentTimeMillis() - 7 * DAY_MS },
    "month" to HRange("This Month", "Showing last 30 days", "in the last 30 days") { System.currentTimeMillis() - 30 * DAY_MS },
)

/**
 * Website `#modal-wallet-history`: withdrawal / deposit history of the last 30 days with the Today / This Week / This Month filter
 * (count + total of the successful ones on top of the list).
 */
@Composable
fun WalletHistoryModal() {
    val c = FF.c
    var tab by remember { mutableStateOf("withdraw") }
    var range by remember { mutableStateOf("month") }
    val r = H_RANGES.getValue(range)
    val since = r.since()
    val data = AppStore.trx.filter { it.s("type") == tab && it.trxMs().let { ms -> ms <= 0L || ms >= since } }
    val total = data.filter { Msg.describe(it).status == "success" }.sumOf { Math.abs(it.n("amount")) }

    ModalSheet {
        val close = LocalSheetClose.current
        Row(Modifier.fillMaxWidth().padding(bottom = 15.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.press(0.9f) { close() }) { FaIcon("fa-solid fa-arrow-left", rem(1.2).value.dp, c.textMain) }
                FText("History", size = rem(1.5), weight = FontWeight.Bold)
            }
            Box(Modifier.press(0.9f) { close() }) { FaIcon("fa-solid fa-xmark", rem(1.4).value.dp, c.textMuted) }
        }
        val shape = RoundedCornerShape(14.dp)
        Row(Modifier.padding(bottom = 12.dp).fillMaxWidth().clip(shape).background(c.bgCard).border(1.dp, c.border, shape).padding(5.dp)) {
            for ((k, label) in listOf("withdraw" to "Withdrawal History", "deposit" to "Deposit History")) {
                val on = tab == k
                Box(
                    Modifier.weight(1f).press(0.97f) { tab = k }.clip(RoundedCornerShape(10.dp)).background(if (on) c.primaryLight else Color.Transparent).padding(12.dp),
                    contentAlignment = Alignment.Center,
                ) { FText(label, size = rem(0.9), weight = if (on) FontWeight.Bold else FontWeight.SemiBold, color = if (on) c.primary else c.textMuted, align = TextAlign.Center) }
            }
        }
        // Today / This Week / This Month
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val pill = RoundedCornerShape(30.dp)
            for ((k, rg) in H_RANGES) {
                val on = range == k
                Box(
                    Modifier.weight(1f).press(0.96f) { range = k }.clip(pill).background(if (on) c.primary else c.bgCard)
                        .border(1.dp, if (on) c.primary else c.border, pill).padding(horizontal = 6.dp, vertical = 9.dp),
                    contentAlignment = Alignment.Center,
                ) { FText(rg.label, size = rem(0.8), weight = FontWeight.Bold, color = if (on) Color.White else c.textMuted, align = TextAlign.Center, maxLines = 1) }
            }
        }
        if (data.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FText(data.size.toString(), size = rem(0.78), weight = FontWeight.Bold)
                    FText(if (tab == "withdraw") "withdrawals" else "deposits", size = rem(0.78), color = c.textMuted)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FText("Total", size = rem(0.78), color = c.textMuted)
                    FText("\u20b9" + (if (total % 1.0 == 0.0) jsNum(total) else String.format(Locale.US, "%.2f", total)), size = rem(0.78), weight = FontWeight.Bold)
                }
            }
        }
        FText(r.hint, size = rem(0.72), color = c.textMuted, align = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp))
        Column(Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
            if (data.isEmpty()) {
                FText("No $tab records ${r.none}.", color = Color(0xFFAAAAAA), align = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(30.dp))
            } else for (t in data) TrxRow(t)
        }
    }
}
