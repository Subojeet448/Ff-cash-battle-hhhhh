package com.ffcashbattle.app.ui.modals

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.data.Repo
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.InputBox
import com.ffcashbattle.app.ui.comp.LocalSheetClose
import com.ffcashbattle.app.ui.comp.ModalSheet
import com.ffcashbattle.app.ui.comp.SheetHandle
import com.ffcashbattle.app.ui.comp.SpinIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.screens.match.RwView
import com.ffcashbattle.app.ui.screens.match.dbl
import com.ffcashbattle.app.ui.screens.match.jsNum
import com.ffcashbattle.app.ui.screens.match.formatLabel
import com.ffcashbattle.app.ui.screens.match.prizeInfo
import com.ffcashbattle.app.ui.screens.FaqChip
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import com.google.firebase.firestore.Transaction
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** The inputs of the website stay filled between two opens of the sheet. */
private object JoinMemo { var name: String = ""; var uid: String = "" }

private val PopEase = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f)
private val ConfettiEase = CubicBezierEasing(0.2f, 0.7f, 0.3f, 1f)
private val OutEase = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)

/** Firestore whole numbers are stored as integers like the JS SDK does. */
private fun num(d: Double): Any = if (d % 1.0 == 0.0 && abs(d) < 9.0e15) d.toLong() else d

/** `runTransaction` throws "SLOT_TAKEN:n" — detect it anywhere in the cause chain. */
private fun isSlotTaken(e: Throwable): Boolean {
    var t: Throwable? = e
    var n = 0
    while (t != null && n < 8) { if ((t.message ?: "").startsWith("SLOT_TAKEN")) return true; t = t.cause; n++ }
    return false
}

private sealed class SlotRow {
    class Head(val kind: String, val text: String, val small: String = "") : SlotRow()
    class Slot(val n: Int) : SlotRow()
}

/** `renderSlotGrid`: same headers (TEAM A / VS / TEAM B or TEAM n · k players) around the numbered slots. */
private fun slotRows(m: Doc): List<SlotRow> {
    val total = m.i("total").takeIf { it > 0 } ?: 48
    val tsize = m.i("teamSize", 1)
    val duel = m.s("mode") == "CS" || m.s("mode") == "LW"
    val out = ArrayList<SlotRow>()
    for (i in 1..total) {
        if (duel) {
            if (i == 1) out.add(SlotRow.Head("a", "TEAM A"))
            if (i == tsize + 1) { out.add(SlotRow.Head("vs", "VS")); out.add(SlotRow.Head("b", "TEAM B")) }
        } else if (tsize > 1 && (i - 1) % tsize == 0) {
            out.add(SlotRow.Head("t", "TEAM ${(i - 1) / tsize + 1}", "· $tsize players"))
        }
        out.add(SlotRow.Slot(i))
    }
    return out
}

/** slot -> occupant name (slot / slots[] of every participant). */
private fun slotMap(m: Doc): Map<Int, String> {
    val map = HashMap<Int, String>()
    for (p in m.maps("participants")) {
        val nm = p["appName"]?.toString()?.ifEmpty { null } ?: p["gameName"]?.toString()?.ifEmpty { null } ?: "Player"
        val s = dbl(p["slot"]).toInt()
        if (s > 0) map[s] = nm
        (p["slots"] as? List<*>)?.forEach { x -> val n = dbl(x).toInt(); if (n > 0) map[n] = nm }
    }
    return map
}

/** Website `#modal-join`: Confirm Join — step 1 "Pay" (name + FF UID + fee) and step 2 "Slot" (choose your box). */
@Composable
fun JoinModal() {
    val c = FF.c
    val first = AppStore.modalArg as? Doc ?: Doc.EMPTY
    val scope = rememberCoroutineScope()

    var match by remember { mutableStateOf(first) }
    var step by remember { mutableIntStateOf(1) }
    var gameName by remember { mutableStateOf(JoinMemo.name.ifEmpty { AppStore.user.s("gameName") }) }
    var gameUid by remember { mutableStateOf(JoinMemo.uid.ifEmpty { AppStore.user.s("gameUid") }) }
    var terms by remember { mutableStateOf(false) }
    var uidError by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var picked by remember { mutableIntStateOf(0) }
    var confirming by remember { mutableStateOf(false) }
    var slotsLoading by remember { mutableStateOf(false) }
    var gridKey by remember { mutableIntStateOf(0) }

    // success overlay (fx.joinDone)
    var doneShow by remember { mutableStateOf(false) }
    var doneTitle by remember { mutableStateOf("") }
    var doneSub by remember { mutableStateOf("") }
    var doneConfetti by remember { mutableStateOf(false) }
    var doneRun by remember { mutableIntStateOf(0) }

    val fee = match.s("fee").toDoubleOrNull() ?: match.n("fee")
    val bal = AppStore.depositBalance + AppStore.withdrawBalance
    val low = bal < fee

    suspend fun showDone(title: String, sub: String, confetti: Boolean, hold: Long, keep: Boolean) {
        doneTitle = title; doneSub = sub; doneConfetti = confetti
        doneRun++
        doneShow = true
        delay(hold)
        if (!keep) doneShow = false
    }

    // Fresh data in the background — close the sheet if the match became full / deleted while still on the payment step.
    LaunchedEffect(first.id) {
        if (first.id.isEmpty()) return@LaunchedEffect
        val close = { AppStore.closeModal() }
        try {
            val fresh = Repo.getDoc("matches", first.id)
            if (fresh == null) { close(); AppStore.toast("This match is no longer available."); return@LaunchedEffect }
            if (step == 1 && !busy) {
                if (fresh.i("joined") >= (fresh.i("total").takeIf { it > 0 } ?: 48)) { close(); AppStore.toast("This match just got full. Please try another match."); return@LaunchedEffect }
                match = fresh
            }
        } catch (_: Exception) { }
    }

    suspend fun reloadSlots() {
        try { Repo.getDoc("matches", match.id)?.let { match = it } } catch (_: Exception) { }
        gridKey++
    }

    fun confirmJoin(close: () -> Unit) {
        val m = match
        val name = gameName.trim()
        val uidText = gameUid.trim()
        if (m.id in AppStore.joinedIds) { AppStore.toast("Already joined!"); return }
        if (name.length < 3) { AppStore.toast("Name too short!"); return }
        if (uidText.toLongOrNull() == null || uidText.length < 6 || uidText.length > 12 || !uidText.all { it.isDigit() }) {
            uidError = true; AppStore.toast("FF UID invalid (6-12 digits)"); return
        }
        uidError = false
        if (!terms) { AppStore.toast("Agree to rules!"); return }
        if (low) { AppStore.toast("Insufficient Balance!"); return }
        val act = "join_" + m.id
        if (!AppStore.rateLimit(act, 60_000L)) return
        busy = true
        JoinMemo.name = name; JoinMemo.uid = uidText
        scope.launch {
            try {
                val uid = AppStore.uid ?: throw IllegalStateException("Please login first")
                // Re-fetch latest balance to prevent rapid-click over-spend
                val cur = Repo.getDoc("users", uid) ?: Doc.EMPTY
                val dep = if (cur.has("depositBalance")) cur.n("depositBalance") else cur.n("balance")
                val wd = cur.n("withdrawBalance")
                if (m.id in cur.strList("joined_matches")) {
                    AppStore.endAction(act, false); busy = false; AppStore.toast("Already joined!"); return@launch
                }
                if (dep + wd < fee) {
                    AppStore.endAction(act, false); busy = false; AppStore.toast("Insufficient Balance!"); return@launch
                }
                val payDep = minOf(dep, fee)
                val payWd = fee - payDep
                val appName = cur.s("appName").ifEmpty { sessionMeName() }
                // ATOMIC: match entry + wallet debit in a single commit (no half-join if it fails midway)
                val b = Repo.db.batch()
                b.update(Repo.doc("matches", m.id), mapOf<String, Any>(
                    "joined" to Repo.inc(1),
                    "participants" to Repo.arrayUnion(mapOf("uid" to uid, "appName" to appName, "gameName" to name, "gameUid" to uidText, "payDep" to num(payDep), "payWd" to num(payWd))),
                ))
                b.update(Repo.doc("users", uid), mapOf<String, Any>(
                    "depositBalance" to num(dep - payDep),
                    "withdrawBalance" to num(wd - payWd),
                    "joined_matches" to Repo.arrayUnion(m.id),
                    "matchesPlayed" to num(cur.n("matchesPlayed") + 1),
                    "gameName" to name,
                    "gameUid" to uidText,
                ))
                b.commit().await()
                try {
                    Repo.add(listOf("users", uid, "transactions"), mapOf(
                        "title" to "Joined ${m.s("title")}", "amount" to "-₹${jsNum(fee)}", "type" to "game", "status" to "success",
                        "date" to java.text.DateFormat.getDateInstance(java.text.DateFormat.SHORT).format(java.util.Date()),
                        "timestamp" to Repo.serverTs(), "createdAt" to System.currentTimeMillis(),
                    ))
                } catch (_: Exception) { }
                AppStore.endAction(act, true)
                // Success animation -> slide to slot step
                showDone("Payment Successful", "₹${jsNum(fee)} paid • now choose your slot", false, 900L, false)
                slotsLoading = true
                step = 2
                try { Repo.getDoc("matches", m.id)?.let { match = it } } catch (_: Exception) { }
                slotsLoading = false
                busy = false
            } catch (e: Exception) {
                AppStore.endAction(act, false); busy = false
                AppStore.toast("Error: " + (e.message ?: "Something went wrong"))
            }
        }
    }

    fun confirmSlot(close: () -> Unit) {
        val m = match
        val slot = picked
        if (slot <= 0) { AppStore.toast("Please select a slot first."); return }
        val uid = AppStore.uid ?: return
        confirming = true
        scope.launch {
            try {
                // Race-safe slot allocation via transaction
                Repo.db.runTransaction(Transaction.Function<Any?> { tx ->
                    val ref = Repo.doc("matches", m.id)
                    val snap = tx.get(ref)
                    if (!snap.exists()) throw IllegalStateException("Match not found")
                    val d = Doc.of(snap)
                    val taken = d.list("takenSlots").map { dbl(it).toInt() }
                    if (slot in taken) throw IllegalStateException("SLOT_TAKEN:$slot")
                    val parts = d.maps("participants").map { p ->
                        if (p["uid"]?.toString() == uid) p + mapOf<String, Any?>("slot" to slot.toLong(), "slots" to listOf(slot.toLong())) else p
                    }
                    tx.update(ref, mapOf<String, Any>("participants" to parts, "takenSlots" to (taken.map { it.toLong() } + slot.toLong())))
                    null
                }).await()
                showDone("Slot #$slot Confirmed!", "Good luck for the match 🔥", true, 1700L, true)
                close()
                AppStore.toast("Slot #$slot confirmed! ✅")
            } catch (e: Exception) {
                if (isSlotTaken(e)) {
                    AppStore.toast("Someone just took this slot. Your entry is safe — please choose another slot.")
                    picked = 0
                    reloadSlots()
                } else AppStore.toast("Error: " + (e.message ?: "Something went wrong"))
                confirming = false
            }
        }
    }

    ModalSheet(handle = false, padding = PaddingValues(0.dp)) {
        val close = LocalSheetClose.current
        Box(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(30.dp)) {
                SheetHandle()
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    FText("Confirm Join", size = rem(1.5), weight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        FaqChip("join")
                        Box(Modifier.press(0.9f) { close() }) { FaIcon("fa-solid fa-xmark", rem(1.5).value.dp, c.textMuted) }
                    }
                }
                JoinSteps(step)
                FText(match.s("title").ifEmpty { "Match Title" }, size = rem(1.0), weight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp), tags = true)
                SummaryBox(match)

                if (step == 1) {
                    Step1(
                        fee = fee, bal = bal, low = low, busy = busy,
                        gameName = gameName, onName = { gameName = it },
                        gameUid = gameUid, onUid = { gameUid = it.filter { ch -> ch.isDigit() }.take(14) },
                        terms = terms, onTerms = { terms = it }, uidError = uidError,
                        onPay = { confirmJoin(close) },
                    )
                } else {
                    Step2(
                        match = match, picked = picked, loading = slotsLoading, confirming = confirming, gridKey = gridKey,
                        onPick = { n ->
                            val taken = slotMap(match)
                            val total = match.i("total").takeIf { it > 0 } ?: 48
                            if (n > total || n in taken.keys) AppStore.toast("Slot $n is not available. Please pick another slot.") else picked = n
                        },
                        onConfirm = { confirmSlot(close) },
                    )
                }
            }
            JoinDoneOverlay(doneShow, doneTitle, doneSub, doneConfetti, doneRun, Modifier.matchParentSize())
        }
    }
}

// ============================================================================================ step indicator

@Composable
private fun JoinSteps(step: Int) {
    val c = FF.c
    val line by animateFloatAsState(if (step == 2) 1f else 0f, tween(700, easing = OutEase), label = "jsLine")
    Row(Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        JsStep("1", "Pay", active = step == 1, done = step == 2)
        Box(Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(4.dp)).background(c.border)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(line).clip(RoundedCornerShape(4.dp)).background(Brush.horizontalGradient(listOf(c.primary, c.accent))))
        }
        JsStep("2", "Slot", active = step == 2, done = false)
    }
}

@Composable
private fun JsStep(n: String, label: String, active: Boolean, done: Boolean) {
    val c = FF.c
    val scale by animateFloatAsState(if (active) 1.08f else 1f, tween(450, easing = PopEase), label = "jsScale")
    val txt = if (done) c.success else if (active) c.primary else c.textMuted
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        Box(
            Modifier.graphicsLayer { scaleX = scale; scaleY = scale }
                .then(if (active) Modifier.drawBehind { drawCircle(c.primaryLight, radius = size.minDimension / 2f + 5.dp.toPx()) } else Modifier)
                .size(26.dp).clip(CircleShape)
                .background(if (done) c.success else if (active) c.primary else c.bgInput)
                .border(2.dp, if (done) c.success else if (active) c.primary else c.border, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            if (done) FaIcon("fa-solid fa-check", rem(0.72).value.dp, Color.White)
            else FText(n, size = rem(0.74), weight = FontWeight.Bold, color = if (active) Color.White else c.textMuted)
        }
        FText(label, size = rem(0.74), weight = FontWeight.Bold, color = txt)
    }
}

// ============================================================================================ summary chips

@Composable
private fun SummaryBox(m: Doc) {
    val c = FF.c
    val shape = RoundedCornerShape(12.dp)
    val hasRw = m["rewards"] != null && ((m["rewards"] as? Map<*, *>)?.get("places") != null)
    val prize: @Composable () -> Unit = {
        if (hasRw) RwView(prizeInfo(m).big, rem(0.8), FontWeight.Bold, c.success)
        else {
            val perKill = m.s("prizeMode") == "per_kill"
            val pr = (m["prizes"] as? Map<*, *>)
            val t = if (perKill) "₹" + jsNum(dbl(pr?.get("1")).takeIf { it != 0.0 } ?: m.n("prize")) + "/kill" else "₹" + jsNum(m.n("prize"))
            FText(t, size = rem(0.8), weight = FontWeight.Bold, color = c.success, maxLines = 1)
        }
    }
    Row(
        Modifier.fillMaxWidth().padding(bottom = 15.dp).clip(shape)
            .background(Brush.linearGradient(listOf(c.bgInput, c.primaryLight)))
            .border(1.dp, c.border, shape).padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        SumItem(0, "Type", { FText(formatLabel(m), size = rem(0.8), weight = FontWeight.Bold, color = c.primary, maxLines = 1, overflow = TextOverflow.Ellipsis) })
        SumItem(1, "Map", { FText(m.s("map").ifEmpty { "Bermuda" }, size = rem(0.8), weight = FontWeight.Bold, color = c.primary, maxLines = 1, overflow = TextOverflow.Ellipsis) })
        SumItem(2, "Prize", prize)
    }
}

@Composable
private fun SumItem(i: Int, label: String, value: @Composable () -> Unit) {
    val c = FF.c
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(120L + i * 80L); a.animateTo(1f, tween(550, easing = PopEase)) }
    Column(
        Modifier.graphicsLayer { val s = 0.6f + 0.4f * a.value; scaleX = s; scaleY = s; alpha = minOf(1f, a.value * 1.5f) },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        value()
        FText(label, size = rem(0.7), color = c.textMuted)
    }
}

// ============================================================================================ step 1

@Composable
private fun Step1(
    fee: Double, bal: Double, low: Boolean, busy: Boolean,
    gameName: String, onName: (String) -> Unit, gameUid: String, onUid: (String) -> Unit,
    terms: Boolean, onTerms: (Boolean) -> Unit, uidError: Boolean, onPay: () -> Unit,
) {
    val c = FF.c
    // Entry Fee count-up (fx.countUp) on every open
    val shownAnim = remember { Animatable(0f) }
    LaunchedEffect(fee) { shownAnim.animateTo(fee.toFloat(), tween(800, easing = OutEase)) }
    val feeNow = shownAnim.value.toDouble()
    val feeText = if (abs(feeNow - fee) < 0.005) jsNum(fee) else if (fee % 1.0 == 0.0) feeNow.toInt().toString() else "%.2f".format(feeNow)

    Column(Modifier.fillMaxWidth()) {
        FText("Game Username *", size = rem(0.8), color = c.textMuted, modifier = Modifier.padding(bottom = 5.dp))
        InputBox(gameName, onName, Modifier.fillMaxWidth(), placeholder = "Exact In-Game Name", imeAction = androidx.compose.ui.text.input.ImeAction.Next)
        Spacer(Modifier.height(15.dp))
        FText("Free Fire UID *", size = rem(0.8), color = c.textMuted, modifier = Modifier.padding(bottom = 5.dp))
        InputBox(gameUid, onUid, Modifier.fillMaxWidth(), placeholder = "Enter your FF UID", keyboardType = KeyboardType.Number, invalid = uidError)
        if (uidError) FText("Invalid UID. Please enter your 6–12 digit Free Fire UID.", size = rem(0.75), color = c.danger, modifier = Modifier.padding(bottom = 8.dp))

        // .checkbox-group
        Row(Modifier.fillMaxWidth().padding(vertical = 15.dp).tap { onTerms(!terms) }, horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            val boxBg by animateFloatAsState(if (terms) 1f else 0f, tween(300, easing = PopEase), label = "chk")
            Box(
                Modifier.size(22.dp).clip(RoundedCornerShape(7.dp)).background(if (terms) c.primary else c.bgInput).border(2.dp, if (terms) c.primary else c.border, RoundedCornerShape(7.dp)),
                contentAlignment = Alignment.Center,
            ) {
                FaIcon("fa-solid fa-check", rem(0.7).value.dp, Color.White, Modifier.graphicsLayer { scaleX = boxBg; scaleY = boxBg; rotationZ = -45f * (1f - boxBg) })
            }
            FText("I agree to match rules & fair play policy.", size = rem(0.85), color = c.textMuted, modifier = Modifier.weight(1f))
        }

        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                FText("Entry Fee", size = rem(0.8), color = c.textMuted)
                FText("₹ $feeText", size = rem(1.2), weight = FontWeight.Bold, color = c.primary)
            }
            BalanceStatus(bal, low)
        }
        BtnMain(
            onClick = { if (!busy && !low) onPay() },
            modifier = Modifier.fillMaxWidth().padding(top = 15.dp),
            enabled = !low && !busy,
        ) {
            if (busy) {
                SpinIcon(rem(1.0).value.dp, Color(0xFF94A3B8)); Spacer(Modifier.width(6.dp))
                FText("Processing...", size = rem(1.0), weight = FontWeight.Bold, color = Color(0xFF94A3B8))
            } else {
                FText(if (low) "Insufficient Balance" else "Pay & Join", size = rem(1.0), weight = FontWeight.Bold, color = if (low) Color(0xFF94A3B8) else Color.White, align = TextAlign.Center)
            }
        }
    }
}

/** `.balance-status`: "₹12.50 ● (OK)" / "(Low)" with a pulsing dot. */
@Composable
private fun BalanceStatus(bal: Double, low: Boolean) {
    val c = FF.c
    val col = if (low) c.danger else c.success
    val inf = rememberInfiniteTransition(label = "dot")
    val p by inf.animateFloat(1f, 0.35f, infiniteRepeatable(tween(700, easing = LinearEasing), RepeatMode.Reverse), label = "dotA")
    Row(
        Modifier.clip(RoundedCornerShape(30.dp)).background(c.bgInput).padding(horizontal = 13.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        FText("₹" + "%.2f".format(bal), size = rem(0.8), weight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).graphicsLayer { alpha = p; scaleX = 0.7f + 0.3f * p; scaleY = 0.7f + 0.3f * p }.clip(CircleShape).background(col))
            Spacer(Modifier.width(6.dp))
            FText(if (low) "(Low)" else "(OK)", size = rem(0.8), weight = FontWeight.Bold, color = col)
        }
    }
}

// ============================================================================================ step 2

@Composable
private fun Step2(
    match: Doc, picked: Int, loading: Boolean, confirming: Boolean, gridKey: Int,
    onPick: (Int) -> Unit, onConfirm: () -> Unit,
) {
    val c = FF.c
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) { enter.animateTo(1f, tween(500, easing = OutEase)) }
    val taken = remember(match, gridKey) { slotMap(match) }
    val rows = remember(match.id, match.i("total"), match.i("teamSize"), match.s("mode")) { slotRows(match) }
    val myName = remember { AppStore.user.s("appName").ifEmpty { sessionMeName() } }

    Column(Modifier.fillMaxWidth().graphicsLayer { alpha = enter.value; translationX = (1f - enter.value) * 40.dp.toPx() }) {
        FText("🎯 Choose Your Slot", weight = FontWeight.Bold, color = c.primary, modifier = Modifier.padding(bottom = 5.dp))
        FText("Just like a Free Fire custom room — choose one slot box and your name will appear in it", size = rem(0.78), color = c.textMuted, modifier = Modifier.padding(bottom = 12.dp))

        Column(Modifier.fillMaxWidth().heightIn(max = 340.dp).verticalScroll(rememberScrollState()).padding(4.dp)) {
            if (loading) {
                Row(Modifier.fillMaxWidth().padding(26.dp), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
                    SpinIcon(rem(0.85).value.dp, c.textMuted)
                    FText("Loading slots…", size = rem(0.85), weight = FontWeight.SemiBold, color = c.textMuted)
                }
            } else {
                var pending = ArrayList<Int>()
                val out = ArrayList<@Composable () -> Unit>()
                fun flush() {
                    if (pending.isEmpty()) return
                    val row = ArrayList(pending); pending = ArrayList()
                    out.add {
                        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (n in row) SlotButton(n, taken[n], n == picked, myName, Modifier.weight(1f), onPick)
                            if (row.size < 2) Box(Modifier.weight(1f))
                        }
                    }
                }
                for (r in rows) {
                    when (r) {
                        is SlotRow.Slot -> { pending.add(r.n); if (pending.size == 2) flush() }
                        is SlotRow.Head -> { flush(); out.add { SlotHead(r) } }
                    }
                }
                flush()
                for (o in out) o()
            }
        }
        BtnMain(
            onClick = { if (picked > 0 && !confirming) onConfirm() },
            modifier = Modifier.fillMaxWidth().padding(top = 15.dp),
            enabled = picked > 0 && !confirming,
        ) {
            val dis = !(picked > 0 && !confirming)
            FText(
                if (confirming) "Confirming..." else if (picked > 0) "Confirm Slot #$picked & Join" else "Confirm Slot",
                size = rem(1.0), weight = FontWeight.Bold, color = if (dis) Color(0xFF94A3B8) else Color.White, align = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun SlotHead(h: SlotRow.Head) {
    val c = FF.c
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(400)) }
    val anim = Modifier.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 8.dp.toPx() }
    if (h.kind == "vs") {
        val inf = rememberInfiniteTransition(label = "vs")
        val s by inf.animateFloat(1f, 1.15f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "vsS")
        Box(Modifier.fillMaxWidth().then(anim).padding(top = 8.dp, bottom = 2.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.graphicsLayer { scaleX = s; scaleY = s }.size(40.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Color(0xFF6366F1), Color(0xFFF43F5E)))),
                contentAlignment = Alignment.Center,
            ) { FText("VS", size = rem(0.85), weight = FontWeight.Black, color = Color.White) }
        }
        return
    }
    val col = when (h.kind) { "a" -> Color(0xFF4F46E5); "b" -> Color(0xFFE11D48); else -> c.textMuted }
    Row(Modifier.fillMaxWidth().then(anim).padding(top = 6.dp, bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        FaIcon(if (h.kind == "t") "fa-solid fa-users" else "fa-solid fa-shield", rem(0.72).value.dp, col)
        FText(h.text, size = rem(0.72), weight = FontWeight.ExtraBold, color = col, letterSpacing = 1.sp)
        if (h.small.isNotEmpty()) FText(h.small, size = rem(0.72), weight = FontWeight.SemiBold, color = col.copy(alpha = 0.8f))
    }
}

/** `#slot-grid button`: #N badge + occupant name; the picked slot turns primary and shows "<me> (You)". */
@Composable
private fun SlotButton(n: Int, occupant: String?, picked: Boolean, myName: String, modifier: Modifier, onPick: (Int) -> Unit) {
    val c = FF.c
    val isTaken = occupant != null
    val shape = RoundedCornerShape(12.dp)
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(minOf(n * 18L, 380L)); a.animateTo(1f, tween(450, easing = PopEase)) }
    val pop = remember { Animatable(1f) }
    LaunchedEffect(picked) { if (picked) { pop.snapTo(0.9f); pop.animateTo(1f, tween(350, easing = PopEase)) } }
    val bg = if (picked) c.primary else if (isTaken) Color(0xFFF1F5F9) else Color.White
    val bd = if (picked) c.primary else if (isTaken) Color(0xFFE2E8F0) else Color(0xFFCBD5E1)
    val fg = if (picked) Color.White else if (isTaken) Color(0xFF94A3B8) else Color(0xFF0F172A)
    Row(
        modifier
            .graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 8.dp.toPx(); scaleX = pop.value; scaleY = pop.value }
            .then(if (picked) Modifier.boxShadow(22.dp, Color(0x614F46E5), shape) else Modifier)
            .defaultMinSize(minHeight = 48.dp).clip(shape).background(bg).border(1.5.dp, bd, shape)
            .then(if (isTaken) Modifier else Modifier.press(0.92f) { onPick(n) })
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.defaultMinSize(minWidth = 28.dp, minHeight = 28.dp).clip(RoundedCornerShape(8.dp))
                .background(if (picked) Color.White else if (isTaken) Color(0xFFE2E8F0) else c.primaryLight).padding(horizontal = 6.dp),
            contentAlignment = Alignment.Center,
        ) {
            FText("#$n", size = rem(0.75), weight = FontWeight.ExtraBold, color = if (picked) c.primary else if (isTaken) Color(0xFF94A3B8) else c.primary, maxLines = 1)
        }
        FText(
            if (picked) "$myName (You)" else occupant ?: "Empty — tap to choose",
            size = rem(0.8), weight = FontWeight.SemiBold,
            color = if (picked) Color.White else Color(0xFF94A3B8),
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
        )
    }
}

// ============================================================================================ success overlay

private class Piece(val dx: Float, val dy: Float, val rot: Float, val color: Color, val delay: Float, val round: Boolean)

private val ConfettiColors = listOf(Color(0xFF4F46E5), Color(0xFFF43F5E), Color(0xFF10B981), Color(0xFFF59E0B), Color(0xFF0EA5E9), Color(0xFFA855F7))

/** `.join-done` — covers the sheet: drawing circle + check, title/sub fade-up, optional confetti burst. */
@Composable
private fun JoinDoneOverlay(show: Boolean, title: String, sub: String, confetti: Boolean, run: Int, modifier: Modifier) {
    val c = FF.c
    val vis by animateFloatAsState(if (show) 1f else 0f, tween(280), label = "jdVis")
    if (vis <= 0.001f && !show) return
    val success = c.success

    val scale = remember { Animatable(0.6f) }
    val circle = remember { Animatable(0f) }
    val check = remember { Animatable(0f) }
    val tIn = remember { Animatable(0f) }
    val sIn = remember { Animatable(0f) }
    val fall = remember { Animatable(0f) }
    LaunchedEffect(run, show) {
        if (!show) return@LaunchedEffect
        scale.snapTo(0.6f); circle.snapTo(0f); check.snapTo(0f); tIn.snapTo(0f); sIn.snapTo(0f); fall.snapTo(0f)
        launch { scale.animateTo(1f, tween(600, easing = PopEase)) }
        launch { delay(100); circle.animateTo(1f, tween(600)) }
        launch { delay(550); check.animateTo(1f, tween(400)) }
        launch { delay(600); tIn.animateTo(1f, tween(500, easing = OutEase)) }
        launch { delay(700); sIn.animateTo(1f, tween(500, easing = OutEase)) }
        if (confetti) launch { fall.animateTo(1f, tween(1680, easing = LinearEasing)) }
    }
    val pieces = remember(run, confetti) {
        if (!confetti) emptyList() else List(40) { i ->
            Piece(Random.nextFloat() * 320f - 160f, -(Random.nextFloat() * 200f + 70f), Random.nextFloat() * 720f - 360f, ConfettiColors[i % ConfettiColors.size], Random.nextFloat() * 0.18f, i % 3 == 0)
        }
    }

    Box(
        modifier.graphicsLayer { alpha = vis }
            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)).background(c.bgCard)
            .tap(enabled = true) { /* swallow touches while the animation plays */ },
        contentAlignment = Alignment.Center,
    ) {
        if (pieces.isNotEmpty()) {
            Canvas(Modifier.fillMaxSize()) {
                val t = fall.value
                val d = density
                for (p in pieces) {
                    val tt = ((t * 1.68f - p.delay) / 1.5f).coerceIn(0f, 1f)      // piece-local progress 0..1 over 1.5s
                    if (tt <= 0f) continue
                    val up = ConfettiEase.transform((tt / 0.35f).coerceIn(0f, 1f))
                    val down = ConfettiEase.transform(((tt - 0.35f) / 0.65f).coerceIn(0f, 1f))
                    val x = size.width * 0.5f + (p.dx * up + p.dx * 0.25f * down) * d
                    val y = size.height * 0.42f + (p.dy * up + 380f * down) * d
                    val a = if (tt < 0.35f) 1f else 1f - down
                    rotate(p.rot * (up + down), pivot = Offset(x, y)) {
                        if (p.round) drawCircle(p.color.copy(alpha = a), radius = 5.dp.toPx(), center = Offset(x, y))
                        else drawRoundRect(p.color.copy(alpha = a), topLeft = Offset(x - 4.5.dp.toPx(), y - 6.5.dp.toPx()), size = Size(9.dp.toPx(), 13.dp.toPx()), cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx()))
                    }
                }
            }
        }
        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Canvas(Modifier.size(104.dp).graphicsLayer { scaleX = scale.value; scaleY = scale.value }) {
                val k = size.width / 60f
                drawCircle(Color(0x1410B981), radius = 26f * k)
                val circ = Path().apply { addOval(androidx.compose.ui.geometry.Rect(Offset(4f * k, 4f * k), Size(52f * k, 52f * k))) }
                val pm = PathMeasure(); pm.setPath(circ, false)
                val seg = Path(); pm.getSegment(0f, pm.length * circle.value, seg, true)
                drawPath(seg, success, style = Stroke(4f * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
                val ck = Path().apply { moveTo(18f * k, 31f * k); lineTo(27f * k, 40f * k); lineTo(43f * k, 18f * k) }
                val pm2 = PathMeasure(); pm2.setPath(ck, false)
                val seg2 = Path(); pm2.getSegment(0f, pm2.length * check.value, seg2, true)
                drawPath(seg2, success, style = Stroke(4f * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            FText(title, size = rem(1.35), weight = FontWeight.ExtraBold, align = TextAlign.Center,
                modifier = Modifier.padding(top = 10.dp).graphicsLayer { alpha = tIn.value; translationY = (1f - tIn.value) * 14.dp.toPx() })
            FText(sub, size = rem(0.92), color = c.textMuted, align = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = sIn.value; translationY = (1f - sIn.value) * 14.dp.toPx() })
        }
    }
}
