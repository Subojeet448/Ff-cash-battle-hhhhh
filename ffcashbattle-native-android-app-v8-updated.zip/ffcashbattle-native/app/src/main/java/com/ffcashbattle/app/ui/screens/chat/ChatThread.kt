package com.ffcashbattle.app.ui.screens.chat

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.horizontalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.data.Chat
import com.ffcashbattle.app.data.ChatKeep
import com.ffcashbattle.app.data.ChatSheet
import com.ffcashbattle.app.data.ChatStore
import com.ffcashbattle.app.data.ChatThread
import com.ffcashbattle.app.data.ChatUi
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.data.Prefs
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FRich
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.VerifiedName
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.Inter
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

// ==================================================================================== backup / restore (phone file picker)

internal class BackupActions(val backup: () -> Unit, val restore: () -> Unit)

@Composable
internal fun rememberBackupActions(): BackupActions {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) scope.launch {
            val text = ChatStore.backupJson(Chat.uid ?: "")
            val n = ChatStore.count()
            val ok = withContext(Dispatchers.IO) {
                try { ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray(Charsets.UTF_8)) }; true } catch (_: Exception) { false }
            }
            AppStore.toast(if (ok) "Backup saved · $n messages ✓" else "Could not save the file")
        }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val text: String? = withContext(Dispatchers.IO) {
                try {
                    val b = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    if (b == null || b.size > 25 * 1048576) null else String(b, Charsets.UTF_8)
                } catch (_: Exception) { null }
            }
            if (text == null) { AppStore.toast("Could not read this file"); return@launch }
            val n = ChatStore.restore(Chat.uid ?: "", text)
            AppStore.toast(
                when {
                    n == -1 -> "This is not a chat backup file"
                    n == -2 -> "This backup belongs to another account"
                    n == 0 -> "No new messages found in this file"
                    else -> "Restored $n message${if (n == 1) "" else "s"} ✓"
                },
            )
        }
    }
    return remember(save, pick) {
        BackupActions(
            backup = {
                ChatUi.menuOpen = false
                if (ChatStore.count() == 0) AppStore.toast("Nothing to back up yet")
                else save.launch("ffcashbattle-chat-backup-" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) + ".json")
            },
            restore = { ChatUi.menuOpen = false; pick.launch(arrayOf("*/*")) },
        )
    }
}

// ==================================================================================== the conversation

@Composable
internal fun ChatThreadScreen(th: ChatThread) {
    val c = FF.c
    val backup = rememberBackupActions()
    val g = if (th.kind == "group") Chat.groups[th.id] else null
    if (th.kind == "group") {
        LaunchedEffect(th, g == null) {
            if (g == null) { delay(1500); if (Chat.thread === th && Chat.groups[th.id] == null) Chat.closeThread() }
        }
    }
    val authors = Chat.msgs.map { it.s("from") }.toSet()
    LaunchedEffect(authors) { authors.forEach { if (it.isNotEmpty() && it != Chat.uid) Chat.loadProf(it) } }

    Box(Modifier.fillMaxSize().background(c.bgBody)) {
        Column(Modifier.fillMaxSize().imePadding()) {
            ThreadBar(th, g)
            MsgList(th, Modifier.weight(1f).fillMaxWidth())
            ThreadBottom(th)
        }
        if (ChatUi.menuOpen) ThreadMenu(th, backup)
    }
}

// ---------------------------------------------------------------- top bar
@Composable
private fun ThreadBar(th: ChatThread, g: Doc?) {
    val name = Chat.threadName(th)
    val p = if (th.kind == "dm") Chat.prof[th.uid] else null
    val sub: String; val online: Boolean
    when (th.kind) {
        "dm" -> {
            online = p?.b("online") == true
            val ls = p?.l("lastSeen") ?: 0L
            sub = if (online) "online" else if (ls > 0L) (if (fmtAgo(ls) == "now") "last seen just now" else "last seen " + fmtAgo(ls) + " ago") else ""
        }
        "group" -> { online = false; sub = (g?.strList("members")?.size ?: 0).toString() + " members" }
        else -> { online = false; sub = if (Chat.world.locked) "locked by admin" else Chat.world.tagline }
    }
    Row(
        Modifier.fillMaxWidth().background(cxBarBrush()).statusBarsPadding().padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 11.dp),
        horizontalArrangement = Arrangement.spacedBy(11.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(42.dp).press(0.88f) { Chat.closeThread() }.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
            FaIcon("fa-solid fa-arrow-left", rem(1.05).value.dp, Color.White)
        }
        when (th.kind) {
            "dm" -> ChatAv(name, p?.s("photo"), 42.dp, ring = true)
            "group" -> EmojiAv(g?.s("emoji") ?: "👥", 42.dp)
            else -> EmojiAv(Chat.world.emoji, 42.dp, world = true)
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                FText(name, Modifier.weight(1f, fill = false), size = rem(1.0), weight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, tags = true)
                if (th.kind == "dm" && Chat.isVer(th.uid)) FaIcon("fa-solid fa-circle-check", rem(0.85).value.dp, Color(0xFF7DD3FC))
            }
            if (sub.isNotEmpty()) FText(sub, size = rem(0.7), color = if (online) Color(0xFFBBF7D0) else Color.White.copy(alpha = 0.9f), weight = if (online) FontWeight.Bold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.size(40.dp).press(0.85f) { ChatUi.menuOpen = !ChatUi.menuOpen }.clip(CircleShape).background(Color.White.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            FaIcon("fa-solid fa-ellipsis-vertical", rem(1.1).value.dp, Color.White)
        }
    }
}

// ---------------------------------------------------------------- ⋮ menu
@Composable
private fun ThreadMenu(th: ChatThread, backup: BackupActions) {
    val c = FF.c
    val scope = rememberCoroutineScope()
    ChatKeep.prefVer
    val rk = ChatKeep.roomKey(th)
    val auto = ChatKeep.inList("auto", rk); val mute = ChatKeep.inList("muted", rk)
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(280, easing = easeOutBack)) }
    Box(Modifier.fillMaxSize().tap { ChatUi.menuOpen = false }) {
        val shape = RoundedCornerShape(18.dp)
        Column(
            Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 60.dp, end = 12.dp).widthIn(min = 190.dp)
                .graphicsLayer { val s = 0.85f + 0.15f * appear.value; scaleX = s; scaleY = s; alpha = appear.value.coerceIn(0f, 1f); transformOrigin = androidx.compose.ui.graphics.TransformOrigin(1f, 0f) }
                .boxShadow(44.dp, Color(0x66000000), shape).clip(shape).background(c.bgCard).tap { }.padding(6.dp),
        ) {
            if (th.kind == "dm") {
                val st = th.uid in Chat.friends.starred; val bl = Chat.isBlocked(th.uid)
                MenuItem(if (bl) "fa-solid fa-lock-open" else "fa-solid fa-ban", if (bl) "Unblock user" else "Block user") { scope.launch { Chat.mBlock() } }
                MenuItem("fa-solid fa-star", if (st) "Remove star" else "Star friend", tint = CxAmber) { scope.launch { Chat.mStar() } }
                MenuItem("fa-solid fa-pen", "Rename") { scope.launch { Chat.mRename() } }
                MenuItem("fa-solid fa-flag", "Report", red = true) { scope.launch { Chat.mReport() } }
            } else if (th.kind == "group") {
                MenuItem("fa-solid fa-users", "Group info") { Chat.mGroupInfo() }
                MenuItem("fa-solid fa-right-from-bracket", "Leave group", red = true) { scope.launch { Chat.mLeave() } }
                MenuItem("fa-solid fa-flag", "Report", red = true) { scope.launch { Chat.mReport() } }
            }
            MenuItem("fa-solid fa-floppy-disk", if (auto) "Stop keeping copy" else "Keep a copy on device", tint = Cx6366) { scope.launch { ChatKeep.toggleAuto() } }
            MenuItem("fa-solid fa-bookmark", "Saved messages", tint = CxAmber) { ChatUi.menuOpen = false; ChatUi.show(ChatSheet.Saved()) }
            MenuItem(if (mute) "fa-solid fa-bell" else "fa-solid fa-volume-xmark", if (mute) "Unmute alerts" else "Mute alerts") { ChatKeep.toggleMute() }
            MenuItem("fa-solid fa-cloud-arrow-down", "Backup chats", tint = Color(0xFF10B981)) { backup.backup() }
            MenuItem("fa-solid fa-cloud-arrow-up", "Restore backup", tint = Color(0xFF3B82F6)) { backup.restore() }
        }
    }
}

@Composable
private fun MenuItem(icon: String, text: String, red: Boolean = false, tint: Color? = null, onClick: () -> Unit) {
    val c = FF.c
    Row(
        Modifier.fillMaxWidth().press(0.97f, onClick = onClick).clip(RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(18.dp), contentAlignment = Alignment.Center) { FaIcon(icon, rem(0.9).value.dp, tint ?: if (red) CxRed else c.textMain) }
        FText(text, size = rem(0.88), weight = FontWeight.Bold, color = if (red) CxRed else c.textMain, maxLines = 1)
    }
}

// ---------------------------------------------------------------- messages
@Composable
private fun TtlBanner(th: ChatThread) {
    val c = FF.c
    val dm = th.kind == "dm"
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp).padding(top = 2.dp, bottom = 10.dp),
        horizontalArrangement = Arrangement.Center,
    ) {
        Row(
            Modifier.widthIn(max = 520.dp).clip(RoundedCornerShape(14.dp)).background(Cx6366.copy(alpha = if (c.isDark) 0.14f else 0.08f)).border(1.dp, Cx6366.copy(alpha = 0.15f), RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top,
        ) {
            FaIcon(if (dm) "fa-solid fa-floppy-disk" else "fa-regular fa-hourglass-half", rem(0.7).value.dp, CxAmber, Modifier.padding(top = 2.dp))
            FRich(
                if (dm) "This chat stays [on your device]. The server copy is removed every [7 days] — use [⋮ → Backup chats] to keep a file."
                else "Messages disappear after [${ChatKeep.ttlLabel(th.kind)}]. Tap a message to [save it on your device].",
                size = rem(0.7), color = c.textMuted, boldColor = c.textMain, lineHeight = rem(0.7) * 1.4f,
            )
        }
    }
}

@Composable
private fun MsgList(th: ChatThread, modifier: Modifier) {
    val c = FF.c
    val list = Chat.msgs
    val state = rememberLazyListState()
    val rev = remember(list) { list.asReversed() }
    var flash by remember { mutableStateOf<String?>(null) }
    val newest = list.lastOrNull()
    val ticks = tickCtx(th, list)   // reads Chat state -> ticks refresh when the friend comes online / opens the chat

    LaunchedEffect(newest?.id) {
        if (newest != null && (state.firstVisibleItemIndex <= 1 || newest.s("from") == Chat.uid)) { try { state.animateScrollToItem(0) } catch (_: Exception) { } }
    }
    LaunchedEffect(Chat.jumpTick) {
        val id = Chat.jumpTo ?: return@LaunchedEffect
        Chat.jumpTo = null
        val idx = rev.indexOfFirst { it.id == id }
        if (idx < 0) { AppStore.toast("That message is no longer here (older than " + ChatKeep.ttlLabel(th.kind) + " or not loaded)"); return@LaunchedEffect }
        try { state.animateScrollToItem(idx) } catch (_: Exception) { }
        flash = id; delay(1800); if (flash == id) flash = null
    }

    Box(
        modifier.drawBehind {
            drawCircle(Brush.radialGradient(listOf(Cx6366.copy(alpha = 0.06f), Color.Transparent), center = Offset(size.width * 0.1f, 0f), radius = size.maxDimension * 0.6f), radius = size.maxDimension * 0.6f, center = Offset(size.width * 0.1f, 0f))
            drawCircle(Brush.radialGradient(listOf(CxPink.copy(alpha = 0.06f), Color.Transparent), center = Offset(size.width, size.height), radius = size.maxDimension * 0.6f), radius = size.maxDimension * 0.6f, center = Offset(size.width, size.height))
        },
    ) {
        if (list.isEmpty()) {
            Column(Modifier.fillMaxSize()) {
                if (Chat.msgsState == "ok") TtlBanner(th)
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    when (Chat.msgsState) {
                        "loading" -> LoadingDots()
                        "error" -> ChatEmpty("fa-solid fa-lock", "Can't open this chat", Chat.msgsError)
                        else -> ChatEmpty("fa-regular fa-comment-dots", "No messages yet", "Say hello 👋")
                    }
                }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), state = state, reverseLayout = true, contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 6.dp)) {
                itemsIndexed(rev, key = { _, m -> m.id }) { i, m ->
                    val older = rev.getOrNull(i + 1)
                    Column(Modifier.animateItem().padding(top = 3.dp)) {
                        if (older == null || !sameDay(older.l("at"), m.l("at"))) {
                            Box(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp), contentAlignment = Alignment.Center) {
                                Box(Modifier.clip(RoundedCornerShape(20.dp)).background(c.bgCard).border(1.dp, c.border, RoundedCornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 4.dp)) {
                                    FText(dayLabel(m.l("at")), size = rem(0.66), weight = FontWeight.ExtraBold, color = c.textMuted)
                                }
                            }
                        }
                        MsgRow(th, m, older, flash == m.id, ticks)
                    }
                }
                item(key = "ttl") { TtlBanner(th) }
            }
        }
    }
}

private fun Modifier.dashed(color: Color, radius: Float): Modifier = drawBehind {
    drawRoundRect(color, cornerRadius = CornerRadius(radius.dp.toPx()), style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 4.dp.toPx()))))
}

@Composable
private fun MsgRow(th: ChatThread, m: Doc, prev: Doc?, flashing: Boolean, ticks: TickCtx) {
    val c = FF.c
    val uid = Chat.uid ?: ""
    val from = m.s("from")
    val mine = from == uid
    val grp = th.kind != "dm"
    val deleted = m.b("deleted")
    val showName = grp && !mine && (prev == null || prev.s("from") != from)
    val parsed = Chat.parseMsg(m)
    val nm = m.s("name").ifEmpty { Chat.friendName(from) }
    val saved = ChatKeep.isSaved(m)
    val emo = !deleted && parsed.rp == null && isBigEmoji(parsed.text)
    val soon = grp && Chat.ttlMs(th.kind) - (System.currentTimeMillis() - m.l("at")) < 3_600_000L
    val ver = Chat.isVer(from)
    val world = th.kind == "world"
    val photo = Chat.prof[from]?.s("photo")?.ifEmpty { null } ?: m.s("photo")
    val openCard = { if (world && !mine) ChatUi.show(ChatSheet.UserCard(from, nm.replace("'", ""), m.s("photo"))) }

    // swipe to reply (drag a message sideways)
    val density = androidx.compose.ui.platform.LocalDensity.current
    val maxPx = with(density) { 84.dp.toPx() }; val goPx = with(density) { 62.dp.toPx() }
    var drag by remember { mutableFloatStateOf(0f) }
    var dragging by remember { mutableStateOf(false) }
    val shown by animateFloatAsState(drag, if (dragging) snap() else spring(dampingRatio = 0.55f, stiffness = 300f), label = "swipe")
    val haptic = LocalHapticFeedback.current
    val flashA by animateFloatAsState(if (flashing) 1f else 0f, tween(400), label = "flash")

    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val maxB = maxWidth * 0.78f
        val pr = (abs(shown) / goPx).coerceIn(0f, 1f)
        if (pr > 0f) {
            Box(
                Modifier.align(if (shown > 0) Alignment.CenterStart else Alignment.CenterEnd).padding(horizontal = 6.dp).size(34.dp)
                    .graphicsLayer { alpha = pr; val s = 0.5f + pr * 0.6f; scaleX = s; scaleY = s }.clip(CircleShape).background(if (pr >= 1f) Cx6366 else Cx6366.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center,
            ) { FaIcon("fa-solid fa-reply", rem(0.9).value.dp, if (pr >= 1f) Color.White else Cx6366) }
        }
        Row(
            Modifier.fillMaxWidth().graphicsLayer { translationX = shown }
                .pointerInput(m.id, deleted) {
                    if (deleted) return@pointerInput
                    var fired = false
                    detectHorizontalDragGestures(
                        onDragStart = { fired = false; dragging = true },
                        onDragEnd = { dragging = false; drag = 0f; if (fired) Chat.replyTo(m.id) },
                        onDragCancel = { dragging = false; drag = 0f },
                        onHorizontalDrag = { change, amount ->
                            change.consume()
                            drag = (drag + amount * 0.7f).coerceIn(-maxPx, maxPx)
                            if (abs(drag) >= goPx * 0.7f && !fired) { fired = true; haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
                        },
                    )
                },
            horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Bottom,
        ) {
            if (grp && !mine) {
                Box(Modifier.width(30.dp).padding(end = 0.dp).tap(enabled = showName) { openCard() }) { if (showName) ChatAv(nm, photo, 30.dp) }
                androidx.compose.foundation.layout.Spacer(Modifier.width(6.dp))
            }
            val shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = if (mine) 20.dp else 6.dp, bottomEnd = if (mine) 6.dp else 20.dp)
            var bm: Modifier = Modifier.widthIn(max = maxB)
            if (!emo) {
                bm = if (deleted) bm.dashed(c.border, 20f)
                else if (mine) bm.boxShadow(18.dp, Cx6366.copy(alpha = 0.55f), shape).clip(shape).background(Brush.linearGradient(listOf(Cx6366, CxViolet)))
                else bm.clip(shape).background(c.bgCard).border(1.dp, c.border, shape)
                if (saved) bm = bm.border(2.dp, CxAmber.copy(alpha = if (c.isDark) 0.55f else 0.45f), shape)
                if (flashA > 0f) bm = bm.border(3.dp, CxAmber.copy(alpha = flashA), shape)
            }
            if (!deleted) bm = bm.press(0.985f) { ChatUi.show(ChatSheet.MsgMenu(m.id)) }
            if (soon) bm = bm.graphicsLayer { alpha = 0.72f }
            val textColor = if (deleted) c.textMuted else if (mine && !emo) Color.White else c.textMain
            Column(bm.padding(start = if (emo) 6.dp else 13.dp, end = if (emo) 6.dp else 13.dp, top = if (emo) 2.dp else 9.dp, bottom = if (emo) 0.dp else 6.dp)) {
                if (!showName && ver) {
                    Box(Modifier.padding(bottom = 3.dp).then(if (mine) Modifier.clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.95f)).padding(horizontal = 10.dp, vertical = 2.dp) else Modifier)) {
                        VerifiedName(if (mine) (Chat.me?.s("name") ?: nm) else nm, from, rem(0.7), weight = FontWeight.Black, color = Cx6366, force = true)
                    }
                }
                if (showName) VerifiedName(nm, from, rem(0.7), Modifier.padding(bottom = 2.dp).tap(enabled = world) { openCard() }, FontWeight.Black, Cx6366, force = ver)
                val rp = parsed.rp
                if (rp != null && !deleted) {
                    val qc = if (mine) Color(0xFFFDE68A) else Cx6366
                    Column(
                        Modifier.padding(bottom = 6.dp).clip(RoundedCornerShape(12.dp)).background(if (mine) Color.White.copy(alpha = 0.18f) else Cx6366.copy(alpha = 0.10f))
                            .drawBehind { drawRect(qc, size = Size(4.dp.toPx(), size.height)) }.tap { Chat.jumpTo = rp.id; Chat.jumpTick++ }.padding(start = 14.dp, end = 10.dp, top = 6.dp, bottom = 6.dp),
                    ) {
                        FText(rp.n, size = rem(0.68), weight = FontWeight.Bold, color = qc, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        FText(rp.t, size = rem(0.78), color = if (mine) Color.White else c.textMain.copy(alpha = 0.85f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (deleted) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        FaIcon("fa-solid fa-ban", rem(0.8).value.dp, textColor)
                        FText(if (m.s("delBy").isNotEmpty() && m.s("delBy") != from) "Removed by a verified user" else "Message deleted", size = rem(0.92), color = textColor, italic = true)
                    }
                } else FText(parsed.text, size = if (emo) rem(2.6) else rem(0.92), color = textColor, lineHeight = if (emo) rem(2.6) * 1.15f else rem(0.92) * 1.42f)
                Row(Modifier.align(Alignment.End).padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                    val pre = if (m.b("edited") && !deleted) (if (m.s("editBy").isNotEmpty() && m.s("editBy") != from) "edited by verified user · " else "edited · ") else ""
                    FText(pre + fmtTime(m.l("at")), size = rem(0.6), color = if (emo) c.textMuted else textColor.copy(alpha = 0.7f))
                    if (saved) FaIcon("fa-solid fa-bookmark", rem(0.6).value.dp, if (mine && !emo) Color(0xFFFDE68A) else CxAmber)
                    if (mine && !deleted) TickIcon(tickOf(m, ticks), !emo)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- bottom: composer or lock bar
@Composable
private fun ThreadBottom(th: ChatThread) {
    val p = if (th.kind == "dm") Chat.prof[th.uid] else null
    val bl = th.kind == "dm" && Chat.isBlocked(th.uid)
    val notF = th.kind == "dm" && !Chat.isFriend(th.uid) && p?.b("isPrivate") == true
    val locked = th.kind == "world" && Chat.world.locked
    when {
        bl -> LockBar("fa-solid fa-ban", "You blocked this user", "Unblock")
        notF -> LockBar("fa-solid fa-lock", "This profile is private — add as a friend to chat", null)
        locked -> LockBar("fa-solid fa-lock", "Chat is locked by admin", null)
        else -> Composer()
    }
}

@Composable
private fun LockBar(icon: String, text: String, action: String?) {
    val c = FF.c
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxWidth().background(c.bgCard).drawBehind { drawRect(c.border, size = Size(size.width, 1.dp.toPx())) }.navigationBarsPadding().padding(horizontal = 16.dp, vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
            FaIcon(icon, rem(0.84).value.dp, c.textMuted)
            FText(text, Modifier.weight(1f, fill = false), size = rem(0.84), weight = FontWeight.Bold, color = c.textMuted, align = TextAlign.Center)
            if (action != null) Box(Modifier.press(0.93f) { scope.launch { Chat.mBlock() } }.clip(RoundedCornerShape(20.dp)).background(c.primary).padding(horizontal = 14.dp, vertical = 7.dp)) {
                FText(action, size = rem(0.8), weight = FontWeight.ExtraBold, color = Color.White)
            }
        }
    }
}

@Composable
private fun Composer() {
    val c = FF.c
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    var focused by remember { mutableStateOf(false) }
    val draft = Chat.draft
    val ready = draft.text.isNotBlank()
    val rp = Chat.reply
    val editing = Chat.editing != null

    LaunchedEffect(ChatUi.emojiOpen) { if (ChatUi.emojiOpen) { focusManager.clearFocus(); keyboard?.hide() } }
    LaunchedEffect(Chat.editing, Chat.reply?.id) { if (Chat.editing != null || Chat.reply != null) { delay(60); try { focus.requestFocus() } catch (_: Exception) { } } }

    Column(Modifier.fillMaxWidth().background(c.bgCard).drawBehind { drawRect(c.border, size = Size(size.width, 1.dp.toPx())) }.navigationBarsPadding().padding(top = 8.dp, bottom = 8.dp)) {
        Column(Modifier.padding(horizontal = 10.dp)) {
            if (editing) Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FaIcon("fa-solid fa-pen", rem(0.74).value.dp, Cx6366)
                FText("Editing message", Modifier.weight(1f), size = rem(0.74), weight = FontWeight.ExtraBold, color = Cx6366)
                Box(Modifier.size(28.dp).tap { Chat.cancelEdit() }, contentAlignment = Alignment.Center) { FaIcon("fa-solid fa-xmark", rem(1.0).value.dp, c.textMuted) }
            }
            if (rp != null && !editing) {
                Row(
                    Modifier.fillMaxWidth().padding(start = 2.dp, end = 2.dp, bottom = 8.dp).clip(RoundedCornerShape(14.dp)).background(Cx6366.copy(alpha = if (c.isDark) 0.2f else 0.10f))
                        .drawBehind { drawRect(Cx6366, size = Size(4.dp.toPx(), size.height)) }.padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    FaIcon("fa-solid fa-reply", rem(0.9).value.dp, Cx6366)
                    Column(Modifier.weight(1f)) {
                        FText("Replying to " + rp.n, size = rem(0.74), weight = FontWeight.Bold, color = Cx6366, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        FText(rp.t.ifEmpty { "…" }, size = rem(0.8), color = c.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Box(Modifier.size(34.dp).tap { Chat.cancelReply() }, contentAlignment = Alignment.Center) { FaIcon("fa-solid fa-xmark", rem(1.0).value.dp, c.textMuted) }
                }
            }
        }
        AnimatedVisibility(ChatUi.emojiOpen, enter = expandVertically(tween(380, easing = easeOutExpo)) + fadeIn(tween(250)), exit = shrinkVertically(tween(260)) + fadeOut(tween(200))) {
            Column {
                EmojiPanel()
                androidx.compose.foundation.layout.Spacer(Modifier.height(8.dp))
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
            Box(
                Modifier.size(44.dp).press(0.85f) { ChatUi.emojiOpen = !ChatUi.emojiOpen }.clip(CircleShape).background(if (ChatUi.emojiOpen) Cx6366.copy(alpha = 0.12f) else Color.Transparent),
                contentAlignment = Alignment.Center,
            ) { FaIcon("fa-regular fa-face-smile", rem(1.35).value.dp, if (ChatUi.emojiOpen) Cx6366 else c.textMuted) }
            val shape = RoundedCornerShape(22.dp)
            Box(Modifier.weight(1f).heightIn(min = 46.dp).clip(shape).background(c.bgInput).border(2.dp, if (focused) Cx6366 else c.border, shape).padding(horizontal = 16.dp, vertical = 11.dp), contentAlignment = Alignment.CenterStart) {
                BasicTextField(
                    draft, { v: TextFieldValue -> if (v.text.length <= 900) Chat.draft = v },
                    Modifier.fillMaxWidth().focusRequester(focus).onFocusChanged { focused = it.isFocused; if (it.isFocused) ChatUi.emojiOpen = false },
                    textStyle = TextStyle(color = c.textMain, fontSize = rem(0.95), fontFamily = Inter, lineHeight = rem(0.95) * 1.35f),
                    cursorBrush = SolidColor(Cx6366), maxLines = 5,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    decorationBox = { inner -> Box { if (draft.text.isEmpty()) FText("Message…", size = rem(0.95), color = c.textMuted); inner() } },
                )
            }
            val sShape = CircleShape
            Box(
                Modifier.size(46.dp).press(0.82f, ready) {
                    val wasEditing = Chat.editing != null
                    val ok = Chat.send { t -> if (Chat.draft.text.isEmpty()) Chat.draft = TextFieldValue(t, TextRange(t.length)) }
                    if (ok && !wasEditing) Chat.draft = TextFieldValue("")
                }.then(if (ready) Modifier.boxShadow(18.dp, Cx6366.copy(alpha = 0.6f), sShape) else Modifier).clip(sShape)
                    .background(if (ready) cxFabBrush() else Brush.linearGradient(listOf(c.border, c.border))),
                contentAlignment = Alignment.Center,
            ) { FaIcon("fa-solid fa-paper-plane", rem(1.05).value.dp, Color.White) }
        }
    }
}

// ---------------------------------------------------------------- emoji panel (chat-pro.js)
private class EmoTab(val id: String, val icon: String?, val glyph: String?, val label: String, val items: String)

private val EMO = listOf(
    EmoTab("recent", "fa-regular fa-clock", null, "Recent", ""),
    EmoTab("smile", "fa-regular fa-face-smile", null, "Smileys", "😀 😃 😄 😁 😆 😅 😂 🤣 🥲 ☺️ 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥸 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🫡 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 ☠️ 👽 👾 🤖"),
    EmoTab("hand", null, "👍", "Gestures", "👋 🤚 🖐️ ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🫰 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 🫶 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦾 🧠 👀 👁️ 👅 👄"),
    EmoTab("heart", "fa-solid fa-heart", null, "Hearts", "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💯 💢 💥 💫 💦 💨 💣 💬 💭 💤 ✨ ⭐ 🌟 ⚡ 🔥 🌈 ☀️ 🌙 ❄️ 💧 🌊"),
    EmoTab("game", "fa-solid fa-gamepad", null, "Gaming", "🎮 🕹️ 🎯 🎲 🧩 ♟️ 🎰 🎳 🏆 🥇 🥈 🥉 🏅 🎖️ 👑 💎 💰 🪙 💸 💵 🎁 🎉 🎊 🚀 🛡️ ⚔️ 🗡️ 🔫 🧨 🪖 🎧 🔊 📣 🏁 🚩 ⚽ 🏀 🏏 🏸 🥊"),
    EmoTab("animal", null, "🐶", "Animals", "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🦅 🦉 🐺 🐗 🐴 🦄 🐝 🦋 🐢 🐍 🦖 🐙 🦈 🐬 🐳"),
    EmoTab("food", null, "🍔", "Food", "🍎 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🍔 🍟 🍕 🌭 🌮 🌯 🍗 🍖 🍜 🍝 🍣 🍩 🍪 🎂 🍰 🍫 🍿 ☕ 🍵 🥤 🍺"),
)

private fun recentKey() = "ffemo_" + (Chat.uid ?: "g")
private fun recents(): List<String> = Prefs.str(recentKey()).split("|").filter { it.isNotEmpty() }
private fun pushRecent(e: String) { Prefs.put(recentKey(), (listOf(e) + recents().filter { it != e }).take(24).joinToString("|")) }

private object EmoState { var tab by mutableStateOf("smile"); var ver by mutableStateOf(0) }

private fun insertEmoji(e: String) {
    val d = Chat.draft
    val s = d.selection.min; val en = d.selection.max
    if (d.text.length - (en - s) + e.length > 900) return
    val t = d.text.substring(0, s) + e + d.text.substring(en)
    Chat.draft = TextFieldValue(t, TextRange(s + e.length))
    pushRecent(e); EmoState.ver++
}

private fun backspace() {
    val d = Chat.draft
    val s = d.selection.min; val en = d.selection.max
    if (s != en) { Chat.draft = TextFieldValue(d.text.substring(0, s) + d.text.substring(en), TextRange(s)); return }
    if (s == 0) return
    val bi = android.icu.text.BreakIterator.getCharacterInstance()
    bi.setText(d.text.substring(0, s))
    var p = bi.preceding(s)
    if (p == android.icu.text.BreakIterator.DONE || p < 0) p = s - 1
    Chat.draft = TextFieldValue(d.text.substring(0, p) + d.text.substring(s), TextRange(p))
}

@Composable
private fun EmojiPanel() {
    val c = FF.c
    EmoState.ver
    val rec = recents()
    val tabs = EMO.filter { it.id != "recent" || rec.isNotEmpty() }
    var cur = EMO.firstOrNull { it.id == EmoState.tab } ?: EMO[1]
    if (cur.id == "recent" && rec.isEmpty()) cur = EMO[1]
    val list = if (cur.id == "recent") rec else cur.items.split(" ").filter { it.isNotEmpty() }
    val cols = if (LocalConfiguration.current.screenWidthDp < 340) 7 else 8
    Column(Modifier.fillMaxWidth().background(c.bgCard).drawBehind { drawRect(c.border, topLeft = Offset(0f, size.height - 1.dp.toPx()), size = Size(size.width, 1.dp.toPx())) }) {
        Row(Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, top = 6.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                tabs.forEach { t ->
                    val on = t.id == cur.id
                    Box(
                        Modifier.width(38.dp).height(36.dp).press(0.9f) { EmoState.tab = t.id }.clip(RoundedCornerShape(12.dp)).background(if (on) Cx6366.copy(alpha = 0.12f) else Color.Transparent)
                            .drawBehind { if (on) drawRoundRect(Cx6366, topLeft = Offset(size.width * 0.3f, size.height - 5.dp.toPx()), size = Size(size.width * 0.4f, 3.dp.toPx()), cornerRadius = CornerRadius(3.dp.toPx())) },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (t.icon != null) FaIcon(t.icon, rem(1.0).value.dp, if (on) Cx6366 else c.textMuted)
                        else FText(t.glyph ?: "", size = rem(1.0), color = if (on) Cx6366 else c.textMuted)
                    }
                }
            }
            Box(Modifier.width(38.dp).height(36.dp).press(0.85f) { backspace() }, contentAlignment = Alignment.Center) { FaIcon("fa-solid fa-delete-left", rem(1.0).value.dp, c.textMuted) }
        }
        if (list.isEmpty()) Box(Modifier.fillMaxWidth().height(232.dp), contentAlignment = Alignment.Center) { FText("Your recent emoji appear here", size = rem(0.8), color = c.textMuted) }
        else LazyVerticalGrid(GridCells.Fixed(cols), Modifier.fillMaxWidth().height(232.dp).padding(horizontal = 8.dp), contentPadding = PaddingValues(top = 4.dp, bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            items(list, key = { cur.id + it }) { e ->
                Box(Modifier.fillMaxWidth().press(0.8f) { insertEmoji(e) }.padding(vertical = 7.dp), contentAlignment = Alignment.Center) { FText(e, size = rem(1.55), align = TextAlign.Center) }
            }
        }
    }
}
