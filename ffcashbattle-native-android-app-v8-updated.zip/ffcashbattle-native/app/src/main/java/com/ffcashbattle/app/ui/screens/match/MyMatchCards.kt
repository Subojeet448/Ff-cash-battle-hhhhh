package com.ffcashbattle.app.ui.screens.match

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.data.GameArt
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ================================================================================== helpers (match.js)

fun money(n: Double): String = "₹" + (if (n % 1.0 == 0.0) n.toLong().toString() else String.format(Locale.US, "%.2f", n))

fun matchStartMs(m: Doc): Long = m.ms("startTime")

/** `dateLbl`: "16 Nov 2026, 07:30 pm" (falls back to `m.time`). */
fun dateLbl(m: Doc): String {
    val ms = matchStartMs(m)
    if (ms <= 0L) return m.s("time")
    return try { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale("en", "IN")).format(Date(ms)).replace("AM", "am").replace("PM", "pm") } catch (_: Exception) { m.s("time") }
}

fun typeLbl(m: Doc): String =
    if (m.s("modeShort").isNotEmpty()) m.s("modeShort") + " " + m.s("subMode")
    else when (m.s("matchType")) { "per_kill" -> "Per Kill"; "team_win" -> "Team Win"; else -> "Win Prize" }

private fun slotText(v: Any?): String = when (v) { is Number -> v.toLong().toString(); null -> ""; else -> v.toString() }

fun myEntry(m: Doc, myUid: String): Map<String, Any?> = m.maps("participants").firstOrNull { it["uid"] == myUid } ?: emptyMap()

fun mySlot(me: Map<String, Any?>): String {
    val s = slotText(me["slot"])
    if (s.isNotEmpty() && s != "0") return s
    val first = (me["slots"] as? List<*>)?.firstOrNull()
    return slotText(first)
}

class MatchResult(
    val me: Map<String, Any?>, val fee: Double, val kills: Int, val won: Boolean, val place: Int,
    val amount: Double, val net: Double, val kind: String, val refunded: Boolean,
)

/** `resultOf`. */
fun resultOf(m: Doc, myUid: String): MatchResult {
    val me = myEntry(m, myUid)
    val refunded = me["refunded"] == true
    val fee = if (refunded) 0.0 else m.n("fee")
    val kills = dbl(me["kills"]).toInt()
    val rk = me["rank"]
    val place = if (rk is Number) rk.toInt() else mapOf("1st" to 1, "2nd" to 2, "3rd" to 3)[rk?.toString()] ?: (rk?.toString()?.toIntOrNull() ?: 0)
    val winnerUids = (m["winnerUids"] as? List<*>) ?: emptyList<Any?>()
    val won = m.s("winnerUid") == myUid || winnerUids.contains(myUid) || place == 1
    val amount = when {
        me["winAmount"] != null -> dbl(me["winAmount"])
        m.s("matchType") == "per_kill" -> kills * m.n("prize")
        won -> m.n("prize")
        else -> 0.0
    }
    val kind = if (won) "win" else if (kills > 0 || amount > 0) "kill" else "loss"
    return MatchResult(me, fee, kills, won, place, amount, amount - fee, kind, refunded)
}

// ---------------------------------------------------------------------------------- colour helpers

@Composable
private fun dk(light: Color, dark: Color): Color = if (FF.c.isDark) dark else light

private val POS = Color(0xFF16A34A)
private val NEG = Color(0xFFDC2626)

/** Fade-up entrance used for list cards (`.anim-list .mm-card`). */
@Composable
private fun FadeUp(index: Int, content: @Composable () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(minOf(index * 60L, 240L)); a.animateTo(1f, tween(450, easing = CubicBezierEasing(0.16f, 1f, 0.3f, 1f))) }
    Box(Modifier.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 16.dp.toPx() }) { content() }
}

@Composable
private fun CardShell(modifier: Modifier = Modifier, borderColor: Color? = null, ring: Color? = null, content: @Composable () -> Unit) {
    val c = FF.c
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 15.dp)
            .then(if (ring != null) Modifier.boxShadow(28.dp, Color(0x2410B981), shape) else Modifier)
            .clip(shape).background(c.bgCard).border(1.dp, borderColor ?: c.border, shape),
    ) { Column(Modifier.padding(bottom = 14.dp)) { content() } }
}

@Composable
private fun MxLabel(text: String) {
    FText(text.uppercase(), size = rem(0.66), weight = FontWeight.Bold, color = FF.c.textMuted, letterSpacing = 0.3.sp, maxLines = 1, softWrap = false, align = TextAlign.Center)
}

@Composable
private fun MxCell(modifier: Modifier, label: String, valueColor: Color? = null, content: (@Composable () -> Unit)? = null, value: String = "", size: Float = 0.88f) {
    val c = FF.c
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(c.bgInput).padding(horizontal = 6.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        MxLabel(label)
        Box(Modifier.padding(top = 3.dp)) {
            if (content != null) content()
            else FText(value, size = rem(size.toDouble()), weight = if (size > 0.9f) FontWeight.Black else FontWeight.ExtraBold, color = valueColor ?: c.textMain, maxLines = 1, overflow = TextOverflow.Ellipsis, align = TextAlign.Center)
        }
    }
}

@Composable
private fun PrizeCell(modifier: Modifier, m: Doc) {
    val c = FF.c
    val perKill = m.s("matchType") == "per_kill"
    MxCell(
        modifier, if (perKill) "Per Kill" else "Prize Pool",
        content = {
            if (m.n("prize") > 0 || m["rewards"] == null) FText(money(m.n("prize")), size = rem(0.88), weight = FontWeight.ExtraBold, color = c.textMain, maxLines = 1)
            else RwView(prizeInfo(m).big, rem(0.88), FontWeight.ExtraBold, c.textMain, cardH = 18.dp)
        },
    )
}

@Composable
private fun TopRow(m: Doc, subtitle: String, chip: @Composable () -> Unit) {
    val c = FF.c
    Row(Modifier.fillMaxWidth().padding(start = 14.dp, top = 14.dp, end = 14.dp, bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
        val img = m.s("img")
        val tm = Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFE2E8F0))
        if (img.isNotBlank()) AsyncImage(img, null, tm, contentScale = ContentScale.Crop)
        else Image(painterResource(GameArt.banner(m)), null, tm, contentScale = ContentScale.Crop)
        Column(Modifier.weight(1f)) {
            FText(m.s("title"), size = rem(0.95), weight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(bottom = 3.dp), tags = true)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                FaIcon("fa-regular fa-calendar", rem(0.66).value.dp, c.textMuted)
                FText(subtitle, size = rem(0.66), weight = FontWeight.SemiBold, color = c.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        chip()
    }
}

@Composable
private fun Chip(text: String, icon: String, bg: Brush, fg: Color, glow: Boolean = false) {
    Row(
        Modifier.then(if (glow) Modifier.boxShadow(12.dp, Color(0x66F59E0B), RoundedCornerShape(99.dp)) else Modifier)
            .clip(RoundedCornerShape(99.dp)).background(bg).padding(horizontal = 10.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        FaIcon(icon, rem(0.68).value.dp, fg)
        FText(text, size = rem(0.68), weight = FontWeight.ExtraBold, color = fg, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun FfRow(me: Map<String, Any?>) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MxCell(Modifier.weight(1f), "FF Name", value = me["gameName"]?.toString()?.ifEmpty { "-" } ?: "-")
        MxCell(Modifier.weight(1f), "FF UID", value = me["gameUid"]?.toString()?.ifEmpty { "-" } ?: "-")
    }
}

// ================================================================================== room box

/** Dashed rounded border (radius 16dp) drawn on top of the background. */
private fun Modifier.dashedRound(col: Color, widthDp: Float): Modifier = this.drawBehind {
    val sw = widthDp.dp.toPx()
    drawRoundRect(
        col, topLeft = Offset(sw / 2f, sw / 2f), size = Size(size.width - sw, size.height - sw),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(16.dp.toPx()),
        style = Stroke(sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(5.dp.toPx(), 4.dp.toPx()))),
    )
}

@Composable
private fun LiveBadge() {
    val inf = rememberInfiniteTransition(label = "live")
    val a by inf.animateFloat(1f, 0.3f, infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "a")
    Row(
        Modifier.clip(RoundedCornerShape(99.dp)).background(dk(Color(0xFFFEE2E2), Color(0x33EF4444))).padding(horizontal = 9.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.graphicsLayer { alpha = a }.size(7.dp).clip(CircleShape).background(Color(0xFFEF4444)))
        FText("LIVE", size = rem(0.65), weight = FontWeight.Black, color = dk(Color(0xFFDC2626), Color(0xFFFCA5A5)))
    }
}

@Composable
private fun RoomHead(icon: String, title: String, sub: String, iconBg: Brush, iconFg: Color, pulse: Boolean = false, pop: Boolean = false, live: Boolean = false) {
    val c = FF.c
    val inf = rememberInfiniteTransition(label = "lock")
    val ps by inf.animateFloat(1f, 1.1f, infiniteRepeatable(tween(1000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "ps")
    val unlock = remember { Animatable(if (pop) 0f else 1f) }
    LaunchedEffect(Unit) { if (pop) unlock.animateTo(1f, tween(700, easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f))) }
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(11.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.graphicsLayer {
                val s = (if (pulse) ps else 1f) * (0.4f + 0.6f * unlock.value)
                scaleX = s; scaleY = s; rotationZ = -25f * (1f - unlock.value); alpha = unlock.value
            }.size(38.dp).clip(RoundedCornerShape(12.dp)).background(iconBg),
            contentAlignment = Alignment.Center,
        ) { FaIcon(icon, rem(1.05).value.dp, iconFg) }
        Column(Modifier.weight(1f)) {
            FText(title, size = rem(0.86), weight = FontWeight.ExtraBold)
            FText(sub, size = rem(0.66), weight = FontWeight.Medium, color = c.textMuted, lineHeight = rem(0.66) * 1.35f, modifier = Modifier.padding(top = 2.dp))
        }
        if (live) LiveBadge()
    }
}

@Composable
private fun CredButton(label: String, value: String, modifier: Modifier, onCopy: () -> Unit) {
    val c = FF.c
    var copied by remember { mutableStateOf(false) }
    val pop = remember { Animatable(1f) }
    LaunchedEffect(copied) { if (copied) { pop.snapTo(0.9f); pop.animateTo(1f, tween(350, easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f))); delay(1050); copied = false } }
    val green = dk(Color(0xFF15803D), Color(0xFF6EE7B7))
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier.graphicsLayer { scaleX = pop.value; scaleY = pop.value }
            .press(0.95f) { onCopy(); copied = true }
            .clip(shape).background(if (copied) dk(Color(0xFFDCFCE7), Color(0x4010B981)) else c.bgCard)
            .border(1.dp, if (copied) dk(Color(0xFF4ADE80), Color(0xFF34D399)) else c.border, shape)
            .padding(horizontal = 8.dp, vertical = 11.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        FText(label.uppercase(), size = rem(0.62), weight = FontWeight.Bold, color = c.textMuted, letterSpacing = 0.4.sp)
        FText(value, size = rem(1.12), weight = FontWeight.Black, mono = true, letterSpacing = 1.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            FaIcon("fa-regular fa-copy", rem(0.66).value.dp, if (copied) green else c.primary)
            FText(if (copied) "COPIED" else "COPY", size = rem(0.66), weight = FontWeight.ExtraBold, color = if (copied) green else c.primary)
        }
    }
}

private fun copyText(text: String) {
    try {
        val cm = AppStore.app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("ffcb", text))
    } catch (_: Exception) { }
}

/** `_roomBox`: live-locked / open (copy buttons) / saved / "no details" / locked-with-countdown. */
@Composable
private fun RoomBox(m: Doc, done: Boolean, now: Long) {
    val c = FF.c
    val shape = RoundedCornerShape(16.dp)
    val haptic = LocalHapticFeedback.current
    val greyLock = Brush.linearGradient(listOf(dk(Color(0xFFE2E8F0), c.bgCard), dk(Color(0xFFE2E8F0), c.bgCard)))
    val greyFg = Color(0xFF94A3B8)
    val roomId = m.s("roomId")
    val roomPass = m.s("roomPass")

    if (!done && m.s("status") == "live") {
        Column(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp).clip(shape).background(c.bgInput).dashedRound(dk(Color(0xFFCBD5E1), c.border), 1.5f).padding(14.dp)) {
            Box(Modifier.padding(bottom = 0.dp)) { RoomHead("fa-solid fa-gamepad", "Game Started", "Room ID & password are closed now. Good luck!", greyLock, greyFg, live = true) }
        }
        return
    }
    if (roomId.isNotEmpty() && roomPass.isNotEmpty()) {
        val open = !done
        val shine by rememberInfiniteTransition(label = "shine").animateFloat(-0.5f, 1.5f, infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "s")
        Column(
            Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp).clip(shape)
                .background(if (open) Brush.linearGradient(listOf(dk(Color(0xFFECFDF5), Color(0x2410B981)), dk(Color(0xFFEEF2FF), Color(0x246366F1)))) else Brush.linearGradient(listOf(c.bgInput, c.bgInput)))
                .then(if (open) Modifier.border(1.5.dp, dk(Color(0xFF6EE7B7), Color(0x8034D399)), shape) else Modifier.dashedRound(c.border, 1f))
                .then(if (open) Modifier.drawBehind {
                    val w = size.width * 0.4f; val x = size.width * shine
                    drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.55f), Color.Transparent), startX = x, endX = x + w), Offset(x, 0f), Size(w, size.height))
                } else Modifier)
                .padding(14.dp),
        ) {
            RoomHead(
                if (done) "fa-solid fa-box-archive" else "fa-solid fa-lock-open",
                if (done) "Saved Room Credentials" else "Room is Open — Join Now!",
                if (done) "Room details of this match" else "Free Fire → Custom Room → enter ID & password",
                if (open) Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF34D399))) else Brush.linearGradient(listOf(c.primaryLight, c.primaryLight)),
                if (open) Color.White else c.primary, pop = open, live = open,
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CredButton("Room ID", roomId, Modifier.weight(1f)) { copyText(roomId); haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
                CredButton("Password", roomPass, Modifier.weight(1f)) { copyText(roomPass); haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
            }
            var all by remember { mutableStateOf(false) }
            LaunchedEffect(all) { if (all) { delay(1400); all = false } }
            val greenFg = dk(Color(0xFF15803D), Color(0xFF6EE7B7))
            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp).press(0.98f) { copyText("Room ID: $roomId\nPassword: $roomPass"); all = true; haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (all) Brush.linearGradient(listOf(dk(Color(0xFFDCFCE7), Color(0x4010B981)), dk(Color(0xFFDCFCE7), Color(0x4010B981)))) else Brush.linearGradient(listOf(c.primary, Color(0xFF818CF8))))
                    .padding(11.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically,
            ) {
                FaIcon("fa-solid fa-clone", rem(0.76).value.dp, if (all) greenFg else Color.White)
                FText(if (all) "COPIED" else "COPY ID & PASSWORD", size = rem(0.76), weight = FontWeight.ExtraBold, color = if (all) greenFg else Color.White)
            }
        }
        return
    }
    if (done) {
        Column(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp).clip(shape).background(c.bgInput).dashedRound(dk(Color(0xFFCBD5E1), c.border), 1.5f).padding(14.dp)) {
            RoomHead("fa-solid fa-ban", "No room details saved", "Room ID & password were not published for this match.", greyLock, greyFg)
        }
        return
    }
    val ms = matchStartMs(m)
    Column(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp).clip(shape).background(c.bgInput).dashedRound(dk(Color(0xFFCBD5E1), c.border), 1.5f).padding(14.dp)) {
        RoomHead("fa-solid fa-lock", "Room ID & Password locked", "They appear here 10 mins before the match. You'll get an alert.", greyLock, greyFg, pulse = true)
        if (ms > 0) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.bgCard).border(1.dp, c.border, RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
            ) {
                FText("Starts in", size = rem(0.78), weight = FontWeight.Bold, color = c.textMuted)
                Countdown(ms, now)
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Skel(Modifier.weight(1f).height(46.dp), 12.dp)
            Skel(Modifier.weight(1f).height(46.dp), 12.dp)
        }
    }
}

// ================================================================================== reward list (`_rwRows`)

/** `.rw-list`: "who gets what" rows (used by the upcoming card and the Join sheet). */
@Composable
fun RwListBox(m: Doc, modifier: Modifier = Modifier) {
    val rows = remember(m) { rwListEntries(m) }
    if (rows.isEmpty()) return
    val purple = dk(Color(0xFF6B21A8), Color(0xFFD8B4FE))
    val c = FF.c
    val shape = RoundedCornerShape(14.dp)
    val line = dk(Color(0xFFEDE9FE), Color(0x40A855F7))
    Column(
        modifier.fillMaxWidth().clip(shape).background(dk(Color(0xFFFAF5FF), Color(0x1FA855F7)))
            .drawBehind {
                val sw = 1.dp.toPx()
                drawRoundRect(Color(0xFFA855F7).copy(alpha = if (c.isDark) 0.35f else 0.28f), topLeft = Offset(sw / 2f, sw / 2f), size = Size(size.width - sw, size.height - sw), cornerRadius = androidx.compose.ui.geometry.CornerRadius(14.dp.toPx()),
                    style = Stroke(sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 3.dp.toPx()))))
            }
            .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        rows.forEachIndexed { i, (label, rw) ->
            Row(
                Modifier.fillMaxWidth().padding(vertical = 7.dp)
                    .then(if (i < rows.size - 1) Modifier.drawBehind {
                        val dash = 3.dp.toPx(); var x = 0f
                        while (x < size.width) { drawLine(line, Offset(x, size.height + 7.dp.toPx()), Offset(minOf(x + dash, size.width), size.height + 7.dp.toPx()), 1.dp.toPx()); x += dash * 2 }
                    } else Modifier),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
            ) {
                FText(label, size = rem(0.8), weight = FontWeight.Bold, color = purple, modifier = Modifier.weight(1f))
                RwView(rw, rem(0.8), FontWeight.ExtraBold, dk(Color(0xFF1F2937), Color(0xFFF3F4F6)), cardH = 18.dp)
            }
        }
    }
}

// ================================================================================== upcoming card

@Composable
fun UpcomingCard(m: Doc, myUid: String, idx: Int, now: Long) {
    val c = FF.c
    val me = myEntry(m, myUid)
    val slot = mySlot(me)
    val perKill = m.s("matchType") == "per_kill"
    val joined = m.i("joined").takeIf { it > 0 } ?: m.list("participants").size
    val total = m.i("total").takeIf { it > 0 } ?: 48
    val pct = minOf(100f, Math.round(joined.toFloat() / total * 100f).toFloat()) / 100f
    val ready = m.s("roomId").isNotEmpty() && m.s("roomPass").isNotEmpty() && m.s("status") != "live"

    // `.flash` when credentials arrive while the page is open
    val wasReady = remember { mutableStateOf(ready) }
    val flash = remember { Animatable(1f) }
    LaunchedEffect(ready) { if (ready && !wasReady.value) { flash.snapTo(0f); flash.animateTo(1f, tween(1600)) }; wasReady.value = ready }

    FadeUp(idx) {
        val shape = RoundedCornerShape(18.dp)
        Box(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 15.dp)
                .drawBehind {
                    val f = flash.value
                    if (f < 1f) {
                        val r = 18.dp.toPx() * f
                        drawRoundRect(Color(0xFF10B981).copy(alpha = 0.7f * (1f - f)), topLeft = Offset(-r, -r), size = Size(size.width + 2 * r, size.height + 2 * r), cornerRadius = androidx.compose.ui.geometry.CornerRadius(18.dp.toPx() + r))
                    }
                }
                .then(if (ready) Modifier.boxShadow(28.dp, Color(0x2410B981), shape) else Modifier)
                .clip(shape).background(c.bgCard).border(1.dp, if (ready) Color(0xFF86EFAC) else c.border, shape),
        ) {
            Column(Modifier.padding(bottom = 14.dp)) {
                TopRow(m, dateLbl(m).ifEmpty { "Upcoming" }) {
                    Chip("JOINED", "fa-solid fa-circle-check", Brush.linearGradient(listOf(dk(Color(0xFFDCFCE7), Color(0x3310B981)), dk(Color(0xFFDCFCE7), Color(0x3310B981)))), dk(Color(0xFF15803D), Color(0xFF6EE7B7)))
                }
                val warn = slot.isEmpty()
                Row(
                    Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp).clip(RoundedCornerShape(12.dp))
                        .background(if (warn) dk(Color(0xFFFEF3C7), Color(0x29F59E0B)) else dk(Color(0xFFDCFCE7), Color(0x2910B981)))
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    val fg = if (warn) dk(Color(0xFFB45309), Color(0xFFFCD34D)) else dk(Color(0xFF15803D), Color(0xFF6EE7B7))
                    FaIcon(if (warn) "fa-solid fa-triangle-exclamation" else "fa-solid fa-circle-check", rem(0.82).value.dp, fg)
                    if (warn) FText("Slot not chosen yet — contact support if this stays", size = rem(0.82), weight = FontWeight.Bold, color = fg, modifier = Modifier.weight(1f))
                    else Row(Modifier.weight(1f)) {
                        FText("You are in — Slot ", size = rem(0.82), weight = FontWeight.Bold, color = fg)
                        FText("#$slot", size = rem(0.82), weight = FontWeight.Black, color = fg)
                    }
                }
                RoomBox(m, false, now)
                Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MxCell(Modifier.weight(1f), "Entry Fee", value = money(m.n("fee")))
                    PrizeCell(Modifier.weight(1f), m)
                    MxCell(Modifier.weight(1f), "Type", value = typeLbl(m))
                }
                RwListBox(m, Modifier.padding(start = 14.dp, end = 14.dp, top = 0.dp, bottom = 10.dp))
                // players bar
                Column(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 10.dp)) {
                    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                            FaIcon("fa-solid fa-users", rem(0.78).value.dp, c.textMuted)
                            FText("Players joined", size = rem(0.78), weight = FontWeight.Bold, color = c.textMuted)
                        }
                        FText("$joined/$total", size = rem(0.78), weight = FontWeight.Bold)
                    }
                    val grow = remember { Animatable(0f) }
                    LaunchedEffect(pct) { grow.animateTo(pct, tween(1000, easing = CubicBezierEasing(0f, 0f, 0.2f, 1f))) }
                    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(99.dp)).background(c.bgInput)) {
                        Box(Modifier.fillMaxWidth(grow.value).fillMaxHeight().clip(RoundedCornerShape(99.dp)).background(Brush.horizontalGradient(listOf(c.primary, Color(0xFFA78BFA)))))
                    }
                }
                FfRow(me)
                Box(Modifier.padding(horizontal = 14.dp)) { RosterButton(m) }
            }
        }
    }
}

// ================================================================================== history

@Composable
private fun CountUp(value: Double, color: Color, size: Double) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(value) { a.animateTo(value.toFloat(), tween(900, easing = CubicBezierEasing(0f, 0f, 0.2f, 1f))) }
    val v = a.value.toDouble()
    val txt = if (value % 1.0 == 0.0) Math.round(v).toString() else String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')
    FText(txt, size = rem(size), weight = FontWeight.Black, color = color, maxLines = 1, align = TextAlign.Center)
}

@Composable
fun HistorySummary(list: List<Doc>, myUid: String) {
    var won = 0; var kills = 0; var spent = 0.0; var earned = 0.0
    for (m in list) { val r = resultOf(m, myUid); spent += r.fee; earned += r.amount; kills += r.kills; if (r.won) won++ }
    val net = earned - spent
    val pop = remember { Animatable(0f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, tween(550, easing = CubicBezierEasing(0.34f, 1.56f, 0.64f, 1f))) }
    val inf = rememberInfiniteTransition(label = "sum")
    val fl by inf.animateFloat(0f, -5f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "fl")
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 16.dp)
            .graphicsLayer { val s = 0.9f + 0.1f * pop.value; scaleX = s; scaleY = s; alpha = minOf(1f, pop.value * 1.5f) }
            .boxShadow(30.dp, Color(0x4D4F46E5), shape).clip(shape)
            .background(Brush.linearGradient(0f to Color(0xFF312E81), 0.55f to Color(0xFF4F46E5), 1f to Color(0xFF7C3AED)))
            .drawBehind { drawCircle(Color(0x1AFFFFFF), radius = 70.dp.toPx(), center = Offset(size.width + 40.dp.toPx() - 70.dp.toPx(), -40.dp.toPx() + 70.dp.toPx())) }
            .padding(16.dp),
    ) {
        Column {
            Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    FText("NET RESULT", size = rem(0.66), weight = FontWeight.Bold, color = Color.White.copy(alpha = 0.75f), letterSpacing = 0.6.sp)
                    FText((if (net >= 0) "+" else "-") + money(Math.abs(net)), size = rem(1.9), weight = FontWeight.Black, color = if (net >= 0) Color(0xFF86EFAC) else Color(0xFFFCA5A5), lineHeight = rem(1.9) * 1.1f)
                }
                Box(Modifier.graphicsLayer { translationY = fl.dp.toPx() }.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color(0x2EFFFFFF)), contentAlignment = Alignment.Center) {
                    FaIcon("fa-solid fa-chart-line", rem(1.2).value.dp, Color.White)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                @Composable
                fun Cell(icon: String, v: Double, label: String, tint: Color) {
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(Color(0x24FFFFFF)).padding(horizontal = 2.dp, vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        FaIcon(icon, rem(0.8).value.dp, tint.copy(alpha = if (tint == Color.White) 0.85f else 1f), Modifier.padding(bottom = 4.dp))
                        CountUp(v, Color.White, 0.98)
                        FText(label.uppercase(), size = rem(0.58), weight = FontWeight.Bold, color = Color.White.copy(alpha = 0.8f), maxLines = 1)
                    }
                }
                Cell("fa-solid fa-gamepad", list.size.toDouble(), "Played", Color.White)
                Cell("fa-solid fa-trophy", won.toDouble(), "Wins", Color(0xFFFDE047))
                Cell("fa-solid fa-crosshairs", kills.toDouble(), "Kills", Color.White)
                Cell("fa-solid fa-indian-rupee-sign", Math.round(earned * 100) / 100.0, "Won", Color(0xFF86EFAC))
                Cell("fa-solid fa-wallet", Math.round(spent * 100) / 100.0, "Spent", Color(0xFFFCA5A5))
            }
        }
    }
}

@Composable
private fun ResultBanner(kind: String, icon: String, small: String, big: String, amt: String, winShine: Boolean = false) {
    val c = FF.c
    val inf = rememberInfiniteTransition(label = "bn")
    val tro by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart), label = "tro")
    val shine by inf.animateFloat(-0.5f, 1.5f, infiniteRepeatable(tween(3000, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "shn")
    val bg: Brush; val bd: Color; val fg: Color; val icoBg: Brush; val amtCol: Color
    when (kind) {
        "win" -> { bg = Brush.linearGradient(listOf(dk(Color(0xFFFFFBEB), Color(0x24F59E0B)), dk(Color(0xFFFEF3C7), Color(0x24F59E0B)))); bd = dk(Color(0xFFFCD34D), Color(0x66FBBF24)); fg = dk(Color(0xFF92400E), Color(0xFFFDE68A)); icoBg = Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFFFBBF24))); amtCol = POS }
        "kill" -> { bg = Brush.linearGradient(listOf(dk(Color(0xFFFEF2F2), Color(0x24EF4444)), dk(Color(0xFFFEF2F2), Color(0x24EF4444)))); bd = dk(Color(0xFFFECACA), Color(0x59F87171)); fg = dk(Color(0xFF991B1B), Color(0xFFFECACA)); icoBg = Brush.linearGradient(listOf(Color(0xFFEF4444), Color(0xFFF87171))); amtCol = POS }
        else -> { bg = Brush.linearGradient(listOf(c.bgInput, c.bgInput)); bd = c.border; fg = c.textMain; icoBg = Brush.linearGradient(listOf(Color(0xFF94A3B8), Color(0xFF94A3B8))); amtCol = c.textMuted }
    }
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp).clip(shape).background(bg).border(1.dp, bd, shape)
            .then(if (winShine) Modifier.drawBehind {
                val w = size.width * 0.35f; val x = size.width * shine
                drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.7f), Color.Transparent), startX = x, endX = x + w), Offset(x, 0f), Size(w, size.height))
            } else Modifier)
            .padding(13.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.graphicsLayer {
                if (winShine) { val p = tro; val t = if (p < 0.25f) p / 0.25f else if (p < 0.75f) 1f - (p - 0.25f) / 0.25f * 2f else -1f + (p - 0.75f) / 0.25f
                    rotationZ = -9f * t; val s = 1f + 0.08f * Math.abs(t); scaleX = s; scaleY = s }
            }.then(if (winShine) Modifier.boxShadow(16.dp, Color(0x73F59E0B), RoundedCornerShape(14.dp)) else Modifier)
                .size(46.dp).clip(RoundedCornerShape(14.dp)).background(icoBg),
            contentAlignment = Alignment.Center,
        ) { FaIcon(icon, rem(1.3).value.dp, Color.White) }
        Column(Modifier.weight(1f)) {
            FText(small.uppercase(), size = rem(0.66), weight = FontWeight.Bold, color = fg.copy(alpha = 0.7f), letterSpacing = 0.3.sp, maxLines = 1)
            FText(big, size = rem(0.98), weight = FontWeight.Black, color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
        }
        FText(amt, size = rem(1.15), weight = FontWeight.Black, color = amtCol, maxLines = 1)
    }
}

@Composable
fun HistoryCard(m: Doc, myUid: String, idx: Int, now: Long) {
    val c = FF.c
    val r = resultOf(m, myUid)
    val me = r.me
    val slot = mySlot(me).ifEmpty { "-" }
    val perKill = m.s("matchType") == "per_kill"
    val joined = m.i("joined").takeIf { it > 0 } ?: m.list("participants").size
    val total = m.i("total").takeIf { it > 0 } ?: 48
    val kind = r.kind
    FadeUp(idx) {
        CardShellH(if (kind == "win") Color(0xFFFCD34D) else null) {
            val sub = dateLbl(m) + (if (m.s("matchCode").isNotEmpty()) " • #" + m.s("matchCode") else "")
            TopRow(m, sub) {
                when {
                    r.refunded -> Chip("REFUNDED", "fa-solid fa-rotate-left", Brush.linearGradient(listOf(dk(Color(0xFFE2E8F0), c.bgInput), dk(Color(0xFFE2E8F0), c.bgInput))), dk(Color(0xFF64748B), c.textMuted))
                    kind == "win" -> Chip("WON", "fa-solid fa-trophy", Brush.linearGradient(listOf(Color(0xFFFBBF24), Color(0xFFF59E0B))), Color.White, glow = true)
                    r.place > 1 && r.amount > 0 -> Chip(if (r.place == 2) "2ND" else if (r.place == 3) "3RD" else "${r.place}TH", "fa-solid fa-medal", Brush.linearGradient(listOf(dk(Color(0xFFFEE2E2), Color(0x33EF4444)), dk(Color(0xFFFEE2E2), Color(0x33EF4444)))), dk(NEG, Color(0xFFFCA5A5)))
                    kind == "kill" -> Chip("${r.kills} KILL" + (if (r.kills > 1) "S" else ""), "fa-solid fa-crosshairs", Brush.linearGradient(listOf(dk(Color(0xFFFEE2E2), Color(0x33EF4444)), dk(Color(0xFFFEE2E2), Color(0x33EF4444)))), dk(NEG, Color(0xFFFCA5A5)))
                    else -> Chip("PLAYED", "fa-solid fa-flag-checkered", Brush.linearGradient(listOf(dk(Color(0xFFE2E8F0), c.bgInput), dk(Color(0xFFE2E8F0), c.bgInput))), dk(Color(0xFF64748B), c.textMuted))
                }
            }
            when {
                r.refunded -> ResultBanner("loss", "fa-solid fa-rotate-left", "ENTRY REFUNDED", "Fee returned to your wallet", "+" + money(dbl(me["refundAmount"]).takeIf { it != 0.0 } ?: m.n("fee")))
                kind == "win" -> ResultBanner("win", "fa-solid fa-trophy", "CHAMPION · WINNER WINNER", m.s("winnerName").ifEmpty { me["appName"]?.toString() ?: "" }.ifEmpty { AppStore.user.s("name").ifEmpty { "You" } }, "+" + money(r.amount), winShine = true)
                r.place > 1 && r.amount > 0 -> ResultBanner("kill", "fa-solid fa-medal", "PODIUM FINISH", (if (r.place == 2) "2nd" else if (r.place == 3) "3rd" else "${r.place}th") + " Place", "+" + money(r.amount))
                kind == "kill" -> ResultBanner("kill", "fa-solid fa-crosshairs", if (perKill) "KILL REWARD" else "GOOD FIGHT", "${r.kills} Kill" + (if (r.kills > 1) "s" else "") + (if (perKill) " × " + money(m.n("prize")) else ""), if (r.amount > 0) "+" + money(r.amount) else "₹0")
                else -> ResultBanner("loss", "fa-solid fa-face-sad-tear", "NO KILLS · NO WIN", "Better luck next time", "₹0")
            }
            Box(Modifier.padding(horizontal = 14.dp)) { Box(Modifier.padding(bottom = 0.dp)) { WinnersStrip(m) } }
            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MxCell(Modifier.weight(1f), "Entry Paid", valueColor = NEG, value = "-" + money(r.fee), size = 0.95f)
                MxCell(Modifier.weight(1f), "Won", valueColor = POS, value = "+" + money(r.amount), size = 0.95f)
                MxCell(Modifier.weight(1f), "Net", valueColor = if (r.net > 0) POS else if (r.net < 0) NEG else c.textMain, value = (if (r.net >= 0) "+" else "-") + money(Math.abs(r.net)), size = 0.95f)
            }
            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MxCell(Modifier.weight(1f), "Slot", value = "#$slot")
                MxCell(Modifier.weight(1f), "Kills", value = r.kills.toString())
                MxCell(Modifier.weight(1f), "Type", value = typeLbl(m))
            }
            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrizeCell(Modifier.weight(1f), m)
                MxCell(Modifier.weight(1f), "Players", value = "$joined/$total")
                MxCell(Modifier.weight(1f), "Map", value = m.s("map").ifEmpty { "Bermuda" })
            }
            FfRow(me)
            Box(Modifier.padding(top = 12.dp)) { RoomBox(m, true, now) }
            Box(Modifier.padding(horizontal = 14.dp)) { RosterButton(m) }
        }
    }
}

@Composable
private fun CardShellH(borderColor: Color?, content: @Composable () -> Unit) = CardShell(borderColor = borderColor, content = content)

// ================================================================================== empty state

@Composable
fun MxEmpty(history: Boolean) {
    val c = FF.c
    val inf = rememberInfiniteTransition(label = "mxe")
    val fl by inf.animateFloat(0f, -8f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "fl")
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(500)) }
    Column(
        Modifier.fillMaxWidth().graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 16.dp.toPx() }.padding(horizontal = 30.dp, vertical = 50.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.graphicsLayer { translationY = fl.dp.toPx() }.padding(bottom = 0.dp).size(76.dp).clip(CircleShape).background(c.bgInput), contentAlignment = Alignment.Center) {
            FaIcon(if (history) "fa-solid fa-clock-rotate-left" else "fa-solid fa-ghost", rem(2.0).value.dp, Color(0xFF94A3B8))
        }
        FText(if (history) "No match history yet" else "No joined matches", size = rem(1.0), weight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
        FText(
            if (history) "Finished matches with your kills, winnings and room details will be saved here." else "Join a match from Home — your Room ID & password will show up here.",
            size = rem(0.82), color = c.textMuted, lineHeight = rem(0.82) * 1.5f, align = TextAlign.Center,
        )
    }
}
