package com.ffcashbattle.app.state

import com.ffcashbattle.app.ui.screens.match.jsNum
import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.ffcashbattle.app.data.Cfg
import com.ffcashbattle.app.data.Deposit
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.data.Msg
import com.ffcashbattle.app.data.NotifStore
import com.ffcashbattle.app.data.Verified
import com.ffcashbattle.app.data.Prefs
import com.ffcashbattle.app.data.Repo
import com.ffcashbattle.app.data.Sfx
import com.ffcashbattle.app.data.SysNotif
import com.ffcashbattle.app.data.sortTrx
import com.ffcashbattle.app.data.trxMs
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.floor
import kotlin.math.max

/** Bottom-nav pages, in the website's order. */
enum class Page { HOME, MATCHES, CHAT, RANK, WALLET }

/** One top-right notify card (ui.notify on the website). */
class NotifyCard(val id: Long, val type: String, val title: String, val message: String, val durationMs: Long)

/** A WebView screen opened over the app (Proofs -> https://ffcashbattle.in/proof, Terms, ...). */
class WebTarget(val url: String, val title: String)

class Flag(val on: Boolean, val note: String)

/**
 * Single source of truth for the whole app — the Kotlin twin of window.db / window.app / window.ui / window.live on the website.
 * Everything is Compose snapshot state, so any @Composable that reads a field re-draws when it changes.
 */
object AppStore {
    lateinit var app: Application
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    // ------------------------------------------------------------------ session
    var uid by mutableStateOf<String?>(null)
    var user by mutableStateOf(Doc.EMPTY)               // users/{uid}
    var userLoaded by mutableStateOf(false)
    val loggedIn: Boolean get() = uid != null

    val depositBalance: Double get() = if (user.has("depositBalance")) user.n("depositBalance") else user.n("balance")
    val withdrawBalance: Double get() = user.n("withdrawBalance")
    val balance: Double get() = depositBalance + withdrawBalance
    val joinedIds: List<String> get() = user.strList("joined_matches")
    val playerId: String get() = user.s("playerId").ifEmpty { (uid ?: "").take(7) }

    /** Saved-session hint (ffcb_hint) so the header shows the last balance instantly. */
    private var hintBal by mutableStateOf<Int?>(null)

    /** Header text: "Login" for guests, else floor(balance). */
    val headerCoins: String
        get() = if (uid == null) "Login" else floor(if (userLoaded) balance else (hintBal ?: balance)).toInt().toString()

    // ------------------------------------------------------------------ live data
    var matches by mutableStateOf<List<Doc>>(emptyList())       // newest MATCH_LIMIT matches, sorted by startTime ASC
    var matchesLoaded by mutableStateOf(false)
    var extraMatches by mutableStateOf<List<Doc>>(emptyList())  // my older matches loaded on demand (window.db._extra)
    var trx by mutableStateOf<List<Doc>>(emptyList())           // users/{uid}/transactions, newest first
    var trxLoaded by mutableStateOf(false)

    // ------------------------------------------------------------------ config (config/banner)
    var config by mutableStateOf(Doc.EMPTY)
    val banners: List<String>
        get() {
            val b = config.strList("banners").filter { it.isNotBlank() }
            return if (b.isNotEmpty()) b else listOfNotNull(config.s("url").takeIf { it.isNotBlank() })
        }
    var minWithdraw by mutableStateOf(10)
    var minDeposit by mutableStateOf(5)
    var flags by mutableStateOf<Map<String, Flag>>(emptyMap())
    var noticeText by mutableStateOf("")
    var whatsapp by mutableStateOf(Pair("", ""))    // (name, link)
    var telegram by mutableStateOf(Pair("", ""))
    var supportNumber by mutableStateOf("")

    fun minWd(): Int = max(3, minWithdraw)
    fun minDep(): Int = max(1, minDeposit)
    fun flagOff(k: String): Boolean = flags[k]?.on == false
    fun flagMsg(k: String): String {
        val f = flags[k]
        if (f != null && f.note.isNotEmpty()) return f.note
        return when (k) {
            "dep" -> "Deposit is temporarily disabled. Please try again later."
            "wd" -> "Withdrawals are temporarily disabled. Please try again later."
            "upi" -> "UPI withdrawal is off right now. Message admin on Telegram or WhatsApp support and they will switch it on, or use Google Play Gift Code."
            else -> "Google Play gift card is temporarily disabled. Please try again later."
        }
    }

    // ------------------------------------------------------------------ UI state
    var page by mutableStateOf(Page.HOME)
    var drawerOpen by mutableStateOf(false)
    var modal by mutableStateOf<String?>(null)          // "modal-deposit", "modal-settings", ... (ids as on the website)
    var modalArg by mutableStateOf<Any?>(null)          // optional payload (match Doc, transaction Doc, ...)
    var dark by mutableStateOf(false)
    var authOpen by mutableStateOf(false)               // login / register screen
    var authTab by mutableStateOf("login")              // login | register | forgot
    var web by mutableStateOf<WebTarget?>(null)         // full-screen WebView overlay
    var chatMode by mutableStateOf(false)               // true while the Chat page is open (global header hides there)
    var notifDot by mutableStateOf(false)               // red dot on the header bell
    var navChatDot by mutableStateOf(false)             // dot on the Chat tab
    var headerHidden by mutableStateOf(false)           // header slides away while scrolling down (header.js)
    var matchesTab by mutableStateOf("join")            // Matches page tab: "join" (My Matches) | "history"
    /** True when no modal / drawer / web overlay / login screen covers the page (child BackHandlers should use this in `enabled`). */
    val overlayFree: Boolean get() = modal == null && !drawerOpen && web == null && !authOpen && gameOpen == null
    var chatOpen by mutableStateOf(false)               // the full-screen chat app (opened from the Chat page's "Enter" card)
    var gameOpen by mutableStateOf<String?>(null)       // full-screen game: "coin" | "bomb" | "fruit" | null

    val notifies = mutableStateListOf<NotifyCard>()
    var toastMsg by mutableStateOf<String?>(null)
    private var toastJob: Job? = null
    private var notifyId = 0L

    // ------------------------------------------------------------------ hooks (set by the Auth module)
    /** Return false to treat the Firebase user as a guest (e.g. e-mail not verified yet — auth-state.js `_needsVerify`). */
    var authGate: (FirebaseUser) -> Boolean = { true }
    /** Called once after login, before the profile is read (auth `_ensureProfile`). */
    var onLogin: suspend (FirebaseUser) -> Unit = { }
    /** Called on logout. */
    var onLogout: () -> Unit = { }

    // ------------------------------------------------------------------ start
    private var liveUid: String? = null
    private var unsubUser: ListenerRegistration? = null
    private var unsubTrx: ListenerRegistration? = null
    private var unsubMatch: ListenerRegistration? = null

    fun start(application: Application) {
        app = application
        dark = Prefs.darkMode
        Msg.minWd = { minWd() }
        Msg.minDep = { minDep() }
        // saved-session hint
        try {
            val h = Prefs.str("ffcb_hint")
            if (h.isNotEmpty()) hintBal = Regex("\"bal\"\\s*:\\s*(\\d+)").find(h)?.groupValues?.get(1)?.toIntOrNull()
        } catch (_: Exception) { }
        scope.launch { fetchConfig() }
        Repo.auth.addAuthStateListener { fa -> onAuth(fa) }
    }

    private fun onAuth(fa: FirebaseAuth) {
        var u = fa.currentUser
        if (u != null && !authGate(u)) u = null
        if (u != null) {
            if (uid == u.uid && unsubUser != null) return
            uid = u.uid
            val me = u
            startLive(me.uid)
            scope.launch {
                try { onLogin(me) } catch (_: Exception) { }
                try { Repo.getDoc("users", me.uid)?.let { applyUserDoc(it) } } catch (_: Exception) { }
            }
        } else {
            stopLive()
            Prefs.remove("ffcb_hint"); hintBal = null
            uid = null; user = Doc.EMPTY; userLoaded = false; trx = emptyList(); trxLoaded = false; trxHooksFor = null
            notifDot = false
            onLogout()
        }
    }

    // ------------------------------------------------------------------ config
    suspend fun fetchConfig() {
        try {
            val d = Repo.getDoc("config", "banner") ?: Doc.EMPTY
            applyConfig(d)
        } catch (_: Exception) { }
    }

    /** Re-read the admin ON/OFF switches (called when Add Money / Withdraw opens). */
    fun refreshFlags() { scope.launch { try { Repo.getDoc("config", "banner")?.let { readFlags(it) } } catch (_: Exception) { } } }

    private fun applyConfig(d: Doc) {
        config = d
        minWithdraw = if (d.n("minWithdraw") >= 1) d.n("minWithdraw").toInt() else 10
        minDeposit = if (d.n("minDeposit") >= 1) d.n("minDeposit").toInt() else 5
        readFlags(d)
        supportNumber = d.s("supportNumber")
        whatsapp = Pair(d.s("whatsappName"), d.s("whatsappLink").ifEmpty { d.s("whatsappNumber") })
        telegram = Pair(d.s("telegramName"), d.s("telegramLink").ifEmpty { d.s("telegramChannel") })
        val n = d.s("notice").trim()
        if (n.isNotEmpty() && noticeText != n) {
            noticeText = n
            scope.launch { delay(2500); if (modal == null) openModal("modal-notice") }
        }
    }

    private fun readFlags(d: Doc) {
        flags = mapOf(
            "dep" to Flag(d["depositEnabled"] != false, d.s("depositNote")),
            "wd" to Flag(d["withdrawEnabled"] != false, d.s("withdrawNote")),
            "upi" to Flag(d["wdUpiEnabled"] != false, d.s("wdUpiNote")),
            "gp" to Flag(d["wdGpEnabled"] != false, d.s("wdGpNote")),
        )
    }

    // ------------------------------------------------------------------ user doc
    fun applyUserDoc(d: Doc) {
        user = d
        userLoaded = true
        try { if (uid != null) Prefs.put("ffcb_hint", "{\"uid\":\"$uid\",\"bal\":${floor(balance).toInt()}}") } catch (_: Exception) { }
    }

    // ------------------------------------------------------------------ realtime (port of js/core/live.js)
    private fun stopLive() {
        unsubUser?.remove(); unsubUser = null
        unsubTrx?.remove(); unsubTrx = null
        unsubMatch?.remove(); unsubMatch = null
        NotifStore.stop()
        Verified.stop()
        com.ffcashbattle.app.data.Chat.reset()
        liveUid = null
    }

    private fun startLive(id: String) {
        if (liveUid == id && unsubUser != null) return
        stopLive(); liveUid = id
        watchUser(id); watchTrx(id); watchMatches(id)
        NotifStore.start(id)
        Verified.start()
        // chat.js / chat-keep.js afterLogin: start chat in the background (red dots + message alerts), 1.5 s after login
        scope.launch { delay(1500); if (liveUid == id) { try { com.ffcashbattle.app.data.Chat.boot() } catch (_: Exception) { } } }
    }

    private fun watchUser(id: String) {
        var prevDep = 0.0; var prevWd = 0.0; var ready = false
        unsubUser = Repo.listenDoc("users", id) { d, fromCache ->
            if (liveUid != id || d == null) return@listenDoc
            val dep = if (d.has("depositBalance")) d.n("depositBalance") else d.n("balance")
            val wd = d.n("withdrawBalance")
            applyUserDoc(d)
            if (!ready) { prevDep = dep; prevWd = wd; if (!fromCache) ready = true; return@listenDoc }
            val dDep = Math.round((dep - prevDep) * 100) / 100.0
            val dWd = Math.round((wd - prevWd) * 100) / 100.0
            prevDep = dep; prevWd = wd
            if (dDep + dWd <= 0) return@listenDoc          // only when the total balance went up
            val L = Msg.live
            val m = when {
                dDep > 0 && dWd <= 0 -> L.depositCredited(dDep)
                dWd > 0 && dDep <= 0 -> L.balanceCredited(dWd)
                else -> L.depositCredited(dDep + dWd)
            }
            notify("success", m.title, m.body, sound = "notification", system = SysNotif.CH_WALLET)
            notifDot = true
        }
    }

    private var trxHooksFor: String? = null

    private fun watchTrx(id: String) {
        val seen = HashMap<String, String>()
        var first = true
        unsubTrx = Repo.listenCol("users", id, "transactions") { docs, fromCache ->
            if (liveUid != id) return@listenCol
            val sorted = sortTrx(docs)
            trx = sorted; trxLoaded = true
            if (!fromCache && trxHooksFor != id) {
                trxHooksFor = id
                // wallet.js: deposit / withdraw records older than 30 days are removed (the History sheet shows 30 days, the wallet page 7);
                // pending UPI deposits are re-checked in the background
                val cutoff = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000
                scope.launch {
                    for (t in sorted) {
                        val ty = t.s("type")
                        val ms = t.trxMs()
                        if ((ty == "deposit" || ty == "withdraw") && ms > 0 && ms < cutoff) { try { Repo.delete(listOf("users", id, "transactions", t.id)) } catch (_: Exception) { } }
                    }
                }
                Deposit.resumePending(id)
            }
            for (t in sorted) {
                val st = Msg.normStatus(t["status"])
                val was = seen[t.id]
                seen[t.id] = st
                if (first || (was == null && st != "success")) continue
                if (t.s("type").lowercase() == "withdraw" && st == "success" && was != "success") {
                    val m = Msg.live.withdrawPaid(t)
                    notify("success", m.title, m.body, sound = "withdrawal", system = SysNotif.CH_WALLET)
                    notifDot = true
                }
            }
            if (first && !fromCache) first = false
        }
    }

    private fun startMs(m: Doc): Long = m.ms("startTime")

    private var mineAt = 0L

    /**
     * `app.loadMyCompleted`: my older matches (outside the newest MATCH_LIMIT) are fetched only when History opens —
     * at most once per 5 minutes and 20 reads. Returns true when something new was added.
     */
    suspend fun loadMyCompleted(): Boolean {
        val now = System.currentTimeMillis()
        if (mineAt != 0L && now - mineAt < 300_000L) return false
        mineAt = now
        val have = matches.map { it.id }.toHashSet()
        val ids = joinedIds.filter { it !in have }.takeLast(20)
        if (ids.isEmpty()) return false
        val got = kotlinx.coroutines.coroutineScope {
            ids.map { id -> async { try { Repo.getDoc("matches", id) } catch (_: Exception) { null } } }.awaitAll()
        }.filterNotNull()
        if (got.isEmpty()) return false
        extraMatches = extraMatches.filter { x -> got.none { it.id == x.id } } + got
        val cur = matches.map { it.id }.toHashSet()
        matches = (matches + got.filter { it.id !in cur }).sortedBy { startMs(it) }
        return true
    }

    private fun watchMatches(id: String) {
        class Known(val room: Boolean, val status: String)
        val known = HashMap<String, Known>()
        var first = true
        unsubMatch = Repo.listenCol("matches", q = { it.orderBy("startTime", Query.Direction.DESCENDING).limit(Cfg.MATCH_LIMIT.toLong()) }) { docs, fromCache ->
            if (liveUid != id) return@listenCol
            val have = docs.map { it.id }.toHashSet()
            val list = (docs + extraMatches.filter { it.id !in have }).sortedBy { startMs(it) }
            matches = list; matchesLoaded = true
            val joined = joinedIds
            for (m in list) {
                val room = m.s("roomId").isNotEmpty() && m.s("roomPass").isNotEmpty()
                val prev = known[m.id]
                known[m.id] = Known(room, m.s("status"))
                if (first || prev == null || m.id !in joined) continue
                val title = m.s("title").ifEmpty { "Your match" }
                if (room && !prev.room && m.s("status") != "completed" && m.s("status") != "live") {
                    notify("info", "Room ID & Password Ready", "$title — open My Matches to copy.", sound = "notification", system = SysNotif.CH_MATCH)
                }
                if (m.s("status") == "completed" && prev.status != "completed") {
                    val me = m.maps("participants").firstOrNull { it["uid"] == id } ?: emptyMap()
                    val won = m.s("winnerUid") == id
                    val amt = if (me["winAmount"] != null) Msg.num(me["winAmount"]) else if (won) m.n("prize") else 0.0
                    val amtS = "₹" + (if (amt % 1.0 == 0.0) amt.toLong().toString() else amt.toString())
                    val kills = ((me["kills"] as? Number)?.toInt() ?: 0)
                    val mt = m.s("title").ifEmpty { "the match" }
                    if (won) notify("success", "Winner Winner! 🏆", "You won $amtS in $mt.", sound = "notification", system = SysNotif.CH_MATCH)
                    else if (amt > 0) notify("success", "Match Result", "You earned $amtS ($kills kills) in $mt.", sound = "notification", system = SysNotif.CH_MATCH)
                    else notify("info", "Match Finished", m.s("title").ifEmpty { "Match" } + " result is in History.")
                }
            }
            if (first && !fromCache) first = false
        }
    }

    /** First load for guests (no realtime listener running). */
    fun loadMatchesOnce() {
        if (matchesLoaded || liveUid != null) return
        scope.launch {
            try {
                val l = Repo.getCol("matches") { it.orderBy("startTime", Query.Direction.DESCENDING).limit(Cfg.MATCH_LIMIT.toLong()) }
                matches = l.sortedBy { startMs(it) }; matchesLoaded = true
            } catch (_: Exception) { }
        }
    }

    // ------------------------------------------------------------------ UI helpers (window.ui / window.nav / window.app)
    fun toast(msg: String) {
        toastMsg = msg
        toastJob?.cancel()
        toastJob = scope.launch { delay(3000); toastMsg = null }
    }

    /**
     * ui.notify(): top-right stackable card (auto-hides after 6s). [system] also posts a real Android notification
     * (status bar / notification shade) on that channel when the OS permission is granted.
     */
    fun notify(type: String = "success", title: String, message: String, durationMs: Long = 6000, sound: String? = null, system: String? = null) {
        val c = NotifyCard(++notifyId, type, title, message, durationMs)
        while (notifies.size >= 4) notifies.removeAt(0)
        notifies.add(c)
        if (sound != null) Sfx.play(sound)
        if (system != null) SysNotif.post(app, system, title, message)
        scope.launch { delay(durationMs + 400); notifies.remove(c) }
    }

    fun dismissNotify(c: NotifyCard) { notifies.remove(c) }

    fun openModal(id: String, arg: Any? = null) {
        if (id == "modal-deposit" || id == "modal-withdraw") refreshFlags()
        modalArg = arg; modal = id
    }

    fun closeModal() { modal = null; modalArg = null }

    fun toggleDrawer() { drawerOpen = !drawerOpen }

    fun goto(p: Page) {
        page = p
        chatMode = p == Page.CHAT
        headerHidden = false
    }

    /** window.app.checkLogin(cb): run cb when logged in, else show the login screen. */
    // ------------------------------------------------------------------ payment verify overlay + wallet coin animation (pages/loading, walletfx)
    /** `dep-verify-overlay`. mode: loading | success | pending | fail. */
    class VerifyOv(val title: String, val sub: String, val mode: String, val amount: String? = null, val ref: String? = null, val refLabel: String = "UTR / Txn ID", val tick: Int = 0)
    var verifyOv by mutableStateOf<VerifyOv?>(null)
    var verifyCountdown by mutableStateOf(10)
    fun showVerify(title: String, sub: String, mode: String = "loading", amount: Any? = null, ref: String? = null) {
        val amt = when (amount) { null -> null; is Double -> jsNum(amount); else -> amount.toString() }
        verifyOv = VerifyOv(title, sub, mode, amt, ref, tick = (verifyOv?.tick ?: 0) + 1)
    }
    fun hideVerify() { verifyOv = null }

    /** `walletfx.deposit / withdraw`: ~3 s full-screen golden-coin animation. */
    class WalletFx(val kind: String, val amount: Double, val newBal: Double, val title: String? = null, val sub: String? = null, val id: Long = System.nanoTime())
    var walletFx by mutableStateOf<WalletFx?>(null)
    fun playWalletFx(kind: String, amount: Double, newBal: Double, title: String? = null, sub: String? = null) { walletFx = WalletFx(kind, amount, newBal, title, sub) }

    // ------------------------------------------------------------------ anti-spam (app.rateLimit / app.endAction)
    private val lastAction = HashMap<String, Long>()
    private val busyActions = HashSet<String>()

    /** Per-action cooldown (default 60 s) + in-flight lock. Returns false (and toasts) when the action must not run now. */
    fun rateLimit(act: String, ms: Long = 60_000L): Boolean {
        if (act in busyActions) { toast("Request already in progress..."); return false }
        val wait = ms - (System.currentTimeMillis() - (lastAction[act] ?: 0L))
        if (wait > 0) { toast("Please wait ${Math.ceil(wait / 1000.0).toInt()}s before trying again"); return false }
        busyActions.add(act)
        return true
    }

    fun endAction(act: String, success: Boolean) {
        busyActions.remove(act)
        if (success) lastAction[act] = System.currentTimeMillis()
    }

    /** `app.openJoin`: a match can only be joined once, never after it started, never when full. */
    fun openJoin(m: Doc) {
        if (m.id in joinedIds) { toast("You have already joined this match."); return }
        if (m.s("status") == "live") { toast("This match has already started. Please try the next match."); return }
        val total = m.i("total").takeIf { it > 0 } ?: 48
        if (m.i("joined") >= total) { toast("This match is full. Please try another match."); return }
        openModal("modal-join", m)
    }

    fun checkLogin(cb: () -> Unit) { if (loggedIn) cb() else { authTab = "login"; authOpen = true } }

    fun toggleDark() { dark = !dark; Prefs.darkMode = dark }

    fun copy(text: String) {
        val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("ffcb", text))
        toast("Copied!")
    }

    /** Open any link in the browser (external app). */
    fun openUrl(url: String) {
        try {
            app.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) { toast("Could not open link") }
    }

    /** Open a page of the website inside the app (full-screen WebView). */
    fun openWeb(url: String, title: String = "") { web = WebTarget(url, title) }

    /** Proofs live on the website: https://ffcashbattle.in/proof (optionally ?share=<transactionId>). */
    fun openProof(shareTrxId: String? = null) {
        openWeb(if (shareTrxId.isNullOrEmpty()) Cfg.PROOF_URL else Cfg.PROOF_URL + "?share=" + Uri.encode(shareTrxId), "Proofs")
    }

    fun openWhatsApp() {
        val link = whatsapp.second
        openUrl(if (link.isBlank()) Cfg.WA_FALLBACK else if (link.startsWith("http")) link else "https://wa.me/" + link.filter { it.isDigit() })
    }

    fun openTelegram() {
        val link = telegram.second
        openUrl(if (link.isBlank()) Cfg.TG_FALLBACK else if (link.startsWith("http")) link else "https://t.me/" + link.removePrefix("@"))
    }

    fun logout() {
        try { Repo.auth.signOut() } catch (_: Exception) { }
    }
}
