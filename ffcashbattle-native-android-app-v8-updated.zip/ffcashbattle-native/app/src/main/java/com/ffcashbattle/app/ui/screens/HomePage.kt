package com.ffcashbattle.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ffcashbattle.app.data.Doc
import com.ffcashbattle.app.data.GameArt
import com.ffcashbattle.app.data.Repo
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.ui.comp.BtnMain
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.comp.tap
import com.ffcashbattle.app.ui.screens.match.MatchCard
import com.ffcashbattle.app.ui.screens.match.MatchSkeleton
import com.ffcashbattle.app.ui.screens.match.Skel
import com.ffcashbattle.app.ui.screens.match.rememberNow
import com.ffcashbattle.app.ui.screens.match.shimmerBrush
import com.ffcashbattle.app.ui.shell.LocalPagePadding
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.Inter
import com.ffcashbattle.app.ui.theme.rem
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Home page state that survives page switches (window.app.selectedCategory / matchView / searchQ). */
object HomeState {
    var category by mutableStateOf("All")
    var queryInput by mutableStateOf("")
    var query by mutableStateOf("")
    var view by mutableStateOf("upcoming")      // "upcoming" | "completed"
    var cats by mutableStateOf<List<String>?>(null)
}

private fun numStr(d: Double): String = if (d % 1.0 == 0.0) d.toLong().toString() else d.toString()

/** `renderMatches` filtering/sorting. */
private fun visibleMatches(all: List<Doc>): List<Doc> {
    var data = all
    if (HomeState.category != "All") data = data.filter { m -> m.s("type").ifEmpty { m.s("modeLabel") } == HomeState.category }
    val completed = HomeState.view == "completed"
    data = data.filter { m -> if (completed) m.s("status") == "completed" else m.s("status") != "completed" }
    data = if (completed) data.reversed() else data.sortedByDescending { if (it.b("pinned")) 1 else 0 }
    val sq = HomeState.query.trim().lowercase().removePrefix("#")
    if (sq.isNotEmpty()) {
        data = data.filter { m ->
            val feeS = if (m["fee"] != null) "fee " + numStr(m.n("fee")) else ""
            val prizeS = if (m["prize"] != null) "prize " + numStr(m.n("prize")) else ""
            listOf(
                m.s("title"), m.s("map"), m.s("type"), m.s("modeLabel"), m.s("mode"), m.s("modeShort"), m.s("subMode"),
                m.s("teamMode"), m.s("matchCode"), m.id.take(8), feeS, prizeS,
            ).any { it.lowercase().contains(sq) }
        }
    }
    return data
}

@Composable
fun HomePage() {
    val c = FF.c
    val listState = rememberLazyListState()
    val now by rememberNow()

    LaunchedEffect(Unit) {
        AppStore.loadMatchesOnce()
        if (HomeState.cats == null) {
            val names = try { Repo.getCol("categories").map { it.s("name") }.filter { it.isNotEmpty() } } catch (_: Exception) { null }
            if (names != null) HomeState.cats = listOf("All") + (if (names.isEmpty()) listOf("Battle Royale", "Clash Squad", "Lone Wolf") else names)
        }
    }
    // debounce the search box (180 ms) and scroll the search bar into view on the first keystroke
    LaunchedEffect(HomeState.queryInput) {
        val wasEmpty = HomeState.query.trim().isEmpty()
        delay(180)
        HomeState.query = HomeState.queryInput
        if (wasEmpty && HomeState.queryInput.trim().isNotEmpty()) { try { listState.animateScrollToItem(1) } catch (_: Exception) { } }
    }

    val data = visibleMatches(AppStore.matches)
    val searching = HomeState.query.trim().isNotEmpty()

    LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = LocalPagePadding.current) {
        item(key = "banner") { HomeBanner() }
        item(key = "search") { HomeSearch() }
        if (searching) item(key = "meta") {
            Row(Modifier.padding(start = 22.dp, end = 22.dp, bottom = 10.dp, top = (-2).dp.coerceAtLeast(0.dp)), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                FaIcon("fa-solid fa-crosshairs", rem(0.78).value.dp, c.primary)
                FText("${data.size} match" + (if (data.size == 1) "" else "es") + " for ", size = rem(0.78), weight = FontWeight.Bold, color = c.textMuted)
                FText(HomeState.query.trim().replace(Regex("[<>&\"']"), ""), size = rem(0.78), weight = FontWeight.Bold, color = c.textMain, maxLines = 1)
            }
        }
        item(key = "chips") { CategoryChips() }
        item(key = "seg") { MatchViewSwitch() }
        item(key = "gap") { Box(Modifier.height(15.dp)) }
        if (!AppStore.matchesLoaded) {
            item(key = "skeleton") { MatchSkeleton() }
        } else if (data.isEmpty()) {
            item(key = "empty") { EmptyMatches(searching) }
        } else {
            itemsIndexed(data, key = { _, m -> m.id }) { i, m -> MatchCard(m, i, now) }
        }
    }
}

// ================================================================================== banner slider

@Composable
private fun HomeBanner() {
    val c = FF.c
    val urls = AppStore.banners
    val loaded = AppStore.config.id.isNotEmpty()
    var gaveUp by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(4000); gaveUp = true }
    val n = if (urls.isEmpty()) 1 else urls.size
    val pager = rememberPagerState(pageCount = { n })
    val shape = RoundedCornerShape(16.dp)

    // Autoplay every 4.5 s. The effect is keyed on settledPage, which only changes AFTER a slide has come to rest.
    // (It used to be keyed on currentPage: that flips at the half-way point of the slide animation, so the effect restarted,
    // cancelled the animation in the middle and the banner stayed stuck half-way between two slides.)
    val settled = pager.settledPage
    LaunchedEffect(settled, n) {
        if (n < 2) return@LaunchedEffect
        while (true) {
            delay(4500)
            if (pager.isScrollInProgress) continue   // finger on the banner / still flinging -> try again next round
            pager.animateScrollToPage((pager.currentPage + 1) % n, animationSpec = tween(600, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)))
        }
    }
    // Never rest between two slides (like the website's scroll-snap): if any scroll ends off-centre, glide to the nearest slide.
    LaunchedEffect(pager) {
        snapshotFlow { pager.isScrollInProgress }.collect { moving ->
            if (!moving && Math.abs(pager.currentPageOffsetFraction) > 0.001f) {
                try { pager.animateScrollToPage(pager.currentPage, animationSpec = tween(250)) } catch (_: Exception) { }
            }
        }
    }

    Box(
        Modifier.padding(20.dp).fillMaxWidth().height(160.dp)
            .boxShadow(25.dp, Color(0x594F46E5), shape).clip(shape).background(c.bgInput),
    ) {
        if (!loaded && !gaveUp) {
            Box(Modifier.fillMaxSize().background(shimmerBrush()))
        } else {
            HorizontalPager(pager, Modifier.fillMaxSize()) { page ->
                BannerSlide(if (urls.isEmpty()) null else urls[page], active = pager.currentPage == page)
            }
            if (n > 1) {
                Box(Modifier.align(Alignment.TopEnd).padding(top = 10.dp, end = 10.dp).clip(RoundedCornerShape(20.dp)).background(Color(0x73000000)).padding(horizontal = 9.dp, vertical = 3.dp)) {
                    FText("${pager.currentPage + 1}/$n", size = rem(0.7), weight = FontWeight.Bold, color = Color.White)
                }
                Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 9.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    for (i in 0 until n) {
                        val on = pager.currentPage == i
                        val w by animateDpAsState(if (on) 20.dp else 7.dp, tween(350, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)), label = "dot")
                        Box(
                            Modifier.width(w).height(7.dp).clip(RoundedCornerShape(10.dp)).background(if (on) Color.White else Color(0x8CFFFFFF))
                                .tap { goPage(pager, i) },
                        )
                    }
                }
            }
        }
    }
}

private fun goPage(pager: androidx.compose.foundation.pager.PagerState, i: Int) {
    AppStore.scope.launch { pager.animateScrollToPage(i, animationSpec = tween(600, easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f))) }
}

@Composable
private fun BannerSlide(url: String?, active: Boolean) {
    var err by remember(url) { mutableStateOf(false) }
    val zoom = remember(url) { Animatable(1f) }
    LaunchedEffect(active) {
        if (active) { zoom.snapTo(1f); zoom.animateTo(1.08f, tween(6000, easing = LinearOutSlowInEasing)) } else zoom.snapTo(1f)
    }
    Box(Modifier.fillMaxSize()) {
        if (url == null || err) {
            // .hb-default / .hb-err : hero art + dark gradient (+ title when there is no banner at all)
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF4F46E5), Color(0xFFF43F5E)))))
            Image(painterResource(GameArt.hero()), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color.Transparent, 0.35f to Color(0x000A0828), 1f to Color(0xBF0A0828))))
            if (url == null) {
                Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    FText("FF Cash Battle", size = rem(1.3), weight = FontWeight.Black, color = Color.White, letterSpacing = 0.5.sp, align = TextAlign.Center)
                    FText("Join • Play • Win Real Cash", size = rem(0.8), color = Color.White.copy(alpha = 0.9f), align = TextAlign.Center)
                }
            }
        } else {
            AsyncImage(
                url, "Banner", Modifier.fillMaxSize().graphicsLayer { scaleX = zoom.value; scaleY = zoom.value },
                contentScale = ContentScale.Crop, onError = { err = true },
            )
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color.Transparent, 0.45f to Color.Transparent, 1f to Color(0x59000000))))
        }
    }
}

// ================================================================================== search

@Composable
private fun HomeSearch() {
    val c = FF.c
    val focus = remember { FocusRequester() }
    val fm = LocalFocusManager.current
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(16.dp)
    val ic by animateFloatAsState(if (focused) 1f else 0f, tween(300), label = "ic")
    Row(
        Modifier.padding(start = 20.dp, end = 20.dp, bottom = 12.dp).fillMaxWidth()
            .graphicsLayer { translationY = -1.dp.toPx() * ic }
            .boxShadow(10.dp, if (c.isDark) Color(0x59000000) else Color(0x0D0F172A), shape)
            .clip(shape).background(c.bgCard)
            .then(
                if (focused) Modifier.drawBehind {
                    drawRoundRect(c.primary.copy(alpha = 0.18f), topLeft = Offset(-4.dp.toPx(), -4.dp.toPx()), size = androidx.compose.ui.geometry.Size(size.width + 8.dp.toPx(), size.height + 8.dp.toPx()), cornerRadius = androidx.compose.ui.geometry.CornerRadius(20.dp.toPx()))
                } else Modifier,
            )
            .border(1.5.dp, if (focused) c.primary else if (c.isDark) Color(0x38949FB8) else c.border, shape),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.padding(start = 16.dp, end = 4.dp).graphicsLayer { val s = 1f + 0.15f * ic; scaleX = s; scaleY = s; rotationZ = -8f * ic }) {
            FaIcon("fa-solid fa-magnifying-glass", rem(1.0).value.dp, if (focused) c.primary else c.textMuted)
        }
        Box(Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 14.dp)) {
            if (HomeState.queryInput.isEmpty()) FText("Search matches, mode, map or #ID…", size = rem(0.92), weight = FontWeight.Medium, color = c.textMuted, maxLines = 1)
            BasicTextField(
                value = HomeState.queryInput, onValueChange = { HomeState.queryInput = it },
                modifier = Modifier.fillMaxWidth().focusRequester(focus).onFocusChanged { focused = it.isFocused },
                singleLine = true,
                textStyle = TextStyle(color = c.textMain, fontSize = rem(0.92), fontWeight = FontWeight.SemiBold, fontFamily = Inter),
                cursorBrush = SolidColor(c.primary),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { fm.clearFocus() }),
            )
        }
        if (HomeState.queryInput.isNotEmpty()) {
            Box(
                Modifier.padding(end = 8.dp).size(30.dp).clip(CircleShape).background(if (c.isDark) Color(0x29949FB8) else c.bgInput)
                    .press(0.85f) { HomeState.queryInput = ""; HomeState.query = ""; focus.requestFocus() },
                contentAlignment = Alignment.Center,
            ) { FaIcon("fa-solid fa-xmark", rem(0.9).value.dp, c.textMuted) }
        }
    }
}

// ================================================================================== chips + view switch

@Composable
private fun CategoryChips() {
    val c = FF.c
    val cats = HomeState.cats
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(start = 20.dp, end = 20.dp, bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (cats == null) {
            Skel(Modifier.size(width = 60.dp, height = 35.dp), 50.dp)
            Skel(Modifier.size(width = 80.dp, height = 35.dp), 50.dp)
            Skel(Modifier.size(width = 70.dp, height = 35.dp), 50.dp)
        } else {
            for (cat in cats) {
                val on = HomeState.category == cat
                val shape = RoundedCornerShape(50.dp)
                Box(
                    Modifier.press(0.965f) { HomeState.category = cat }
                        .then(if (on && c.isDark) Modifier.boxShadow(16.dp, Color(0x666366F1), shape) else Modifier)
                        .clip(shape)
                        .background(if (on) Brush.linearGradient(listOf(c.primary, Color(0xFF7C3AED))) else Brush.linearGradient(listOf(c.bgCard, c.bgCard)))
                        .border(1.dp, if (on) Color.Transparent else c.border, shape)
                        .padding(horizontal = 18.dp, vertical = 8.dp),
                ) { FText(cat, weight = FontWeight.SemiBold, color = if (on) Color.White else c.textMuted, maxLines = 1, softWrap = false) }
            }
        }
    }
}

@Composable
private fun MatchViewSwitch() {
    val c = FF.c
    val completed = HomeState.view == "completed"
    BoxWithConstraints(Modifier.padding(start = 20.dp, end = 20.dp, top = 6.dp, bottom = 4.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.bgInput).padding(4.dp)) {
        val half = maxWidth / 2
        val x by animateDpAsState(if (completed) half else 0.dp, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow), label = "thumb")
        Box(
            Modifier.offset(x = x).width(half).height(40.dp)
                .boxShadow(10.dp, Color(0x14000000), RoundedCornerShape(11.dp)).clip(RoundedCornerShape(11.dp)).background(if (c.isDark) c.bgCard else Color.White),
        )
        Row(Modifier.fillMaxWidth()) {
            for ((vk, label, icon) in listOf(Triple("upcoming", "Upcoming", "fa-solid fa-bolt"), Triple("completed", "Completed", "fa-solid fa-trophy"))) {
                val on = HomeState.view == vk
                Row(
                    Modifier.weight(1f).press(0.965f) { HomeState.view = vk }.padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically,
                ) {
                    FaIcon(icon, rem(0.85).value.dp, if (on) c.primary else c.textMuted)
                    FText(label, size = rem(0.85), weight = FontWeight.Bold, color = if (on) c.primary else c.textMuted)
                }
            }
        }
    }
}

// ================================================================================== empty state

@Composable
private fun EmptyMatches(searching: Boolean) {
    val c = FF.c
    val inf = rememberInfiniteTransition(label = "empty")
    val fl by inf.animateFloat(0f, -8f, infiniteRepeatable(tween(2000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "float")
    val completed = HomeState.view == "completed"
    Column(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 30.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Image(
            painterResource(GameArt.empty(if (searching) "search" else "matches")), null,
            Modifier.fillMaxWidth(0.7f).widthIn(max = 260.dp).padding(bottom = 6.dp).graphicsLayer { translationY = fl.dp.toPx() },
            contentScale = ContentScale.Fit,
        )
        FText(if (searching) "No match found" else if (completed) "No completed matches yet" else "No matches right now", size = rem(1.05), weight = FontWeight.Bold, align = TextAlign.Center)
        FText(
            if (searching) "Try a different name, mode, map or match ID." else "New battles are added often — check back soon!",
            size = rem(0.82), color = c.textMuted, lineHeight = rem(0.82) * 1.5f, align = TextAlign.Center, modifier = Modifier.widthIn(max = 280.dp),
        )
        if (searching) {
            Box(Modifier.padding(top = 14.dp).widthIn(max = 220.dp).fillMaxWidth()) {
                BtnMain("Clear search", { HomeState.queryInput = ""; HomeState.query = "" }, Modifier.fillMaxWidth())
            }
        }
    }
}
