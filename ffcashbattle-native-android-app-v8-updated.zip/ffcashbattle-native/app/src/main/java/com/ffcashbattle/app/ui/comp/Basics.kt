package com.ffcashbattle.app.ui.comp

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ffcashbattle.app.R
import com.ffcashbattle.app.data.GameArt
import com.ffcashbattle.app.data.Img
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.Inter
import com.ffcashbattle.app.ui.theme.rem

// ============================================================ taps
/** Click without a ripple (the website has no ripples). */
fun Modifier.tap(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, enabled = enabled, onClick = onClick)
}

/** Click + the website's `:active { transform:scale(.965) }` press effect. */
fun Modifier.press(scale: Float = 0.965f, enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed && enabled) scale else 1f, tween(120), label = "press")
    graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

// ============================================================ text
/**
 * The app's Text. Defaults = the website body text (Inter 14px). Sizes: use rem(0.9) for CSS "0.9rem" or 13.sp for "13px".
 * Emoji are drawn as the website's PNG pictures automatically.
 */
@Composable
fun FText(
    text: String,
    modifier: Modifier = Modifier,
    size: TextUnit = rem(1.0),
    weight: FontWeight = FontWeight.Normal,
    color: Color = FF.c.textMain,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip,
    align: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    mono: Boolean = false,
    italic: Boolean = false,
    underline: Boolean = false,
    brush: Brush? = null,
    softWrap: Boolean = true,
    /** true for names / titles: a `(cs)` in the text becomes the CS badge picture and empty `()` are dropped (see [NameTag]). */
    tags: Boolean = false,
) {
    val ctx = LocalContext.current
    var style = TextStyle(
        color = color,
        fontSize = size,
        fontWeight = weight,
        fontFamily = if (mono) FontFamily.Monospace else Inter,
        fontStyle = if (italic) FontStyle.Italic else FontStyle.Normal,
        textDecoration = if (underline) TextDecoration.Underline else TextDecoration.None,
        lineHeight = lineHeight,
        letterSpacing = letterSpacing,
        textAlign = align ?: TextAlign.Unspecified,
    )
    if (brush != null) style = style.copy(brush = brush, alpha = 1f)
    val built = remember(text, tags) { (if (tags) NameTag.build(ctx, text) else null) ?: Emoji.build(ctx, text) }
    if (built == null) {
        BasicText(text, modifier, style, overflow = overflow, softWrap = softWrap, maxLines = maxLines)
    } else {
        BasicText(built.text, modifier, style, overflow = overflow, softWrap = softWrap, maxLines = maxLines, inlineContent = built.inline)
    }
}

// ============================================================ icons / images
/**
 * Font Awesome icon (the same glyphs the website uses). name: "fa-solid fa-wallet" | "fa-regular fa-bell" | "fa-brands fa-whatsapp" | "wallet".
 * size = the CSS font-size (icon height = 1em).
 */
@Composable
fun FaIcon(name: String, size: Dp = 14.dp, tint: Color = FF.c.textMain, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val id = remember(name) { faRes(ctx, name) }
    if (id == 0) { Spacer(modifier.size(size)); return }
    val painter = painterResource(id)
    val sz = painter.intrinsicSize
    val ar = if (sz.isSpecified && sz.height > 0f) sz.width / sz.height else 1f
    Image(painter, null, modifier.size(width = size * ar, height = size), colorFilter = ColorFilter.tint(tint), contentScale = ContentScale.Fit)
}

private fun faRes(ctx: android.content.Context, raw: String): Int {
    val toks = raw.trim().split(Regex("\\s+"))
    var style = "solid"
    var n = toks.last()
    for (t in toks) { if (t == "fa-regular" || t == "far") style = "regular"; if (t == "fa-brands" || t == "fab") style = "brands" }
    if (n.startsWith("fa-")) n = n.removePrefix("fa-")
    val base = n.replace('-', '_')
    val res = when (style) { "regular" -> "fa_r_$base"; "brands" -> "fa_b_$base"; else -> "fa_$base" }
    var id = ctx.resources.getIdentifier(res, "drawable", ctx.packageName)
    if (id == 0 && style == "regular") id = ctx.resources.getIdentifier("fa_$base", "drawable", ctx.packageName)
    return id
}

/** Drawable by resource name (e.g. "ff_coin", "wallet_deposit", "art_hero"). */
@Composable
fun NamedImage(name: String, modifier: Modifier = Modifier, contentScale: ContentScale = ContentScale.Fit, tint: Color? = null) {
    val ctx = LocalContext.current
    val id = remember(name) { ctx.resources.getIdentifier(name, "drawable", ctx.packageName) }
    if (id != 0) ResImage(id, modifier, contentScale, tint)
}

@Composable
fun ResImage(@DrawableRes id: Int, modifier: Modifier = Modifier, contentScale: ContentScale = ContentScale.Fit, tint: Color? = null) {
    Image(painterResource(id), null, modifier, contentScale = contentScale, colorFilter = tint?.let { ColorFilter.tint(it) })
}

/** The FF coin picture (.coin-ico: 18px, .xs: 15px). */
@Composable
fun Coin(size: Dp = 18.dp, modifier: Modifier = Modifier) {
    Image(painterResource(R.drawable.ff_coin), null, modifier.size(size), contentScale = ContentScale.Fit)
}

/** coinHtml(v): the coin picture followed by the value (.coin-ico.xs: 15px, margin -2px 3px 0 0). */
@Composable
fun CoinAmount(
    value: String,
    size: TextUnit = rem(1.0),
    weight: FontWeight = FontWeight.Bold,
    color: Color = FF.c.textMain,
    coinSize: Dp = 15.dp,
    modifier: Modifier = Modifier,
) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Coin(coinSize)
        Spacer(Modifier.width(3.dp))
        FText(value, size = size, weight = weight, color = color)
    }
}

/**
 * Round avatar: the player's photo (url or data: URI) else the generated art for [seed].
 */
@Composable
fun Avatar(photo: String?, seed: String, size: Dp, modifier: Modifier = Modifier, borderColor: Color? = null, borderWidth: Dp = 2.dp) {
    val fallback = painterResource(GameArt.avatar(seed))
    var m = modifier.size(size)
    if (borderColor != null) m = m.border(borderWidth, borderColor, CircleShape)
    m = m.clip(CircleShape)
    if (photo.isNullOrBlank()) Image(fallback, null, m, contentScale = ContentScale.Crop)
    else if (photo.startsWith("data:")) {
        val bmp = remember(photo) { Img.fromDataUrl(photo) }
        if (bmp != null) Image(bmp, null, m, contentScale = ContentScale.Crop) else Image(fallback, null, m, contentScale = ContentScale.Crop)
    } else AsyncImage(model = photo, contentDescription = null, modifier = m, contentScale = ContentScale.Crop, placeholder = fallback, error = fallback)
}

// ============================================================ shadows / gradients
/** Approximation of CSS box-shadow: `0 <y> <blur> <color>`. */
fun Modifier.boxShadow(blur: Dp, color: Color, shape: Shape = androidx.compose.ui.graphics.RectangleShape): Modifier =
    this.shadow(elevation = blur / 2, shape = shape, clip = false, ambientColor = color.copy(alpha = color.alpha * 0.6f), spotColor = color)

/** linear-gradient(135deg, a, b) (top-left -> bottom-right). */
fun gradient135(vararg colors: Color): Brush = Brush.linearGradient(colors.toList())

// ============================================================ buttons
/**
 * .btn-main — full width, 135deg primary gradient, radius 12, padding 14, 700 weight, shadow, shine sweep.
 * small = .btn-sm (padding 8x16, 0.8rem, radius 8).
 */
@Composable
fun BtnMain(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    small: Boolean = false,
    shine: Boolean = true,
    colors: List<Color>? = null,
    content: @Composable RowScope.() -> Unit,
) {
    val c = FF.c
    val shape = RoundedCornerShape(if (small) 8.dp else 12.dp)
    val bg = if (enabled) Brush.linearGradient(colors ?: listOf(c.primary, c.primaryDark)) else SolidColor(Color(0xFFCBD5E1))
    val inf = rememberInfiniteTransition(label = "shine")
    val sh by inf.animateFloat(
        initialValue = -1.2f, targetValue = 2.2f,
        animationSpec = infiniteRepeatable(keyframes { durationMillis = 3600; -1.2f at 0 using LinearEasing; 2.2f at 2160 using LinearEasing; 2.2f at 3600 }, RepeatMode.Restart),
        label = "shineX",
    )
    Row(
        modifier
            .press(0.96f, enabled, onClick)
            .then(if (enabled) Modifier.boxShadow(15.dp, Color(0x664F46E5), shape) else Modifier)
            .clip(shape)
            .background(bg)
            .then(if (enabled && shine) Modifier.drawBehind {
                val w = size.width * 0.4f
                val x = size.width * sh
                drawRect(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.28f), Color.Transparent), startX = x, endX = x + w), topLeft = Offset(x, 0f), size = Size(w, size.height))
            } else Modifier)
            .padding(if (small) PaddingValues(horizontal = 16.dp, vertical = 8.dp) else PaddingValues(14.dp))
            .graphicsLayer { alpha = if (enabled) 1f else 0.6f },
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

@Composable
fun BtnMain(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, small: Boolean = false, colors: List<Color>? = null) {
    BtnMain(onClick, modifier, enabled, small, colors = colors) {
        FText(text, size = if (small) rem(0.8) else rem(1.0), weight = FontWeight.Bold, color = if (enabled) Color.White else Color(0xFF94A3B8), align = TextAlign.Center)
    }
}

// ============================================================ inputs
/** .input-box — 14x16 padding, 2px border (primary on focus), bg-input, radius 12, 0.95rem, focus ring 4px primary-light. */
@Composable
fun InputBox(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    keyboardType: KeyboardType = KeyboardType.Text,
    password: Boolean = false,
    singleLine: Boolean = true,
    enabled: Boolean = true,
    maxLength: Int? = null,
    imeAction: ImeAction = ImeAction.Default,
    onDone: (() -> Unit)? = null,
    textAlign: TextAlign = TextAlign.Start,
    minLines: Int = 1,
    fontSize: TextUnit = rem(0.95),
    weight: FontWeight = FontWeight.Normal,
    invalid: Boolean = false,
    leading: (@Composable () -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    accent: Color? = null,                 // overrides the border colour (+ soft ring): `.valid` green, `.invalid` amber
    mono: Boolean = false,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    capitalize: Boolean = false,
    ring: Boolean = true,                  // accent border also draws the soft 4px ring (false = border colour only)
    restBg: Color? = null,                 // background while NOT focused (default: bg-input)
    restBorder: Color? = null,             // border colour while NOT focused (default: none)
) {
    val c = FF.c
    val src = remember { MutableInteractionSource() }
    val focused by src.collectIsFocusedAsState()
    val shape = RoundedCornerShape(12.dp)
    val bg = if (invalid) (if (c.isDark) Color(0xFF3F1D24) else Color(0xFFFEF2F2)) else if (focused) (if (c.isDark) c.bgCard else Color.White) else (restBg ?: c.bgInput)
    val textStyle = TextStyle(color = c.textMain, fontSize = fontSize, fontFamily = if (mono) FontFamily.Monospace else Inter, fontWeight = weight, textAlign = textAlign, letterSpacing = letterSpacing)
    Box(
        modifier
            .drawBehind {
                if (focused || (accent != null && ring)) {
                    val r = 4.dp.toPx()
                    drawRoundRect(if (accent != null && accent != Color.Unspecified) accent.copy(alpha = 0.15f) else c.primaryLight, topLeft = Offset(-r / 2, -r / 2), size = Size(size.width + r, size.height + r), cornerRadius = CornerRadius(12.dp.toPx() + r / 2), style = androidx.compose.ui.graphics.drawscope.Stroke(r))
                }
            }
            .clip(shape)
            .background(bg)
            .border(2.dp, if (accent != null) accent else if (invalid) c.danger else if (focused) c.primary else (restBorder ?: Color.Transparent), shape)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (leading != null) { leading(); Spacer(Modifier.width(10.dp)) }
            Box(Modifier.weight(1f)) {
                if (value.isEmpty() && placeholder.isNotEmpty()) {
                    FText(placeholder, size = fontSize, weight = weight, color = c.textMuted.copy(alpha = 0.75f), modifier = Modifier.fillMaxWidth(), align = textAlign, maxLines = 1)
                }
                BasicTextField(
                    value = value,
                    onValueChange = { v -> if (maxLength == null || v.length <= maxLength) onValueChange(v) },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = enabled,
                    singleLine = singleLine,
                    minLines = minLines,
                    textStyle = textStyle,
                    cursorBrush = SolidColor(c.primary),
                    visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
                    keyboardOptions = KeyboardOptions(capitalization = if (capitalize) androidx.compose.ui.text.input.KeyboardCapitalization.Characters else androidx.compose.ui.text.input.KeyboardCapitalization.None, keyboardType = if (password) KeyboardType.Password else keyboardType, imeAction = imeAction),
                    keyboardActions = KeyboardActions(onDone = { onDone?.invoke() }, onGo = { onDone?.invoke() }, onSend = { onDone?.invoke() }, onSearch = { onDone?.invoke() }),
                    interactionSource = src,
                )
            }
            if (trailing != null) { Spacer(Modifier.width(10.dp)); trailing() }
        }
    }
}

