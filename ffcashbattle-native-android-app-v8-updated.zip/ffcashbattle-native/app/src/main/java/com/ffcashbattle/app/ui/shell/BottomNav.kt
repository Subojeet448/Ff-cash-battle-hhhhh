package com.ffcashbattle.app.ui.shell

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.ffcashbattle.app.R
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.state.Page
import com.ffcashbattle.app.ui.comp.FText
import com.ffcashbattle.app.ui.comp.FaIcon
import com.ffcashbattle.app.ui.comp.boxShadow
import com.ffcashbattle.app.ui.comp.press
import com.ffcashbattle.app.ui.theme.FF
import com.ffcashbattle.app.ui.theme.rem

private class NavDef(val page: Page, val icon: String, val label: String, val needsLogin: Boolean, val png: Int? = null)

private val NAV = listOf(
    NavDef(Page.HOME, "fa-solid fa-house", "Home", false),
    NavDef(Page.MATCHES, "fa-solid fa-gamepad", "Matches", true),
    NavDef(Page.CHAT, "fa-solid fa-comments", "Chat", true, png = R.drawable.nav_chat),
    NavDef(Page.RANK, "fa-solid fa-trophy", "Rank", false),
    NavDef(Page.WALLET, "fa-solid fa-wallet", "Wallet", true),
)

/**
 * `.nav-bar` — 65dp (+ nav bar inset), radius 22 on top, bg-card @88%, shadow 0 -8 28 rgba(15,23,42,.08);
 * five equal items (icon 1.3rem + label .75rem), a 28x3 gradient indicator above the active one, red dot on Chat.
 */
@Composable
fun BottomNav(modifier: Modifier = Modifier) {
    val c = FF.c
    val shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
    Column(
        modifier
            .fillMaxWidth()
            .boxShadow(28.dp, Color(0x140F172A), shape)
            .clip(shape)
            .background(c.bgCard.copy(alpha = 0.96f))
            .windowInsetsPadding(WindowInsets.navigationBars),
    ) {
        Row(Modifier.fillMaxWidth().height(ShellDims.navBase), verticalAlignment = Alignment.CenterVertically) {
            for (d in NAV) NavItem(d, active = AppStore.page == d.page, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun NavItem(d: NavDef, active: Boolean, modifier: Modifier) {
    val c = FF.c
    val tint by animateColor(if (active) c.primary else c.textMuted)
    val lift by animateDpAsState(if (active) (-2).dp else 0.dp, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "lift")
    val bar by animateFloatAsState(if (active) 1f else 0f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow), label = "bar")

    Box(
        modifier.fillMaxHeight().press(0.9f) {
            if (AppStore.page == d.page) return@press
            if (d.needsLogin) AppStore.checkLogin { AppStore.goto(d.page) } else AppStore.goto(d.page)
        },
        contentAlignment = Alignment.Center,
    ) {
        // active indicator: 28x3, top:0, radius 0 0 6 6, gradient primary -> #7c3aed
        Box(
            Modifier.align(Alignment.TopCenter).width(28.dp).height(3.dp)
                .graphicsLayer { scaleX = bar }
                .clip(RoundedCornerShape(bottomStart = 6.dp, bottomEnd = 6.dp))
                .background(Brush.horizontalGradient(listOf(c.primary, Color(0xFF7C3AED)))),
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(5.dp)) {
            Box(Modifier.padding(bottom = 2.dp).offset(y = lift)) {
                if (d.png != null) NavPng(d.png, active, attention = d.page == Page.CHAT && AppStore.navChatDot)
                else FaIcon(d.icon, rem(1.3).value.dp, tint)
            }
            FText(d.label, size = rem(0.75), weight = if (active) FontWeight.Bold else FontWeight.Medium, color = tint, maxLines = 1)
        }
        if (d.page == Page.CHAT && AppStore.navChatDot) {
            val inf = rememberInfiniteTransition(label = "navdot")
            val pulse by inf.animateFloat(1f, 1.2f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "p")
            // .nav-dot.plain: 12x12, top 10, left calc(50% + 6), #ef4444, 2dp bg-card border
            Box(Modifier.align(Alignment.TopCenter).offset(x = 6.dp + 6.dp, y = 10.dp).graphicsLayer { scaleX = pulse; scaleY = pulse }
                .size(12.dp).clip(CircleShape).background(Color(0xFFEF4444)).border(2.dp, c.bgCard, CircleShape))
        }
    }
}

/**
 * Chat tab as a coloured PNG (res/drawable-nodpi/nav_chat.png) instead of the one-colour font icon. Not selected = grey and a bit
 * transparent (like the other tabs); selected = full colour with a springy pop. While there is something unread (red dot) it wiggles
 * every second so the tab gets noticed. Website twin: `.nav-png` in components/nav-bar/nav-bar.css.
 */
@Composable
private fun NavPng(res: Int, active: Boolean, attention: Boolean) {
    val on by animateFloatAsState(if (active) 1f else 0f, tween(250), label = "navPngOn")
    val pop by animateFloatAsState(if (active) 1.14f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "navPngPop")
    val inf = rememberInfiniteTransition(label = "navPng")
    val wig by inf.animateFloat(-1f, 1f, infiniteRepeatable(tween(300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "navPngWig")
    val gap by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "navPngGap")
    val matrix = ColorMatrix().apply { setToSaturation(0.05f + 0.95f * on) }
    Image(
        painterResource(res), null,
        Modifier.size(27.dp).graphicsLayer {
            alpha = 0.62f + 0.38f * on
            scaleX = pop; scaleY = pop
            // wiggle only for the first 0.6 s of every 2.6 s, so it is a nudge and not a nuisance
            rotationZ = if (attention && !active && gap < 0.23f) wig * 9f else 0f
        },
        contentScale = ContentScale.Fit,
        colorFilter = ColorFilter.colorMatrix(matrix),
    )
}

@Composable
private fun animateColor(target: Color) = androidx.compose.animation.animateColorAsState(target, tween(250), label = "navTint")
