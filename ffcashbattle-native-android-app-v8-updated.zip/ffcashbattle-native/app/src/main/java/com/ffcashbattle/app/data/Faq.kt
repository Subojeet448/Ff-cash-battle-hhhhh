package com.ffcashbattle.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.ffcashbattle.app.state.AppStore
import com.ffcashbattle.app.state.Page

/**
 * Port of components/faq/faq.js — FAQ topics. Answers use `[bold]` markup (rendered by FRich).
 *   Faq.open("wallet")                 opens the FAQ sheet for a page / popup
 *   Faq.register("refer") { [[q, a]] } adds / replaces a topic (used by Refer & Earn: its text depends on the server config)
 */
object Faq {
    private class Topic(val title: String, val items: List<Pair<String, String>>)

    private val T = mapOf(
        "home" to Topic(
            "Matches & joining",
            listOf(
                "How do I join a match?" to "Open a match card and tap [JOIN NOW], pick your slot and confirm. The entry fee is taken from your wallet.",
                "Where do I get the Room ID & Password?" to "After you join, the Room ID & Password appear in [My Matches] shortly before the match starts. You also get a notification.",
                "Why does a match say FULL or MATCH STARTED?" to "FULL means all slots are taken. When a match has started or is locked, new players cannot join — pick the next match.",
                "Where can I see finished matches?" to "On Home switch the toggle to [Completed] to see the latest results. Your own results are in [My Matches → History].",
            ),
        ),
        "matches" to Topic(
            "My Matches",
            listOf(
                "Where is my Room ID?" to "Your joined matches are listed here. Room ID & Password show on the card once the admin adds them — tap to copy.",
                "When do I get my prize?" to "When the match is completed the prize is added to your wallet automatically and shows in [History] and Wallet history.",
                "Can I leave a match after joining?" to "Please check the match rules on the card. If you cannot play, contact support from the menu before the match starts.",
            ),
        ),
        "leaderboard" to Topic(
            "Leaderboard",
            listOf(
                "How is the rank decided?" to "Players are ranked by their match winnings for the selected period — [Daily], [Weekly] or [Monthly].",
                "Are there rewards?" to "When the admin turns on leaderboard rewards, the top players of the month get a bonus in their withdrawable balance.",
            ),
        ),
        "wallet" to Topic(
            "Wallet",
            listOf(
                "What is Deposit balance vs Withdraw balance?" to "[Deposit balance] is money you add — use it to join matches and games. [Withdraw balance] holds your winnings and can be withdrawn.",
                "How do I add money?" to "Tap [Add Money], pay using the shown UPI / QR and submit the payment reference (UTR). The balance is added after it is verified.",
                "My deposit is not showing" to "Open [History] to see its status. If it is still pending, wait a little; if it stays pending contact support with your UTR.",
                "How do I withdraw?" to "Tap [Withdraw], choose a method and enter the amount. Only the Withdraw balance can be withdrawn.",
            ),
        ),
        "deposit" to Topic(
            "Add Money",
            listOf(
                "How does a deposit work?" to "Pay to the shown UPI ID / QR from any app, then enter the UTR / reference number and submit.",
                "When is it credited?" to "After the payment is verified. You will see a notification and the entry in Wallet history.",
                "I paid but nothing came" to "Check Wallet history for the status first. Keep your payment screenshot and UTR ready and contact support from the menu.",
            ),
        ),
        "withdraw" to Topic(
            "Withdraw",
            listOf(
                "Which balance can I withdraw?" to "Only your [Withdraw balance] (match winnings and similar rewards). Deposit balance is for playing.",
                "How long does it take?" to "Requests are processed by the team and the status updates in Wallet history. You get a notification when it is paid.",
                "Why was my request rejected?" to "Usually wrong payment details or a rule issue. The reason is shown in the notification / history — fix it and try again.",
            ),
        ),
        "transfer" to Topic(
            "Transfer",
            listOf(
                "What does Transfer do?" to "It moves balance using your available [Deposit balance]. Check the amount shown as Available before you confirm.",
                "Can I undo a transfer?" to "No — please double-check the details before you confirm.",
            ),
        ),
        "join" to Topic(
            "Joining a match",
            listOf(
                "What happens when I tap Pay & Join?" to "The entry fee is deducted from your wallet and your slot is reserved. You can see the match in [My Matches].",
                "Why can I not join?" to "The match may be full, already started, or you may not have enough balance. Add money and try again.",
                "Do I need my Free Fire UID?" to "Yes — make sure your game name & UID in your profile are correct so the prize reaches the right player.",
            ),
        ),
        "games" to Topic(
            "Games",
            listOf(
                "How do Coin Battle, Bomb & Gems and Fruit Slash work?" to "Pick an entry amount, get matched with another player and play (Fruit Slash is a live 1v1 fruit-cutting duel, and it also has a free endless mode with no prize). The winner gets the prize after the platform cut. Draws are refunded where the game says so.",
                "Is there a free practice mode?" to "Yes — free practice matches are available every day (the number is shown inside the game).",
                "What are BOT players?" to "If no real player is found for a free practice game, a BOT may join. Bots are always labelled [BOT].",
                "A game is missing" to "The admin can switch a game off for a while. It comes back here automatically when it is switched on.",
            ),
        ),
    )

    private val dyn = HashMap<String, () -> List<Pair<String, String>>>()

    /** The topic whose sheet is open (null = closed). */
    var current by mutableStateOf<String?>(null)

    fun register(key: String, fn: () -> List<Pair<String, String>>) { dyn[key] = fn }

    fun items(key: String): List<Pair<String, String>> {
        dyn[key]?.let { try { return it() } catch (_: Exception) { } }
        return T[key]?.items ?: emptyList()
    }

    fun title(key: String): String = if (key == "refer") "Refer & Earn" else T[key]?.title ?: "FAQ"

    /** The topic of the page that is on screen. */
    fun pageKey(): String = when (AppStore.page) {
        Page.HOME -> "home"
        Page.MATCHES -> "matches"
        Page.RANK -> "leaderboard"
        Page.WALLET -> "wallet"
        else -> ""
    }

    fun open(key: String = "") { current = key.ifEmpty { pageKey().ifEmpty { "home" } } }
    fun close() { current = null }
}
