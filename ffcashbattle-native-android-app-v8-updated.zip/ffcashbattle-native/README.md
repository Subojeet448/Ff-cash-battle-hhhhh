# FF Cash Battle — native Android app (Kotlin + Jetpack Compose)

The whole website UI (tournament-ff-cash-battle) rebuilt as a **real native Android app**. No Capacitor, no website wrapper:
every screen, sheet, card and animation is Kotlin / Jetpack Compose. Same Firebase project as the website
(`tournament-e8da7`), so accounts, wallet, matches, notifications and chat are shared with ffcashbattle.in.

* package `com.ffcashbattle.app`, applicationId `in.ffcashbattle.app`
* Kotlin 2.1.20 · Compose BOM 2025.05.01 · AGP 8.9.2 · Gradle 8.14.3 · compileSdk/targetSdk 35 · minSdk 24 · JDK 17

## Build
1. Install Android Studio (Ladybug or newer, JDK 17). **File → Open** this folder, let Gradle sync.
2. Run on a phone/emulator (`app` configuration), or **Build → Generate Signed App Bundle / APK** for release.

### Settings to check before release
| What | Where | Note |
|---|---|---|
| Firebase Android app | `app/google-services.json` (already added: project `tournament-e8da7`, package `in.ffcashbattle.app`; Gradle plugin `com.google.gms.google-services` 4.6.0, Firebase BoM 35.2.0) | **Add your SHA-1 and SHA-256** in Firebase console -> Project settings -> Your apps -> `in.ffcashbattle.app` (debug key: `./gradlew signingReport`; Play release key: Play Console -> App signing), otherwise Google sign-in fails (error 10 / DEVELOPER_ERROR) and the Android API key may be refused. Download `google-services.json` again afterwards and replace the file. Debug and release use the same package (`in.ffcashbattle.app`) because the json only knows that one. |
| Google sign-in | `app/build.gradle.kts` -> `GOOGLE_WEB_CLIENT_ID` | Already set to the Web client ID from `google-services.json` (`461449506021-knqkgpc9gfgt0dcm904l1d1i3ch6n1lo.apps.googleusercontent.com`). Authentication -> Sign-in method -> Google must be enabled in Firebase. |
| Site / proof link | `SITE_URL` in `app/build.gradle.kts`, `data/Cfg.kt` | `https://ffcashbattle.in` (Proof = `/proof`, Terms = `/terms`). |
| Game server | `data/Cfg.kt` → `GAME_SERVER`, `GAME_API` | Same Render admin panel the website uses. |
| Separate chat project | `data/Cfg.kt` → `CHAT_TOKEN_URL` | Empty = chat runs in the main project (exactly like the website today). |
| Reset-password links | Firebase console → Authentication → Templates → action URL = `https://ffcashbattle.in/...` | The app opens `ffcashbattle.in` links itself (intent filter in the manifest). |

## Website → app map
| Website | App |
|---|---|
| Header, drawer, bottom nav, FAQ chips | `ui/shell/*`, `ui/screens/FaqLayer.kt` |
| Home, Matches (+ my matches), Rank, Wallet | `ui/screens/*Page.kt`, `ui/screens/match/*`, `ui/screens/wallet/*` |
| Join, Roster, Deposit, Withdraw (+success), Transfer, Gift, Refer + scratch card | `ui/modals/*` |
| Settings (Security & Payment, **Proofs → ffcashbattle.in/proof**, Terms, **website link**), Sound, Notice, Rules, Edit profile, Logout | `ui/modals/*` |
| Notification bell, message cards, balance cards, wallet FX (same sizes) | `ui/modals/NotificationsModal.kt`, `ui/comp/Notify.kt`, `state/AppStore.kt` |
| Login / sign-up / OTP / forgot password, welcome, ban screen, session overlay | `ui/screens/Auth*.kt`, `ForgotLayer.kt`, `WelcomeHost.kt`, `BanOverlay.kt` |
| **Chat** (World chat, friends, requests, DMs, groups, replies, edit/delete, verified moderation, saved messages + backup/restore, alerts) | `data/Chat*.kt`, `ui/screens/Chat*.kt`, `ui/screens/chat/*` |
| **Games** (Coin Battle, Bomb & Gems — in Chat → Game tab) | `data/Games.kt`, `ui/screens/GameOverlay.kt`, `assets/site/*` |

## How the games work
The server (admin panel on Render) runs all rules and money, as on the website. The two game screens are the website's
own game pages bundled in `app/src/main/assets/site/pages/game/` and shown in a **native full-screen host**
(`GameOverlay.kt`). `assets/site/js/bridge.js` ↔ `GameNative` (Kotlin) give the pages: Firebase login token + server calls
(done natively), wallet balance, live game updates (native Firestore listener), confirm dialog, deposit, close, sounds.
Hardware Back closes the lobby or asks "Leave the match?".

## Updated with website v8 (this round)
| What | Where | How it works |
|---|---|---|
| **Proof page: Like / Comment / Share work when you are logged in** | `data/WebAuth.kt`, `ui/shell/WebOverlay.kt` | The proof page is the website inside a WebView, which has its own storage and never knew the app login. Before the page starts, the app writes the current Firebase user (same format the Firebase JS SDK saves) into the WebView, so the page opens already signed in as the same user. Only `ffcashbattle.in` gets it; logged out = the saved user is removed. The token is valid ~1 hour (open the page again after that). |
| **Wallet History = Today / Week / Month** | `ui/modals/WalletHistoryModal.kt`, `state/AppStore.kt` | Deposits and withdrawals of the last **30 days**, with 3 range buttons at the top (Today / Week / Month), count + total for the chosen range. |
| **Chat ticks** | `ui/screens/chat/ChatTicks.kt`, `data/Chat.kt` | Friend chat: spinner while not on the server, 1 tick = sent, 2 ticks = delivered (friend online), **green** 2 ticks = seen. World chat: 1 tick = sent, 2 green ticks once somebody else opened World / posted after it. Group chat: 1 tick. Same rules as the website (`pages/chat/chat-ui.js`). |
| **Banner no longer stops half-way** | `ui/screens/HomePage.kt` | Auto-slide used to be cancelled in the middle of a swipe; now it waits until the pager has settled and snaps back to the nearest slide if it ever stops between two. |
| **Booyah Lounge emblem (new PNG + animation)** | `res/drawable-nodpi/booyah_lounge.png`, `ui/screens/chat/ChatParts.kt` (`BooyahPng`, `WorldIcon`) | New artwork: purple chat bubble with a flame, sparkles and a BOOYAH! LOUNGE plate. Used on the Chat page hero, the World-room card, the chat overlay and the room header/avatar (a custom emoji set by the admin still wins). Hero / card / overlay are animated: a purple glow that breathes + a slight swell, and a white shine that runs across the picture every ~4 s (only on the picture's own pixels). List avatars stay still. |
| **Chat tab = PNG icon** | `res/drawable-nodpi/nav_chat.png`, `ui/shell/BottomNav.kt` (`NavPng`) | The Chat tab shows a coloured chat-bubble PNG instead of the one-colour font icon: grey + faded when not selected, full colour with a springy pop when selected, and a short wiggle every ~2.6 s while something is unread (red dot). |
| **"(cs)" in a name -> CS badge** | `ui/comp/NameTag.kt`, `res/drawable-nodpi/tag_cs.png` | `FText(..., tags = true)` replaces `(cs)` (any case, any place in the name) with the CS picture and hides an empty `()`. Used for player names, match titles, roster, join, chat names. Website twin: `window.ffTag` in `js/core/verified.js`. |
| **Fruit Slash game (new in the app)** | `assets/site/pages/game/fruit.html`, `fruit/fruit.js`, `fruit/fruits/*.png`, `fruit/sounds/*.mp3`, `data/Games.kt`, `ui/screens/GameOverlay.kt`, `ui/screens/chat/ChatPanes.kt`, `assets/site/js/bridge.js` | The website's live 1v1 fruit duel + free endless mode now runs inside the app like Coin Battle / Bomb & Gems: card in Chat -> Game tab (shown only while the admin switch `config/games.fruit` is on), full-screen host, same native bridge (`window.fruitBridge`: login token, wallet, live opponent score from `fruit_games/{id}`, confirm, deposit, close). The server is the admin panel `/api/fruit/*` (derived from `GAME_API`, like Bomb & Gems). Hardware Back = Quit/Finish while playing, cancel while searching, home on the result screen. |
| **Coin Battle / Bomb & Gems pages refreshed** | `assets/site/pages/game/coin.html`, `bomb.html` | Replaced with the website v8 versions (soft PNG background with parallax + falling coin/gem PNGs); the only changes are the native-bridge script, dark mode from the app, and no website-only emoji script. |
| **Proof page: dark mode, loader, new links** | `data/WebAuth.kt`, `ui/shell/WebOverlay.kt` | The app's light/dark mode is handed to the page too; a spinner shows while the login hand-over runs (< 1 s, max 6 s); a new target opened while the page is showing (e.g. a `?share=` notification) loads properly. |
| **"(cs)" badge in game pages** | `assets/site/js/bridge.js`, `assets/site/assets/img/tags/cs.png` | Names shown by the games (opponent, roster) use the same CS badge. |

**Firestore rules:** the World-chat "seen" tick needs every user to be able to update only their own `cprofiles/{uid}.worldSeenAt` (same rule the website v8 already uses).

## Honest limits
* This project was **written without an Android SDK, so it has not been compiled or run here**. Expect to fix a few small
  compile errors / visual nits on the first Android Studio build (Build → Make Project shows them).
* Push when the app is fully closed (FCM) needs a server that sends the messages. In-app notifications, the bell, the
  system notification while the app is in the background (live listener) and chat alerts work without it.
* Proofs (`ffcashbattle.in/proof`) and Terms open inside the app in a full-screen web view, and the website login is separate.
* Chat alerts when the app is closed also need a server-side push.
* The proof-page login hand-over is a best-effort bridge (Firebase JS SDK storage format); if the website changes its Firebase SDK or its sign-in storage, `data/WebAuth.kt` is the one file to adjust.
